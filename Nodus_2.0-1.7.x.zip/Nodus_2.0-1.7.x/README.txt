Nodus 2.0 RELEASE 2

Y - Click Gui
U - Console
Type “@“ before a message to chat in the IRC 

============

by ConnorM

============
This is just for those of you who want to join any 1.7 server. A really cool new update coming soon!