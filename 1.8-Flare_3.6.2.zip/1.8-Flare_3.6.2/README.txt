Flare 3.6.2 - By Gildfesh, KNOX and Aarow
	Cracked: Aug 23, 2015

IMPORTANT:
	- Delete the the "flare" directory in ".minecraft" if you crash!

Info:
	- Obfuscator: Zelix KlassMaster - http://zelix.com/
	- Website: https://aarow.me/
	
Checksum info (1.8-Flare_3.6.2.jar):
	CRC32: C8D3603B
	CRC64: 5E5A1808395BDCF0
	SHA256: DA23163BE37BBC335CA87E417EE402CC15EB4625067510C549AD9425F25BAFDA
	SHA1: 3E6D86CF8BEAC859A192A33D7BA224D300D66051
	
-------------------------------------------------
People:
	- Lone
	- Ayzhin
	- Phizo
	- Itami
	- N3xuz_DK 

Find us at: http://hentaiandecchi.ayzhin.com/

We have a forum!: http://hentaiandecchi.ayzhin.com/forums/

About us: http://hentaiandecchi.ayzhin.com/about/

-------------------------------------------------

HEY! THIS IS IMPORTANT

| | | | | | | | | | | |
V V V V V V V V V V V V

Prerequisites:
	Software:
		- Java 8
		- Minecraft
		- WinRAR, unrar
		- 7zip, p7zip
		- unzip

FAQ:
	- No we cannot crack a client that we don't have. Thank you for asking.
	- We distribute our releases in "RAR", "7z", "tar.xz", "zip"!
	- If you have a problem be check your Java version first
		You should preferably use Java with version 8 support because it has the best compatibility with modern Java programs
	- GL15 function not supported:
		Your video card is too old, or needs updated drivers. Please use a modern video card with OpenGL 2.1 or higher.
	- Client does not show up in "Use Version"
		1) Check if the archive was extracted properly.
		2) Make sure the folder name is the same as in the JSON file.
			- id": "some client"
	- Client crashes and/or doesn't start.
		Please post or PM the ENTIRE crash log!
	- Client closes without crash log.
		Contact lonephenom.
	- All published cracks (usually) have had all authentication and IRC connections removed.
		Note: Harmless connections are still active.
		Also if we are lazy the bytecode for these connections are still in there for you to inspect.
	- Sometimes the cracker misses a kill switch or a check.
		If this is the case report this on the thread and contact lonephenom.
	- Why don't you release cracks more frequently?
		1) If nobody has given us the program so we can't crack it.
		2) We don't have time at the moment.
		3) A new form of obfuscation makes it difficult to crack the code.
		4) We are busy watching Chinese cartoons.
		5) Noooo body gives a shit
		6) We have vulnerable white girls to exploit.
		7) Long live the queen! (RIP)
		8) ALLAHU AKBAR!
		9) Too high on the SUGOI scale
		10) wingdings right up in that bitch
		11) ayy lmao
		12) "I'm on a mission"
		13) "I fucking hate her when she doesn't fucking tell me what's wrong fuck fuck fuck n3xuz help me with my waifu problems."

How to install:

	Windows:
	- Hold down "Windows" key and press "R"
	- Type %appdata%\.minecraft\versions

	OSX:
	- Go to ~/Library/Application Support/minecraft/versions

	Linux:
	- Go to ~/.minecraft/versions
	
	How to extract:
	- Extract archive into a folder
		- The versions folder should look like so:
			/client/client.jar
			/client/client.json
		
	How to switch profiles:
		- Open Minecraft Launcher
		- Press "Edit Profile" in the bottom left
		- Select "Use Version" and find the client name
		- Press "Save Profile" and press "Play"
		
	If the profile doesn't show up check the JSON file for the "name" tag and correct it if necessary.