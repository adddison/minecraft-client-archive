package bleach.hack.module.mods;

import bleach.hack.module.Category;
import bleach.hack.module.Module;

public class ToggleMSGs extends Module{

    public ToggleMSGs()
    {
        super("ToggleMSGs", KEY_UNBOUND, Category.MISC, "Messages in chat when you turn on/off a module");
    }
}
