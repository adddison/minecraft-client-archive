package bleach.hack.module.mods;

import bleach.hack.module.Category;
import bleach.hack.module.Module;

public class SafeWalk extends Module {

    public SafeWalk() {
        super("SafeWalk", KEY_UNBOUND, Category.MOVEMENT, "Stops you walking off blocks");
    }
}
