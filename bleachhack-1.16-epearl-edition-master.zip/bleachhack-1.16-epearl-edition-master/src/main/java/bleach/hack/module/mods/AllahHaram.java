package bleach.hack.module.mods;

import bleach.hack.module.Category;
import bleach.hack.module.Module;

public class AllahHaram extends Module {

	public AllahHaram() {
		super("AllahHaram", KEY_UNBOUND, Category.RENDER, "ﮗﮃﭹﭫﭗﭿﭬﭸﮔﭤﮙﭮﮉﭝﭸﮕﭡﭶﭪﭼﭟﮇﭜﮋﮐﮒﭯﮚﭯﮜﮇﭭﮔﮐﮠﭦﮟﮑﭤﮅﮍﮖﭵﭘﭓﮟﮍﭦﭟﭰﭪﮎﮅﭛﮍﮒ");
	}

}
