# BleachHack 1.16.2 epearl edition
![](https://img.shields.io/github/last-commit/22s/bleachhack-1.16-epearl-edition.svg)
![](https://img.shields.io/github/languages/code-size/22s/bleachhack-1.16-epearl-edition.svg)

Very cool client and now reskinned by epearl using spaghetti code.  

Works on fabric 1.16.2  

> Join Bleach's Discord Cuz He Made The Client Im Skidding: https://discord.gg/b5Wc4nQ

## Installation:
**For normal people:**

Download [fabric for minecraft 1.16.2](https://fabricmc.net/use/)  
Download the lastest compiled version of bleachhack for your Minecraft version [from the Actions section](https://github.com/22s/bleachhack-1.16-epearl-edition/actions)  
Extract the zip and put the jar into your mods folder  

## Images

![GUI](https://media.discordapp.net/attachments/745366273168244906/745372657423351808/unknown.png)  
![GUI2](https://media.discordapp.net/attachments/745366273168244906/745372674464809563/unknown.png)  
