▬▬▬▬▬▬▬▬▬▬▬▬★How to install★▬▬▬▬▬▬▬▬▬▬▬▬
#1: Go to your start menu, click on run and type %appdata%
#2: Navigate to the folder called ".minecraft"
#3: Inside the ".minecraft" folder, navigate to a folder called "versions"
#4: Drag and drop the folder called "Remix" into "versions"
#5: Run the Minecraft launcher and create a new profile
#6: Save it and click on "Play"

