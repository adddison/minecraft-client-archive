package me.memeszz.aurora.module.modules.misc;

import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.setting.Setting;

import java.text.DecimalFormat;

public class ClinetTimer extends Module {
    public ClinetTimer() {
        super("Timer", Category.MISC, "Clinet's TimerSwitch");
        speedUsual = this.registerD("Speed", 4.2, 1, 10);
        fastUsual = this.registerD("FastSpeed", 10, 1, 1000);
        tickToFast = this.registerD("TickToFast", 4, 0, 20);
        tickToNoFast = this.registerD("TickToDisableFast", 7, 0, 20);
    }

    int tickWait = 0;
    float hudInfo = 0;
    Setting.d speedUsual;
    Setting.d fastUsual;
    Setting.d tickToFast;
    Setting.d tickToNoFast;



    public void onDisable() {
        mc.timer.tickLength = 50.0F;
    }

    public void onUpdate() {
        if ((float)tickWait == (float)tickToFast.getValue()) {
            mc.timer.tickLength = 50.0F / (float)fastUsual.getValue();
            hudInfo = (float)fastUsual.getValue();
        }

        if ((float)this.tickWait >= (float)tickToNoFast.getValue()) {
            this.tickWait = 0;
            mc.timer.tickLength = 50.0F / (float)speedUsual.getValue();
            hudInfo = (float)speedUsual.getValue();
        }

        ++this.tickWait;
    }

    public String getHudInfo(){
        return new DecimalFormat("0.##").format(hudInfo);
    }


}
