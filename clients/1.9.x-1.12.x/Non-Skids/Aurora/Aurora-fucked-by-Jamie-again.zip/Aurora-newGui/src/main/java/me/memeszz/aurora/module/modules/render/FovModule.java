package me.memeszz.aurora.module.modules.render;

import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.setting.Setting;

public class FovModule extends Module {
    public FovModule() {
        super("FOV", Category.RENDER, "Changes your fov");
        fov = this.registerI("Value",  90, 0, 180);
        setDrawn(false);
    }

    Setting.i fov;

    public void onUpdate(){
        mc.gameSettings.fovSetting = (float)fov.getValue();
    }
}
