package me.memeszz.aurora.event.events;

import me.memeszz.aurora.event.AuroraEvent;
import net.minecraft.util.math.BlockPos;

public class DestroyBlockEvent extends AuroraEvent {
    BlockPos pos;
    public DestroyBlockEvent(BlockPos blockPos){
        super();
        pos = blockPos;
    }

    public BlockPos getBlockPos(){
        return pos;
    }
}
