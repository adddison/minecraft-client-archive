package me.memeszz.aurora.module.modules.gui;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.memeszz.aurora.Aurora;
import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.module.ModuleManager;
import me.memeszz.aurora.setting.Setting;
import me.memeszz.aurora.util.FontUtils;
import me.memeszz.aurora.util.Rainbow;

import java.awt.*;
import java.util.Comparator;

public class ModList extends Module {
    public ModList() {
        super("Arraylist", Category.GUI, "Attacks nearby players");
    }
    private Setting.b sortUp;
    private Setting.b right;
    private Setting.b customFont;
    private Setting.b rainbow;
    Setting.i x;
    Setting.i y;
    Setting.i red;
    Setting.i green;
    Setting.i blue;
    Setting.i espA;
    int modCount;
    int sort;

    Color c;
    public void setup() {
        customFont = this.registerB("CustomFont", false);
        sortUp = this.registerB("SortUp", true);
        right = this.registerB("RightSide", true);
        x = this.registerI("X",  255, 0, 960);
        y = this.registerI("Y",  255, 0, 530);
        red = this.registerI("Red",  255, 0, 255);
        green = this.registerI("Green",  255, 0, 255);
        blue = this.registerI("Blue",  255, 0, 255);
        rainbow = this.registerB("Rainbow", false);


    }

    public void onRender(){
        if(rainbow.getValue())
            c = Rainbow.getColor();
        else
            c = new Color((int)red.getValue(), (int)green.getValue(), (int)blue.getValue());

        if(sortUp.getValue()){ sort = -1;
        } else { sort = 1; }
        modCount = 0;
        ModuleManager.getModules()
                .stream()
                .filter(Module::isEnabled)
                .filter(Module::isDrawn)
                .sorted(Comparator.comparing(module -> FontUtils.getStringWidth(customFont.getValue(), module.getName() + ChatFormatting.GRAY + " " + module.getHudInfo()) * (-1)))
                .forEach(m -> {
                    if(sortUp.getValue()) {
                        if (right.getValue()) {
                            drawStringWithShadow(m.getName() + ChatFormatting.GRAY + " " + m.getHudInfo(), (int) x.getValue() - FontUtils.getStringWidth(customFont.getValue(), m.getName() + ChatFormatting.GRAY + " " + m.getHudInfo()), (int) y.getValue() + (modCount * 10), c.getRGB());
                        } else {
                            drawStringWithShadow(m.getName() + ChatFormatting.GRAY + " " + m.getHudInfo(), (int) x.getValue(), (int) y.getValue() + (modCount * 10), c.getRGB());
                        }
                        modCount++;
                    } else {
                        if (right.getValue()) {
                            drawStringWithShadow(m.getName() + ChatFormatting.GRAY + " " + m.getHudInfo(), (int) x.getValue() - FontUtils.getStringWidth(customFont.getValue(),m.getName() + ChatFormatting.GRAY + " " + m.getHudInfo()), (int) y.getValue() + (modCount * -10), c.getRGB());
                        } else {
                            drawStringWithShadow(m.getName() + ChatFormatting.GRAY + " " + m.getHudInfo(), (int) x.getValue(), (int) y.getValue() + (modCount * -10), c.getRGB());
                        }
                        modCount++;
                    }
                });
    }

    private void drawStringWithShadow(String text, int x, int y, int color){
        if(customFont.getValue())
            Aurora.fontRenderer.drawStringWithShadow(text, x, y, color);
        else
            mc.fontRenderer.drawStringWithShadow(text, x, y, color);
    }
}