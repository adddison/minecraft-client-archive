package me.memeszz.aurora.event.events;

import me.memeszz.aurora.event.AuroraEvent;

public class PlayerJumpEvent extends AuroraEvent {
    public PlayerJumpEvent(){
        super();
    }
}
