package me.memeszz.aurora.module.modules.render;

import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.passive.*;
import net.minecraft.entity.player.EntityPlayer;

import java.util.List;
import java.util.stream.Collectors;

public class GlowESP extends Module {
    public GlowESP() {
        super("GlowESP", Category.RENDER, "Gives entities the glowing effect");
    }

    Setting.b players;
    Setting.b passive;
    Setting.b monsters;
    Setting.b items;
    Setting.b xpBottles;
    Setting.b crystals;

    List<Entity> entities;

    public void setup(){
        players = this.registerB("Players", true);
        passive = this.registerB("Passive", false);
        monsters = this.registerB("Monsters", false);
        items = this.registerB("Items", false);
        crystals = this.registerB("Crystals", false);
        xpBottles = this.registerB("XpBottles", false);
    }

    public void onUpdate(){
        entities = mc.world.loadedEntityList.stream()
                .filter(e -> e != mc.player)
                .collect(Collectors.toList());
        entities.forEach(e -> {
            if(e instanceof EntityPlayer && players.getValue())
                e.setGlowing(true);

            if(isPassive(e) && passive.getValue())
                e.setGlowing(true);

            if(e instanceof EntityExpBottle && xpBottles.getValue())
                e.setGlowing(true);

            if(isMonster(e) && monsters.getValue())
                e.setGlowing(true);

            if(e instanceof EntityItem && items.getValue())
                e.setGlowing(true);

            if(e instanceof EntityEnderCrystal && crystals.getValue())
                e.setGlowing(true);
        });
    }

    public void onDisable(){
        entities.forEach(p -> p.setGlowing(false));
    }

    public static boolean isPassive(Entity e) {
        if (e instanceof EntityWolf && ((EntityWolf) e).isAngry()) return false;
        if (e instanceof EntityAnimal || e instanceof EntityAgeable || e instanceof EntityTameable || e instanceof EntityAmbientCreature || e instanceof EntitySquid)
            return true;
        if (e instanceof EntityIronGolem && ((EntityIronGolem) e).getRevengeTarget() == null) return true;
        return false;
    }

    public static boolean isMonster(Entity entity) {
        return entity.isCreatureType(EnumCreatureType.MONSTER, false);
    }

}
