package me.memeszz.aurora.event.events;

import me.memeszz.aurora.event.AuroraEvent;

public class PlayerJoinEvent extends AuroraEvent {
    private final String name;

    public PlayerJoinEvent(String n){
        super();
        name = n;
    }

    public String getName(){
        return name;
    }
}
