

//package me.memeszz.aurora.module.modules.gui;
//
//import com.ibm.icu.text.DecimalFormat;
//import me.memeszz.aurora.Aurora;
//import me.memeszz.aurora.module.Module;
//import me.memeszz.aurora.setting.Setting;
//import me.memeszz.aurora.util.Rainbow;
//import me.memeszz.aurora.util.TpsUtils;
//import me.memeszz.aurora.util.Wrapper;
//import net.minecraft.client.resources.I18n;
//
//import java.awt.*;
//
//import static me.memeszz.aurora.Aurora.MODNAME;
//import static me.memeszz.aurora.Aurora.MODVER;
//
///**
// * Memeszz
// */
//public class Tps extends Module {
//    public static TpsUtils INSTANCE;
//
//    public Tps() {
//        super("Tps", Category.GUI, "Attacks nearby players");
//    }
//
//    private Setting.b customFont;
//    private Setting.b rainbow;
//    Setting.i x;
//    Setting.i y;
//    Setting.i red;
//    Setting.i green;
//    Setting.i blue;
//    DecimalFormat decimalFormat = new DecimalFormat("##.#");
//
//    public void setup() {
//        customFont = this.registerB("CustomFont", false);
//        x = this.registerI("X", 255, 0, 905);
//        y = this.registerI("Y", 255, 0, 530);
//        red = this.registerI("Red", 255, 0, 255);
//        green = this.registerI("Green", 255, 0, 255);
//        blue = this.registerI("Blue", 255, 0, 255);
//        rainbow = this.registerB("Rainbow", false);
//
//    }
//
//    public void onRender() {
//        Color c = new Color((int) red.getValue(), (int) green.getValue(), (int) blue.getValue());
//        if (!rainbow.getValue())
//            drawStringWithShadow(decimalFormat.format(TpsUtils.getTickRate()) + " \u00A78Tps", (int) x.getValue(), (int) y.getValue(), c.getRGB());
//        else
//            drawStringWithShadow(decimalFormat.format(TpsUtils.getTickRate()) + " \u00A78Tps", (int) x.getValue(), (int) y.getValue(), Rainbow.getInt());
//    }
//
//    public void onEnable() {
//        Aurora.EVENT_BUS.subscribe(this);
//    }
//
//    public void onDisable() {
//        Aurora.EVENT_BUS.unsubscribe(this);
//    }
//
//
//
//
//    private void drawStringWithShadow(String text, int x, int y, int color){
//        if(customFont.getValue())
//            Aurora.fontRenderer.drawStringWithShadow(text, x, y, color);
//        else
//            mc.fontRenderer.drawStringWithShadow(text, x, y, color);
//    }
//}