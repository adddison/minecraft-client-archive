package me.memeszz.aurora.module.modules.movement;

import me.memeszz.aurora.module.Module;

public class HoleTP extends Module {
    public HoleTP() {
        super("HoleTP", Category.COMBAT, "Makes you fall down into holes faster");
    }
//bruh
    public void onUpdate() {
        if (mc.player.onGround)
            --mc.player.motionY;
    }
}
