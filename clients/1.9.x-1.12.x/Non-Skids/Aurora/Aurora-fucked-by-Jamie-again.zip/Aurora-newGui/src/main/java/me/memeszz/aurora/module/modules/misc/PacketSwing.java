package me.memeszz.aurora.module.modules.misc;

import me.memeszz.aurora.module.Module;
import net.minecraft.item.ItemSword;

/**
 * Memeszz
 */
public class PacketSwing extends Module {
    public PacketSwing() {
        super("PacketSwing", Category.COMBAT, "Swings differently should help to hit ppl phasing");
    }

    @Override
    public void onUpdate() {
        if (mc.player.getHeldItemMainhand().getItem() instanceof ItemSword && mc.entityRenderer.itemRenderer.prevEquippedProgressMainHand >= 0.9) {
            mc.entityRenderer.itemRenderer.equippedProgressMainHand = 1.0f;
            mc.entityRenderer.itemRenderer.itemStackMainHand = mc.player.getHeldItemMainhand();
        }
    }
}
