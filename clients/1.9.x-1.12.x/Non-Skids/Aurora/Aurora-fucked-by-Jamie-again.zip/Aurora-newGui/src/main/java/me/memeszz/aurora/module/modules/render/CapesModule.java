package me.memeszz.aurora.module.modules.render;

import me.memeszz.aurora.module.Module;

public class CapesModule extends Module {
    public CapesModule() {
        super("Capes", Category.RENDER);
        setEnabled(true);
        setDrawn(false);
    }
}
