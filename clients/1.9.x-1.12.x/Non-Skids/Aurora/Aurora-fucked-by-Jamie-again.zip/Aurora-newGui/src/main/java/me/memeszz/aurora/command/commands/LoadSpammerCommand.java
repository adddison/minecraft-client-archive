package me.memeszz.aurora.command.commands;

import me.memeszz.aurora.Aurora;
import me.memeszz.aurora.command.Command;
import me.memeszz.aurora.module.modules.chat.Spammer;
import me.memeszz.aurora.util.Wrapper;

public class LoadSpammerCommand extends Command {
    @Override
    public String[] getAlias() {
        return new String[]{"loadspammer"};
    }

    @Override
    public String getSyntax() {
        return "loadspammer";
    }

    @Override
    public void onCommand(String command, String[] args) throws Exception {
        Spammer.text.clear();
        Aurora.getInstance().configUtils.loadSpammer();
        Wrapper.sendClientMessage("Loaded Spammer File");
    }
}
