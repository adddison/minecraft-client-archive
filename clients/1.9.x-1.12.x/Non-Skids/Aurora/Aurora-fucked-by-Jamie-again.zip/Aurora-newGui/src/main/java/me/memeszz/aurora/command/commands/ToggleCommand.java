package me.memeszz.aurora.command.commands;

import com.google.common.base.Strings;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.memeszz.aurora.command.Command;
import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.module.ModuleManager;
import me.memeszz.aurora.util.Wrapper;

public class ToggleCommand extends Command {
    @Override
    public String[] getAlias() {
        return new String[]{"toggle", "t"};
    }

        @Override
        public String getSyntax() {
        return "toggle <Module>";
    }

        @Override
        public void onCommand(final String command, final String[] args) throws Exception {
        if (args.length < 1 || Strings.isNullOrEmpty(args[0])) {
            Wrapper.sendErrorMessage(this.getSyntax());
            return;
        }
        final Module module = Wrapper.mod.moduleManager.getModuleByName(args[0]);
        if (module == null) {
            Wrapper.sendErrorMessage("Unknown Module: " + args[0]);
            return;
        }
        module.toggle();
        if (!Wrapper.mod.moduleManager.isModuleEnabled("ToggleMessages")) {
            Wrapper.sendClientMessage(module.isEnabled() ? (module.getName() + ChatFormatting.GREEN + " enabled") : (module.getName() + ChatFormatting.RED + " disabled"));
        }
    }
    }

