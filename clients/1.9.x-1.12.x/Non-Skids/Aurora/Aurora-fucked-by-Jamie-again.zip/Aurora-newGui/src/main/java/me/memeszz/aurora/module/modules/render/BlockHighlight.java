package me.memeszz.aurora.module.modules.render;

import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.event.events.RenderEvent;
import me.memeszz.aurora.setting.Setting;
import me.memeszz.aurora.util.AuroraTessellator;
import me.memeszz.aurora.util.GeometryMasks;
import me.memeszz.aurora.util.Tessellator;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public class BlockHighlight extends Module {
    public BlockHighlight() {
        super("BlockHighlight", Category.RENDER, "Highlights the block you're looking at");
    }

    Setting.i r;
    Setting.i g;
    Setting.i b;
    Setting.i a;
    Setting.i w;

    Setting.i a2;



    Setting.b boundingbox;
    Setting.b box;
    Setting.b rainbow;

    public void setup(){
        box = this.registerB("Box", true);
        boundingbox = this.registerB("boundingbox", true);
        r = this.registerI("Red",  255, 0, 255);
        g = this.registerI("Green",  255, 0, 255);
        b = this.registerI("Blue",  255, 0, 255);
        a = this.registerI("BoundingBoxAlpha",  255, 0, 255);
        a2 = this.registerI("Alpha",30, 0, 255);
        w = this.registerI("Width",  1, 1, 10);
        rainbow = this.registerB("Rainbow",  false);
    }

    public void onWorldRender(RenderEvent event) {
        final float[] hue = {(System.currentTimeMillis() % (360 * 32)) / (360f * 32)};
        int rgb = Color.HSBtoRGB(hue[0], 1, 1);
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = rgb & 0xFF;
        final Minecraft mc = Minecraft.getMinecraft();
        final RayTraceResult ray = mc.objectMouseOver;
        if (ray == null) return;
        if (ray.typeOfHit == RayTraceResult.Type.BLOCK) {

            final BlockPos blockpos = ray.getBlockPos();
            final IBlockState iblockstate = mc.world.getBlockState(blockpos);

            if (iblockstate.getMaterial() != Material.AIR && mc.world.getWorldBorder().contains(blockpos)) {
                if (box.getValue()) {
                    Tessellator.prepare(GL11.GL_QUADS);
                    if (rainbow.getValue()) {
                        Tessellator.drawBox(blockpos, r, g, b, a2.getValue(), GeometryMasks.Quad.ALL);
                    } else {
                        Tessellator.drawBox(blockpos, this.r.getValue(), this.g.getValue(), this.b.getValue(), a2.getValue(), GeometryMasks.Quad.ALL);
                    }
                    Tessellator.release();
                }
                if (boundingbox.getValue()) {
                    AuroraTessellator.prepare(GL11.GL_QUADS);
                    if (rainbow.getValue()) {
                        AuroraTessellator.drawBoundingBoxBlockPos(blockpos, w.getValue(), r, g, b, a.getValue());
                    } else {
                        AuroraTessellator.drawBoundingBoxBlockPos(blockpos, w.getValue(), this.r.getValue(), this.g.getValue(), this.b.getValue(), a.getValue());
                    }
                    AuroraTessellator.release();
                }
            }
        }
    }
}