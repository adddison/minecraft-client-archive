package me.memeszz.aurora.module.modules.chat;

import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.Aurora;
import me.memeszz.aurora.command.Command;
import me.memeszz.aurora.event.events.PacketEvent;
import me.memeszz.aurora.setting.Setting;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.client.CPacketChatMessage;

import java.util.ArrayList;

public class ColorChat extends Module {
    public ColorChat() {
        super("ColorChat", Category.CHAT);
    }

    Setting.mode mode;

    public void setup(){
        ArrayList<String> modes = new ArrayList<>();
        modes.add("Green");
        modes.add("Blue");
        mode = this.registerMode("Color", modes, "Green");
    }

    @EventHandler
    private Listener<PacketEvent.Send> listener = new Listener<>(event -> {
        if(event.getPacket() instanceof CPacketChatMessage){
            if(((CPacketChatMessage) event.getPacket()).getMessage().startsWith("/") || ((CPacketChatMessage) event.getPacket()).getMessage().startsWith(Command.getPrefix())) return;
            String message = ((CPacketChatMessage) event.getPacket()).getMessage();
            String prefix = "";
            if(mode.getValue().equalsIgnoreCase("Green")) prefix = ">";
            if(mode.getValue().equalsIgnoreCase("Blue")) prefix = "`";
            String s = prefix + message;
            if(s.length() > 255) return;
            ((CPacketChatMessage) event.getPacket()).message = s;
        }
    });

    public void onEnable(){
        Aurora.EVENT_BUS.subscribe(this);
    }

    public void onDisable(){
        Aurora.EVENT_BUS.unsubscribe(this);
    }

    public String getHudInfo(){
        return mode.getValue().toUpperCase();
    }
}
