package me.memeszz.aurora.module.modules.chat;

import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.command.Command;
import me.memeszz.aurora.setting.Setting;
import me.memeszz.aurora.util.Wrapper;

import java.util.ArrayList;
import java.util.List;

public class Spammer extends Module {
    public Spammer() {
        super("Spammer", Category.CHAT);
        text = new ArrayList<>();
    }

    public static List<String> text;
    int waitCounter;
    Setting.i delay;
    int i = -1;

    public void setup(){
        delay = this.registerI("Delay", 5, 1, 100);
    }

    public void onUpdate(){
        if(text.size() <= 0 || text.isEmpty()){
            Wrapper.sendClientMessage("Spammer list empty, disabling");
            disable();
        }
        if (waitCounter < delay.getValue() * 100) {
            waitCounter++;
            return;
        } else {
            waitCounter = 0;
        }
        i++;
        if(!(i + 1 > text.size()))
            mc.player.sendChatMessage(text.get(i));
        else
            i = -1;

    }
}
