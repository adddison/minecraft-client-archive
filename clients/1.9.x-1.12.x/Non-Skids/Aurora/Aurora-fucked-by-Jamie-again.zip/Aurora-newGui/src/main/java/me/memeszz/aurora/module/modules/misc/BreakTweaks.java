package me.memeszz.aurora.module.modules.misc;

import me.memeszz.aurora.module.Module;

public class BreakTweaks extends Module {
    public BreakTweaks() {
        super("BreakTweaks", Category.MISC, "Tweaks block breaking");
    }
}
