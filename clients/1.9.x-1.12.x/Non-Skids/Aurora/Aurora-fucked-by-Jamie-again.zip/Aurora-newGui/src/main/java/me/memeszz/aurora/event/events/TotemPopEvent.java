package me.memeszz.aurora.event.events;

import me.memeszz.aurora.event.AuroraEvent;

import net.minecraft.entity.Entity;


public class TotemPopEvent extends AuroraEvent {

    private Entity entity;

    public TotemPopEvent(Entity entity) {
        super();
        this.entity = entity;
    }

    public Entity getEntity() {
        return entity;
    }

}