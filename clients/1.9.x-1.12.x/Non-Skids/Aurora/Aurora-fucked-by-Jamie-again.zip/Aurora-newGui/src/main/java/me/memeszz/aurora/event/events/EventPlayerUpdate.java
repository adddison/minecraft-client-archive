package me.memeszz.aurora.event.events;

import me.memeszz.aurora.event.AuroraEvent;

public class EventPlayerUpdate extends AuroraEvent
{
    public EventPlayerUpdate()
    {
        super();
    }
}