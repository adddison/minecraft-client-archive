package me.memeszz.aurora.module.modules.combat;

import me.memeszz.aurora.event.events.PacketSendEvent;
import me.memeszz.aurora.friends.Friends;
import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.setting.Setting;
import me.memeszz.aurora.util.RotationManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.Comparator;

public class KillAura extends Module {
    public KillAura() {
        super("KillAura", Category.COMBAT, "Attacks nearby players");
    }
    private Setting.d range;
    private boolean swordOnly;
    private boolean caCheck;
    private Setting.b criticals;
    private Setting.b rotate;
    private boolean tpsSync;
    private boolean isAttacking;

    public void setup() {
        this.swordOnly = true;
        this.caCheck = true;
        this.tpsSync = false;
        this.isAttacking = false;
        this.range = this.registerD("Range", 4.5, 0.0, 10.0);
        this.criticals = this.registerB("Criticals", true);
        this.rotate = this.registerB("Rotate", true);


    }

    @Override
    public void onUpdate() {
        if (KillAura.mc.player.isDead || KillAura.mc.player.getHealth() <= 0.0f) {
            return;
        }
        KillAura.mc.world.playerEntities.stream().filter(entity -> entity != KillAura.mc.player).filter(entity -> KillAura.mc.player.getDistance(entity) <= this.range.getValue()).filter(e -> e.getHealth() > 0.0f).filter(e -> !e.isDead).filter(e -> !Friends.isFriend(e.getName())).sorted(Comparator.comparing(e -> KillAura.mc.player.getDistance(e))).forEach(this::attack);
    }

    @SubscribeEvent
    public void onSendPacket(final PacketSendEvent event) {
        if (event.getPacket() instanceof CPacketUseEntity && this.criticals.getValue() && ((CPacketUseEntity)event.getPacket()).getAction() == CPacketUseEntity.Action.ATTACK && KillAura.mc.player.onGround && this.isAttacking) {
            KillAura.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(KillAura.mc.player.posX, KillAura.mc.player.posY + 0.10000000149011612, KillAura.mc.player.posZ, false));
            KillAura.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(KillAura.mc.player.posX, KillAura.mc.player.posY, KillAura.mc.player.posZ, false));
        }
    }

    private void attack(final Entity e) {
        if (this.swordOnly && !(KillAura.mc.player.getHeldItemMainhand().getItem() instanceof ItemSword)) {
            return;
        }
        if (this.caCheck && CrystalAura.isActive) {
            return;
        }
        final float i = 1.0f;
        if (KillAura.mc.player.getCooledAttackStrength(0.0f) >= i) {
            this.isAttacking = true;
            final boolean rotatee = this.rotate.getValue();
            if (rotatee) {
                RotationManager.lookAt(e, (EntityPlayer)KillAura.mc.player);
            }
            KillAura.mc.playerController.attackEntity((EntityPlayer)KillAura.mc.player, e);
            KillAura.mc.player.swingArm(EnumHand.MAIN_HAND);
            if (rotatee) {
                RotationManager.resetRotation();
            }
            this.isAttacking = false;
        }
    }
}
