package me.memeszz.aurora.module.modules.misc;

import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.AuroraRPC;
import me.memeszz.aurora.command.Command;
import me.memeszz.aurora.util.Wrapper;

public class RpcModule extends Module {
    public RpcModule() {
        super("DiscordRPC", Category.MISC, "Discord Rich Presence");
        setEnabled(true);
        setDrawn(false);
    }

    public void onEnable(){
        AuroraRPC.init();
        if(mc.player != null)
            Wrapper.sendClientMessage("discord rpc started");
    }

    public void onDisable(){
        Wrapper.sendClientMessage("you need to restart your game disable rpc");
    }
}
