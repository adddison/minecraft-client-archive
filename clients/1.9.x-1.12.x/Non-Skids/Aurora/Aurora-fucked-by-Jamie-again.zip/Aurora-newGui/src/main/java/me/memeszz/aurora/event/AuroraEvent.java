package me.memeszz.aurora.event;

import me.memeszz.aurora.util.Wrapper;
import me.zero.alpine.type.Cancellable;

public class AuroraEvent extends Cancellable {

    private Era era = Era.PRE;
    private final float partialTicks;

    public AuroraEvent() {
        partialTicks = Wrapper.getMinecraft().getRenderPartialTicks();
    }

    public Era getEra() {
        return era;
    }

    public float getPartialTicks() {
        return partialTicks;
    }

    public enum Era {
        PRE, PERI, POST
    }

}
