package me.memeszz.aurora.event.events;

import me.memeszz.aurora.event.AuroraEvent;
import net.minecraft.client.gui.GuiScreen;

public class GuiScreenDisplayedEvent extends AuroraEvent {
    private final GuiScreen guiScreen;
    public GuiScreenDisplayedEvent(GuiScreen screen){
        super();
        guiScreen = screen;
    }

    public GuiScreen getScreen(){
        return guiScreen;
    }

}
