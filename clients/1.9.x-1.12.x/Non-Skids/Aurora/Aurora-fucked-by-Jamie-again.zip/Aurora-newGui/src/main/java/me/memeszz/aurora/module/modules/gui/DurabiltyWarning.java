package me.memeszz.aurora.module.modules.gui;


import me.memeszz.aurora.Aurora;
import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.setting.Setting;
import me.memeszz.aurora.util.Wrapper;
import net.minecraft.item.ItemStack;

import java.awt.*;


public class DurabiltyWarning extends Module {
    public DurabiltyWarning() {
        super("DurabiltyWarning", Category.GUI, "Attacks nearby players");
    }
    private Setting.b sortUp;
    private Setting.b right;
    private Setting.b customFont;
    private Setting.b rainbow;
    Setting.i x;
    Setting.i y;
    Setting.i red;
    Setting.i green;
    Setting.i blue;
    Setting.i threshold;


    Color c;
    public void setup() {
        customFont = this.registerB("CustomFont", false);
        threshold = this.registerI("Percent",  50, 0, 100);
        x = this.registerI("X",  255, 0, 960);
        y = this.registerI("Y",  255, 0, 530);
        red = this.registerI("Red",  255, 0, 255);
        green = this.registerI("Green",  255, 0, 255);
        blue = this.registerI("Blue",  255, 0, 255);
        rainbow = this.registerB("Rainbow", false);


    }

    @Override
    public void onRender() {
        final float[] hue = {(System.currentTimeMillis() % (360 * 32)) / (360f * 32)};
        int rgb = Color.HSBtoRGB(hue[0], 1, 1);
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = rgb & 0xFF;
        if (this.shouldMend(0) || this.shouldMend(1) || this.shouldMend(2) || this.shouldMend(3)) {
            final String text = "Armor Durability Is Below " + String.valueOf(this.threshold.getValue() + "%");
            final int divider = getScale();
            if (rainbow.getValue()) {

                drawStringWithShadow(text, (int) x.getValue(),
                        (int) y.getValue(), new Color(r, g, b).getRGB());
            } else {
                drawStringWithShadow(text, (int) x.getValue(),
                        (int) y.getValue(), new Color(red.getValue(), green.getValue(), blue.getValue()).getRGB());

            }
        }
    }

    private boolean shouldMend(final int i) {
        return ((ItemStack) DurabiltyWarning.mc.player.inventory.armorInventory.get(i)).getMaxDamage()
                != 0 && 100 * ((ItemStack) DurabiltyWarning.mc.player.inventory.armorInventory.get(i)).getItemDamage()
                / ((ItemStack) DurabiltyWarning.mc.player.inventory.armorInventory.get(i)).getMaxDamage()
                > reverseNumber(this.threshold.getValue(), 1, 100);
    }

    public static int reverseNumber(final int num, final int min, final int max) {
        return max + min - num;
    }

    public static int getScale() {
        int scaleFactor = 0;
        int scale = Wrapper.getMinecraft().gameSettings.guiScale;
        if (scale == 0) {
            scale = 1000;
        }
        while (scaleFactor < scale && Wrapper.getMinecraft().displayWidth / (scaleFactor + 1) >= 320 && Wrapper.getMinecraft().displayHeight / (scaleFactor + 1) >= 240) {
            ++scaleFactor;
        }
        if (scaleFactor == 0) {
            scaleFactor = 1;
        }
        return scaleFactor;
    }
    private void drawStringWithShadow(String text, int x, int y, int color){
        if(customFont.getValue())
            Aurora.fontRenderer.drawStringWithShadow(text, x, y, color);
        else
            mc.fontRenderer.drawStringWithShadow(text, x, y, color);
    }
}