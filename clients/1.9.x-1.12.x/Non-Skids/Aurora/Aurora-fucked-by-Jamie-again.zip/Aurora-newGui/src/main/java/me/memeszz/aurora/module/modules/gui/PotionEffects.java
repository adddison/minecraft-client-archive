

//package me.memeszz.aurora.module.modules.gui;
//
//import com.ibm.icu.text.DecimalFormat;
//import com.mojang.realmsclient.gui.ChatFormatting;
//import me.memeszz.aurora.Aurora;
//import me.memeszz.aurora.module.Module;
//import me.memeszz.aurora.setting.Setting;
//import me.memeszz.aurora.util.TpsUtils;
//import me.memeszz.aurora.util.Wrapper;
//import net.minecraft.client.resources.I18n;
//
//import java.awt.*;
//import java.util.ArrayList;
//
//import static me.memeszz.aurora.Aurora.MODNAME;
//import static me.memeszz.aurora.Aurora.MODVER;
//
///**
// * Memeszz Ez
// */
//public class PotionEffects extends Module {
//    public PotionEffects() {
//        super("PotionEffects", Category.GUI, "Attacks nearby players");
//    }
//
//    private Setting.b customFont;
//    private Setting.b rainbow;
//    private Setting.b sortUp;
//    private Setting.b right;
//
//
//    Setting.i x;
//    Setting.i y;
//    Setting.i red;
//    Setting.i green;
//    Setting.i blue;
//    int count;
//    DecimalFormat format1 = new DecimalFormat("0");
//    DecimalFormat format2 = new DecimalFormat("00");
//    Setting.mode mode;
//
//    public void setup() {
//        customFont = this.registerB("CustomFont", false);
//        sortUp = this.registerB("SortUp", false);
//        right = this.registerB("RightSide", false);
//        x = this.registerI("X", 255, 0, 905);
//        y = this.registerI("Y", 255, 0, 530);
//        red = this.registerI("Red", 255, 0, 255);
//        green = this.registerI("Green", 255, 0, 255);
//        blue = this.registerI("Blue", 255, 0, 255);
//        rainbow = this.registerB("Rainbow", false);
//
//    }
//
//    public void onRender() {
//        count = 0;
//        try {
//            mc.player.getActivePotionEffects().forEach(effect -> {
//                String name = I18n.format(effect.getPotion().getName());
//                double duration = effect.getDuration() / TpsUtils.getTickRate();
//                int amplifier = effect.getAmplifier() + 1;
//                int color = effect.getPotion().getLiquidColor();
//                double p1 = duration % 60;
//                double p2 = duration / 60;
//                double p3 = p2 % 60;
//                String minutes = format1.format(p3);
//                String seconds = format2.format(p1);
//                String s = name + " " + amplifier + ChatFormatting.GRAY + " " + minutes + ":" + seconds;
//                if (sortUp.getValue()) {
//                    if (right.getValue()) {
//                        mc.fontRenderer.drawStringWithShadow(s, (int) x.getValue() - mc.fontRenderer.getStringWidth(s), (int) y.getValue() + (count * 10), color);
//                    } else {
//                        mc.fontRenderer.drawStringWithShadow(s, (int) x.getValue(), (int) y.getValue() + (count * 10), color);
//                    }
//                    count++;
//                } else {
//                    if (right.getValue()) {
//                        mc.fontRenderer.drawStringWithShadow(s, (int) x.getValue() - mc.fontRenderer.getStringWidth(s), (int) y.getValue() + (count * -10), color);
//                    } else {
//                        mc.fontRenderer.drawStringWithShadow(s, (int) x.getValue(), (int) y.getValue() + (count * -10), color);
//                    }
//                    count++;
//                }
//            });
//        } catch (NullPointerException e) {
//            e.printStackTrace();
//        }
//    }
//}
//
//    private void drawStringWithShadow(String text, int x, int y, int color){
//        if(customFont.getValue())
//            Aurora.fontRenderer.drawStringWithShadow(text, x, y, color);
//        else
//            mc.fontRenderer.drawStringWithShadow(text, x, y, color);
//    }
//}