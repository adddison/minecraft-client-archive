package me.memeszz.aurora.module.modules.render;

import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.event.events.RenderEvent;
import me.memeszz.aurora.setting.Setting;
import me.memeszz.aurora.util.AuroraTessellator;
import me.memeszz.aurora.util.Tessellator;
import me.memeszz.aurora.friends.Friends;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.Vec3d;

import static org.lwjgl.opengl.GL11.*;

public class CsgoESP extends Module {
    public CsgoESP() {
        super("CsgoESP", Category.RENDER);
    }

    Setting.b players;
    Setting.b passive;
    Setting.b monsters;
    Setting.b items;
    Setting.b xpBottles;
    Setting.b crystals;
    Setting.b orbs;

    public void setup(){
        players = this.registerB("Players",  true);
        passive = this.registerB("Passive",  false);
        monsters = this.registerB("Monsters",  false);
        items = this.registerB("Items",  false);
        crystals = this.registerB("Crystals",  false);
        xpBottles = this.registerB("XpBottles",  false);
        orbs = this.registerB("XpOrbs",  false);
    }

    public void onWorldRender(RenderEvent event) {
        if (mc.getRenderManager().options == null) return;
                boolean isThirdPersonFrontal = mc.getRenderManager().options.thirdPersonView == 2;
                float viewerYaw = mc.getRenderManager().playerViewY;

                mc.world.loadedEntityList.stream()
                        .filter(entity -> mc.player != entity)
                        .forEach(e -> {
                            Tessellator.prepareGL();
                            GlStateManager.pushMatrix();
                            Vec3d pos = AuroraTessellator.getInterpolatedPos(e, mc.getRenderPartialTicks());
                            GlStateManager.translate(pos.x-mc.getRenderManager().renderPosX, pos.y-mc.getRenderManager().renderPosY, pos.z-mc.getRenderManager().renderPosZ);
                            GlStateManager.glNormal3f(0.0F, 1.0F, 0.0F);
                            GlStateManager.rotate(-viewerYaw, 0.0F, 1.0F, 0.0F);
                            GlStateManager.rotate((float)(isThirdPersonFrontal ? -1 : 1), 1.0F, 0.0F, 0.0F);
                            glColor4f(1, 1, 1, 0.5f);

                            glLineWidth(3f);
                            glEnable(GL_LINE_SMOOTH);

                            if(e instanceof EntityPlayer && players.getValue()) {
                                if (Friends.isFriend(e.getName())) {
                                    glColor4f(0, 1, 1, 0.5f);
                                } else {
                                    glColor4f(1f, 0f, 0f, 0.5f);
                                }
                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(-e.width, 0);
                                    glVertex2d(-e.width, e.height / 3);
                                    glVertex2d(-e.width, 0);
                                    glVertex2d((-e.width / 3) * 2, 0);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(-e.width, e.height);
                                    glVertex2d((-e.width / 3) * 2, e.height);
                                    glVertex2d(-e.width, e.height);
                                    glVertex2d(-e.width, (e.height / 3) * 2);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(e.width, e.height);
                                    glVertex2d((e.width / 3) * 2, e.height);
                                    glVertex2d(e.width, e.height);
                                    glVertex2d(e.width, (e.height / 3) * 2);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(e.width, 0);
                                    glVertex2d((e.width / 3) * 2, 0);
                                    glVertex2d(e.width, 0);
                                    glVertex2d(e.width, e.height / 3);
                                }
                                glEnd();
                            }

                            glColor4f(1, 1, 1, 0.5f);

                            if(GlowESP.isPassive(e) && passive.getValue()) {
                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(-e.width, 0);
                                    glVertex2d(-e.width, e.height / 3);
                                    glVertex2d(-e.width, 0);
                                    glVertex2d((-e.width / 3) * 2, 0);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(-e.width, e.height);
                                    glVertex2d((-e.width / 3) * 2, e.height);
                                    glVertex2d(-e.width, e.height);
                                    glVertex2d(-e.width, (e.height / 3) * 2);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(e.width, e.height);
                                    glVertex2d((e.width / 3) * 2, e.height);
                                    glVertex2d(e.width, e.height);
                                    glVertex2d(e.width, (e.height / 3) * 2);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(e.width, 0);
                                    glVertex2d((e.width / 3) * 2, 0);
                                    glVertex2d(e.width, 0);
                                    glVertex2d(e.width, e.height / 3);
                                }
                                glEnd();
                            }

                            if(GlowESP.isMonster(e) && monsters.getValue()) {
                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(-e.width, 0);
                                    glVertex2d(-e.width, e.height / 3);
                                    glVertex2d(-e.width, 0);
                                    glVertex2d((-e.width / 3) * 2, 0);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(-e.width, e.height);
                                    glVertex2d((-e.width / 3) * 2, e.height);
                                    glVertex2d(-e.width, e.height);
                                    glVertex2d(-e.width, (e.height / 3) * 2);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(e.width, e.height);
                                    glVertex2d((e.width / 3) * 2, e.height);
                                    glVertex2d(e.width, e.height);
                                    glVertex2d(e.width, (e.height / 3) * 2);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(e.width, 0);
                                    glVertex2d((e.width / 3) * 2, 0);
                                    glVertex2d(e.width, 0);
                                    glVertex2d(e.width, e.height / 3);
                                }
                                glEnd();
                            }

                            if(e instanceof EntityItem && items.getValue()) {
                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(-e.width, 0);
                                    glVertex2d(-e.width, e.height / 3);
                                    glVertex2d(-e.width, 0);
                                    glVertex2d((-e.width / 3) * 2, 0);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(-e.width, e.height);
                                    glVertex2d((-e.width / 3) * 2, e.height);
                                    glVertex2d(-e.width, e.height);
                                    glVertex2d(-e.width, (e.height / 3) * 2);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(e.width, e.height);
                                    glVertex2d((e.width / 3) * 2, e.height);
                                    glVertex2d(e.width, e.height);
                                    glVertex2d(e.width, (e.height / 3) * 2);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(e.width, 0);
                                    glVertex2d((e.width / 3) * 2, 0);
                                    glVertex2d(e.width, 0);
                                    glVertex2d(e.width, e.height / 3);
                                }
                                glEnd();
                            }

                            if(e instanceof EntityExpBottle && xpBottles.getValue()) {
                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(-e.width, 0);
                                    glVertex2d(-e.width, e.height / 3);
                                    glVertex2d(-e.width, 0);
                                    glVertex2d((-e.width / 3) * 2, 0);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(-e.width, e.height);
                                    glVertex2d((-e.width / 3) * 2, e.height);
                                    glVertex2d(-e.width, e.height);
                                    glVertex2d(-e.width, (e.height / 3) * 2);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(e.width, e.height);
                                    glVertex2d((e.width / 3) * 2, e.height);
                                    glVertex2d(e.width, e.height);
                                    glVertex2d(e.width, (e.height / 3) * 2);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(e.width, 0);
                                    glVertex2d((e.width / 3) * 2, 0);
                                    glVertex2d(e.width, 0);
                                    glVertex2d(e.width, e.height / 3);
                                }
                                glEnd();
                            }


                            if(e instanceof EntityEnderCrystal && crystals.getValue()) {
                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(-e.width / 2, 0);
                                    glVertex2d(-e.width / 2, e.height / 3);
                                    glVertex2d(-e.width / 2, 0);
                                    glVertex2d(((-e.width / 3) * 2) / 2, 0);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(-e.width / 2, e.height);
                                    glVertex2d(((-e.width / 3) * 2) / 2, e.height);
                                    glVertex2d(-e.width / 2, e.height);
                                    glVertex2d(-e.width / 2, (e.height / 3) * 2);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(e.width / 2, e.height);
                                    glVertex2d(((e.width / 3) * 2) / 2, e.height);
                                    glVertex2d(e.width / 2, e.height);
                                    glVertex2d(e.width / 2, (e.height / 3) * 2);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(e.width / 2, 0);
                                    glVertex2d(((e.width / 3) * 2) / 2, 0);
                                    glVertex2d(e.width / 2, 0);
                                    glVertex2d(e.width / 2, e.height / 3);
                                }
                                glEnd();
                            }

                            if(e instanceof EntityXPOrb && orbs.getValue()) {
                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(-e.width / 2, 0);
                                    glVertex2d(-e.width / 2, e.height / 3);
                                    glVertex2d(-e.width / 2, 0);
                                    glVertex2d(((-e.width / 3) * 2) / 2, 0);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(-e.width / 2, e.height);
                                    glVertex2d(((-e.width / 3) * 2) / 2, e.height);
                                    glVertex2d(-e.width / 2, e.height);
                                    glVertex2d(-e.width / 2, (e.height / 3) * 2);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(e.width / 2, e.height);
                                    glVertex2d(((e.width / 3) * 2) / 2, e.height);
                                    glVertex2d(e.width / 2, e.height);
                                    glVertex2d(e.width / 2, (e.height / 3) * 2);
                                }
                                glEnd();

                                glBegin(GL_LINE_LOOP);
                                {
                                    glVertex2d(e.width / 2, 0);
                                    glVertex2d(((e.width / 3) * 2) / 2, 0);
                                    glVertex2d(e.width / 2, 0);
                                    glVertex2d(e.width / 2, e.height / 3);
                                }
                                glEnd();
                            }

                            Tessellator.releaseGL();
                            GlStateManager.popMatrix();
                        });
                glColor4f(1,1,1, 1);
    }
}
