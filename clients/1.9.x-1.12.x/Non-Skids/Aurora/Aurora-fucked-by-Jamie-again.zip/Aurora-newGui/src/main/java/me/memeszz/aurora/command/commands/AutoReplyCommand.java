package me.memeszz.aurora.command.commands;

import me.memeszz.aurora.command.Command;
import me.memeszz.aurora.module.modules.chat.AutoReply;
import me.memeszz.aurora.util.Wrapper;

public class AutoReplyCommand extends Command {
    @Override
    public String[] getAlias() {
        return new String[]{
                "autoreply"
        };
    }

    @Override
    public String getSyntax() {
        return "autoreply <message (use \"_\" for spaces)>";
    }

    @Override
    public void onCommand(String command, String[] args) throws Exception {
        if(args[0] != null && !args[0].equalsIgnoreCase("")){
            AutoReply.setReply(args[0].replace("_", " "));
            Wrapper.sendClientMessage("AutoReply message set to " + AutoReply.getReply());
        } else {
            Wrapper.sendClientMessage(getSyntax());
        }
    }
}
