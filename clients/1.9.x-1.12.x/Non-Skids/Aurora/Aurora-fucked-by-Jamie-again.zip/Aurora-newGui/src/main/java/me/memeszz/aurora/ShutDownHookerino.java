package me.memeszz.aurora;

public class ShutDownHookerino extends Thread {
    @Override
    public void run(){
        saveConfig();
    }

    public static void saveConfig(){
        Aurora.getInstance().configUtils.saveMods();
        Aurora.getInstance().configUtils.saveSettingsList();
        Aurora.getInstance().configUtils.saveBinds();
        Aurora.getInstance().configUtils.saveDrawn();
        Aurora.getInstance().configUtils.saveFriends();
        Aurora.getInstance().configUtils.savePrefix();
        Aurora.getInstance().configUtils.saveRainbow();
        Aurora.getInstance().configUtils.saveMacros();
        Aurora.getInstance().configUtils.saveMsgs();
        Aurora.getInstance().configUtils.saveAutoGG();
        Aurora.getInstance().configUtils.saveSpammer();
        Aurora.getInstance().configUtils.saveAutoReply();
        Aurora.getInstance().configUtils.saveAnnouncer();
        Aurora.getInstance().configUtils.saveFont();
        Aurora.getInstance().configUtils.saveEnemies();
        Aurora.getInstance().configUtils.saveClientname();
    }
}
