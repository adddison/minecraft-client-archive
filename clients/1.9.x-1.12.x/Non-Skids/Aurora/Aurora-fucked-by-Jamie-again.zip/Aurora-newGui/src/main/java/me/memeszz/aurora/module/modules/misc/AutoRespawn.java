package me.memeszz.aurora.module.modules.misc;

import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.Aurora;
import me.memeszz.aurora.event.events.GuiScreenDisplayedEvent;
import me.memeszz.aurora.setting.Setting;
import me.memeszz.aurora.util.Wrapper;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.gui.GuiGameOver;

public class AutoRespawn extends Module {
    public AutoRespawn() {
        super("AutoRespawn", Category.MISC, "Respawn when you die");
    }

    Setting.b coords;

    public void setup(){
        coords = this.registerB("DeathCoords", true);
    }

    @EventHandler
    private Listener<GuiScreenDisplayedEvent> listener = new Listener<>(event -> {
        if(event.getScreen() instanceof GuiGameOver) {
            if(coords.getValue())
                Wrapper.sendClientMessage(String.format("You died at x%d y%d z%d", (int)mc.player.posX, (int)mc.player.posY, (int)mc.player.posZ));
            if(mc.player != null)
                mc.player.respawnPlayer();
            mc.displayGuiScreen(null);
        }
    });

    public void onEnable(){
        Aurora.EVENT_BUS.subscribe(this);
    }

    public void onDisable(){
        Aurora.EVENT_BUS.unsubscribe(this);
    }
}
