package me.memeszz.aurora.module.modules.chat;

import me.memeszz.aurora.module.Module;

public class ToggleMsgs extends Module {
    public ToggleMsgs() {
        super("ToggleMsgs", Category.CHAT, "Sends a client side message when you toggle any module");
    }
}
