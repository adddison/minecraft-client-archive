
//package me.memeszz.aurora.module.modules.render;
//
//import io.netty.util.internal.ConcurrentSet;
//import me.memeszz.aurora.event.events.RenderEvent;
//import me.memeszz.aurora.module.Module;
//import me.memeszz.aurora.module.modules.combat.AutoCrystal;
//import me.memeszz.aurora.setting.Setting;
//import me.memeszz.aurora.util.AuroraTessellator;
//import me.memeszz.aurora.util.BlockInteractionHelper;
//import me.memeszz.aurora.util.GeometryMasks;
//import me.memeszz.aurora.util.Tessellator;
//import net.minecraft.init.Blocks;
//import net.minecraft.util.math.BlockPos;
//import net.minecraft.util.math.Vec3i;
//import org.lwjgl.opengl.GL11;
//
//import java.awt.*;
//import java.util.ArrayList;
//import java.util.List;
//import static me.memeszz.aurora.module.modules.combat.AutoCrystal.getPlayerPos;
//public class VoidESP extends Module {
//    public VoidESP() {
//        super("VoidESP", Category.RENDER, "Shows holes nigga");
//    }
//
//    Setting.d range;
//    Setting.i r;
//    Setting.i g;
//    Setting.i b;
//    Setting.i a;
//    Setting.i activateAtY;
//    Setting.mode mode;
//    Setting.mode rmode;
//    private ConcurrentSet<BlockPos> voidHoles;
//    public void setup(){
//        ArrayList<String> modes = new ArrayList<>();
//        modes.add("Down");
//        modes.add("Block");
//        ArrayList<String> rmodes = new ArrayList<>();
//        rmodes.add("Sides");
//        rmodes.add("Above");
//        mode = this.registerMode("Mode", modes, "Above");
//        rmode = this.registerMode("RenderMode", rmodes, "Down");
//        range = this.registerD("Range",  8.0, 1.0, 32.0);
//        activateAtY = this.registerI("YLevel",  32, 1, 512);
//        r = this.registerI("Red",  160, 0, 255);
//        g = this.registerI("Green",  0, 0, 255);
//        b = this.registerI("Blue",  255, 0, 255);
//
//    }
//
//
//    @Override
//    public void onUpdate() {
//
//        if (mc.player == null) {
//            return;
//        }
//
//        // skip if in end
//        if (mc.player.dimension == 1) {
//            return;
//        }
//
//        if (mc.player.getPosition().getY() > activateAtY.getValue()) {
//            return;
//        }
//
//        if (voidHoles == null) {
//            voidHoles = new ConcurrentSet<>();
//        } else {
//            voidHoles.clear();
//        }
//
//        List<BlockPos> blockPosList = BlockInteractionHelper.getCircle(getPlayerPos(), 0, (float) range.getValue(), false);
//
//        for (BlockPos pos : blockPosList) {
//
//            if (mc.world.getBlockState(pos).getBlock().equals(Blocks.BEDROCK)) {
//                continue;
//            }
//
//            if (isAnyBedrock(pos, Offsets.center)) {
//                continue;
//            }
//
//            boolean aboveFree = false;
//
//            if (!isAnyBedrock(pos, Offsets.above)) {
//                aboveFree = true;
//            }
//
//            if(mode.getValue().equalsIgnoreCase("Above")) {
//                if (aboveFree) {
//                    voidHoles.add(pos);
//                }
//                continue;
//            }
//
//            boolean sidesFree = false;
//
//            if (!isAnyBedrock(pos, Offsets.north)) {
//                sidesFree = true;
//            }
//
//            if (!isAnyBedrock(pos, Offsets.east)) {
//                sidesFree = true;
//            }
//
//            if (!isAnyBedrock(pos, Offsets.south)) {
//                sidesFree = true;
//            }
//
//            if (!isAnyBedrock(pos, Offsets.west)) {
//                sidesFree = true;
//            }
//
//            if(mode.getValue().equalsIgnoreCase("Sides")) {
//                if (aboveFree || sidesFree) {
//                    voidHoles.add(pos);
//                }
//            }
//
//        }
//
//    }
//
//
//    private boolean isAnyBedrock(BlockPos origin, BlockPos[] offset) {
//        for (BlockPos pos : offset) {
//            if (mc.world.getBlockState(origin.add(pos)).getBlock().equals(Blocks.BEDROCK)) {
//                return true;
//            }
//        }
//        return false;
//    }
//
//    @Override
//    public void onWorldRender(final RenderEvent event) {
//
//        if (mc.player == null || voidHoles == null || voidHoles.isEmpty()) {
//            return;
//        }
//
//        AuroraTessellator.prepare(GL11.GL_QUADS);
//
//        voidHoles.forEach(blockPos -> {
//            drawBlock(blockPos, r.getValue(), g.getValue(), b.getValue());
//        });
//
//        AuroraTessellator.release();
//
//    }
//
//    private void drawBlock(BlockPos blockPos, int r, int g, int b) {
//        Color color = new Color(r, g, b, a.getValue());
//        int mask = 0;
//        if(rmode.getValue().equalsIgnoreCase("Block")) {
//            mask = GeometryMasks.Quad.ALL;
//        }
//        if(rmode.getValue().equalsIgnoreCase("Down")) {
//            mask = GeometryMasks.Quad.DOWN;
//        }
//        AuroraTessellator.drawBox(blockPos, color.getRGB(), mask);
//    }
//
//    @Override
//    public String getHudInfo() {
//        return mode.getValue().toString();
//    }
//
//
//
//    private static class Offsets {
//
//        static final BlockPos[] center = {
//                new BlockPos(0, 1, 0),
//                new BlockPos(0, 2, 0)
//        };
//
//        static final BlockPos[] above = {
//                new BlockPos(0, 3, 0),
//                new BlockPos(0, 4, 0)
//        };
//
//        static final BlockPos[] aboveStep1 = {
//                new BlockPos(0, 3, 0)
//        };
//
//        static final BlockPos[] aboveStep2 = {
//                new BlockPos(0, 4, 0)
//        };
//
//        static final BlockPos[] north = {
//                new BlockPos(0, 1, -1),
//                new BlockPos(0, 2, -1)
//        };
//
//        static final BlockPos[] east = {
//                new BlockPos(1, 1, 0),
//                new BlockPos(1, 2, 0)
//        };
//
//        static final BlockPos[] south = {
//                new BlockPos(0, 1, 1),
//                new BlockPos(0, 2, 1)
//        };
//
//        static final BlockPos[] west = {
//                new BlockPos(-1, 1, 0),
//                new BlockPos(-1, 2, 0)
//        };
//
//    }
//
//}