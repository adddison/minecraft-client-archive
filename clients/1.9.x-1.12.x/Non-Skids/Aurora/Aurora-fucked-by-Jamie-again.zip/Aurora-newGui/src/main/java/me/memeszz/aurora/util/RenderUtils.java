// 
// Decompiled by Procyon v0.5.36
// 

package me.memeszz.aurora.util;

import net.minecraft.world.World;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;

public class RenderUtils extends Tessellator
{
    public static RenderUtils INSTANCE;
    
    public RenderUtils() {
        super(2097152);
    }
    
    public static void prepareGL() {
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.glLineWidth(1.5f);
        GlStateManager.disableTexture2D();
        GlStateManager.depthMask(false);
        GlStateManager.enableBlend();
        GlStateManager.disableDepth();
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableAlpha();
        GlStateManager.color(1.0f, 1.0f, 1.0f);
    }
    
    public static void releaseGL() {
        GlStateManager.enableCull();
        GlStateManager.depthMask(true);
        GlStateManager.enableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.enableDepth();
        GlStateManager.color(1.0f, 1.0f, 1.0f);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    }
    
    public static void prepare(final int mode) {
        prepareGL();
        RenderUtils.INSTANCE.getBuffer().begin(mode, DefaultVertexFormats.POSITION_COLOR);
    }
    
    public static void drawBox(final AxisAlignedBB bb, final int argb) {
        final int a = argb >>> 24 & 0xFF;
        final int r = argb >>> 16 & 0xFF;
        final int g = argb >>> 8 & 0xFF;
        final int b = argb & 0xFF;
        drawBox((float)bb.minX, (float)bb.minY, (float)bb.minZ, (float)bb.maxX - (float)bb.minX, (float)bb.maxY - (float)bb.minY, (float)bb.maxZ - (float)bb.minZ, r, g, b, a);
    }
    
    public static void drawBox(final BlockPos blockPos, final int argb) {
        final int a = argb >>> 24 & 0xFF;
        final int r = argb >>> 16 & 0xFF;
        final int g = argb >>> 8 & 0xFF;
        final int b = argb & 0xFF;
        drawBox((float)blockPos.getX(), (float)blockPos.getY(), (float)blockPos.getZ(), 1.0f, 1.0f, 1.0f, r, g, b, a);
    }
    
    public static void drawBox(final float x, final float y, final float z, final float w, final float h, final float d, final int r, final int g, final int b, final int a) {
        final BufferBuilder buffer = RenderUtils.INSTANCE.getBuffer();
        prepare(7);
        buffer.pos((double)(x + w), (double)y, (double)z).color(r, g, b, a).endVertex();
        buffer.pos((double)(x + w), (double)y, (double)(z + d)).color(r, g, b, a).endVertex();
        buffer.pos((double)x, (double)y, (double)(z + d)).color(r, g, b, a).endVertex();
        buffer.pos((double)x, (double)y, (double)z).color(r, g, b, a).endVertex();
        buffer.pos((double)(x + w), (double)(y + h), (double)z).color(r, g, b, a).endVertex();
        buffer.pos((double)x, (double)(y + h), (double)z).color(r, g, b, a).endVertex();
        buffer.pos((double)x, (double)(y + h), (double)(z + d)).color(r, g, b, a).endVertex();
        buffer.pos((double)(x + w), (double)(y + h), (double)(z + d)).color(r, g, b, a).endVertex();
        buffer.pos((double)(x + w), (double)y, (double)z).color(r, g, b, a).endVertex();
        buffer.pos((double)x, (double)y, (double)z).color(r, g, b, a).endVertex();
        buffer.pos((double)x, (double)(y + h), (double)z).color(r, g, b, a).endVertex();
        buffer.pos((double)(x + w), (double)(y + h), (double)z).color(r, g, b, a).endVertex();
        buffer.pos((double)x, (double)y, (double)(z + d)).color(r, g, b, a).endVertex();
        buffer.pos((double)(x + w), (double)y, (double)(z + d)).color(r, g, b, a).endVertex();
        buffer.pos((double)(x + w), (double)(y + h), (double)(z + d)).color(r, g, b, a).endVertex();
        buffer.pos((double)x, (double)(y + h), (double)(z + d)).color(r, g, b, a).endVertex();
        buffer.pos((double)x, (double)y, (double)z).color(r, g, b, a).endVertex();
        buffer.pos((double)x, (double)y, (double)(z + d)).color(r, g, b, a).endVertex();
        buffer.pos((double)x, (double)(y + h), (double)(z + d)).color(r, g, b, a).endVertex();
        buffer.pos((double)x, (double)(y + h), (double)z).color(r, g, b, a).endVertex();
        buffer.pos((double)(x + w), (double)y, (double)(z + d)).color(r, g, b, a).endVertex();
        buffer.pos((double)(x + w), (double)y, (double)z).color(r, g, b, a).endVertex();
        buffer.pos((double)(x + w), (double)(y + h), (double)z).color(r, g, b, a).endVertex();
        buffer.pos((double)(x + w), (double)(y + h), (double)(z + d)).color(r, g, b, a).endVertex();
        RenderUtils.INSTANCE.draw();
        releaseGL();
    }
    
    public static void drawBottomBox(final BlockPos blockPos, final int argb) {
        final int a = argb >>> 24 & 0xFF;
        final int r = argb >>> 16 & 0xFF;
        final int g = argb >>> 8 & 0xFF;
        final int b = argb & 0xFF;
        drawBottomBox((float)blockPos.getX(), (float)blockPos.getY(), (float)blockPos.getZ(), r, g, b, a);
    }
    
    private static void drawBottomBox(final float x, final float y, final float z, final int r, final int g, final int b, final int a) {
        final BufferBuilder buffer = RenderUtils.INSTANCE.getBuffer();
        prepare(7);
        buffer.pos((double)(x + 1.0f), (double)y, (double)z).color(r, g, b, a).endVertex();
        buffer.pos((double)(x + 1.0f), (double)y, (double)(z + 1.0f)).color(r, g, b, a).endVertex();
        buffer.pos((double)x, (double)y, (double)(z + 1.0f)).color(r, g, b, a).endVertex();
        buffer.pos((double)x, (double)y, (double)z).color(r, g, b, a).endVertex();
        RenderUtils.INSTANCE.draw();
        releaseGL();
    }
    
    public static void drawBoundingBox(final AxisAlignedBB bb, final float width, final int argb) {
        final int a = argb >>> 24 & 0xFF;
        final int r = argb >>> 16 & 0xFF;
        final int g = argb >>> 8 & 0xFF;
        final int b = argb & 0xFF;
        drawBoundingBox(bb, width, r, g, b, a);
    }
    
    public static void drawBoundingBox(final BlockPos blockPos, final int argb, final float width) {
        final int a = argb >>> 24 & 0xFF;
        final int r = argb >>> 16 & 0xFF;
        final int g = argb >>> 8 & 0xFF;
        final int b = argb & 0xFF;
        drawBoundingBox(Wrapper.mc.world.getBlockState(blockPos).getSelectedBoundingBox((World)Wrapper.mc.world, blockPos), width, r, g, b, a);
    }
    
    public static void drawBoundingBox(final AxisAlignedBB bb, final float width, final int red, final int green, final int blue, final int alpha) {
        final BufferBuilder bufferbuilder = RenderUtils.INSTANCE.getBuffer();
        prepare(3);
        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.disableDepth();
        GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
        GlStateManager.disableTexture2D();
        GlStateManager.depthMask(false);
        GlStateManager.glLineWidth(width);
        bufferbuilder.pos(bb.minX, bb.minY, bb.minZ).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos(bb.minX, bb.minY, bb.maxZ).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos(bb.maxX, bb.minY, bb.maxZ).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos(bb.maxX, bb.minY, bb.minZ).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos(bb.minX, bb.minY, bb.minZ).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos(bb.minX, bb.maxY, bb.minZ).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos(bb.minX, bb.maxY, bb.maxZ).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos(bb.minX, bb.minY, bb.maxZ).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos(bb.maxX, bb.minY, bb.maxZ).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos(bb.maxX, bb.maxY, bb.maxZ).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos(bb.minX, bb.maxY, bb.maxZ).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos(bb.maxX, bb.maxY, bb.maxZ).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos(bb.maxX, bb.maxY, bb.minZ).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos(bb.maxX, bb.minY, bb.minZ).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos(bb.maxX, bb.maxY, bb.minZ).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos(bb.minX, bb.maxY, bb.minZ).color(red, green, blue, alpha).endVertex();
        RenderUtils.INSTANCE.draw();
        releaseGL();
        GlStateManager.depthMask(true);
        GlStateManager.enableDepth();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }
    
    static {
        RenderUtils.INSTANCE = new RenderUtils();
    }
}
