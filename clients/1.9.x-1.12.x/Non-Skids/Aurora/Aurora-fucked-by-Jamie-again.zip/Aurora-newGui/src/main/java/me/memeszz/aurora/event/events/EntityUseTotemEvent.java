package me.memeszz.aurora.event.events;

import me.memeszz.aurora.event.AuroraEvent;
import net.minecraft.entity.Entity;

public class EntityUseTotemEvent extends AuroraEvent {
    private Entity entity;

    public EntityUseTotemEvent(Entity entity) {
        super();
        this.entity = entity;
    }

    public Entity getEntity() {
        return entity;
    }
}