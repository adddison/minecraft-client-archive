package me.memeszz.aurora.module.modules.render;

import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.event.events.RenderEvent;
import me.memeszz.aurora.friends.Friends;
import me.memeszz.aurora.setting.Setting;
import me.memeszz.aurora.util.Tessellator;
import me.memeszz.aurora.util.Rainbow;
import net.minecraft.entity.item.*;
import net.minecraft.entity.player.EntityPlayer;

import java.awt.*;

public class OutLineESP extends Module {
    public OutLineESP() {
        super("OutLineESP", Category.RENDER);
        players = this.registerB("Players", false);
        passive = this.registerB("Passive", false);
        mobs = this.registerB("Mobs", false);
        exp = this.registerB("XpBottles", false);
        orbs = this.registerB("XpOrbs", false);
        epearls = this.registerB("Epearls", false);
        crystals = this.registerB("Crystals", false);
        items = this.registerB("Items", false);
        rainbow = this.registerB("Rainbow", false);
        r = this.registerI("Red", 255, 1, 255);
        g = this.registerI("Green", 255, 1, 255);
        b = this.registerI("Blue", 255, 1, 255);
        a = this.registerI("Alpha", 50, 1, 255);
    }

    Setting.b players;
    Setting.b passive;
    Setting.b mobs;
    Setting.b exp;
    Setting.b epearls;
    Setting.b crystals;
    Setting.b items;
    Setting.b orbs;

    Setting.b rainbow;
    Setting.i r;
    Setting.i g;
    Setting.i b;
    Setting.i a;
    Color c;

    public void onWorldRender(RenderEvent event){
        c = new Color(r.getValue(), g.getValue(), b.getValue(), a.getValue());
        if(rainbow.getValue()) c = new Color(Rainbow.getColor().getRed(), Rainbow.getColor().getGreen(), Rainbow.getColor().getBlue(), a.getValue());
        Color enemy = new Color(255, 0, 0, a.getValue());
        Color friend = new Color(0, 255, 255, a.getValue());
        mc.world.loadedEntityList.stream()
                .filter(entity -> entity != mc.player)
                .forEach(e -> {
                    Tessellator.prepareGL();
                    if(players.getValue() && e instanceof EntityPlayer) {
                        if (Friends.isFriend(e.getName())) Tessellator.drawBoundingBox(e.getRenderBoundingBox(), 1, friend.getRGB());
                        else Tessellator.drawBoundingBox(e.getRenderBoundingBox(), 1, enemy.getRGB());
                    }
                    if(mobs.getValue() && GlowESP.isMonster(e)){
                        Tessellator.drawBoundingBox(e.getRenderBoundingBox(), 1, c.getRGB());
                    }
                    if(passive.getValue() && GlowESP.isPassive(e)){
                        Tessellator.drawBoundingBox(e.getRenderBoundingBox(), 1, c.getRGB());
                    }
                    if(exp.getValue() && e instanceof EntityExpBottle){
                        Tessellator.drawBoundingBox(e.getRenderBoundingBox(), 1, c.getRGB());
                    }
                    if(epearls.getValue() && e instanceof EntityEnderPearl){
                        Tessellator.drawBoundingBox(e.getRenderBoundingBox(), 1, c.getRGB());
                    }
                    if(crystals.getValue() && e instanceof EntityEnderCrystal){
                        Tessellator.drawBoundingBox(e.getRenderBoundingBox(), 1, c.getRGB());
                    }
                    if(items.getValue() && e instanceof EntityItem){
                        Tessellator.drawBoundingBox(e.getRenderBoundingBox(), 1, c.getRGB());
                    }
                    if(orbs.getValue() && e instanceof EntityXPOrb){
                        Tessellator.drawBoundingBox(e.getRenderBoundingBox(), 1, c.getRGB());
                    }
                    Tessellator.releaseGL();
                });
    }
}
