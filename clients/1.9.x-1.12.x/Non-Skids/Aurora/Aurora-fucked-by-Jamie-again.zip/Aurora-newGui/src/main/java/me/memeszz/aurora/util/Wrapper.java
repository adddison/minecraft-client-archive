/*    */
package me.memeszz.aurora.util;


 import com.mojang.realmsclient.gui.ChatFormatting;
 import me.memeszz.aurora.Aurora;
 import me.memeszz.aurora.event.EventProcessor;
 import me.memeszz.aurora.font.CFontRenderer;
 import net.minecraft.client.Minecraft;
 import net.minecraft.client.entity.EntityPlayerSP;
 import net.minecraft.util.text.ITextComponent;
 import net.minecraft.util.text.Style;
 import net.minecraft.util.text.TextComponentString;
 import net.minecraft.util.text.event.HoverEvent;
 import net.minecraft.world.World;
 import org.lwjgl.input.Keyboard;

 import java.awt.*;


public class Wrapper
 {
     private static CFontRenderer fontRenderer;
     public static final Aurora mod;
     private static String prefix;
     public static void init() { fontRenderer = Aurora.fontRenderer; }
     public static final Minecraft mc;

   public static Minecraft getMinecraft() { return Minecraft.getMinecraft(); }


   public static EntityPlayerSP getPlayer() { return (getMinecraft()).player; }


   public static World getWorld() { return (getMinecraft()).world; }


   public static int getKey(String keyname) { return Keyboard.getKeyIndex(keyname.toUpperCase()); }

     public static void sendErrorMessage(final String message) {
         if (Wrapper.mc.player == null) {
             return;
         }
     }
     static {
         mc = Minecraft.getMinecraft();
         mod = Aurora.getInstance();
         Wrapper.prefix = ChatFormatting.DARK_GRAY + "[" + ChatFormatting.AQUA + "Aurora" + ChatFormatting.DARK_GRAY + "] ";
     }
     public static void sendClientMessage(final String message) {
     if (Wrapper.mc.player == null) {
         return;
     }
     final ITextComponent itc = new TextComponentString(Wrapper.prefix + ChatFormatting.GRAY + message).setStyle(new Style().setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, (ITextComponent)new TextComponentString("Aurora"))));
     Wrapper.mc.ingameGUI.getChatGUI().printChatMessageWithOptionalDeletion(itc, 5936);
 }
     public static Color getRainbow() {
         return EventProcessor.INSTANCE.c;
     }

     public static Color getRainbow(final int alpha) {
         return new Color(EventProcessor.INSTANCE.c.getRed(), EventProcessor.INSTANCE.c.getGreen(), EventProcessor.INSTANCE.c.getBlue(), alpha);
     }
   public static CFontRenderer getFontRenderer() { return fontRenderer; }}
