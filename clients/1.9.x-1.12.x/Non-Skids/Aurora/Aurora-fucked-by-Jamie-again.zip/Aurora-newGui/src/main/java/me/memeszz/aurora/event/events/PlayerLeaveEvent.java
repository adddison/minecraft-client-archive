package me.memeszz.aurora.event.events;

import me.memeszz.aurora.event.AuroraEvent;

public class PlayerLeaveEvent extends AuroraEvent {

    private final String name;

    public PlayerLeaveEvent(String n){
        super();
        name = n;
    }

    public String getName(){
        return name;
    }


}
