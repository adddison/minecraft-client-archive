package me.memeszz.aurora.module.modules.movement;

import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.Aurora;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraftforge.client.event.InputUpdateEvent;

public class NoSlow extends Module {
    public NoSlow() {
        super("NoSlow", Category.MOVEMENT, "Prevents item use form slowing you down");
    }

    @EventHandler
    private Listener<InputUpdateEvent> eventListener = new Listener<>(event -> {
        if (mc.player.isHandActive() && !mc.player.isRiding()) {
            event.getMovementInput().moveStrafe *= 5;
            event.getMovementInput().moveForward *= 5;
        }
    });

    public void onEnable(){
        Aurora.EVENT_BUS.subscribe(this);
    }

    public void onDisable(){
        Aurora.EVENT_BUS.unsubscribe(this);
    }
}
