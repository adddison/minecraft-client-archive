package me.memeszz.aurora.module.modules.gui;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.memeszz.aurora.Aurora;
import me.memeszz.aurora.friends.Friends;
import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.setting.Setting;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;

import java.awt.*;
import java.text.DecimalFormat;

public class TextRadar extends Module {
    public TextRadar() {
        super("PlayerRadar", Category.GUI, "Attacks nearby players");
    }
    private Setting.b sortUp;
    private Setting.b right;
    private Setting.b customFont;
    private Setting.b rainbow;
    Setting.i x;
    Setting.i y;
    Setting.i red;
    Setting.i green;
    Setting.i blue;
    Setting.b distance;
    int modCount;
    int sort;

    String s = "";
    int count;
    DecimalFormat decimalFormat = new DecimalFormat("00.0");
    ChatFormatting cf;
    Color c;
    public void setup() {
        customFont = this.registerB("CustomFont", true);
        right = this.registerB("RightSide", true);
        x = this.registerI("X",  255, 0, 960);
        y = this.registerI("Y",  255, 0, 530);
        red = this.registerI("Red",  255, 0, 255);
        green = this.registerI("Green",  255, 0, 255);
        blue = this.registerI("Blue",  255, 0, 255);
        distance = this.registerB("Distance", true);


    }

    public void onRender(){
        boolean font = customFont.getValue();
        count = 0;
        mc.world.loadedEntityList.stream()
                .filter(e->e instanceof EntityPlayer)
                .filter(e->e != mc.player)
                .forEach(e->{
                    if(Friends.isFriend(e.getName())) cf = ChatFormatting.AQUA;
                    else if(((EntityPlayer) e).isPotionActive(MobEffects.STRENGTH)) cf = ChatFormatting.RED;
                    else cf = ChatFormatting.LIGHT_PURPLE;
                    if((((EntityPlayer) e).getHealth() + ((EntityPlayer) e).getAbsorptionAmount()) <= 5) s = ChatFormatting.RED +" "+ decimalFormat.format((((EntityPlayer) e).getHealth() + ((EntityPlayer) e).getAbsorptionAmount()));
                    if((((EntityPlayer) e).getHealth() + ((EntityPlayer) e).getAbsorptionAmount()) > 5 && (((EntityPlayer) e).getHealth() + ((EntityPlayer) e).getAbsorptionAmount()) <=15) s = ChatFormatting.YELLOW +" "+ decimalFormat.format((((EntityPlayer) e).getHealth() + ((EntityPlayer) e).getAbsorptionAmount()));
                    if((((EntityPlayer) e).getHealth() + ((EntityPlayer) e).getAbsorptionAmount()) >15) s = ChatFormatting.GREEN +" "+ decimalFormat.format((((EntityPlayer) e).getHealth() + ((EntityPlayer) e).getAbsorptionAmount()));
                    if(distance.getValue()) s += " " + ChatFormatting.GRAY + (int)mc.player.getDistance(e);
                    if(right.getValue()) {
                        if(font) Aurora.fontRenderer.drawStringWithShadow(cf + e.getName() + s, (int) x.getValue() - Aurora.fontRenderer.getStringWidth(cf + e.getName() + s), (int) y.getValue() + count, 0xffffffff);
                        else mc.fontRenderer.drawStringWithShadow(cf + e.getName() + s, (int) x.getValue() - mc.fontRenderer.getStringWidth(cf + e.getName() + s), (int) y.getValue() + count, 0xffffffff);
                    } else {
                        if(font) Aurora.fontRenderer.drawStringWithShadow(cf + e.getName() + s, (int) x.getValue(), (int) y.getValue() + count, 0xffffffff);
                        else mc.fontRenderer.drawStringWithShadow(cf + e.getName() + s, (int) x.getValue(), (int) y.getValue() + count, 0xffffffff);
                    }
                    count += 10;
                });
    }
}