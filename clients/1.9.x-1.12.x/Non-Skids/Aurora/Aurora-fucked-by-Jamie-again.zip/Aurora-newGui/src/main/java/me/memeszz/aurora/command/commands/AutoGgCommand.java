package me.memeszz.aurora.command.commands;

import me.memeszz.aurora.command.Command;
import me.memeszz.aurora.module.modules.chat.AutoGG;
import me.memeszz.aurora.util.Wrapper;

public class AutoGgCommand extends Command {
    @Override
    public String[] getAlias() {
        return new String[]{"autogg", "autoez"};
    }

    @Override
    public String getSyntax() {
        return "autogg <add | del> <message> (use \"{name}\" for the player's name, use \"_\" for spaces)";
    }

    @Override
    public void onCommand(String command, String[] args) throws Exception {
        String s = args[1].replace("_", " ");
        if(args[0].equalsIgnoreCase("add")) {
            if (!AutoGG.getAutoGgMessages().contains(s)) {
                AutoGG.addAutoGgMessage(s);
                Wrapper.sendClientMessage("Added AutoGG message: " + s);
            } else {
                Wrapper.sendClientMessage("AutoGG list doesn't contain " + s);
            }
        } else if (args[0].equalsIgnoreCase("del") || args[0].equalsIgnoreCase("remove")){
            AutoGG.getAutoGgMessages().remove(s);
            Wrapper.sendClientMessage("Removed AutoGG message: " + s);
        }
    }
}
