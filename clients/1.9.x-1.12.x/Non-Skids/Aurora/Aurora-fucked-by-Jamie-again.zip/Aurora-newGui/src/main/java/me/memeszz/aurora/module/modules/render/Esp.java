package me.memeszz.aurora.module.modules.render;

import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.event.events.RenderEvent;
import me.memeszz.aurora.friends.Friends;
import me.memeszz.aurora.setting.Setting;
import me.memeszz.aurora.util.GeometryMasks;
import me.memeszz.aurora.util.Tessellator;
import me.memeszz.aurora.util.Rainbow;
import net.minecraft.entity.item.*;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public class Esp extends Module {
    public Esp() {
        super("Esp", Category.RENDER, "Draws a box around entities");
        players = this.registerB("Players", false);
        passive = this.registerB("Passive", false);
        mobs = this.registerB("Mobs", false);
        exp = this.registerB("XpBottles", false);
        crystals = this.registerB("Crystals", false);
        items = this.registerB("Items", false);
        orbs = this.registerB("XpOrbs", false);
        rainbow = this.registerB("Rainbow", false);
        r = this.registerI("Red", 255, 1, 255);
        g = this.registerI("Green", 255, 1, 255);
        b = this.registerI("Blue", 255, 1, 255);
        a = this.registerI("Alpha", 50, 1, 255);
    }

    Setting.b players;
    Setting.b passive;
    Setting.b mobs;
    Setting.b exp;
    Setting.b crystals;
    Setting.b items;
    Setting.b orbs;

    Setting.b rainbow;
    Setting.i r;
    Setting.i g;
    Setting.i b;
    Setting.i a;

    public void onWorldRender(RenderEvent event){
        Color c = new Color(r.getValue(), g.getValue(), b.getValue(), a.getValue());
        if(rainbow.getValue()) c = new Color(Rainbow.getColor().getRed(), Rainbow.getColor().getGreen(), Rainbow.getColor().getBlue(), a.getValue());
        Color enemy = new Color(255, 0, 0, a.getValue());
        Color friend = new Color(0, 255, 255, a.getValue());
        Color finalC = c;
        mc.world.loadedEntityList.stream()
                .filter(entity -> entity != mc.player)
                .forEach(e -> {
                    Tessellator.prepare(GL11.GL_QUADS);
                    if(players.getValue() && e instanceof EntityPlayer) {
                        if (Friends.isFriend(e.getName())) Tessellator.drawBox(e.getRenderBoundingBox(), friend.getRGB(), GeometryMasks.Quad.ALL);
                        else Tessellator.drawBox(e.getRenderBoundingBox(), enemy.getRGB(), GeometryMasks.Quad.ALL);
                    }
                    if(mobs.getValue() && GlowESP.isMonster(e)){
                        Tessellator.drawBox(e.getRenderBoundingBox(), finalC.getRGB(), GeometryMasks.Quad.ALL);
                    }
                    if(passive.getValue() && GlowESP.isPassive(e)){
                        Tessellator.drawBox(e.getRenderBoundingBox(), finalC.getRGB(), GeometryMasks.Quad.ALL);
                    }
                    if(exp.getValue() && e instanceof EntityExpBottle){
                        Tessellator.drawBox(e.getRenderBoundingBox(), finalC.getRGB(), GeometryMasks.Quad.ALL);
                    }
                    if(crystals.getValue() && e instanceof EntityEnderCrystal){
                        Tessellator.drawBox(e.getRenderBoundingBox(), finalC.getRGB(), GeometryMasks.Quad.ALL);
                    }
                    if(items.getValue() && e instanceof EntityItem){
                        Tessellator.drawBox(e.getRenderBoundingBox(), finalC.getRGB(), GeometryMasks.Quad.ALL);
                    }
                    if(orbs.getValue() && e instanceof EntityXPOrb){
                        Tessellator.drawBox(e.getRenderBoundingBox(), finalC.getRGB(), GeometryMasks.Quad.ALL);
                    }
                    Tessellator.release();
                });
    }
}
