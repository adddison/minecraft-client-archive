package me.memeszz.aurora.module.modules.chat;

import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.Aurora;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraftforge.client.event.ClientChatReceivedEvent;

public class AutoReply extends Module {
    public AutoReply() {
        super("AutoReply", Category.CHAT, "Reply to whispers");
    }

    private static String reply = "fuck off";

    @EventHandler
    private Listener<ClientChatReceivedEvent> listener = new Listener<>(event ->{
        if( event.getMessage().getUnformattedText().contains("whispers: ") && !event.getMessage().getUnformattedText().startsWith(mc.player.getName())){
            mc.player.sendChatMessage("/r " + reply);
        }
    });

    public static String getReply(){
        return reply;
    }

    public static void setReply(String r){
        reply = r;
    }

    public void onEnable(){
        Aurora.EVENT_BUS.subscribe(this);
    }

    public void onDisable(){
        Aurora.EVENT_BUS.unsubscribe(this);
    }
}
