

package me.memeszz.aurora.module.modules.gui;

import me.memeszz.aurora.Aurora;
import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.setting.Setting;
import me.memeszz.aurora.util.Rainbow;
import me.memeszz.aurora.util.Wrapper;

import java.awt.*;

import static me.memeszz.aurora.Aurora.MODNAME;
import static me.memeszz.aurora.Aurora.MODVER;

/**
 * Memeszz
 */
public class Ping extends Module {
    public Ping() {
        super("Ping", Category.GUI, "Attacks nearby players");
    }
    private Setting.b customFont;
    private Setting.b rainbow;
    Setting.i x;
    Setting.i y;
    Setting.i red;
    Setting.i green;
    Setting.i blue;
    Color c;
    public void setup() {
        customFont = this.registerB("CustomFont", false);
        x = this.registerI("X",  255, 0, 905);
        y = this.registerI("Y",  255, 0, 503);
        red = this.registerI("Red",  255, 0, 255);
        green = this.registerI("Green",  255, 0, 255);
        blue = this.registerI("Blue",  255, 0, 255);
        rainbow = this.registerB("Rainbow", false);

    }
    public void onRender(){
        Color c = new Color((int)red.getValue(), (int)green.getValue(), (int)blue.getValue());
        if(!rainbow.getValue())
            drawStringWithShadow(getPing() + " \u00A78Ping", (int)x.getValue(), (int)y.getValue(), c.getRGB());
        else
            drawStringWithShadow(getPing() + " \u00A78Ping", (int)x.getValue(), (int)y.getValue(), Rainbow.getInt());
    }

    public int getPing(){
        int p = -1;
        if(mc.player == null || mc.getConnection() == null || mc.getConnection().getPlayerInfo(mc.player.getName()) == null || mc.player.getName() == null){
            p = -1;
        } else {
            p = mc.getConnection().getPlayerInfo(mc.player.getName()).getResponseTime();
        }
        return p;
    }

    private void drawStringWithShadow(String text, int x, int y, int color){
        if(customFont.getValue())
            Aurora.fontRenderer.drawStringWithShadow(text, x, y, color);
        else
            mc.fontRenderer.drawStringWithShadow(text, x, y, color);
    }
}