////
//// Decompiled by Procyon v0.5.36
////
//
//package com.elementars.eclient.module.render;
//
//import me.memeszz.aurora.module.Module;
//import me.memeszz.aurora.setting.Setting;
//import net.minecraft.entity.player.EntityPlayer;
//import net.minecraft.util.math.Vec3d;
//import net.minecraft.block.state.IBlockState;
//import com.elementars.eclient.command.Command;
//import net.minecraft.world.World;
//import net.minecraft.entity.Entity;
//import com.elementars.eclient.util.MathUtil;
//import com.elementars.eclient.util.KamiTessellator;
//import java.awt.Color;
//import com.elementars.eclient.event.events.RenderEvent;
//import java.util.Iterator;
//import net.minecraft.util.math.Vec3i;
//import com.elementars.eclient.util.SettingLookup;
//import net.minecraft.block.material.Material;
//import net.minecraft.init.Blocks;
//import com.elementars.eclient.util.RainbowUtils;
//import com.elementars.eclient.Eclient;
//import com.elementars.eclient.module.Category;
//import de.Hero.settings.Setting;
//import java.util.concurrent.ConcurrentHashMap;
//import net.minecraft.util.math.BlockPos;
//import java.util.ArrayList;
//import com.elementars.eclient.module.Module;
//
//public class HoleESP extends Module {
//
//    public HoleESP() {
//
//        super("HoleESP", Category.RENDER, "Attacks nearby players");
//    }
//    BlockPos[] blockcheck;
//    private ConcurrentHashMap<BlockPos, Boolean> holes;
//    private int totalholes;
//    BlockPos pos;
//    private Setting.b announceUsage;
//    private Setting.d range;
//    private Setting.b rotate;
//    private Setting.i tickDelay;
//    private Setting.i blocksPerTick;
//    Setting.mode mode;
//
//    public void setup() {
//        ArrayList<String> modes = new ArrayList<>();
//        modes.add("Full");
//        modes.add("Feet");
//        modes.add("Body");
//        mode = this.registerMode("Mode", modes, "Full");
//        range = this.registerD("Range", 4.5, 0.0, 6.0);
//        blocksPerTick = this.registerI("BPT", 4, 0, 10);
//        tickDelay = this.registerI("TimeoutTicks", 1, 0, 10);
//        announceUsage = this.registerB("Announce", true);
//        rotate = this.registerB("Rotate", true);
//    }
//    private EntityPlayer closestTarget;
//    private String lastTickTargetName;
//    private int playerHotbarSlot = -1;
//    private int lastHotbarSlot = -1;
//    private int delayStep = 0;
//    private boolean isSneaking = false;
//    private int offsetStep = 0;
//    private boolean firstRun;
//
//
//    @Override
//    public void onUpdate() {
//        this.holes = new ConcurrentHashMap<BlockPos, Boolean>();
//        this.totalholes = 0;
//        final Iterable<BlockPos> blocks = (Iterable<BlockPos>)BlockPos.getAllInBox(HoleESP.mc.player.getPosition().add(-this.range.getValue(), -this.range.getValDouble(), -this.range.getValDouble()), HoleESP.mc.player.getPosition().add(this.range.getValDouble(), this.range.getValDouble(), this.range.getValDouble()));
//        for (final BlockPos pos : blocks) {
//            if (!HoleESP.mc.world.getBlockState(pos).getMaterial().blocksMovement() && !HoleESP.mc.world.getBlockState(pos.add(0, 1, 0)).getMaterial().blocksMovement()) {
//                final boolean solidNeighbours = (HoleESP.mc.world.getBlockState(pos.add(0, -1, 0)).getBlock() == Blocks.BEDROCK | HoleESP.mc.world.getBlockState(pos.add(0, -1, 0)).getBlock() == Blocks.OBSIDIAN) && (HoleESP.mc.world.getBlockState(pos.add(1, 0, 0)).getBlock() == Blocks.BEDROCK | HoleESP.mc.world.getBlockState(pos.add(1, 0, 0)).getBlock() == Blocks.OBSIDIAN) && (HoleESP.mc.world.getBlockState(pos.add(0, 0, 1)).getBlock() == Blocks.BEDROCK | HoleESP.mc.world.getBlockState(pos.add(0, 0, 1)).getBlock() == Blocks.OBSIDIAN) && (HoleESP.mc.world.getBlockState(pos.add(-1, 0, 0)).getBlock() == Blocks.BEDROCK | HoleESP.mc.world.getBlockState(pos.add(-1, 0, 0)).getBlock() == Blocks.OBSIDIAN) && (HoleESP.mc.world.getBlockState(pos.add(0, 0, -1)).getBlock() == Blocks.BEDROCK | HoleESP.mc.world.getBlockState(pos.add(0, 0, -1)).getBlock() == Blocks.OBSIDIAN) && HoleESP.mc.world.getBlockState(pos.add(0, 0, 0)).getMaterial() == Material.AIR && HoleESP.mc.world.getBlockState(pos.add(0, 1, 0)).getMaterial() == Material.AIR && HoleESP.mc.world.getBlockState(pos.add(0, 2, 0)).getMaterial() == Material.AIR;
//                if (!solidNeighbours) {
//                    continue;
//                }
//                if (SettingLookup.getSettingFromMod(this, "Maximum").getValBoolean() && this.totalholes >= this.holesnum.getValDouble()) {
//                    break;
//                }
//                if (SettingLookup.getSettingFromMod(this, "Color Difference").getValBoolean()) {
//                    boolean isBrock = true;
//                    for (final BlockPos pos2 : this.blockcheck) {
//                        if (HoleESP.mc.world.getBlockState(pos.add((Vec3i)pos2)).getBlock() != Blocks.BEDROCK) {
//                            isBrock = false;
//                        }
//                    }
//                    this.holes.put(pos, isBrock);
//                }
//                else {
//                    this.holes.put(pos, false);
//                }
//                ++this.totalholes;
//            }
//        }
//    }
//
//    @Override
//    public void onWorldRender(final RenderEvent event) {
//        final int[] color1 = new int[1];
//        final int[] color2 = new int[1];
//        final int[] color3 = new int[1];
//        final IBlockState[] iBlockState3 = new IBlockState[1];
//        final Vec3d[] interp3 = new Vec3d[1];
//        final IBlockState[] iBlockState4 = new IBlockState[1];
//        final Vec3d[] interp4 = new Vec3d[1];
//        final IBlockState[] iBlockState5 = new IBlockState[1];
//        final Vec3d[] interp5 = new Vec3d[1];
//        final IBlockState[] iBlockState6 = new IBlockState[1];
//        final Vec3d[] interp6 = new Vec3d[1];
//        this.holes.forEach((blockPos, isBedrock) -> {
//            if (SettingLookup.getSettingFromMod(this, "Offset Lower").getValBoolean()) {
//                blockPos = blockPos.add(0, -1, 0);
//            }
//            color1[0] = (int)this.red.getValDouble();
//            color2[0] = (int)this.green.getValDouble();
//            color3[0] = (int)this.blue.getValDouble();
//            if (SettingLookup.getSettingFromMod(this, "Rainbow").getValBoolean()) {
//                color1[0] = RainbowUtils.r;
//                color2[0] = RainbowUtils.g;
//                color3[0] = RainbowUtils.b;
//            }
//            if (SettingLookup.getSettingFromMod(this, "Color Difference").getValBoolean()) {
//                if (isBedrock) {
//                    color1[0] = Color.green.getRed();
//                    color2[0] = Color.green.getGreen();
//                    color3[0] = Color.green.getBlue();
//                }
//                else {
//                    color1[0] = Color.red.getRed();
//                    color2[0] = Color.red.getGreen();
//                    color3[0] = Color.red.getBlue();
//                }
//            }
//            if (this.mode.getValString().equalsIgnoreCase("Solid")) {
//                KamiTessellator.prepare(7);
//                KamiTessellator.drawBox(blockPos, color1[0], color2[0], color3[0], (int)this.alpha.getValDouble(), 63);
//                KamiTessellator.release();
//            }
//            else if (this.mode.getValString().equalsIgnoreCase("Solid Flat")) {
//                KamiTessellator.prepare(7);
//                KamiTessellator.drawFace(blockPos, color1[0], color2[0], color3[0], (int)this.alpha.getValDouble(), 63);
//                KamiTessellator.release();
//            }
//            else if (this.mode.getValString().equalsIgnoreCase("Full")) {
//                iBlockState3[0] = HoleESP.mc.world.getBlockState(blockPos);
//                interp3[0] = MathUtil.interpolateEntity((Entity)HoleESP.mc.player, HoleESP.mc.getRenderPartialTicks());
//                KamiTessellator.drawFullBox(iBlockState3[0].getSelectedBoundingBox((World)HoleESP.mc.world, blockPos).grow(0.0020000000949949026).offset(-interp3[0].x, -interp3[0].y, -interp3[0].z), blockPos, 1.5f, color1[0], color2[0], color3[0], (int)this.alpha.getValDouble(), (int)this.alpha2.getValDouble());
//            }
//            else if (this.mode.getValString().equalsIgnoreCase("Full Flat")) {
//                iBlockState4[0] = HoleESP.mc.world.getBlockState(blockPos);
//                interp4[0] = MathUtil.interpolateEntity((Entity)HoleESP.mc.player, HoleESP.mc.getRenderPartialTicks());
//                KamiTessellator.drawFullFace(iBlockState4[0].getSelectedBoundingBox((World)HoleESP.mc.world, blockPos).grow(0.0020000000949949026).offset(-interp4[0].x, -interp4[0].y, -interp4[0].z), blockPos, 1.5f, color1[0], color2[0], color3[0], (int)this.alpha.getValDouble(), (int)this.alpha2.getValDouble());
//            }
//            else if (this.mode.getValString().equalsIgnoreCase("Outline")) {
//                iBlockState5[0] = HoleESP.mc.world.getBlockState(blockPos);
//                interp5[0] = MathUtil.interpolateEntity((Entity)HoleESP.mc.player, HoleESP.mc.getRenderPartialTicks());
//                KamiTessellator.drawBoundingBox(iBlockState5[0].getSelectedBoundingBox((World)HoleESP.mc.world, blockPos).grow(0.0020000000949949026).offset(-interp5[0].x, -interp5[0].y, -interp5[0].z), 1.5f, color1[0], color2[0], color3[0], (int)this.alpha.getValDouble());
//            }
//            else if (this.mode.getValString().equalsIgnoreCase("Outline Flat")) {
//                iBlockState6[0] = HoleESP.mc.world.getBlockState(blockPos);
//                interp6[0] = MathUtil.interpolateEntity((Entity)HoleESP.mc.player, HoleESP.mc.getRenderPartialTicks());
//                KamiTessellator.drawBoundingBoxFace(iBlockState6[0].getSelectedBoundingBox((World)HoleESP.mc.world, blockPos).grow(0.0020000000949949026).offset(-interp6[0].x, -interp6[0].y, -interp6[0].z), 1.5f, color1[0], color2[0], color3[0], (int)this.alpha.getValDouble());
//            }
//            else {
//                Command.sendChatMessage("Error! HoleESP Mode not found!");
//            }
//        });
//    }
//}
//