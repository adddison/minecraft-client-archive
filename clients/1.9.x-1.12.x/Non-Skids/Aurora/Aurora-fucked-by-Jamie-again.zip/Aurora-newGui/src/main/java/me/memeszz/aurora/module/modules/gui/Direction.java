

package me.memeszz.aurora.module.modules.gui;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.memeszz.aurora.Aurora;
import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.setting.Setting;
import me.memeszz.aurora.util.Rainbow;

import java.awt.*;

/**
 * Memeszz
 */
public class Direction extends Module {
    public Direction() {
        super("Direction", Category.GUI, "Attacks nearby players");
    }
    private Setting.b customFont;
    private Setting.b rainbow;
    Setting.i x;
    Setting.i y;
    Setting.i red;
    Setting.i green;
    Setting.i blue;
    String coords;
    public void setup() {
        customFont = this.registerB("CustomFont", false);
        x = this.registerI("X",  255, 0, 905);
        y = this.registerI("Y",  255, 0, 530);
        red = this.registerI("Red",  255, 0, 255);
        green = this.registerI("Green",  255, 0, 255);
        blue = this.registerI("Blue",  255, 0, 255);
        rainbow = this.registerB("Rainbow", false);

    }
    public void onRender() {
        if (mc.player.dimension == -1) {
            coords = mc.player.getPosition().getX() + ", " + mc.player.getPosition().getY() + ", " + mc.player.getPosition().getZ() +
                    ChatFormatting.DARK_GRAY + "[" + ChatFormatting.RESET + mc.player.getPosition().getX() * 8 + ", " + mc.player.getPosition().getZ() * 8 + ChatFormatting.DARK_GRAY + "]";
        } else {
            coords = mc.player.getPosition().getX() + ", " + mc.player.getPosition().getY() + ", " + mc.player.getPosition().getZ() +
                    ChatFormatting.DARK_GRAY + "[" + ChatFormatting.RESET + mc.player.getPosition().getX() / 8 + ", " + mc.player.getPosition().getZ() / 8 + ChatFormatting.DARK_GRAY + "]";
        }
        Color c = new Color((int) red.getValue(), (int) green.getValue(), (int) blue.getValue());
        if(rainbow.getValue())
            drawStringWithShadow(coords, (int)x.getValue(), (int)y.getValue(), Rainbow.getInt());
        else
            drawStringWithShadow(coords, (int) x.getValue(), (int) y.getValue(), c.getRGB());
    }
    private void drawStringWithShadow(String text, int x, int y, int color){
        if(customFont.getValue())
            Aurora.fontRenderer.drawStringWithShadow(text, x, y, color);
        else
            mc.fontRenderer.drawStringWithShadow(text, x, y, color);
    }
}