package me.memeszz.aurora.module.modules.chat;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.Aurora;
import me.memeszz.aurora.setting.Setting;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.client.event.ClientChatReceivedEvent;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ChatTimeStamps extends Module {
    public ChatTimeStamps() {
        super("ChatTimeStamps", Category.CHAT);
        ArrayList<String> formats = new ArrayList<>();
        formats.add("H24:mm");
        formats.add("H12:mm");
        formats.add("H12:mm a");
        formats.add("H24:mm:ss");
        formats.add("H12:mm:ss");
        formats.add("H12:mm:ss a");
        ArrayList<String> deco = new ArrayList<>(); deco.add("< >"); deco.add("[ ]"); deco.add("{ }"); deco.add(" ");
        ArrayList<String> colors = new ArrayList<>();
        for(ChatFormatting cf : ChatFormatting.values()){
            colors.add(cf.getName());
        }

        format = this.registerMode("Format", formats, "H12:mm");
        color = this.registerMode("Color", colors, ChatFormatting.AQUA.getName());
        decoration =  this.registerMode("Deco",deco, "< >");
        space = this.registerB("Space", true);
    }

    Setting.mode format;
    Setting.mode color;
    Setting.mode decoration;
    Setting.b space;

    @EventHandler
    private Listener<ClientChatReceivedEvent> listener = new Listener<>(event -> {
        String decoLeft = decoration.getValue().equalsIgnoreCase(" ") ? "" : decoration.getValue().split(" ")[0];
        String decoRight = decoration.getValue().equalsIgnoreCase(" ") ? "" : decoration.getValue().split(" ")[1];
        if(space.getValue()) decoRight += " ";
        String dateFormat = format.getValue().replace("H24", "k").replace("H12", "h");
        String date = new SimpleDateFormat(dateFormat).format(new Date());
        TextComponentString time = new TextComponentString(ChatFormatting.getByName(color.getValue()) + decoLeft + date + decoRight + ChatFormatting.RESET);
        event.setMessage(time.appendSibling(event.getMessage()));
    });

    public void onEnable(){
        Aurora.EVENT_BUS.subscribe(this);
    }

    public void onDisable(){
        Aurora.EVENT_BUS.unsubscribe(this);
    }

}
