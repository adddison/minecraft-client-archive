//package me.memeszz.aurora.module.modules.player;
//
//import me.memeszz.aurora.module.Module;
//import me.memeszz.aurora.setting.Setting;
//import net.minecraft.block.Block;
//import net.minecraft.block.state.IBlockState;
//import net.minecraft.client.Minecraft;
//import net.minecraft.network.play.client.CPacketPlayerDigging;
//import net.minecraft.util.EnumHand;
//import net.minecraft.util.math.BlockPos;
//
//import java.util.ArrayList;
//
//
//public class SpeedMine extends Module {
//    public SpeedMine() {
//        super("SpeedMine", Category.PLAYER, "Mine blocks faster");
//    }
//    private Setting.b announceUsage;
//    private Setting.d range;
//    private Setting.b reset;
//    private Setting.i tickDelay;
//    private Setting.i blocksPerTick;
//    Setting.mode mode;
//    public void setup() {
//
//        ArrayList<String> modes = new ArrayList<>();
//        modes.add("Full");
//        modes.add("Feet");
//        modes.add("Body");
//        mode = this.registerMode("Mode", modes, "Full");
//        range = this.registerD("Range", 4.5, 0.0, 6.0);
//        blocksPerTick = this.registerI("BPT", 4, 0, 10);
//        tickDelay = this.registerI("TimeoutTicks", 1, 0, 10);
//        announceUsage = this.registerB("Announce", true);
//        reset = this.registerB("Reset", true);
//    }
//    public void onUpdate(){
//        {
//            Minecraft.getMinecraft().playerController.blockHitDelay = 0;
//
//            if (reset.getValue() && Minecraft.getMinecraft().gameSettings.keyBindUseItem.isKeyDown()) {
//                Minecraft.getMinecraft().playerController.isHittingBlock = false;
//            }
//        }
//    }
//            final Minecraft mc = Minecraft.getMinecraft();
//        if(mode.getValue().equalsIgnoreCase("Packet")) {
//                    mc.player.swingArm(EnumHand.MAIN_HAND);
//                    mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, event.getPos(), event.getFace()));
//                    mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, event.getPos(), event.getFace()));
//        if(mode.getValue().equalsIgnoreCase("Damage")) {
//                    if (mc.playerController.curBlockDamageMP >= 0.7f) {
//                        mc.playerController.curBlockDamageMP = 1.0f;
//                    }
//            if(mode.getValue().equalsIgnoreCase("Instant")) {
//                    mc.player.swingArm(EnumHand.MAIN_HAND);
//                    mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, event.getPos(), event.getFace()));
//                    mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, event.getPos(), event.getFace()));
//                    mc.playerController.onPlayerDestroyBlock(event.getPos());
//                    mc.world.setBlockToAir(event.getPos());
//            }
//        }
//
//        if (this.doubleBreak.getValue()) {
//            final BlockPos above = event.getPos().add(0, 1, 0);
//
//            final Minecraft mc = Minecraft.getMinecraft();
//
//            if (canBreak(above) && mc.player.getDistance(above.getX(), above.getY(), above.getZ()) <= 5f) {
//                mc.player.swingArm(EnumHand.MAIN_HAND);
//                mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, above, event.getFace()));
//                mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, above, event.getFace()));
//                mc.playerController.onPlayerDestroyBlock(above);
//                mc.world.setBlockToAir(above);
//            }
//        }
//    }
//
//    private boolean canBreak(BlockPos pos) {
//        final IBlockState blockState = Minecraft.getMinecraft().world.getBlockState(pos);
//        final Block block = blockState.getBlock();
//
//        return block.getBlockHardness(blockState, Minecraft.getMinecraft().world, pos) != -1;
//    }
//
//}