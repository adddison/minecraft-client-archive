

package me.memeszz.aurora.module.modules.gui;

import me.memeszz.aurora.Aurora;
import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.module.ModuleManager;
import me.memeszz.aurora.setting.Setting;
import me.memeszz.aurora.util.Wrapper;

import java.awt.*;

import static me.memeszz.aurora.Aurora.MODNAME;
import static me.memeszz.aurora.Aurora.MODVER;

/**
 * Memeszz
 */
public class PvPInfo extends Module {
    public PvPInfo() {
        super("PvpInfo", Category.GUI, "Info for pvp");
    }
    private Setting.b customFont;
    private Setting.b rainbow;
    Setting.i x;
    Setting.i y;
    Color c;
    public void setup() {
        customFont = this.registerB("CustomFont", false);
        x = this.registerI("X",  255, 0, 905);
        y = this.registerI("Y",  255, 0, 530);

    }
    public void onRender(){
        Color red = new Color(255, 255, 255);
        Color green = new Color(0, 255, 0);
        if(ModuleManager.isModuleEnabled("CrystalAura")){
            drawStringWithShadow("CrystalAura ON", x.getValue(), y.getValue(), green.getRGB());
        } else{
            drawStringWithShadow("CrystalAura OFF", x.getValue(), y.getValue(), red.getRGB());
        }
        if(ModuleManager.isModuleEnabled("KillAura")){
            drawStringWithShadow("KillAura ON", x.getValue(), y.getValue() + 10, green.getRGB());
        } else{
            drawStringWithShadow("KillAura OFF", x.getValue(), y.getValue() + 10, red.getRGB());
        }
        if(ModuleManager.isModuleEnabled("Surround")){
            drawStringWithShadow("Surround ON", x.getValue(), y.getValue() + 20, green.getRGB());
        } else{
            drawStringWithShadow("Surround OFF", x.getValue(), y.getValue() + 20, red.getRGB());
        }
        if(ModuleManager.isModuleEnabled("AutoTrap")){
            drawStringWithShadow("AutoTrap ON", x.getValue(), y.getValue() + 30, green.getRGB());
        } else{
            drawStringWithShadow("AutoTrap OFF", x.getValue(), y.getValue() + 30, red.getRGB());
        }
        if(ModuleManager.isModuleEnabled("AutoWeb")){
            drawStringWithShadow("AutoWeb ON", x.getValue(), y.getValue() + 40, green.getRGB());
        } else{
            drawStringWithShadow("AutoWeb OFF", x.getValue(), y.getValue() + 40, red.getRGB());
        }
        if(ModuleManager.isModuleEnabled("OffHandGap")){
            drawStringWithShadow("OffHandGap ON", x.getValue(), y.getValue() + 50, green.getRGB());
        } else{
            drawStringWithShadow("OffHandGap OFF", x.getValue(), y.getValue() + 50, red.getRGB());
        }
    }
    private void drawStringWithShadow(String text, int x, int y, int color){
        if(customFont.getValue())
            Aurora.fontRenderer.drawStringWithShadow(text, x, y, color);
        else
            mc.fontRenderer.drawStringWithShadow(text, x, y, color);
    }
}
//ez