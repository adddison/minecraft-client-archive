package me.memeszz.aurora.module.modules.gui;

import me.memeszz.aurora.Aurora;
import me.memeszz.aurora.macro.Macro;
import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.module.ModuleManager;
import me.memeszz.aurora.module.modules.chat.Announcer;
import me.memeszz.aurora.setting.Setting;
import me.memeszz.aurora.util.Wrapper;
import org.lwjgl.input.Keyboard;

public class ClickGuiModule extends Module {
    public ClickGuiModule INSTANCE;

    public static Setting.mode design;

    public static Setting.b rainbow;

    public static Setting.i red;

    public static Setting.i green;

    public static Setting.i blue;

    public Setting.b customFont;

    public ClickGuiModule() {
        super("ClickGUI", Category.GUI, "Opens the ClickGUI");
        setBind(Keyboard.KEY_P);
        INSTANCE = this;
    }

    public void setup(){
        customFont = this.registerB("CustomFont", false);

    }

    public void onEnable(){
        mc.displayGuiScreen(Aurora.getInstance().clickGui);
        if(((Announcer)ModuleManager.getModuleByName("Announcer")).clickGui.getValue() && ModuleManager.isModuleEnabled("Announcer") && mc.player != null)
            if(((Announcer)ModuleManager.getModuleByName("Announcer")).clientSide.getValue()){
                Wrapper.sendClientMessage(Announcer.guiMessage);
            } else {
                mc.player.sendChatMessage(Announcer.guiMessage);
            }
        disable();
    }
    private void drawStringWithShadow(String text, int x, int y, int color){
        if(customFont.getValue())
            Aurora.fontRenderer.drawStringWithShadow(text, x, y, color);
        else
            mc.fontRenderer.drawStringWithShadow(text, x, y, color);
    }
}