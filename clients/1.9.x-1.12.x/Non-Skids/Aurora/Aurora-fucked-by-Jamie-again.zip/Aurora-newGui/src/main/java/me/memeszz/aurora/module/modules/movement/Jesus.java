package me.memeszz.aurora.module.modules.movement;

import me.memeszz.aurora.module.Module;


public class Jesus extends Module {
    public Jesus() {
        super("Jesus", Category.MOVEMENT, "Walk on water, changing water to wine not implemented yet");
    }

    public void onUpdate(){
    }
}
