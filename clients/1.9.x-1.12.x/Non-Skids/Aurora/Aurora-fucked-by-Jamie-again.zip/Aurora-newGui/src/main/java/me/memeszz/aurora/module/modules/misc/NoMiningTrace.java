package me.memeszz.aurora.module.modules.misc;

import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.setting.Setting;
import net.minecraft.item.ItemPickaxe;


public class NoMiningTrace extends Module {
    private static NoMiningTrace INSTANCE;
    public NoMiningTrace() {
        super("NoEntityTrace", Category.COMBAT, "Attacks nearby players");
    }
    private Setting.b pickaxe;

    public static void setINSTANCE(NoMiningTrace INSTANCE) {
        NoMiningTrace.INSTANCE = INSTANCE;
    }


    public void setup() {
        this.pickaxe = this.registerB("PickaxeOnly", true);


    }
    // we need this singleton pattern to access the isEnabled method static



    // this gets called in MixinEntityRenderer
    public static boolean spoofTrace() {
        if (INSTANCE.isDisabled()) {
            return false;
        }
        if (INSTANCE.pickaxe.getValue() && !(mc.player.getHeldItemMainhand().getItem() instanceof ItemPickaxe)) {
            return false;
        }
        return true;
    }

}