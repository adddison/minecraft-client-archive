package me.memeszz.aurora.module.modules.movement;

import me.memeszz.aurora.module.Module;
import me.memeszz.aurora.setting.Setting;
import net.minecraft.init.Blocks;

public class IceSpeed extends Module {
   public IceSpeed() {
      super("IceSpeed", Category.MOVEMENT, "SPEED");
   }

   Setting.d speed;
      public void setup(){
            speed = this.registerD("Speed",  0.4, 0, 1.0);

   }
   public void onUpdate() {
      Blocks.ICE.slipperiness = (float) this.speed.getValue();
      Blocks.PACKED_ICE.slipperiness = (float) this.speed.getValue();
      Blocks.FROSTED_ICE.slipperiness = (float) this.speed.getValue();
   }

   public void onDisable() {
      Blocks.ICE.slipperiness = 0.98F;
      Blocks.PACKED_ICE.slipperiness = 0.98F;
      Blocks.FROSTED_ICE.slipperiness = 0.98F;
   }
}
