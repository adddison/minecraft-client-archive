class Compile:
	def __init__(self):
		self.run()

	def run(self):
		import os
		os.system("gradlew setupDecompWorkspace --stop && gradlew clean build")
		
		import shutil
		try:
			shutil.copyfile("aurora/build/libs/aurora-0.1-all.jar", os.getenv("APPDATA") + "\\.minecraft\\mods\\aurora-0.1.jar")
			os.system("start C:/Users/Public/Desktop/Minecraft_Launcher")
			print("Copiadokkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk")
		except:
			print("Ta sem o lib q se foda")

		import sys
		sys.exit()

Compile()