package me.finz0.osiris.module.modules.combat;

import me.finz0.osiris.command.Command;
import me.finz0.osiris.event.events.EventNetworkPacketEvent;
import me.finz0.osiris.event.events.EventPlayerUpdate;
import me.finz0.osiris.module.Module;
//import me.zero.alpine.listener.EventHandler;
//import me.zero.alpine.listener.Listener;
//import net.minecraft.entity.Entity;
//import net.minecraft.entity.player.EntityPlayer;
//import net.minecraft.network.play.server.SPacketEntityStatus;
//
//import java.util.HashMap;
//
//
//
//public class TotemPopCounter extends Module {
//    public TotemPopCounter() {
//        super("TotemPopCounter", Category.COMBAT);
//    }
//
//    private HashMap<String, Integer> TotemPopContainer = new HashMap<String, Integer>();
//    @EventHandler
//    private Listener<EventNetworkPacketEvent> PacketEvent = new Listener<>(p_Event ->
//    {
//        if (p_Event.getPacket() instanceof SPacketEntityStatus)
//        {
//            SPacketEntityStatus l_Packet = (SPacketEntityStatus)p_Event.getPacket();
//
//            if (l_Packet.getOpCode() == 35) ///< Opcode check the packet 35 is totem, thxmojang
//            {
//                Entity l_Entity = l_Packet.getEntity(mc.world);
//
//                if (l_Entity == null)
//                    return;
//
//                int l_Count = 1;
//
//                if (TotemPopContainer.containsKey(l_Entity.getName()))
//                {
//                    l_Count = TotemPopContainer.get(l_Entity.getName()).intValue();
//                    TotemPopContainer.put(l_Entity.getName(), ++l_Count);
//                }
//                else
//                {
//                    TotemPopContainer.put(l_Entity.getName(), l_Count);
//                }
//
//                Command.sendClientMessage(l_Entity.getName() + " popped " + l_Count + " totem(s)!");
//            }
//        }
//    });
//
//    @EventHandler
//    private Listener<EventPlayerUpdate> OnPlayerUpdate = new Listener<>(p_Event ->
//    {
//        for (EntityPlayer l_Player : mc.world.playerEntities)
//        {
//            if (!TotemPopContainer.containsKey(l_Player.getName()))
//                continue;
//
//            if (l_Player.isDead || l_Player.getHealth() <= 0.0f)
//            {
//                int l_Count = TotemPopContainer.get(l_Player.getName()).intValue();
//
//                TotemPopContainer.remove(l_Player.getName());
//
//           Command.sendClientMessage(l_Player.getName() + " died after popping " + l_Count + " totem(s)!");
//            }
//        }
//    });
//}