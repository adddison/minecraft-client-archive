package me.finz0.osiris.module.modules.combat;

import me.finz0.osiris.module.Module;
import net.minecraft.item.ItemSword;

/**
 * Memeszz
 */
public class PacketSwing extends Module {
    public PacketSwing() {
        super("PacketSwing", Category.COMBAT, "Swings differently should help to hit ppl phasing");
    }

    @Override
    public void onUpdate() {
        if (PacketSwing.mc.player.getHeldItemMainhand().getItem() instanceof ItemSword && PacketSwing.mc.entityRenderer.itemRenderer.prevEquippedProgressMainHand >= 0.9) {
            PacketSwing.mc.entityRenderer.itemRenderer.equippedProgressMainHand = 1.0f;
            PacketSwing.mc.entityRenderer.itemRenderer.itemStackMainHand = PacketSwing.mc.player.getHeldItemMainhand();
        }
    }
}
