// 
// Decompiled by Procyon v0.5.36
// 

package me.finz0.osiris.module.modules.combat;

import me.finz0.osiris.module.Module;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.util.EnumHand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.RayTraceResult;
import org.lwjgl.input.Mouse;
import net.minecraftforge.fml.common.gameevent.InputEvent;

/**
 * Memeszz
 */
public class MultiTask extends Module {
    public MultiTask() {
        super("MultiTask", Category.COMBAT);
    }

    @SubscribeEvent
    public void onMouseInput(final InputEvent.MouseInputEvent event) {
        if (Mouse.getEventButtonState() && MultiTask.mc.player != null && MultiTask.mc.objectMouseOver.typeOfHit.equals((Object)RayTraceResult.Type.ENTITY) && MultiTask.mc.player.isHandActive() && (MultiTask.mc.gameSettings.keyBindAttack.isPressed() || Mouse.getEventButton() == MultiTask.mc.gameSettings.keyBindAttack.getKeyCode())) {
            MultiTask.mc.playerController.attackEntity((EntityPlayer)MultiTask.mc.player, MultiTask.mc.objectMouseOver.entityHit);
            MultiTask.mc.player.swingArm(EnumHand.MAIN_HAND);
        }
    }
}
