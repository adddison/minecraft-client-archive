package me.finz0.osiris.module.modules.movement;

import me.finz0.osiris.module.Module;

public class HoleTP extends Module {
    public HoleTP() {
        super("HoleTP", Category.COMBAT, "Makes you fall down into holes faster");
    }

    public void onUpdate() {
        if (mc.player.onGround)
            --mc.player.motionY;
    }
}
