package me.finz0.osiris.friends;

public class Friend {
    String name;
    public Friend(String n){
        name = n;
    }

    public String getName(){
        return name;
    }
}
