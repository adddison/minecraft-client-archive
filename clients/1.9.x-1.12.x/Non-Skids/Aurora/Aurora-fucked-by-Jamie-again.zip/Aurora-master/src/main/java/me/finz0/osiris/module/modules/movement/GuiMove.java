package me.finz0.osiris.module.modules.movement;

import me.finz0.osiris.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.settings.KeyBinding;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class GuiMove extends Module {
    public GuiMove() {
        super("GuiMove", Category.MISC, "Let's you move in GUIs");
    }


    public void onUpdate(){
            final Minecraft mc = Minecraft.getMinecraft();

            if (mc.currentScreen instanceof GuiChat || mc.currentScreen == null) {
                return;
            }

            final int[] keys = new int[]{mc.gameSettings.keyBindForward.getKeyCode(), mc.gameSettings.keyBindLeft.getKeyCode(), mc.gameSettings.keyBindRight.getKeyCode(), mc.gameSettings.keyBindBack.getKeyCode()};

            for (int keyCode : keys) {
                if (Keyboard.isKeyDown(keyCode)) {
                    KeyBinding.setKeyBindState(keyCode, true);
                } else {
                    KeyBinding.setKeyBindState(keyCode, false);
                }
            }

            if (Keyboard.isKeyDown(mc.gameSettings.keyBindJump.getKeyCode())) {
                if (mc.player.isInLava() || mc.player.isInWater()) {
                    mc.player.motionY += 0.039f;
                } else {
                    if (mc.player.onGround) {
                        mc.player.jump();
                    }
                }
            }

            if (Mouse.isButtonDown(2)) {
                Mouse.setGrabbed(true);
                mc.inGameHasFocus = true;
            } else {
                Mouse.setGrabbed(false);
                mc.inGameHasFocus = false;
            }
        }
    }


