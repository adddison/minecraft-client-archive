
package me.finz0.osiris.module.modules.render;

import de.Hero.settings.Setting;
import io.netty.util.internal.ConcurrentSet;
import me.finz0.osiris.AuroraMod;
import me.finz0.osiris.event.events.RenderEvent;
import me.finz0.osiris.module.Module;
import me.finz0.osiris.module.modules.combat.AutoCrystal;
import me.finz0.osiris.util.BlockInteractionHelper;
import me.finz0.osiris.util.OsirisTessellator;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class VoidESP extends Module {
    public VoidESP() {
        super("VoidESP", Category.RENDER, "Shows voidholes");
    }

    Setting range;
    Setting activateAtY;
    Setting HoleMode;
    Setting RenderMode;
    Setting red;
    Setting green;
    Setting blue;
    Setting alpha;
    ConcurrentSet<BlockPos> voidHoles;

    public void setup() {
        range = new Setting("Range", this, 8, 0, 20, true, "VoidESPRange");
        AuroraMod.getInstance().settingsManager.rSetting(range);
        activateAtY = new Setting("ActivateAtY", this, 8, 1, 30, true, "VoidESPActivateAtY");
        AuroraMod.getInstance().settingsManager.rSetting(activateAtY);
        //
        ArrayList<String> holeM = new ArrayList<>();
        holeM.add("Down");
        holeM.add("Block");
        //
        HoleMode = new Setting("HoleMode", this, "Sides", holeM, "VoidESPMode");
        AuroraMod.getInstance().settingsManager.rSetting(HoleMode);
        //
        ArrayList<String> renderM = new ArrayList<>();
        renderM.add("Sides");
        renderM.add("Above");
        //
        RenderMode = new Setting("RenderMode", this, "Down", renderM, "VoidESPRenderMode");
        AuroraMod.getInstance().settingsManager.rSetting(RenderMode);
        red = new Setting("Red", this, 255, 0, 255, true, "HoleEspRed");
        AuroraMod.getInstance().settingsManager.rSetting(red);
        green = new Setting("Green", this, 255, 0, 255, true, "HoleEspGreen");
        AuroraMod.getInstance().settingsManager.rSetting(green);
        blue = new Setting("Blue", this, 255, 0, 255, true, "HoleEspBlue");
        AuroraMod.getInstance().settingsManager.rSetting(blue);

    }

    @Override
    public void onUpdate() {
        if ((double) VoidESP.mc.player.getPosition().getY() > this.activateAtY.getValDouble()) {
            return;
        }
        if (this.voidHoles == null) {
            this.voidHoles = new ConcurrentSet();
        } else {
            this.voidHoles.clear();
        }
        List<BlockPos> blockPosList = BlockInteractionHelper.getCircle(AutoCrystal.getPlayerPos(), 0, (float) this.range.getValDouble(), false);
        for (BlockPos pos : blockPosList) {
            if (VoidESP.mc.world.getBlockState(pos).getBlock().equals((Object) Blocks.BEDROCK) || this.isAnyBedrock(pos, Offsets.center))
                continue;
            boolean aboveFree = false;
            if (!this.isAnyBedrock(pos, Offsets.above)) {
                aboveFree = true;
            }
            if (this.HoleMode.getValString().equalsIgnoreCase("Above")) {
                if (!aboveFree) continue;
                this.voidHoles.add((BlockPos) pos);
                continue;
            }
            boolean sidesFree = false;
            if (!this.isAnyBedrock(pos, Offsets.north)) {
                sidesFree = true;
            }
            if (!this.isAnyBedrock(pos, Offsets.east)) {
                sidesFree = true;
            }
            if (!this.isAnyBedrock(pos, Offsets.south)) {
                sidesFree = true;
            }
            if (!this.isAnyBedrock(pos, Offsets.west)) {
                sidesFree = true;
            }
            if (!this.HoleMode.getValString().equalsIgnoreCase("Sides") || !aboveFree && !sidesFree) continue;
            this.voidHoles.add((BlockPos) pos);
        }
    }

    private boolean isAnyBedrock(BlockPos origin, BlockPos[] offset) {
        for (BlockPos pos : offset) {
            if (!VoidESP.mc.world.getBlockState(origin.add((Vec3i) pos)).getBlock().equals((Object) Blocks.BEDROCK))
                continue;
            return true;
        }
        return false;
    }

    @Override
    public void onWorldRender(RenderEvent event) {
        if (VoidESP.mc.player == null || this.voidHoles == null || this.voidHoles.isEmpty()) {
            return;
        }
        OsirisTessellator.prepare(7);
        this.voidHoles.forEach(blockPos -> this.drawBlock((BlockPos) blockPos, (int) this.red.getValDouble(), (int) this.green.getValDouble(), (int) this.blue.getValDouble()));
        OsirisTessellator.release();
    }

    private void drawBlock(BlockPos blockPos, int r, int g, int b) {
        Color color = new Color(r, g, b, (int) this.alpha.getValDouble());
        int mask = 0;
        if (this.RenderMode.getValString().equalsIgnoreCase("Block")) {
            mask = 63;
        }
        if (this.RenderMode.getValString().equalsIgnoreCase("Down")) {
            mask = 1;
        }
        OsirisTessellator.drawBox(blockPos, color.getRGB(), mask);
    }

    @Override
    public String getHudInfo() {
        return this.HoleMode.getValString();
    }

    private static class Offsets {
        static final BlockPos[] center = new BlockPos[]{new BlockPos(0, 1, 0), new BlockPos(0, 2, 0)};
        static final BlockPos[] above = new BlockPos[]{new BlockPos(0, 3, 0), new BlockPos(0, 4, 0)};
        static final BlockPos[] aboveStep1 = new BlockPos[]{new BlockPos(0, 3, 0)};
        static final BlockPos[] aboveStep2 = new BlockPos[]{new BlockPos(0, 4, 0)};
        static final BlockPos[] north = new BlockPos[]{new BlockPos(0, 1, -1), new BlockPos(0, 2, -1)};
        static final BlockPos[] east = new BlockPos[]{new BlockPos(1, 1, 0), new BlockPos(1, 2, 0)};
        static final BlockPos[] south = new BlockPos[]{new BlockPos(0, 1, 1), new BlockPos(0, 2, 1)};
        static final BlockPos[] west = new BlockPos[]{new BlockPos(-1, 1, 0), new BlockPos(-1, 2, 0)};

        private Offsets() {
        }
    }
}

