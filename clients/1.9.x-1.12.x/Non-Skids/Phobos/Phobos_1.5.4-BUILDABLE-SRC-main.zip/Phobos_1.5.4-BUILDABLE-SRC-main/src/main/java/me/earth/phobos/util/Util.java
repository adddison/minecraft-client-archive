// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.util;

import net.minecraft.client.Minecraft;

public interface Util
{
    public static final Minecraft mc = Minecraft.getMinecraft();
}
