// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.util;

public class MultiThread
{
    public static void startThreadLoop() {
    }
}
