package bleach.a32k.module.modules;

import bleach.a32k.module.*;
import java.util.*;
import bleach.a32k.settings.*;

public class RuhamaOntop extends Module
{
    public RuhamaOntop() {
        super("RuhamaOntop", 0, Category.MISC, "Ruhama best client", null);
    }
}
