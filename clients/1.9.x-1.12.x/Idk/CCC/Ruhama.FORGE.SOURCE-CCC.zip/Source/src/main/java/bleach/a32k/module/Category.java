package bleach.a32k.module;

public enum Category
{
    RENDER, 
    COMBAT, 
    MISC, 
    EXPLOITS
}
