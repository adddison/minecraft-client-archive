package io.github.giantnuker.pyro;

import net.minecraftforge.fml.common.Mod;

@Mod(
        modid = "pyroclient-loader",
        name = "Pyro Client",
        version = "loader-0.1"
)
public class Pyro {
}
