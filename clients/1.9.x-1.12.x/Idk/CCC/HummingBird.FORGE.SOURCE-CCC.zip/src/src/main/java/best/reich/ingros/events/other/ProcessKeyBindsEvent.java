package best.reich.ingros.events.other;

import net.b0at.api.event.Event;

/**
 * Author: TBM
 * Date: 5/7/20
 */
public class ProcessKeyBindsEvent extends Event {
}
