package best.reich.ingros.mixin.accessors;

public interface IPlayerSP {

    boolean isInLiquid();

    boolean isOnLiquid();

    boolean isMoving();

    void setInPortal(boolean inPortal);
}
