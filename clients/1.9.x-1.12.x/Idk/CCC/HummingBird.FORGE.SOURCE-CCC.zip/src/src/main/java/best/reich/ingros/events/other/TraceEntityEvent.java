package best.reich.ingros.events.other;

import net.b0at.api.event.Event;

public class TraceEntityEvent extends Event {
}
