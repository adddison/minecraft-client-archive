package best.reich.ingros.mixin.accessors;

public interface IEntityRenderer {
    void cameraOrientation(float partialTicks);
}
