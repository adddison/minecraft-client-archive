package best.reich.ingros.events.render;

import me.xenforu.kelo.module.type.ToggleableModule;

public class RenderModelEvent extends ToggleableModule {
}
