package best.reich.ingros.util.thealtening.utils;


import best.reich.ingros.util.thealtening.domain.AlteningAlt;

public class UserSkin {

    private final AlteningAlt account;

    public UserSkin(AlteningAlt account) {
        this.account = account;
    }



}
