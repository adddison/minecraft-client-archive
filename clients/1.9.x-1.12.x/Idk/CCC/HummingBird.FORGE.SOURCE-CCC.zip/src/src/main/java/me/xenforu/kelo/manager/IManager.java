package me.xenforu.kelo.manager;

/**
 * made by Xen for Kelo
 * at 1/3/2020
 **/
public interface IManager {
    void load();
    void unload();
}
