package best.reich.ingros.mixin.accessors;

public interface ISPacketPosLook {

    void setYaw(float yaw);

    void setPitch(float pitch);

}
