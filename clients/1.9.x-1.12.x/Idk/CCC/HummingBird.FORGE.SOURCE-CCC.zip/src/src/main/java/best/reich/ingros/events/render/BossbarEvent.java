package best.reich.ingros.events.render;

import net.b0at.api.event.Event;

public class BossbarEvent extends Event {
}
