package me.xenforu.kelo.traits;

import net.minecraft.client.Minecraft;

/**
 * made by Xen for IngrosWare
 * at 1/3/2020
 **/
public interface Minecraftable {
    Minecraft mc = Minecraft.getMinecraft();
}
