package best.reich.ingros.manager;

import me.xenforu.kelo.keybind.AbstractKeybindManager;

/**
 * made by Xen for IngrosWare
 * at 1/3/2020
 **/
public class KeybindManager extends AbstractKeybindManager {

    @Override
    public void load() {

    }

    @Override
    public void unload() {

    }
}
