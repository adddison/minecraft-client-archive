package best.reich.ingros.mixin.accessors;

public interface ICPacketTabComplete {

    void setMessage(String message);

}
