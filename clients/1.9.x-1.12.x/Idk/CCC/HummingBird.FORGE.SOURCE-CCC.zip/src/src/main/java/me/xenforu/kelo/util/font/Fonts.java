package me.xenforu.kelo.util.font;

import java.awt.*;

public class Fonts {
    public static final MCFontRenderer alataFont = new MCFontRenderer(new Font("Alata Regular", Font.PLAIN,18),true,true);
}
