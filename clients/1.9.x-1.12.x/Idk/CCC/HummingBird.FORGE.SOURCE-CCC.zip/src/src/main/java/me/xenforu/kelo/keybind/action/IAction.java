package me.xenforu.kelo.keybind.action;

/**
 * made by Xen for Kelo
 * at 1/3/2020
 **/
public interface IAction {
    void execute();
}
