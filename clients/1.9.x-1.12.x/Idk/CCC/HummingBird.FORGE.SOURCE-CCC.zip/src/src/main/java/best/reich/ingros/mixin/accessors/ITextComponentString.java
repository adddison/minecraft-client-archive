package best.reich.ingros.mixin.accessors;

public interface ITextComponentString {
    void setText(String text);
}
