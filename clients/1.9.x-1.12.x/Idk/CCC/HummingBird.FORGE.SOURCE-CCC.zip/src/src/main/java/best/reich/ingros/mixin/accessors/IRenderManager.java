package best.reich.ingros.mixin.accessors;

public interface IRenderManager {

    double getRenderPosX();
    double getRenderPosY();
    double getRenderPosZ();
}