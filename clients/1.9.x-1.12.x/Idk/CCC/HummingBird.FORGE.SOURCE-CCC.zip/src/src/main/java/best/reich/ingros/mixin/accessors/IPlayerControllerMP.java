package best.reich.ingros.mixin.accessors;

public interface IPlayerControllerMP {

    void setBlockHitDelay(int blockHitDelay);

    void setCurBlockDamageMP(float curBlockDamageMP);

    float getCurBlockDamageMP();
}
