package best.reich.ingros.mixin.accessors;

public interface IEntityLivingBase {
    boolean getIsJumping();
}
