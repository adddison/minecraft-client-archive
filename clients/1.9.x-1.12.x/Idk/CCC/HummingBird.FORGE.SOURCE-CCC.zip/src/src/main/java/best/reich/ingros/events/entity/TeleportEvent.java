package best.reich.ingros.events.entity;

import net.b0at.api.event.Event;

public class TeleportEvent extends Event {
}
