package me.finz0.osiris.event;

import me.zero.alpine.type.Cancellable;

public class OsirisEvent extends Cancellable {

    public OsirisEvent() {
    }
}
