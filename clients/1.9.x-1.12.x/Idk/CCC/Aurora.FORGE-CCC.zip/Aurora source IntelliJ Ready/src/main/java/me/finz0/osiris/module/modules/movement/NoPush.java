package me.finz0.osiris.module.modules.movement;

import me.finz0.osiris.module.Module;

public class NoPush extends Module {
    public NoPush() {
        super("NoPush", Category.MOVEMENT, "Don't get pushed by entities");
    }
}
