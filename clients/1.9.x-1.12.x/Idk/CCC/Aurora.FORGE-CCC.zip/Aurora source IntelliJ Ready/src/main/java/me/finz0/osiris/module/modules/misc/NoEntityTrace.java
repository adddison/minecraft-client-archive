package me.finz0.osiris.module.modules.misc;

import me.finz0.osiris.module.Module;

public class NoEntityTrace extends Module {
    public NoEntityTrace() {
        super("NoEntityTrace", Category.MISC);
    }
}
