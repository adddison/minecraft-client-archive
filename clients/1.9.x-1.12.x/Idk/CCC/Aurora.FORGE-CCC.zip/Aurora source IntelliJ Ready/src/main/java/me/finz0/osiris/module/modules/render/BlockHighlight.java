package me.finz0.osiris.module.modules.render;

import de.Hero.settings.Setting;
import me.finz0.osiris.module.Module;
import me.finz0.osiris.AuroraMod;
import me.finz0.osiris.event.events.RenderEvent;
import me.finz0.osiris.util.AuroraTessellator;
import me.finz0.osiris.util.GeometryMasks;
import me.finz0.osiris.util.OsirisTessellator;
import me.finz0.osiris.util.Rainbow;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public class BlockHighlight extends Module {
    public BlockHighlight() {
        super("BlockHighlight", Category.RENDER, "Highlights the block you're looking at");
    }

    Setting r;
    Setting g;
    Setting b;
    Setting w;

    Setting a;



    Setting boundingbox;
    Setting box;
    Setting rainbow;

    public void setup(){

        boundingbox = new Setting("boundingbox", this, true, "boundingbox");
        AuroraMod.getInstance().settingsManager.rSetting(boundingbox);
        r = new Setting("Red", this, 255, 0, 255, true, "BlockHighlightRed");
        AuroraMod.getInstance().settingsManager.rSetting(r);
        g = new Setting("Green", this, 255, 0, 255, true, "BlockHighlightGreen");
        AuroraMod.getInstance().settingsManager.rSetting(g);
        b = new Setting("Blue", this, 255, 0, 255, true, "BlockHighlightBlue");
        AuroraMod.getInstance().settingsManager.rSetting(b);

        a = new Setting("BoundingBoxAlpha", this, 255, 0, 255, true, "BoundingBoxAlpha");
        w = new Setting("Width", this, 1, 1, 10, true, "BlockHighlightWidth");
        AuroraMod.getInstance().settingsManager.rSetting(w);
        AuroraMod.getInstance().settingsManager.rSetting(rainbow = new Setting("Rainbow", this, false, "BlockHighlightRainbow"));
    }

    public void onWorldRender(RenderEvent event) {
        Color color = Rainbow.getColor();
        Color c = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)a.getValDouble());
        final Minecraft mc = Minecraft.getMinecraft();
        final RayTraceResult ray = mc.objectMouseOver;
        if (ray.typeOfHit == RayTraceResult.Type.BLOCK) {

            final BlockPos blockpos = ray.getBlockPos();
            final IBlockState iblockstate = mc.world.getBlockState(blockpos);

            if (iblockstate.getMaterial() != Material.AIR && mc.world.getWorldBorder().contains(blockpos)) {

                if (boundingbox.getValBoolean()) {
                    AuroraTessellator.prepare(GL11.GL_QUADS);

                    if (rainbow.getValBoolean()) {
                        AuroraTessellator.drawBoundingBoxBlockPos(blockpos, w.getValInt(), c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha());

                    } else {

                        AuroraTessellator.drawBoundingBoxBlockPos(blockpos, w.getValInt(), this.r.getValInt(), this.g.getValInt(), this.b.getValInt(), a.getValInt());

                    }
                    AuroraTessellator.release();
                }
            }
        }
    }
}