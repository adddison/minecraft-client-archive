package me.finz0.osiris.module.modules.gui;

import de.Hero.settings.Setting;
import me.finz0.osiris.module.Module;
import me.finz0.osiris.AuroraMod;

import java.awt.*;

public class Fps extends Module {
    public Fps() {
        super("FPS", Category.GUI);
        setDrawn(false);
    }
    public Setting rainbow;
    public Setting customFont;
    public Setting color;

    public void setup(){
        AuroraMod.getInstance().settingsManager.rSetting(rainbow = new Setting("Rainbow", this, false, "FpsRainbow"));
        AuroraMod.getInstance().settingsManager.rSetting(customFont = new Setting("CFont", this, false, "FpsCustomFont"));
        rSetting(color = new Setting("Color", this, Color.WHITE, "FpsColor"));
    }

    public void onEnable(){
        disable();
    }
}
