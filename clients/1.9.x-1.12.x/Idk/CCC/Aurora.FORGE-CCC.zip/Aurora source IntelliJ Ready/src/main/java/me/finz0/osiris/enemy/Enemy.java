package me.finz0.osiris.enemy;

public class Enemy {
    String name;
    public Enemy(String n){
        name = n;
    }

    public String getName(){
        return name;
    }
}
