package me.finz0.osiris.gui.clickgui.listener;

import me.finz0.osiris.gui.clickgui.elements.Slider;

public interface SliderChangeListener {

    void onSliderChange(Slider slider);
}
