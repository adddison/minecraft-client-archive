package me.finz0.osiris.gui.clickgui.listener;

import me.finz0.osiris.gui.clickgui.elements.ComboBox;

public interface ComboBoxListener {

    void onComboBoxSelectionChange(ComboBox comboBox);

}
