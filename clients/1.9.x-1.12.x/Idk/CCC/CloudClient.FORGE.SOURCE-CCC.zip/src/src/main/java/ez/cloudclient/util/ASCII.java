package ez.cloudclient.util;

public class ASCII {
    public static void printFancyConsoleMSG() {
        System.out.println("======================================================================");
        System.out.println("      ______  __        ______    __    __   _______            ");
        System.out.println("     /      ||  |      /  __  \\  |  |  |  | |       \\           ");
        System.out.println("    |  ,----'|  |     |  |  |  | |  |  |  | |  .--.  |          ");
        System.out.println("    |  |     |  |     |  |  |  | |  |  |  | |  |  |  |          ");
        System.out.println("   |  `----.|  `----.|  `--'  | |  `--'  | |  '--'  |          ");
        System.out.println("    \\______||_______| \\______/   \\______/  |_______/           ");
        System.out.println("                                                               ");
        System.out.println("     ______  __       __   _______ .__   __. .___________.     ");
        System.out.println("    /      ||  |     |  | |   ____||  \\ |  | |           |     ");
        System.out.println("   |  ,----'|  |     |  | |  |__   |   \\|  | `---|  |----`     ");
        System.out.println("   |  |     |  |     |  | |   __|  |  . `  |     |  |          ");
        System.out.println("   |  `----.|  `----.|  | |  |____ |  |\\   |     |  |          ");
        System.out.println("    \\______||_______||__| |_______||__| \\__|     |__|          ");
        System.out.println("                                                               ");
        System.out.println(" __        ______        ___       _______   _______  _______  ");
        System.out.println("|  |      /  __  \\      /   \\     |       \\ |   ____||       \\ ");
        System.out.println("|  |     |  |  |  |    /  ^  \\    |  .--.  ||  |__   |  .--.  |");
        System.out.println("|  |     |  |  |  |   /  /_\\  \\   |  |  |  ||   __|  |  |  |  |");
        System.out.println("|  `----.|  `--'  |  /  _____  \\  |  '--'  ||  |____ |  '--'  |");
        System.out.println("|_______| \\______/  /__/     \\__\\ |_______/ |_______||_______/ ");
        System.out.println("                                                               ");
        System.out.println("======================================================================");
        // Please dont break this
    }
}
