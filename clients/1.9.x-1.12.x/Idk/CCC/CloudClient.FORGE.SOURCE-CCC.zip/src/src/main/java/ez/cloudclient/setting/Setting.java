package ez.cloudclient.setting;

public abstract class Setting {

}
