# Cloud Client
The official GitHub for Cloud Client.
- This is a private Utility Mod for Minecraft Forge 1.12.2 and is oriented towards Anarchy Servers.

### Commands
The default prefix for commands is '.' put this prefix before all your commands, this works just like '/' does for regular Minecraft commands!
- Toggle <MODULE>
  * Toggles a module on or off.
- Panic
  * Turns off all your modules and hides the HUD, when you toggle panic off, the client remembers all your settings for you, so you don't need to worry about having to toggle all your modules again.
- ClearChat
  * Clears your entire chat, who would have guessed?!
- Drawn <MODULE>
  * Toggles a module from being shown in the HUD arraylist.
- ListModule
  * Lists all the modules avaliable in the client

### Modules
- Chat Replacement
- Auto Totem
- Crystal Aura
- Kill Aura
- Anti Hunger
- Coordinate Logger
- Elytra Flight
- Fast Stop
- Flight
- Sprint
- Auto Respawn
- No Fall
- Full Bright
- Player ESP
- DiscordRPC

### Credits
Huge thanks to all the contributors for their work on the project:
- **RemainingToast**#4201
- **wnuke**#1010
- **RSK5**#9982
- **Zilleyy**#2213
- **LittleDraily**#3718
- **ollie**#0057
- **OccultMC**#3683
- **iSudo**#4297
- **noodles**#0984

Join our [Discord Server](https://discord.gg/ZydwkaY)
