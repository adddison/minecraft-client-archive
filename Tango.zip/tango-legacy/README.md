# **Tango** [![code quality](https://api.codacy.com/project/badge/Grade/1c3d159db66c4725a8a831ed95d7e36b)](https://www.codacy.com?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=wine/tango&amp;utm_campaign=Badge_Grade)

*this is the legacy branch, prior to the rewrite*
