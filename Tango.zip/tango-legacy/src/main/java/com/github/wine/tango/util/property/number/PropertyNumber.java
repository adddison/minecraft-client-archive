package com.github.wine.tango.util.property.number;

import com.github.wine.tango.util.property.Property;
import com.github.wine.tango.util.property.number.util.NumberCaster;
import com.github.wine.tango.util.property.number.util.NumberClamper;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Contains property values for numbers.
 *
 * @author Kix
 * @since 9/21/18
 */
public class PropertyNumber<T extends Number> extends Property<T> {

  private final T minimum, maximum;

  public PropertyNumber(String label, Field field, Object parentObject, T minimum, T maximum) {
    super(label, field, parentObject);
    this.minimum = minimum;
    this.maximum = maximum;
  }

  @Override
  public void setValue(T value) {
    super.setValue(NumberClamper.clamp(NumberCaster.cast((Class<T>) ((Number) (getValue())).getClass(), round(value.doubleValue(), 1)), minimum, maximum));
  }

  private double round(double value, int places) {
    BigDecimal decimal = new BigDecimal(value);
    decimal = decimal.setScale(places, RoundingMode.UP);
    return decimal.doubleValue();
  }

  public T getMinimum() {
    return minimum;
  }

  public T getMaximum() {
    return maximum;
  }
}
