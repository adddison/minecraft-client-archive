package com.github.wine.tango.launch.mixin.impl.entity;

import net.minecraft.entity.EntityLivingBase;
import org.spongepowered.asm.mixin.Mixin;

/**
 * @author Kix
 * @since 9/21/18
 */
@Mixin(EntityLivingBase.class)
public abstract class MixinEntityLivingBase extends MixinEntity {
}
