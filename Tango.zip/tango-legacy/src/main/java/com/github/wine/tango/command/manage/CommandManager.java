package com.github.wine.tango.command.manage;

import com.github.wine.tango.Tango;
import com.github.wine.tango.command.FeatureCommand;
import com.github.wine.tango.command.TangoCommandFormattingProvider;
import com.github.wine.tango.command.impl.*;
import com.github.wine.tango.feature.Feature;
import pw.hysteria.input.dashfoo.api.Initializes;
import pw.hysteria.input.dashfoo.command.CommandDispatcher;
import pw.hysteria.input.dashfoo.command.parsing.impl.SimpleRegexProvider;

/**
 * Handles all command actions.
 *
 * @author Kix
 * @since 9/19/18
 */
public class CommandManager extends CommandDispatcher {

  public CommandManager() {
    super(new SimpleRegexProvider(new TangoCommandFormattingProvider()));
  }

  public void init() {
    try {
      registerCommand(new CommandEcho());
      registerCommand(new CommandHelp());
      registerCommand(new CommandFriend());
      registerCommand(new CommandToggle());
      registerCommand(new CommandFeatures());

      for (Feature feature : Tango.INSTANCE.getFeatureManager().getFeatures().values()) {
        if (!Tango.INSTANCE.getPropertyManager().findProperties(feature).isEmpty()) {
          registerCommand(new FeatureCommand(feature));
        }
      }

    } catch (Initializes.InitializationException e) {
      e.printStackTrace();
    }
  }

}
