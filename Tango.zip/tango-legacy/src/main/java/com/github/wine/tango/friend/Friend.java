package com.github.wine.tango.friend;

/**
 * Acts as an object to carry info on friends.
 *
 * <p>
 * Typically these will hold crucial info such as username and alias.
 * </p>
 *
 * @author Kix
 * @since 9/21/18
 */
public class Friend {

  /**
   * The friend's in game user name.
   *
   * <p>
   * This is how we will hide the friend's name in chat with the alias.
   * </p>
   */
  private final String username;

  /**
   * The preferred name for the friend.
   *
   * <p>
   * This is used to replace the username in nametags, chat, and leave their name in a bold color.
   * </p>
   */
  private final String alias;

  public Friend(String username, String alias) {
    this.username = username;
    this.alias = alias;
  }

  public String getUsername() {
    return username;
  }

  public String getAlias() {
    return alias;
  }
}
