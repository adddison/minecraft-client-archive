package com.github.wine.tango.command;

import pw.hysteria.input.dashfoo.command.parsing.CommandFormattingProvider;

/**
 * Provides command formatting for DashFoo.
 * <p>
 * DashFoo is one of the best command systems for Java, so in order to utilize this we use Bowser's test formatting
 * edited.
 * </p>
 *
 * @author Kix
 * @since 9/19/18
 */
public class TangoCommandFormattingProvider implements CommandFormattingProvider {

  @Override
  public String getEscapeChar() {
    return "\\\\";
  }

  @Override
  public String getIgnoreChar() {
    return "\"";
  }

  @Override
  public String getExplodeChar() {
    return "\\s";
  }

  @Override
  public String getFlagChar() {
    return "-";
  }

  @Override
  public String getHandleChar() {
    return ".";
  }
}
