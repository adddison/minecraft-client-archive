package com.github.wine.tango.feature.impl;

import com.github.wine.tango.event.impl.EventPreUpdate;
import com.github.wine.tango.feature.toggle.ToggleFeature;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;

public class FeatureNofall extends ToggleFeature {
  @EventHandler
  private final Listener<EventPreUpdate> preUpdateListener = new Listener<>(event -> {
    Vec3d positionUnderPlayer = minecraft.player.getPositionVector().subtract(0, 4, 0);
    RayTraceResult traceResult = minecraft.world.rayTraceBlocks(
        minecraft.player.getPositionVector(),
        positionUnderPlayer,
        false,
        true,
        true);

    if (traceResult != null && traceResult.typeOfHit == RayTraceResult.Type.BLOCK) {
      extension().teleport(minecraft.player.posX, minecraft.player.posY + 250, minecraft.player.posZ, true);
      extension().teleport(minecraft.player.posX, minecraft.player.posY, minecraft.player.posZ, true);
    }
  }, event -> minecraft.player.fallDistance > 4);

  public FeatureNofall() {
    super("Nofall");
  }
}
