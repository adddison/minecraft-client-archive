package com.github.wine.tango.command;

import pw.hysteria.input.dashfoo.command.FlagDispatcher;
import pw.hysteria.input.dashfoo.command.MethodAsInvokableFactory;
import pw.hysteria.input.dashfoo.command.impl.FlaggedCommand;
import pw.hysteria.input.dashfoo.command.parsing.UserInputFlagParser;
import pw.hysteria.input.dashfoo.command.parsing.impl.RegexSmartParser;
import pw.hysteria.input.dashfoo.command.parsing.impl.SimpleRegexProvider;
import pw.hysteria.input.dashfoo.command.parsing.impl.SimpleSanityChecker;

import java.util.ArrayList;

/**
 * A pre-setup instance of FlaggedCommand.
 *
 * @author Kix
 * @since 9/19/18
 */
public abstract class TangoCommand extends FlaggedCommand {

  private final MethodAsInvokableFactory methodiser = new MethodAsInvokableFactory();
  private UserInputFlagParser flagParser;

  public TangoCommand() {
    super(new FlagDispatcher());
  }

  @Override
  protected void initCommand() {
    flagParser = new RegexSmartParser(new SimpleRegexProvider(new TangoCommandFormattingProvider()),
        new SimpleSanityChecker(getFlagDispatcher()));
    final ArrayList<MethodAsInvokableFactory.MethodAsFlag> flags = methodiser.constructFromClass(this);
    getFlagDispatcher().addAll(flags);
  }

  @Override
  protected UserInputFlagParser getFlagParser() {
    return flagParser;
  }
}
