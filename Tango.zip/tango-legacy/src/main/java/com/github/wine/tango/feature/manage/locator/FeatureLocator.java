package com.github.wine.tango.feature.manage.locator;

import com.github.wine.tango.feature.Feature;

import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * Locates features based on the provided collection.
 *
 * <p>
 * This cannot be utilized until all of the features in the client have been added to the registrar.
 * </p>
 *
 * @author Kix
 * @since 9/19/18
 */
public class FeatureLocator {

  /**
   * Supplies us with all of the features in {@link com.github.wine.tango.feature.manage.FeatureManager}
   */
  private final Supplier<Map<String, Feature>> featureRegistrarSupplier;

  public FeatureLocator(Supplier<Map<String, Feature>> featureRegistrarSupplier) {
    this.featureRegistrarSupplier = featureRegistrarSupplier;
  }

  /**
   * Allows us to locate any feature in the client by name quickly.
   *
   * @param feature The name of the feature that is being searched for.
   * @return An {@link Optional} instance of that specific {@link Feature}.
   */
  public Optional<Feature> locate(String feature) {
    return Optional.ofNullable(featureRegistrarSupplier.get().get(feature.toLowerCase()));
  }
}
