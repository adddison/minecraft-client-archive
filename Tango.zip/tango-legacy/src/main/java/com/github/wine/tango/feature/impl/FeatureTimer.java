package com.github.wine.tango.feature.impl;

import com.github.wine.tango.Tango;
import com.github.wine.tango.event.impl.EventPreUpdate;
import com.github.wine.tango.feature.toggle.ToggleFeature;
import com.github.wine.tango.launch.mixin.api.client.MinecraftClient;
import com.github.wine.tango.util.property.Value;
import com.github.wine.tango.util.property.number.Clamp;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;

/**
 * @author Kix
 * @since 9/23/18
 */
public class FeatureTimer extends ToggleFeature {

  @Clamp(minimum = "1", maximum = "10")
  @Value("Speed")
  private int speed = 1;

  @EventHandler
  private final Listener<EventPreUpdate> preUpdateListener = new Listener<>(event -> {
    ((MinecraftClient) minecraft).getTimer().elapsedTicks = speed;
  });

  public FeatureTimer() {
    super("Timer");

    Tango.INSTANCE.getPropertyManager().register(this);
  }

  @Override
  public void onDisable() {
    super.onDisable();
    ((MinecraftClient) minecraft).getTimer().elapsedTicks = 1;
  }
}
