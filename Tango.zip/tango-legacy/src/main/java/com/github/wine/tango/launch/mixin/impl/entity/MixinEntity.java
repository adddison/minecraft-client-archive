package com.github.wine.tango.launch.mixin.impl.entity;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

/**
 * @author Kix
 * @since 9/21/18
 */
@Mixin(Entity.class)
public abstract class MixinEntity {
  @Shadow
  public double lastTickPosY;

  @Shadow
  public double posY;

  @Shadow
  public boolean onGround;

  @Shadow
  public double motionZ;

  @Shadow
  public double motionX;

  @Shadow
  public float rotationPitch;

  @Shadow
  public float rotationYaw;

  @Shadow
  public double posZ;

  @Shadow
  public double posX;

  @Shadow
  public abstract boolean isRiding();

  @Shadow
  public abstract AxisAlignedBB getEntityBoundingBox();

  @Shadow
  public abstract boolean isSprinting();
}
