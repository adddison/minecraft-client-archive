package com.github.wine.tango.util.logging;

import net.minecraft.client.Minecraft;
import net.minecraft.util.text.TextComponentString;

/**
 * @author Kix
 * @since 9/19/18
 */
public final class Logger {

  private static final String PREFIX = "\2476[Tango]:\247f";

  public static void logChat(String message) {
    Minecraft.getMinecraft().ingameGUI.getChatGUI().printChatMessage(new TextComponentString(
        String.format("%s %s", PREFIX, message)));
  }

}
