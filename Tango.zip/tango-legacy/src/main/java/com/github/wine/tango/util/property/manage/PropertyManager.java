package com.github.wine.tango.util.property.manage;

import com.github.wine.tango.util.property.Property;
import com.github.wine.tango.util.property.Value;
import com.github.wine.tango.util.property.number.Clamp;
import com.github.wine.tango.util.property.number.PropertyNumber;

import java.util.*;

/**
 * Handles the registration and collection of properties.
 *
 * @author Kix
 * @since 9/22/18
 */
public class PropertyManager {

  /**
   * Contains all of our properties based on the class.
   */
  private final Map<Property, Class> properties = new HashMap<>();

  /**
   * Grabs all properties from the object and adds them.
   *
   * @param object The class being read from.
   */
  @SuppressWarnings("unchecked")
  public void register(Object object) {
    if (object == null) {
      return;
    }
    Class<?> clazz = object.getClass();
    Arrays.stream(clazz.getDeclaredFields()).forEach(field -> {
      boolean oldAccessible = field.isAccessible();
      field.setAccessible(true);
      if (field.isAnnotationPresent(Value.class)) {
        Value value = field.getAnnotation(Value.class);

        if (field.isAnnotationPresent(Clamp.class)) {
          Clamp clamp = field.getAnnotation(Clamp.class);
          PropertyNumber property = null;

          if (field.getType().isAssignableFrom(Integer.TYPE)) {
            property = new PropertyNumber(value.value(), field, object, Integer.parseInt(clamp.minimum()), Integer.parseInt(clamp.maximum()));
          } else if (field.getType().isAssignableFrom(Long.TYPE)) {
            property = new PropertyNumber(value.value(), field, object, Long.parseLong(clamp.minimum()), Long.parseLong(clamp.maximum()));
          } else if (field.getType().isAssignableFrom(Double.TYPE)) {
            property = new PropertyNumber(value.value(), field, object, Double.parseDouble(clamp.minimum()), Double.parseDouble(clamp.maximum()));
          } else if (field.getType().isAssignableFrom(Float.TYPE)) {
            property = new PropertyNumber(value.value(), field, object, Float.parseFloat(clamp.minimum()), Float.parseFloat(clamp.maximum()));
          }
          if (property != null) {
            properties.put(property, clazz);
          }
        } else {
          Property property = new Property(value.value(), field, object);
          properties.put(property, clazz);
        }
      }
      field.setAccessible(oldAccessible);
    });
  }

  /**
   * Finds every property and compiles them to a list for the given object.
   *
   * @param object The object being searched through.
   * @return A collection of all properties in the object.
   */
  public List<Property> findProperties(Object object) {
    List<Property> properties = new ArrayList<>();
    this.properties.entrySet().stream()
        .filter(entry -> entry.getValue().equals(object.getClass()))
        .forEach(entry -> properties.add(entry.getKey()));
    return properties;
  }

  public Map<Property, Class> getProperties() {
    return properties;
  }
}
