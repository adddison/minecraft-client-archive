package com.github.wine.tango.event.impl;

import com.github.wine.tango.util.math.angle.Angle;
import me.zero.alpine.event.Cancellable;

/**
 * @author Kix
 * @since 9/21/18
 */
public class EventPreUpdate extends Cancellable {

  private final Angle angle;
  private final double previousY;
  private double y;
  private boolean onGround;

  public EventPreUpdate(Angle angle, double previousY, double y, boolean onGround) {
    this.angle = angle;
    this.previousY = previousY;
    this.y = y;
    this.onGround = onGround;
  }

  public Angle getAngle() {
    return angle;
  }

  public double getPreviousY() {
    return previousY;
  }

  public double getY() {
    return y;
  }

  public void setY(double y) {
    this.y = y;
  }

  public boolean isOnGround() {
    return onGround;
  }

  public void setOnGround(boolean onGround) {
    this.onGround = onGround;
  }
}
