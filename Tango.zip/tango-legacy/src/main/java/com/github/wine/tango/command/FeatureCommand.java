package com.github.wine.tango.command;

import com.github.wine.tango.Tango;
import com.github.wine.tango.feature.Feature;
import com.github.wine.tango.util.logging.Logger;
import com.github.wine.tango.util.property.Property;
import com.github.wine.tango.util.property.number.PropertyNumber;
import org.apache.commons.lang3.math.NumberUtils;
import pw.hysteria.input.dashfoo.command.Command;
import pw.hysteria.input.dashfoo.command.HelpProvider;

import java.util.List;

/**
 * @author Kix
 * @since 9/22/18
 */
@SuppressWarnings("ALL")
public class FeatureCommand extends Command {

  /**
   * The feature being affected in the command.
   */
  private final Feature feature;

  public FeatureCommand(Feature feature) {
    this.feature = feature;
  }

  @Override
  public void initialize() {

  }

  @Override
  public void invokeCommand(String commandText) {
    final String[] args = commandText.split(" ");
    if (args.length >= 2) {
      List<Property> properties = Tango.INSTANCE.getPropertyManager().findProperties(feature);
      properties.stream()
          .filter(property -> args[1].equalsIgnoreCase(property.getLabel()))
          .forEach(property -> {
            if (property.getValue() instanceof Boolean) {
              Property<Boolean> booleanProperty = (Property<Boolean>) property;
              booleanProperty.setValue(!(Boolean) property.getValue());
              Logger.logChat(property.getLabel() + " has been set to " + property.getValue().toString() + ".");
            }
            if (property instanceof PropertyNumber) {
              PropertyNumber numberProperty = (PropertyNumber) property;
              String number = args[2].substring(0, args[2].contains(" ") ? args[2].indexOf(32) : args[2].length());
              if (NumberUtils.isCreatable(number)) {
                numberProperty.setValue(NumberUtils.createNumber(number));
                Logger.logChat(property.getLabel() + " has been set to " + property.getValue().toString() + ".");
              }
            }
          });
    }
  }

  @Override
  public String[] getHandles() {
    return new String[]{feature.getLabel().toLowerCase()};
  }

  @Override
  public HelpProvider getHelpProvider() {
    return new HelpProvider() {
      @Override
      public String getDescription() {
        return "Allows us to modify values for " + feature.getLabel() + ".";
      }

      @Override
      public String getHelp() {
        return "." + feature.getLabel().toLowerCase() + " <property> <value>";
      }
    };
  }
}
