package com.github.wine.tango.util.math.timing;

/**
 * Allows us to check delays.
 *
 * @author Kix
 * @since 9/22/18
 */
public class Timer {

  /**
   * The last checked system time.
   */
  private long old = System.currentTimeMillis();

  /**
   * Checks if the amount of time has past.
   *
   * @param delay The amount of time needing to pass.
   * @return Whether or not that delay has passed.
   */
  public boolean delay(long delay) {
    return System.currentTimeMillis() - old >= delay;
  }

  /**
   * Resets the time counter.
   */
  public void reset() {
    old = System.currentTimeMillis();
  }
}
