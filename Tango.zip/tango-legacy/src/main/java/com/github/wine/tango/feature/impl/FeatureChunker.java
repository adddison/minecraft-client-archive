package com.github.wine.tango.feature.impl;

import com.github.wine.tango.event.impl.EventHandleChunkData;
import com.github.wine.tango.event.impl.EventRenderWorld;
import com.github.wine.tango.feature.toggle.ToggleFeature;
import com.github.wine.tango.util.render.RenderUtil;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.culling.ICamera;
import net.minecraft.util.math.AxisAlignedBB;
import org.lwjgl.opengl.GL11;

import java.util.HashSet;
import java.util.Set;

/**
 * Allows us to see if a chunk is new.
 *
 * @author Kix
 * @since 9/22/18
 */
public class FeatureChunker extends ToggleFeature {

  /**
   * A collection of all of the chunks that are considered new.
   */
  private final Set<ChunkData> newChunks = new HashSet<>();

  @EventHandler
  private final Listener<EventHandleChunkData> chunkDataListener = new Listener<>(event ->
      newChunks.add(new ChunkData(event.getChunkData().getChunkX() * 16, event.getChunkData().getChunkZ() * 16)),
      event -> !event.getChunkData().isFullChunk());

  @EventHandler
  private final Listener<EventRenderWorld> renderWorldListener = new Listener<>(event ->
      newChunks.forEach(chunk -> {
        ICamera camera = new Frustum();

        camera.setPosition(minecraft.getRenderViewEntity().posX, minecraft.getRenderViewEntity().posY, minecraft.getRenderViewEntity().posZ);
        AxisAlignedBB boundingBox = new AxisAlignedBB(chunk.getChunkX(), 0, chunk.getChunkZ(), chunk.getChunkX() + 16, 1, chunk.getChunkZ() + 16);

        if (camera.isBoundingBoxInFrustum(boundingBox)) {
          GL11.glPushMatrix();
          GL11.glEnable(GL11.GL_BLEND);
          GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
          GL11.glDisable(GL11.GL_TEXTURE_2D);
          GL11.glEnable(GL11.GL_LINE_SMOOTH);
          GL11.glDisable(GL11.GL_DEPTH_TEST);
          GL11.glDepthMask(false);
          GL11.glLineWidth(1f);
          GL11.glColor4f(1f, 1f, 1f, 1f);
          AxisAlignedBB bb = new AxisAlignedBB(0.0, 0.0, 0.0, 16d, 1d, 16d).offset(chunk.chunkX - minecraft.getRenderManager().viewerPosX,
              -minecraft.getRenderManager().viewerPosY, chunk.chunkZ - minecraft.getRenderManager().viewerPosZ);
          RenderUtil.bb(bb);
          GL11.glDisable(GL11.GL_LINE_SMOOTH);
          GL11.glEnable(GL11.GL_TEXTURE_2D);
          GL11.glEnable(GL11.GL_DEPTH_TEST);
          GL11.glDepthMask(true);
          GL11.glDisable(GL11.GL_BLEND);
          GL11.glPopMatrix();
        }
      }));

  public FeatureChunker() {
    super("Chunker");
  }

  @Override
  public void onDisable() {
    super.onDisable();
    newChunks.clear();
  }

  /**
   * Acts as a container class for all chunk data.
   */
  private class ChunkData {
    private final int chunkX;
    private final int chunkZ;

    ChunkData(int chunkX, int chunkZ) {
      this.chunkX = chunkX;
      this.chunkZ = chunkZ;
    }

    public int getChunkX() {
      return chunkX;
    }

    public int getChunkZ() {
      return chunkZ;
    }
  }

}
