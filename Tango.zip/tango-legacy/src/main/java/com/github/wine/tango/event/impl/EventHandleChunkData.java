package com.github.wine.tango.event.impl;

import net.minecraft.network.play.server.SPacketChunkData;

/**
 * @author Kix
 * @since 9/22/18
 */
public class EventHandleChunkData {

  private final SPacketChunkData chunkData;

  public EventHandleChunkData(SPacketChunkData chunkData) {
    this.chunkData = chunkData;
  }

  public SPacketChunkData getChunkData() {
    return chunkData;
  }
}
