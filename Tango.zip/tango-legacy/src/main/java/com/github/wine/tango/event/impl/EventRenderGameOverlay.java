package com.github.wine.tango.event.impl;

/**
 * Renders on the game's overlay.
 *
 * @author Kix
 * @since 9/18/18
 */
public class EventRenderGameOverlay {

  /**
   * The game's render ticks.
   */
  private final float partialTicks;

  public EventRenderGameOverlay(float partialTicks) {
    this.partialTicks = partialTicks;
  }

  public float getPartialTicks() {
    return partialTicks;
  }
}
