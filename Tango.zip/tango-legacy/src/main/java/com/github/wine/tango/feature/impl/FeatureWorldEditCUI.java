package com.github.wine.tango.feature.impl;

import com.github.wine.tango.event.impl.EventLeftClickMouse;
import com.github.wine.tango.event.impl.EventRenderWorld;
import com.github.wine.tango.event.impl.EventRightClickMouse;
import com.github.wine.tango.feature.toggle.ToggleFeature;
import com.github.wine.tango.util.render.RenderUtil;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

/**
 * Acts as a world edit region for the client.
 *
 * @author Kix
 * @since 9/23/18
 */
public class FeatureWorldEditCUI extends ToggleFeature {

  private final ClickRegion[] regions = new ClickRegion[]{null, null};

  @EventHandler
  private final Listener<EventLeftClickMouse> leftClickMouseListener = new Listener<>(event -> {
    if (minecraft.objectMouseOver != null && minecraft.objectMouseOver.typeOfHit == RayTraceResult.Type.BLOCK && minecraft.objectMouseOver.hitVec != null) {
      Vec3d hitVec = minecraft.objectMouseOver.hitVec;
      regions[0] = new ClickRegion(hitVec.x, hitVec.y, hitVec.z);
    }
  });

  @EventHandler
  private final Listener<EventRightClickMouse> rightClickMouseListener = new Listener<>(event -> {
    if (minecraft.objectMouseOver != null && minecraft.objectMouseOver.typeOfHit == RayTraceResult.Type.BLOCK && minecraft.objectMouseOver.hitVec != null) {
      Vec3d hitVec = minecraft.objectMouseOver.hitVec;
      regions[1] = new ClickRegion(hitVec.x, hitVec.y, hitVec.z);
    }
  });

  @EventHandler
  private final Listener<EventRenderWorld> renderWorldListener = new Listener<>(event -> {
    GL11.glPushMatrix();
    GL11.glEnable(GL11.GL_BLEND);
    GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
    GL11.glDisable(GL11.GL_TEXTURE_2D);
    GL11.glEnable(GL11.GL_LINE_SMOOTH);
    GL11.glDisable(GL11.GL_DEPTH_TEST);
    GL11.glDepthMask(false);
    GL11.glLineWidth(1f);
    GL11.glColor4f(1f, 1f, 1f, 1f);
    AxisAlignedBB bb = new AxisAlignedBB(0.0, 0.0, 0.0, regions[1].getPosX() - regions[0].getPosX(), regions[1].getPosY() - regions[0].getPosY(), regions[1].getPosZ() - regions[0].getPosZ()).offset(regions[0].getPosX() - minecraft.getRenderManager().viewerPosX,
        regions[0].getPosY() - minecraft.getRenderManager().viewerPosY, regions[0].getPosZ() - minecraft.getRenderManager().viewerPosZ);
    RenderUtil.bb(bb);
    GL11.glDisable(GL11.GL_LINE_SMOOTH);
    GL11.glEnable(GL11.GL_TEXTURE_2D);
    GL11.glEnable(GL11.GL_DEPTH_TEST);
    GL11.glDepthMask(true);
    GL11.glDisable(GL11.GL_BLEND);
    GL11.glPopMatrix();
  }, event -> regions[0] != null && regions[1] != null);

  public FeatureWorldEditCUI() {
    super("WorldEditCUI");
  }

  /**
   * Contains info on each click.
   */
  private class ClickRegion {

    private final double posX, posY, posZ;

    public ClickRegion(double posX, double posY, double posZ) {
      this.posX = posX;
      this.posY = posY;
      this.posZ = posZ;
    }

    public double getPosX() {
      return posX;
    }

    public double getPosY() {
      return posY;
    }

    public double getPosZ() {
      return posZ;
    }
  }

}
