package com.github.wine.tango.launch.mixin.impl.entity.extension;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.stats.RecipeBook;
import net.minecraft.stats.StatisticsManager;
import net.minecraft.world.World;

public class EntityPlayerSPExtension extends EntityPlayerSP {
  public EntityPlayerSPExtension(Minecraft minecraft, World world, NetHandlerPlayClient client, StatisticsManager statistics, RecipeBook recipe) {
    super(minecraft, world, client, statistics, recipe);
  }

  public void teleport(double x, double y, double z, boolean onGround) {
    connection.sendPacket(new CPacketPlayer.Position(x, y, z, onGround));
    setPosition(x, y, z);
  }
}
