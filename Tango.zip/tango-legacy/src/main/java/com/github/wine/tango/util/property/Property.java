package com.github.wine.tango.util.property;

import java.lang.reflect.Field;

/**
 * Acts as a container for a value.
 *
 * @author Kix
 * @since 9/21/18
 */
public class Property<T> {

  private final Object parentObject;
  private final String label;
  private final Field field;

  public Property(String label, Field field, Object parentObject) {
    this.label = label;
    this.field = field;
    this.parentObject = parentObject;
  }

  @SuppressWarnings("unchecked")
  public T getValue() {
    boolean oldAccessible = field.isAccessible();
    try {
      field.setAccessible(true);
      T type = (T) field.get(parentObject);
      field.setAccessible(oldAccessible);
      return type;
    } catch (IllegalAccessException e) {
      e.printStackTrace();
    }
    return null;
  }

  @SuppressWarnings("unchecked")
  public void setValue(T value) {
    boolean oldAccessible = field.isAccessible();
    try {
      field.setAccessible(true);
      field.set(parentObject, value);
      field.setAccessible(oldAccessible);
    } catch (IllegalAccessException e) {
      e.printStackTrace();
    }
  }

  public String getLabel() {
    return label;
  }

  public Field getField() {
    return field;
  }

  public Object getParentObject() {
    return parentObject;
  }
}
