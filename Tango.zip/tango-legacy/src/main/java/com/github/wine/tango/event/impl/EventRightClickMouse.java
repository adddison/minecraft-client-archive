package com.github.wine.tango.event.impl;

/**
 * @author Kix
 * @since 9/23/18
 */
public class EventRightClickMouse {
}
