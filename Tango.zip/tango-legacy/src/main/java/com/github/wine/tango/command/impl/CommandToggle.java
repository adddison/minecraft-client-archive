package com.github.wine.tango.command.impl;

import com.github.wine.tango.Tango;
import com.github.wine.tango.command.TangoCommand;
import com.github.wine.tango.feature.Feature;
import com.github.wine.tango.feature.toggle.ToggleFeature;
import com.github.wine.tango.util.logging.Logger;
import pw.hysteria.input.dashfoo.command.IsFlag;

import java.util.Optional;

/**
 * Allows us to toggle features.
 *
 * @author Kix
 * @since 9/21/18
 */
public class CommandToggle extends TangoCommand {

  @IsFlag(handles = "@default")
  public void toggle(String feature) {
    Optional<Feature> optionalFeature = Tango.INSTANCE.getFeatureManager().getLocator().locate(feature);
    if (optionalFeature.isPresent()) {
      Feature foundFeature = optionalFeature.get();
      if (foundFeature instanceof ToggleFeature) {
        ((ToggleFeature) foundFeature).toggle();
      } else {
        Logger.logChat(feature + " is not toggleable.");
      }
    } else {
      Logger.logChat(feature + " was not found!");
    }
  }

  @Override
  public String[] getHandles() {
    return new String[]{"toggle", "t", "tog"};
  }
}
