package com.github.wine.tango.friend.manage;

import com.github.wine.tango.friend.Friend;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

/**
 * Manages all of the friend's in the client.
 *
 * @author Kix
 * @since 9/21/18
 */
public class FriendManager {

  /**
   * Contains all of the friend's in the client by object.
   *
   * <p>
   * We are storing this in a set to prevent accidental duplicates when adding friends.
   * </p>
   *
   * <p>
   * We want to keep this as lightweight as possible so I assume using an {@link Set} would work great here.
   * </p>
   */
  private final Set<Friend> friends = new HashSet<>();

  /**
   * Automatically builds and sets up an {@link Friend} based on the provided arguments.
   *
   * <p>
   * This works great for parsing Strings in things such as Commands or Serialization.
   * </p>
   *
   * @param username The username of the friend being added.
   * @param alias    The alias of the friend being added.
   */
  public void register(String username, String alias) {
    friends.add(new Friend(username, alias));
  }

  /**
   * Automatically removes an {@link Friend} based on the provided username.
   *
   * <p>
   * Only works if the friend is found.
   * </p>
   *
   * <p>
   * This works great for String parsing such as Commands or Serialization.
   * </p>
   *
   * @param username The username of the friend being removed.
   */
  public void unregister(String username) throws IllegalStateException {
    Optional<Friend> optionalFriend = getFriend(username);
    if (optionalFriend.isPresent()) {
      friends.remove(optionalFriend.get());
    } else {
      throw new IllegalStateException("The friend was unable to be unregistered.");
    }
  }

  /**
   * Provides an {@link Optional} instance of the friend found based on provided arguments.
   *
   * <p>
   * We are utilizing Optionals here to prevent any NPEs from dropping.
   * </p>
   *
   * @param username The username of the friend being searched for.
   * @return A non-null instance of the friend.
   */
  public Optional<Friend> getFriend(String username) {
    return friends.stream()
        .filter(friend -> friend.getUsername().equalsIgnoreCase(username))
        .findFirst();
  }

  public Set<Friend> getFriends() {
    return friends;
  }
}
