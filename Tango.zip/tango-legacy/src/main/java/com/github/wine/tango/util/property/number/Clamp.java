package com.github.wine.tango.util.property.number;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Allows us to specify number properties.
 *
 * @author Kix
 * @since 9/21/18
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface Clamp {

  String minimum() default "0";

  String maximum() default "20";

}
