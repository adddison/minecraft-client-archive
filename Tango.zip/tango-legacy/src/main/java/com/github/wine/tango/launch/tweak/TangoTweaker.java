package com.github.wine.tango.launch.tweak;

import net.minecraft.launchwrapper.ITweaker;
import net.minecraft.launchwrapper.LaunchClassLoader;
import org.spongepowered.asm.launch.MixinBootstrap;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.Mixins;

import java.io.File;
import java.util.List;
import java.util.logging.Logger;

/**
 * Allows us to directly access the game with Mixins.
 *
 * @author jackson
 * @since 9/16/18
 */
public class TangoTweaker implements ITweaker {

  @Override
  public void acceptOptions(List<String> args, File gameDir, File assetsDir, String profile) {
    Logger.getGlobal().info("No options were parsed.");
  }

  @Override
  public void injectIntoClassLoader(LaunchClassLoader classLoader) {
    MixinBootstrap.init();
    Mixins.addConfiguration("mixins.tango.json");
    MixinEnvironment.getDefaultEnvironment().setObfuscationContext("searge");
    MixinEnvironment.getDefaultEnvironment().setSide(MixinEnvironment.Side.CLIENT);
  }

  @Override
  public String getLaunchTarget() {
    return "net.minecraft.client.main.Main";
  }

  @Override
  public String[] getLaunchArguments() {
    return new String[0];
  }
}
