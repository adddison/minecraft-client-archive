package com.github.wine.tango.launch.mixin.api.gui;

import net.minecraft.tileentity.TileEntitySign;

/**
 * @author Kix
 * @since 9/22/18
 */
public interface Sign {

  TileEntitySign getTileSign();

}
