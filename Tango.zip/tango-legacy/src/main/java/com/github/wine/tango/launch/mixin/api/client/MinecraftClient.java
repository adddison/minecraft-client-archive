package com.github.wine.tango.launch.mixin.api.client;

import net.minecraft.util.Timer;

/**
 * @author Kix
 * @since 9/23/18
 */
public interface MinecraftClient {

  Timer getTimer();

}
