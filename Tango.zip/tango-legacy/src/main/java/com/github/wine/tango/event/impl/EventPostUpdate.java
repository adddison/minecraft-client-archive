package com.github.wine.tango.event.impl;

/**
 * @author Kix
 * @since 9/21/18
 */
public class EventPostUpdate {
}
