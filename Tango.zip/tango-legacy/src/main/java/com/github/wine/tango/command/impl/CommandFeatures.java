package com.github.wine.tango.command.impl;

import com.github.wine.tango.Tango;
import com.github.wine.tango.command.TangoCommand;
import com.github.wine.tango.feature.toggle.ToggleFeature;
import com.github.wine.tango.util.logging.Logger;
import pw.hysteria.input.dashfoo.command.IsFlag;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Tells the user all of the features in the cheat.
 *
 * @author Kix
 * @since 9/23/18
 */
public class CommandFeatures extends TangoCommand {

  @IsFlag(handles = "@default")
  public void features() {
    List<ToggleFeature> features = Tango.INSTANCE.getFeatureManager().getFeatures().values().stream()
        .filter(ToggleFeature.class::isInstance)
        .map(ToggleFeature.class::cast)
        .collect(Collectors.toList());
    StringBuilder stringBuilder = new StringBuilder(String.format("%s [%s]: ", "Features", features.size()));
    features.forEach(feature -> stringBuilder.append(feature.isEnabled() ? "\247a" : "\247c").append(feature.getLabel()).append("\247f, "));
    Logger.logChat(stringBuilder.toString().substring(0, stringBuilder.toString().length() - 2));
  }

  @Override
  public String[] getHandles() {
    return new String[]{"features", "mods", "plugins"};
  }
}
