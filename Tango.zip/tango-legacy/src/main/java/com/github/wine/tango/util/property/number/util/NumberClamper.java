package com.github.wine.tango.util.property.number.util;

/**
 * Clamps numbers based on given values.
 *
 * @author N3xuz
 * @since 8/7/18
 */
public class NumberClamper {

  /**
   * Attempts to clamp Numbers as a whole.
   *
   * @param value to be clamped.
   * @param min   number that the value can be.
   * @param max   number that the value can be
   * @param <T>   the generic supertype extending Number.
   * @return the ultimately clamped number.
   */
  @SuppressWarnings("unchecked")
  public static <T extends Number> T clamp(T value, T min, T max) {
    return (((Comparable) value).compareTo(min) < 0) ? min : ((((Comparable) value).compareTo(max) > 0) ? max : value);
  }

}
