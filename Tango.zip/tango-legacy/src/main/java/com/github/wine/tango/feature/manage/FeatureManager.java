package com.github.wine.tango.feature.manage;

import com.github.wine.tango.feature.Feature;
import com.github.wine.tango.feature.impl.*;
import com.github.wine.tango.feature.manage.locator.FeatureLocator;

import java.util.Map;
import java.util.TreeMap;

/**
 * Performs basic actions for all of our features.
 *
 * <p>
 * I rewrote this from the previous implementation because it did not have a good setup in my personal opinion.
 * It seemed extremely sloppy to have this class implement ArrayList.
 * </p>
 *
 * @author Kix
 * @since 9/18/2018
 */
public class FeatureManager {

  /**
   * Our collection for our features.
   * Acts as a registrar to hold every single feature by name.
   *
   * <p>
   * Because we are using the TreeMap implementation, we can automatically sort the features by alphabetical order.
   * Which we are doing.
   * </p>
   */
  private final Map<String, Feature> features = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);

  /**
   * The feature's locator.
   *
   * <p>
   * I moved this to it's own class to further implement the Single Responsibility Principle into the client.
   * </p>
   */
  private FeatureLocator locator;

  public void init() {
    register(new FeatureOverlay());
    register(new FeatureCommands());
    register(new FeatureForcefield());
    register(new FeatureGamma());
    register(new FeatureChunker());
    register(new FeatureStamp());
    register(new FeatureColorSigns());
    register(new FeatureWorldEditCUI());
    register(new FeatureLightningStrike());
    register(new FeatureTimer());
    register(new FeatureNofall());
    register(new FeaturePacketFly());
    register(new FeaturePolice());
    register(new FeatureElytraFly());

    locator = new FeatureLocator(() -> features);
  }

  /**
   * Adds a feature to the registrar of features.
   *
   * <p>
   * By storing in lowercase, we are in the end giving ourselves a faster search time.
   * </p>
   *
   * @param feature The feature being registered.
   */
  public void register(Feature feature) {
    features.put(feature.getLabel().toLowerCase(), feature);
  }

  /**
   * Removes a feature from the registrar.
   *
   * <p>
   * Utilizing that our feature is stored in lowercase, we effectively have a faster removal.
   * </p>
   *
   * @param feature The feature being unregistered.
   */
  public void unregister(Feature feature) {
    features.remove(feature.getLabel().toLowerCase());
  }

  public FeatureLocator getLocator() {
    return locator;
  }

  public Map<String, Feature> getFeatures() {
    return features;
  }
}
