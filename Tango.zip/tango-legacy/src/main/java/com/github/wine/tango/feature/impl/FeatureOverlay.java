package com.github.wine.tango.feature.impl;

import com.github.wine.tango.Tango;
import com.github.wine.tango.event.impl.EventRenderGameOverlay;
import com.github.wine.tango.feature.Feature;
import com.github.wine.tango.feature.toggle.ToggleFeature;
import com.github.wine.tango.util.property.Value;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listenable;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.gui.ScaledResolution;

import java.awt.*;

/**
 * Showcases a heads-up-display for the user to see any useful information for the cheat.
 *
 * @author Kix
 * @since 9/18/18
 */
public class FeatureOverlay extends Feature implements Listenable {

  /**
   * Showcases the client's name on the hud.
   */
  @Value("Watermark")
  private boolean watermark = true;

  /**
   * Showcases the client's position on the hud.
   */
  @Value("Coords")
  private boolean coords = true;

  /**
   * Showcases all of the features in the client.
   */
  @Value("Features")
  private boolean features = true;

  @EventHandler
  private final Listener<EventRenderGameOverlay> renderGameOverlayListener = new Listener<>(event -> {
    final ScaledResolution scaledResolution = new ScaledResolution(minecraft);

    if (watermark) {
      minecraft.fontRenderer.drawStringWithShadow("Tango", 2, 2, Color.WHITE.getRGB());
    }

    if (coords) {
      minecraft.fontRenderer.drawStringWithShadow(String.format("%s, %s, %s",
          Math.round(minecraft.player.posX), Math.round(minecraft.player.posY), Math.round(minecraft.player.posZ)), 2, 12, Color.WHITE.getRGB());
    }

    if (features) {
      int y = minecraft.player.getActivePotionEffects().isEmpty() ? 2 : 28;
      for (Feature feature : Tango.INSTANCE.getFeatureManager().getFeatures().values()) {
        if (feature instanceof ToggleFeature && ((ToggleFeature) feature).isEnabled()) {
          minecraft.fontRenderer.drawStringWithShadow(feature.getLabel(), scaledResolution.getScaledWidth() - minecraft.fontRenderer.getStringWidth(feature.getLabel()) - 2, y, 0xFFDEDEDE);
          y += minecraft.fontRenderer.FONT_HEIGHT;
        }
      }
    }
  }, event -> !minecraft.gameSettings.showDebugInfo);

  public FeatureOverlay() {
    super("Overlay");

    Tango.INSTANCE.getPropertyManager().register(this);
    Tango.INSTANCE.getEventBus().subscribe(this);
  }
}
