package com.github.wine.tango.launch.mixin.impl.client.world;

import com.github.wine.tango.Tango;
import com.github.wine.tango.event.impl.EventLightningStrike;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * @author Kix
 * @since 9/23/18
 */
@Mixin(World.class)
public class MixinWorld {

  @Inject(method = "addWeatherEffect", at = @At("HEAD"))
  private void addWeatherEffect(Entity entityIn, CallbackInfoReturnable<Boolean> cir) {
    if (entityIn instanceof EntityLightningBolt) {
      Tango.INSTANCE.getEventBus().post(new EventLightningStrike(entityIn.posX, entityIn.posY, entityIn.posZ));
    }
  }
}
