package com.github.wine.tango.feature.impl;

import com.github.wine.tango.event.impl.EventPreUpdate;
import com.github.wine.tango.feature.toggle.ToggleFeature;
import com.github.wine.tango.launch.mixin.api.gui.Sign;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.gui.inventory.GuiEditSign;
import net.minecraft.util.text.TextComponentString;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Adds a stamp containing name and date on a sign.
 *
 * @author Kix
 * @since 9/22/18
 */
public class FeatureStamp extends ToggleFeature {

  @EventHandler
  private final Listener<EventPreUpdate> preUpdateListener = new Listener<>(event -> {
    if (minecraft.currentScreen instanceof GuiEditSign) {
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yy");
      GuiEditSign editSign = (GuiEditSign) minecraft.currentScreen;
      Sign sign = (Sign) editSign;
      sign.getTileSign().signText[2] = new TextComponentString(minecraft.player.getGameProfile().getName());
      sign.getTileSign().signText[3] = new TextComponentString(simpleDateFormat.format(new Date()));
    }
  });

  public FeatureStamp() {
    super("Stamp");
  }
}
