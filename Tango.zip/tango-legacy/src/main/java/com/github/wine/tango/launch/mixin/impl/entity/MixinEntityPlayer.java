package com.github.wine.tango.launch.mixin.impl.entity;

import net.minecraft.entity.player.EntityPlayer;
import org.spongepowered.asm.mixin.Mixin;

/**
 * @author Kix
 * @since 9/21/18
 */
@Mixin(EntityPlayer.class)
public abstract class MixinEntityPlayer extends MixinEntityLivingBase {
}
