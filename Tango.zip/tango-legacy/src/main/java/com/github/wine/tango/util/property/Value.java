package com.github.wine.tango.util.property;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a property as a value for the property system.
 *
 * @author Kix
 * @since 9/21/18
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface Value {

  /**
   * @return The property's label.
   */
  String value();
}
