package com.github.wine.tango.feature;

import com.github.wine.tango.launch.mixin.impl.entity.extension.EntityPlayerSPExtension;
import net.minecraft.client.Minecraft;

/**
 * Acts as the basis for all hacks and utilities in the cheat.
 *
 * <p>
 * This class is marked as abstract to allow the developer and any viewers to know that this class should be treated
 * as a parent class and only that.
 * </p>
 *
 * <p>
 * TODO: Maybe add categories, depends on whether or not me and you agree @fth.
 * </p>
 *
 * @author Kix
 * @since 9/18/18
 */
public abstract class Feature {

  protected final Minecraft minecraft = Minecraft.getMinecraft();
  /**
   * The feature's identifier throughout the entire cheat's backend and the frontend UI.
   */
  private final String label;

  public Feature(String label) {
    this.label = label;
  }

  public String getLabel() {
    return label;
  }

  protected EntityPlayerSPExtension extension() {
    return (EntityPlayerSPExtension) minecraft.player;
  }
}
