package com.github.wine.tango.feature.impl;

import com.github.wine.tango.Tango;
import com.github.wine.tango.event.impl.EventSendChatMessage;
import com.github.wine.tango.feature.Feature;
import com.github.wine.tango.util.logging.Logger;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listenable;
import me.zero.alpine.listener.Listener;

/**
 * Automatically executes commands from the game chat.
 *
 * @author Kix
 * @since 9/19/18
 */
public class FeatureCommands extends Feature implements Listenable {

  @EventHandler
  private final Listener<EventSendChatMessage> sendChatMessageListener = new Listener<>(event -> {
    event.cancel();
    try {
      Tango.INSTANCE.getCommandManager().dispatchCommand(event.getMessage());
    } catch (Exception e) {
      Logger.logChat("Execution failed!");
    }
  }, event -> event.getMessage().startsWith("."));

  public FeatureCommands() {
    super("Commands");
    Tango.INSTANCE.getEventBus().subscribe(this);
  }
}
