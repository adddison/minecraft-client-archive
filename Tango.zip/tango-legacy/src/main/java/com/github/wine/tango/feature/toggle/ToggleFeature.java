package com.github.wine.tango.feature.toggle;

import com.github.wine.tango.Tango;
import com.github.wine.tango.feature.Feature;
import me.zero.alpine.listener.Listenable;

/**
 * A feature that can be toggled on or off.
 *
 * @author Kix
 * @since 9/18/18
 */
public class ToggleFeature extends Feature implements Toggle, Listenable {

  /**
   * The feature's current state.
   */
  private boolean enabled;

  public ToggleFeature(String label) {
    super(label);
  }

  @Override
  public void toggle() {
    this.enabled = !enabled;

    if (enabled) {
      onEnable();
    } else {
      onDisable();
    }
  }

  public void onEnable() {
    Tango.INSTANCE.getEventBus().subscribe(this);
  }

  public void onDisable() {
    Tango.INSTANCE.getEventBus().unsubscribe(this);
  }

  public boolean isEnabled() {
    return enabled;
  }

  public void setEnabled(boolean enabled) {
    this.enabled = enabled;
  }
}
