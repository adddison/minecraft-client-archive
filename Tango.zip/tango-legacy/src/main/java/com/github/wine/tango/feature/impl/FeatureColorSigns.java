package com.github.wine.tango.feature.impl;

import com.github.wine.tango.event.impl.EventPreUpdate;
import com.github.wine.tango.feature.toggle.ToggleFeature;
import com.github.wine.tango.launch.mixin.api.gui.Sign;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.gui.inventory.GuiEditSign;
import net.minecraft.util.text.TextComponentString;

/**
 * @author Kix
 * @since 9/22/18
 */
public class FeatureColorSigns extends ToggleFeature {

  @EventHandler
  private final Listener<EventPreUpdate> preUpdateListener = new Listener<>(event -> {
    if (minecraft.currentScreen instanceof GuiEditSign) {
      GuiEditSign editSign = (GuiEditSign) minecraft.currentScreen;
      Sign sign = (Sign) editSign;
      for (int i = 0; i < 3; i++) {
        sign.getTileSign().signText[i] = new TextComponentString(sign.getTileSign().signText[i].getUnformattedText().replaceAll("&", "\247" + "\247a"));
      }
    }
  });

  public FeatureColorSigns() {
    super("ColorSigns");
  }
}
