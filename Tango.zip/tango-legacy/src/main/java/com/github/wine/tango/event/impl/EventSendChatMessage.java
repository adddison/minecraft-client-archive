package com.github.wine.tango.event.impl;

import me.zero.alpine.event.Cancellable;

/**
 * Allows us to interrupt / interact with the game's chat system.
 *
 * @author Kix
 * @since 9/19/18
 */
public class EventSendChatMessage extends Cancellable {

  /**
   * The message being sent where we hook.
   */
  private String message;

  public EventSendChatMessage(String message) {
    this.message = message;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }
}
