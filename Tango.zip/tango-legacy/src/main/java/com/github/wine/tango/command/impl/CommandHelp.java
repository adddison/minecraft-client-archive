package com.github.wine.tango.command.impl;

import com.github.wine.tango.Tango;
import com.github.wine.tango.command.TangoCommand;
import com.github.wine.tango.util.logging.Logger;
import pw.hysteria.input.dashfoo.command.Command;
import pw.hysteria.input.dashfoo.command.IsFlag;

import java.util.HashSet;
import java.util.Set;

/**
 * Lists every single command in the client that is not a module command.
 *
 * <p>
 * Typically this is done by an {@link StringBuilder} so that's what we'll be doing.
 * </p>
 *
 * @author Kix
 * @since 9/21/18
 */
public class CommandHelp extends TangoCommand {

  /**
   * We are gonna run our command on the home of the command.
   *
   * <p>
   * Meaning our command is executed whether there is arguments or not.
   * </p>
   *
   * <p>
   * We are gonna utilize Java's {@link Set} collection to prevent duplicates.
   * </p>
   */
  @IsFlag(handles = "@default")
  public void help() {
    Set<Command> commands = new HashSet<>(Tango.INSTANCE.getCommandManager().getLoadedCommands().values());
    StringBuilder stringBuilder = new StringBuilder(String.format("%s [%s]: ", "Commands", commands.size()));
    commands.forEach(command -> stringBuilder.append(command.getHandles()[0]).append(", "));
    Logger.logChat(stringBuilder.toString().substring(0, stringBuilder.toString().length() - 2));
  }

  @Override
  public String[] getHandles() {
    return new String[]{"help", "he", "commands", "cmds"};
  }
}
