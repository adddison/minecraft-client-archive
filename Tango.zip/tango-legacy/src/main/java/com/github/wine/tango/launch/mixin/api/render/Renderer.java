package com.github.wine.tango.launch.mixin.api.render;

/**
 * @author Kix
 * @since 9/22/18
 */
public interface Renderer {

  void transform(float partialTicks);

}
