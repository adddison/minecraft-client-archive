package com.github.wine.tango.command.impl;

import com.github.wine.tango.Tango;
import com.github.wine.tango.command.TangoCommand;
import com.github.wine.tango.util.logging.Logger;
import pw.hysteria.input.dashfoo.command.IsFlag;

/**
 * Allows us to add and remove friends as well as access them.
 *
 * @author Kix
 * @since 9/21/18
 */
public class CommandFriend extends TangoCommand {

  /**
   * We need to have a default flag to prevent crashes.
   */
  @IsFlag(handles = "@default")
  public void home() {

  }

  /**
   * Adds a friend to the client's friend system.
   *
   * @param username The username of the friend being added.
   * @param alias    The alias of the friend being added.
   */
  @IsFlag(handles = {"add", "a"})
  public void add(String username, String alias) {
    if (username != null && alias != null) {
      Tango.INSTANCE.getFriendManager().register(username, alias);
      Logger.logChat(username + " is now a friend.");
    } else {
      Logger.logChat("One or more args is null!");
    }
  }

  /**
   * Removes a friend from the client's friend system.
   *
   * @param username The username of the friend being removed.
   */
  @IsFlag(handles = {"remove", "delete"})
  public void remove(String username) {
    if (username != null) {
      try {
        Tango.INSTANCE.getFriendManager().unregister(username);
        Logger.logChat(username + " is no longer a friend.");
      } catch (IllegalStateException e) {
        Logger.logChat(e.getMessage());
      }
    } else {
      Logger.logChat("Args were not provided.");
    }
  }

  @Override
  public String[] getHandles() {
    return new String[]{"friend", "fr", "fri"};
  }
}
