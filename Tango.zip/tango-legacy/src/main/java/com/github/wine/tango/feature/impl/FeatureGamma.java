package com.github.wine.tango.feature.impl;

import com.github.wine.tango.feature.toggle.ToggleFeature;

/**
 * Maxes the gamma value for the game.
 *
 * @author Kix
 * @since 9/22/18
 */
public class FeatureGamma extends ToggleFeature {

  private final float oldGamma = minecraft.gameSettings.gammaSetting;

  public FeatureGamma() {
    super("Gamma");
  }

  @Override
  public void onEnable() {
    super.onEnable();
    minecraft.gameSettings.gammaSetting = 16f;
  }

  @Override
  public void onDisable() {
    super.onDisable();
    minecraft.gameSettings.gammaSetting = oldGamma;
  }
}
