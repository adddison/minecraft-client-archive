package com.github.wine.tango.feature.impl;

import com.github.wine.tango.event.impl.EventPreUpdate;
import com.github.wine.tango.feature.toggle.ToggleFeature;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.MathHelper;

public class FeaturePolice extends ToggleFeature {
  private static final int speedLimit = 15;
  private long time = System.currentTimeMillis();

  @EventHandler
  private final Listener<EventPreUpdate> preUpdateListener = new Listener<>(event -> {
    minecraft.world.playerEntities
        .forEach(entity -> {
          SpeedInfo info = getSpeedInfoForPlayer(entity);
          if (info.didBreakLimit) {
            minecraft.player.sendChatMessage(String.format("Uh oh %s! You were caught speeding at %.2f bps, please don't go over the %d bps limit!", entity.getName(), info.blocksPerSecond, speedLimit));
            time = System.currentTimeMillis();
          }
        });
  }, event -> System.currentTimeMillis() - time > 2500);

  public FeaturePolice() {
    super("Police");
  }

  private SpeedInfo getSpeedInfoForPlayer(EntityPlayer player) {
    double lastTickX = player.posX - player.prevPosX;
    double lastTickZ = player.posZ - player.prevPosZ;
    double blocksPerSecond = MathHelper.sqrt(lastTickX * lastTickX + lastTickZ * lastTickZ) / 0.05F;

    return new SpeedInfo(blocksPerSecond);
  }

  @Override
  public void onEnable() {
    super.onEnable();
  }

  private class SpeedInfo {
    private double blocksPerSecond;
    private boolean didBreakLimit;

    SpeedInfo(double blocksPerSecond) {
      this.blocksPerSecond = blocksPerSecond;
      this.didBreakLimit = blocksPerSecond > FeaturePolice.speedLimit;
    }
  }
}
