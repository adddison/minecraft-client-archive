package com.github.wine.tango.feature.impl;

import com.github.wine.tango.event.impl.EventPreUpdate;
import com.github.wine.tango.feature.toggle.ToggleFeature;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;

public class FeatureElytraFly extends ToggleFeature {
  @EventHandler
  private final Listener<EventPreUpdate> preUpdateListener = new Listener<>(event -> {
    minecraft.player.capabilities.isFlying = true;

    extension().teleport(minecraft.player.posX, minecraft.player.posY + 250, minecraft.player.posZ, false);
  }, event -> minecraft.player.isElytraFlying());

  public FeatureElytraFly() {
    super("ElytraFly");
  }

  @Override
  public void onDisable() {
    super.onDisable();

    minecraft.player.capabilities.isFlying = false;
  }
}
