package com.github.wine.tango.launch.mixin.impl.client;

import com.github.wine.tango.Tango;
import com.github.wine.tango.event.impl.EventLeftClickMouse;
import com.github.wine.tango.event.impl.EventMiddleClickMouse;
import com.github.wine.tango.event.impl.EventRightClickMouse;
import com.github.wine.tango.launch.mixin.api.client.MinecraftClient;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Timer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Acts as a mixin for {@link net.minecraft.client.Minecraft}
 *
 * @author Kix
 * @since 9/16/18
 */
@Mixin(Minecraft.class)
public abstract class MixinMinecraft implements MinecraftClient {

  @Override
  @Accessor
  public abstract Timer getTimer();

  @Inject(method = "clickMouse", at = @At("HEAD"))
  private void clickMouse(CallbackInfo ci) {
    Tango.INSTANCE.getEventBus().post(new EventLeftClickMouse());
  }

  @Inject(method = "rightClickMouse", at = @At("HEAD"))
  private void rightClickMouse(CallbackInfo ci) {
    Tango.INSTANCE.getEventBus().post(new EventRightClickMouse());
  }

  @Inject(method = "middleClickMouse", at = @At("HEAD"))
  private void middleClickMouse(CallbackInfo ci) {
    Tango.INSTANCE.getEventBus().post(new EventMiddleClickMouse());
  }

  @Inject(method = "init", at = @At(value = "RETURN"))
  private void init(CallbackInfo ci) {
    Tango.INSTANCE.init();
  }

}
