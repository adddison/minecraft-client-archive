package com.github.wine.tango.feature.impl;

import com.github.wine.tango.event.impl.EventPreUpdate;
import com.github.wine.tango.feature.toggle.ToggleFeature;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;

public class FeaturePacketFly extends ToggleFeature {
  @EventHandler
  private final Listener<EventPreUpdate> preUpdateListener = new Listener<>(event -> {
    minecraft.player.motionY = 0;
    extension().teleport(
        minecraft.player.posX + minecraft.player.motionX * 11,
        minecraft.player.posY + (minecraft.gameSettings.keyBindJump.isKeyDown() ? 0.0625 : minecraft.gameSettings.keyBindSneak.isKeyDown() ? -0.0625 : 0),
        minecraft.player.posZ + minecraft.player.motionZ * 11,
        false);

    extension().teleport(
        minecraft.player.posX + minecraft.player.motionX * 11,
        minecraft.player.posY + 250,
        minecraft.player.posZ + minecraft.player.motionZ * 11,
        false);
  });

  public FeaturePacketFly() {
    super("PacketFly");
  }
}
