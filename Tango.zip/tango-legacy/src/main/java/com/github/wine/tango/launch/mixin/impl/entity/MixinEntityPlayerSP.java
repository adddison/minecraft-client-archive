package com.github.wine.tango.launch.mixin.impl.entity;

import com.github.wine.tango.Tango;
import com.github.wine.tango.event.impl.EventPostUpdate;
import com.github.wine.tango.event.impl.EventPreUpdate;
import com.github.wine.tango.event.impl.EventSendChatMessage;
import com.github.wine.tango.util.math.angle.Angle;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

/**
 * @author Kix
 * @since 9/19/18
 */
@Mixin(EntityPlayerSP.class)
public abstract class MixinEntityPlayerSP extends MixinEntityPlayer {

  @Shadow
  @Final
  public NetHandlerPlayClient connection;
  @Shadow
  protected Minecraft mc;
  @Shadow
  private boolean serverSprintState;

  @Shadow
  private boolean serverSneakState;

  @Shadow
  private double lastReportedPosX;

  @Shadow
  private double lastReportedPosY;

  @Shadow
  private double lastReportedPosZ;

  @Shadow
  private float lastReportedYaw;

  @Shadow
  private float lastReportedPitch;

  @Shadow
  private int positionUpdateTicks;

  @Shadow
  private boolean prevOnGround;

  @Shadow
  private boolean autoJumpEnabled;

  @Shadow
  public abstract boolean isSneaking();

  @Shadow
  protected abstract boolean isCurrentViewEntity();

  /**
   * @author Kix
   * @reason We need to include an UpdateEvent.
   */
  @Overwrite
  private void onUpdateWalkingPlayer() {
    boolean flag = this.isSprinting();
    EntityPlayerSP _this = (EntityPlayerSP) (Object) this;
    final EventPreUpdate preUpdate = new EventPreUpdate(new Angle(rotationYaw, rotationPitch), lastReportedPosY, posY, onGround);
    Tango.INSTANCE.getEventBus().post(preUpdate);

    if (preUpdate.isCancelled()) {
      return;
    }

    if (flag != this.serverSprintState) {
      if (flag) {
        this.connection.sendPacket(new CPacketEntityAction(_this, CPacketEntityAction.Action.START_SPRINTING));
      } else {
        this.connection.sendPacket(new CPacketEntityAction(_this, CPacketEntityAction.Action.STOP_SPRINTING));
      }

      this.serverSprintState = flag;
    }

    boolean flag1 = this.isSneaking();

    if (flag1 != this.serverSneakState) {
      if (flag1) {
        this.connection.sendPacket(new CPacketEntityAction(_this, CPacketEntityAction.Action.START_SNEAKING));
      } else {
        this.connection.sendPacket(new CPacketEntityAction(_this, CPacketEntityAction.Action.STOP_SNEAKING));
      }

      this.serverSneakState = flag1;
    }

    if (this.isCurrentViewEntity()) {
      double d0 = this.posX - this.lastReportedPosX;
      double d1 = preUpdate.getY() - this.lastReportedPosY;
      double d2 = this.posZ - this.lastReportedPosZ;
      double d3 = (double) (preUpdate.getAngle().getYaw() - this.lastReportedYaw);
      double d4 = (double) (preUpdate.getAngle().getPitch() - this.lastReportedPitch);
      ++this.positionUpdateTicks;
      boolean flag2 = d0 * d0 + d1 * d1 + d2 * d2 > 9.0E-4D || this.positionUpdateTicks >= 20;
      boolean flag3 = d3 != 0.0D || d4 != 0.0D;

      if (this.isRiding()) {
        this.connection.sendPacket(new CPacketPlayer.PositionRotation(this.motionX, -999.0D, this.motionZ, preUpdate.getAngle().getYaw(), preUpdate.getAngle().getPitch(), preUpdate.isOnGround()));
        flag2 = false;
      } else if (flag2 && flag3) {
        this.connection.sendPacket(new CPacketPlayer.PositionRotation(this.posX, preUpdate.getY(), this.posZ, preUpdate.getAngle().getYaw(), preUpdate.getAngle().getPitch(), preUpdate.isOnGround()));
      } else if (flag2) {
        this.connection.sendPacket(new CPacketPlayer.Position(this.posX, preUpdate.getY(), this.posZ, preUpdate.isOnGround()));
      } else if (flag3) {
        this.connection.sendPacket(new CPacketPlayer.Rotation(preUpdate.getAngle().getYaw(), preUpdate.getAngle().getPitch(), preUpdate.isOnGround()));
      } else if (this.prevOnGround != preUpdate.isOnGround()) {
        this.connection.sendPacket(new CPacketPlayer(preUpdate.isOnGround()));
      }

      if (flag2) {
        this.lastReportedPosX = this.posX;
        this.lastReportedPosY = preUpdate.getY();
        this.lastReportedPosZ = this.posZ;
        this.positionUpdateTicks = 0;
      }

      if (flag3) {
        this.lastReportedYaw = preUpdate.getAngle().getYaw();
        this.lastReportedPitch = preUpdate.getAngle().getPitch();
      }

      this.prevOnGround = preUpdate.isOnGround();
      this.autoJumpEnabled = this.mc.gameSettings.autoJump;
    }

    Tango.INSTANCE.getEventBus().post(new EventPostUpdate());

  }

  /**
   * @author Kix
   * @reason To setup an event for interacting with the game's chat system.
   */
  @Overwrite
  public void sendChatMessage(String message) {
    EventSendChatMessage eventSendChatMessage = new EventSendChatMessage(message);
    Tango.INSTANCE.getEventBus().post(eventSendChatMessage);

    if (!eventSendChatMessage.isCancelled()) {
      this.connection.sendPacket(new CPacketChatMessage(eventSendChatMessage.getMessage()));
    }
  }

}
