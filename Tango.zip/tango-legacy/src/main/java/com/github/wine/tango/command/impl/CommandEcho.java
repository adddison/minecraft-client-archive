package com.github.wine.tango.command.impl;

import com.github.wine.tango.command.TangoCommand;
import com.github.wine.tango.util.logging.Logger;
import pw.hysteria.input.dashfoo.command.IsFlag;

/**
 * Allows the user to echo a message back to them.
 *
 * @author Kix
 * @since 9/19/18
 */
public class CommandEcho extends TangoCommand {

  @IsFlag(handles = "@default")
  public void echo(String message) {
    Logger.logChat(message);
  }

  @Override
  public String[] getHandles() {
    return new String[]{"echo", "ech", "message"};
  }
}
