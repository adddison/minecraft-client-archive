package com.github.wine.tango.feature.toggle;

/**
 * Allows us to mark an object as toggleable.
 *
 * @author Kix
 * @since 9/18/18
 */
public interface Toggle {

  /**
   * Changes the object's state to the opposite.
   */
  void toggle();
}
