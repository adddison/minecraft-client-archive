package com.github.wine.tango.launch.mixin.impl.client.network;

import com.github.wine.tango.Tango;
import com.github.wine.tango.event.impl.EventHandleChunkData;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.server.SPacketChunkData;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * @author Kix
 * @since 9/22/18
 */
@Mixin(NetHandlerPlayClient.class)
public class MixinNetHandlerPlayClient {

  @Inject(method = "handleChunkData", at = @At("RETURN"))
  private void handleChunkData(SPacketChunkData packetIn, CallbackInfo ci) {
    Tango.INSTANCE.getEventBus().post(new EventHandleChunkData(packetIn));
  }

}
