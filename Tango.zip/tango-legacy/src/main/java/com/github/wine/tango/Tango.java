package com.github.wine.tango;

import com.github.wine.tango.command.manage.CommandManager;
import com.github.wine.tango.feature.manage.FeatureManager;
import com.github.wine.tango.friend.manage.FriendManager;
import com.github.wine.tango.util.property.manage.PropertyManager;
import me.zero.alpine.bus.EventBus;
import me.zero.alpine.bus.EventManager;
import net.minecraft.client.Minecraft;

import java.util.logging.Logger;

/**
 * Our core class for our client.
 *
 * <p>
 * Tango is the ultimate boomer hack.
 * The color scheme for the client is monochrome because colors are too mainstream.
 * The best video game was quake 3 and only 2 video games have ever been invented, quake 3 and doom.
 * </p>
 *
 * <p>
 * Hey idiot, I think you forgot Wolfenstein!
 * </p>
 *
 * @author Kix
 * @since 9/16/18
 */
public final class Tango {

  /**
   * A singleton instance of Tango.
   */
  public final static Tango INSTANCE = new Tango();

  /**
   * The client's event bus.
   *
   * <p>
   * Due to fth's recent change, this is Alpine by Brady now.
   * </p>
   */
  private final EventBus eventBus = new EventManager();

  /**
   * The client's feature manager.
   *
   * <p>
   * This will store all info about features and assist with accessing them.
   * </p>
   */
  private final FeatureManager featureManager = new FeatureManager();

  /**
   * The client's command manager.
   *
   * <p>
   * This handles everything from registration to execution of commands.
   * </p>
   */
  private final CommandManager commandManager = new CommandManager();

  /**
   * The client's friend system.
   *
   * <p>
   * This allows us to access friends and change their states.
   * </p>
   */
  private final FriendManager friendManager = new FriendManager();

  /**
   * The client's property system.
   *
   * <p>
   * This allows us to have clean properties.
   * </p>
   */
  private final PropertyManager propertyManager = new PropertyManager();

  private Tango() {
    Logger.getGlobal().info("Tango has been constructed.");
  }

  /**
   * Hooks into the game's main initialization function.
   * This hook is located in {@link Minecraft#init()}
   */
  public void init() {
    featureManager.init();
    commandManager.init();
  }

  public EventBus getEventBus() {
    return eventBus;
  }

  public FeatureManager getFeatureManager() {
    return featureManager;
  }

  public CommandManager getCommandManager() {
    return commandManager;
  }

  public FriendManager getFriendManager() {
    return friendManager;
  }

  public PropertyManager getPropertyManager() {
    return propertyManager;
  }
}
