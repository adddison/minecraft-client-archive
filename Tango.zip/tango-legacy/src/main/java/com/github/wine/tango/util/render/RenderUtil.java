package com.github.wine.tango.util.render;


import net.minecraft.util.math.AxisAlignedBB;
import org.lwjgl.BufferUtils;
import org.lwjgl.util.glu.GLU;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import static org.lwjgl.opengl.GL11.*;

/**
 * @author Kix
 * @since 9/22/18
 */
public class RenderUtil {

  public static void bb(AxisAlignedBB bb) {
    glBegin(GL_LINES);
    glVertex3d(bb.minX, bb.minY, bb.minZ);
    glVertex3d(bb.maxX, bb.minY, bb.minZ);
    glVertex3d(bb.maxX, bb.minY, bb.minZ);
    glVertex3d(bb.maxX, bb.minY, bb.maxZ);
    glVertex3d(bb.maxX, bb.minY, bb.maxZ);
    glVertex3d(bb.minX, bb.minY, bb.maxZ);
    glVertex3d(bb.minX, bb.minY, bb.maxZ);
    glVertex3d(bb.minX, bb.minY, bb.minZ);
    glVertex3d(bb.minX, bb.minY, bb.minZ);
    glVertex3d(bb.minX, bb.maxY, bb.minZ);
    glVertex3d(bb.maxX, bb.minY, bb.minZ);
    glVertex3d(bb.maxX, bb.maxY, bb.minZ);
    glVertex3d(bb.maxX, bb.minY, bb.maxZ);
    glVertex3d(bb.maxX, bb.maxY, bb.maxZ);
    glVertex3d(bb.minX, bb.minY, bb.maxZ);
    glVertex3d(bb.minX, bb.maxY, bb.maxZ);
    glVertex3d(bb.minX, bb.maxY, bb.minZ);
    glVertex3d(bb.maxX, bb.maxY, bb.minZ);
    glVertex3d(bb.maxX, bb.maxY, bb.minZ);
    glVertex3d(bb.maxX, bb.maxY, bb.maxZ);
    glVertex3d(bb.maxX, bb.maxY, bb.maxZ);
    glVertex3d(bb.minX, bb.maxY, bb.maxZ);
    glVertex3d(bb.minX, bb.maxY, bb.maxZ);
    glVertex3d(bb.minX, bb.maxY, bb.minZ);
    glEnd();
  }

  /**
   * Uses GLU Projection to get the 2d coords of a 3d position.
   *
   * <p>
   * This is from StackOverflow.
   * </p>
   */
  public static int[] get2d(double x, double y, double z) {
    FloatBuffer screenCoords = BufferUtils.createFloatBuffer(4);
    IntBuffer viewport = BufferUtils.createIntBuffer(16);
    FloatBuffer modelView = BufferUtils.createFloatBuffer(16);
    FloatBuffer projection = BufferUtils.createFloatBuffer(16);
    glGetFloat(GL_MODELVIEW_MATRIX, modelView);
    glGetFloat(GL_PROJECTION_MATRIX, projection);
    glGetInteger(GL_VIEWPORT, viewport);
    boolean result = GLU.gluProject((float) x, (float) y, (float) z, modelView, projection, viewport, screenCoords);
    if (result) {
      return new int[]{(int) screenCoords.get(0), (int) screenCoords.get(1)};
    }
    return null;
  }

}
