package com.github.wine.tango.event.impl;

/**
 * @author Kix
 * @since 9/22/18
 */
public class EventRenderWorld {

  private final float partialTicks;

  public EventRenderWorld(float partialTicks) {
    this.partialTicks = partialTicks;
  }

  public float getPartialTicks() {
    return partialTicks;
  }
}
