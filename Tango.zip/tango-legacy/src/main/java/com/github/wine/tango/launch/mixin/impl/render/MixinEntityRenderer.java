package com.github.wine.tango.launch.mixin.impl.render;

import com.github.wine.tango.Tango;
import com.github.wine.tango.event.impl.EventRenderGameOverlay;
import com.github.wine.tango.event.impl.EventRenderWorld;
import com.github.wine.tango.launch.mixin.api.render.Renderer;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.renderer.EntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * @author Kix
 * @since 9/18/18
 */
@Mixin(EntityRenderer.class)
public abstract class MixinEntityRenderer implements Renderer {

  @Shadow
  protected abstract void setupCameraTransform(float partialTicks, int pass);

  @Override
  public void transform(float partialTicks) {
    setupCameraTransform(partialTicks, 0);
  }

  @Redirect(method = "updateCameraAndRender", at = @At(value = "INVOKE", target = "net/minecraft/client/gui/GuiIngame.renderGameOverlay(F)V"))
  private void updateCameraAndRender(GuiIngame guiIngame, float partialTicks) {
    guiIngame.renderGameOverlay(partialTicks);
    Tango.INSTANCE.getEventBus().post(new EventRenderGameOverlay(partialTicks));
  }

  @Inject(method = "renderWorldPass", at = @At(value = "INVOKE_STRING", target = "net/minecraft/profiler/Profiler.endStartSection(Ljava/lang/String;)V", args = {"ldc=hand"}))
  private void renderWorldPass(int pass, float partialTicks, long finishTimeNano, CallbackInfo ci) {
    Tango.INSTANCE.getEventBus().post(new EventRenderWorld(partialTicks));
  }

}
