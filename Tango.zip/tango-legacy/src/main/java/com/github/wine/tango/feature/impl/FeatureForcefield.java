package com.github.wine.tango.feature.impl;

import com.github.wine.tango.Tango;
import com.github.wine.tango.event.impl.EventPostUpdate;
import com.github.wine.tango.event.impl.EventPreUpdate;
import com.github.wine.tango.feature.toggle.ToggleFeature;
import com.github.wine.tango.util.math.angle.Angle;
import com.github.wine.tango.util.math.angle.AngleUtil;
import com.github.wine.tango.util.property.Value;
import com.github.wine.tango.util.property.number.Clamp;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Allows us to hit all of the players around us.
 *
 * <p>
 * We call this force field because theoretically, we should have a force field around our player where no one can attack us.
 * </p>
 *
 * @author Kix
 * @since 9/21/18
 */
public class FeatureForcefield extends ToggleFeature {

  /**
   * Instance of our angle utility.
   */
  private final AngleUtil angleUtil = new AngleUtil();
  /**
   * The player's range to the entity.
   */
  @Clamp(minimum = "3.0", maximum = "6.0")
  @Value("Range")
  private float range = 4.5f;
  /**
   * Whether or not to show rotation change.
   */
  @Value("Lockview")
  private boolean lockview = false;
  /**
   * Our current target;
   */
  private EntityPlayer target;

  @EventHandler
  private final Listener<EventPreUpdate> preUpdateListener = new Listener<>(event -> {
    final List<EntityPlayer> nearby = minecraft.world.playerEntities.stream()
        .filter(entity -> entity != minecraft.player && entity != null && minecraft.player.getDistanceToEntity(entity) <= range)
        .filter(entity -> !Tango.INSTANCE.getFriendManager().getFriend(entity.getGameProfile().getName()).isPresent())
        .sorted((o1, o2) -> Float.compare(minecraft.player.getDistanceToEntity(o1), minecraft.player.getDistanceToEntity(o2)))
        .collect(Collectors.toList());

    if (!nearby.isEmpty()) {
      target = nearby.get(0);
    }

    if (target != null) {
      Angle angle = angleUtil.calculateAngle(target);
      if (lockview) {
        minecraft.player.rotationYaw = angle.getYaw();
        minecraft.player.rotationPitch = angle.getPitch();
      } else {
        event.getAngle().setYaw(angle.getYaw());
        event.getAngle().setPitch(angle.getPitch());
      }
    }
  });

  @EventHandler
  private final Listener<EventPostUpdate> postUpdateListener = new Listener<>(event -> {
    final Minecraft minecraft = Minecraft.getMinecraft();
    final EntityPlayerSP player = minecraft.player;
    player.swingArm(EnumHand.MAIN_HAND);
    minecraft.playerController.attackEntity(player, target);
    target = null;
  }, event -> target != null && minecraft.player.getCooledAttackStrength(0) >= 1);

  public FeatureForcefield() {
    super("Forcefield");

    Tango.INSTANCE.getPropertyManager().register(this);
  }

}
