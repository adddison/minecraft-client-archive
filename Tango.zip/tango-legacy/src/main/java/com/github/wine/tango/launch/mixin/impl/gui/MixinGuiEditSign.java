package com.github.wine.tango.launch.mixin.impl.gui;

import com.github.wine.tango.launch.mixin.api.gui.Sign;
import net.minecraft.client.gui.inventory.GuiEditSign;
import net.minecraft.tileentity.TileEntitySign;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * @author Kix
 * @since 9/22/18
 */
@Mixin(GuiEditSign.class)
public abstract class MixinGuiEditSign implements Sign {

  @Override
  @Accessor
  public abstract TileEntitySign getTileSign();
}
