package com.github.wine.tango.feature.impl;

import com.github.wine.tango.event.impl.EventLightningStrike;
import com.github.wine.tango.feature.toggle.ToggleFeature;
import com.github.wine.tango.util.logging.Logger;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;

/**
 * Listens for lightning strikes around the player and tells the position.
 *
 * @author Kix
 * @since 9/23/18
 */
public class FeatureLightningStrike extends ToggleFeature {

  @EventHandler
  private final Listener<EventLightningStrike> lightningStrikeListener = new Listener<>(event ->
      Logger.logChat(String.format("A lightning bolt has struck at %s, %s, %s", event.getX(), event.getY(),
          event.getZ())));

  public FeatureLightningStrike() {
    super("LightningStrike");
  }
}
