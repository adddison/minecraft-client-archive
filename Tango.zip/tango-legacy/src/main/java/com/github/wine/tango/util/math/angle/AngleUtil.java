package com.github.wine.tango.util.math.angle;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.MathHelper;

/**
 * An abstraction of faceEntity to allow us to get bettter angles.
 *
 * @author Kix
 * @since 9/22/18
 */
public class AngleUtil {

  public Angle calculateAngle(Entity entityIn) {
    double d0 = entityIn.posX - Minecraft.getMinecraft().player.posX;
    double d2 = entityIn.posZ - Minecraft.getMinecraft().player.posZ;
    double d1;
    if (entityIn instanceof EntityLivingBase) {
      EntityLivingBase entitylivingbase = (EntityLivingBase) entityIn;
      d1 = entitylivingbase.posY + (double) entitylivingbase.getEyeHeight() - (Minecraft.getMinecraft().player.posY + (double) Minecraft.getMinecraft().player.getEyeHeight());
    } else {
      d1 = (entityIn.getEntityBoundingBox().minY + entityIn.getEntityBoundingBox().maxY) / 2.0D - (Minecraft.getMinecraft().player.posY + (double) Minecraft.getMinecraft().player.getEyeHeight());
    }
    double d3 = (double) MathHelper.sqrt(d0 * d0 + d2 * d2);
    float f = (float) (MathHelper.atan2(d2, d0) * (180D / Math.PI)) - 90.0F;
    float f1 = (float) (-(MathHelper.atan2(d1, d3) * (180D / Math.PI)));
    return new Angle(f, f1);
  }

}
