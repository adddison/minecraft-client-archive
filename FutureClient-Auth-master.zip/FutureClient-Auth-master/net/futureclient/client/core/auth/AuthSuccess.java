package net.futureclient.client.core.auth;

public enum AuthSuccess
{
    False;
    
    private static final AuthSuccess[] field_1856;
    
    True;
    
    static {
        field_1856 = new AuthSuccess[] { AuthSuccess.True, AuthSuccess.False };
    }
}
