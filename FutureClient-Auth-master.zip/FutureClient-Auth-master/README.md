# FutureClient.net Authentication Reversed
- Some parts may be named wrong/not named however should be fairly readable.
- hi [@0-x-2-2](https://github.com/0-x-2-2) and [@pKalju](https://github.com/pKalju)
