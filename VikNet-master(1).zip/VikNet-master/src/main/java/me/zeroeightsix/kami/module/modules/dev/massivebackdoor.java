package me.zeroeightsix.kami.module.modules.dev;

import me.zeroeightsix.kami.module.Module;


/**
 * Created by the legendary viktisen
 * 1111111111111111111111111111111111111111111111111111111111111111111111111111111111111
 * do ".backdoor" to backdoor a server
 */
@Module.Info(name = "massivebackdoor", description = "instantly backdoors any server!!!", category = Module.Category.HIDDEN)
public class massivebackdoor extends Module {

}

