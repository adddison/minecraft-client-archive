package me.zeroeightsix.kami.module.modules.player;

import me.zeroeightsix.kami.module.Module;
import me.zeroeightsix.kami.setting.Settings;
import me.zeroeightsix.kami.setting.Setting;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Items;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;

//OUTDATED SEE "AbsorptionEat" FOR NEW
/**
 * Created by 086 on 8/04/2018. made better by cryroByte
 * thanks krts for helping because i am legit brain dead - cryrobyte
 */
@Module.Info(name = "AutoEatcrystalOLD", description = "Automatically eat when hungry", category = Module.Category.HIDDEN)
public class AutoEatcrystalOLD extends Module {

    private Setting healthbar = this.register(Settings.integerBuilder("Health Slider").withMinimum(0).withMaximum(36).withValue((int)20).build());
    private Setting<Boolean> switch1 = register(Settings.b("Switch", false));
    private int lastSlot = -1;
    private boolean eating = false;

    private boolean isValid(ItemStack stack, int food) {
        return stack.getItem() instanceof ItemFood && ((int)this.healthbar.getValue()-food)>=((ItemFood) stack.getItem()).getHealAmount(stack);

    }

    @Override
    public void onUpdate() {
        if (eating && !mc.player.isHandActive()) {
            if (lastSlot != -1) {
                mc.player.inventory.currentItem = lastSlot;
                lastSlot = -1;
            }
            eating = false;
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
            return;
        }
        if (eating) return;
        float playerAbsorption = mc.player.getAbsorptionAmount();
        if (isValid(mc.player.getHeldItemOffhand(), (int) mc.player.getHealth() + (int) playerAbsorption)) { /*stupid way i did it ik ik ik*/
            mc.player.setActiveHand(EnumHand.OFF_HAND);
            eating = true;
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
            mc.rightClickMouse();
        }else{
            for (int i = 0; i < 9; i++) {
                if (isValid(mc.player.inventory.getStackInSlot(i), (int) mc.player.getHealth() + (int) playerAbsorption)) { /*stupid way i did it ik ik ik*/
                    if ((Boolean)this.switch1.getValue()) {
                        lastSlot = mc.player.inventory.currentItem;
                        mc.player.inventory.currentItem = i;
                    }
                    if (mc.player.getHeldItemMainhand().getItem() == Items.GOLDEN_APPLE) {
                        eating = true;
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
                        mc.rightClickMouse();
                        return;
                    }
                }
            }
        }
    }
}
