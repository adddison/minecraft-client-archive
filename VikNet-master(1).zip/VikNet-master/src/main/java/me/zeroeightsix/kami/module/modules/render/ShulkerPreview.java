package me.zeroeightsix.kami.module.modules.render;

import me.zeroeightsix.kami.module.Module;

/**
 * Created by 086 on 24/12/2017.
 * @see me.zeroeightsix.kami.mixin.client.MixinGuiScreen
 */
@Module.Info(name = "ShulkerPreview", category = Module.Category.RENDER)
public class ShulkerPreview extends Module {
}
