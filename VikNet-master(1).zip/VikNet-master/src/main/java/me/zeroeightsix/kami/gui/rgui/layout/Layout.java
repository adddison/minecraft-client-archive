package me.zeroeightsix.kami.gui.rgui.layout;

import me.zeroeightsix.kami.gui.rgui.component.container.Container;

/**
 * Created by 086 on 26/06/2017.
 */
public interface Layout {

    public void organiseContainer(Container container);

}
