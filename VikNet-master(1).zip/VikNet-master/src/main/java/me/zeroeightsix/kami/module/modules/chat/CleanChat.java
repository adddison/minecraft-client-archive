package me.zeroeightsix.kami.module.modules.chat;

import me.zeroeightsix.kami.module.Module;

//@MixinGuiNewChat
@Module.Info(name = "CleanChat", category = Module.Category.HIDDEN)
public class CleanChat extends Module {

}
