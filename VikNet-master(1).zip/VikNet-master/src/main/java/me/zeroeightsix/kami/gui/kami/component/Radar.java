package me.zeroeightsix.kami.gui.kami.component;

import me.zeroeightsix.kami.gui.rgui.component.AbstractComponent;

/**
 * Created by 086 on 11/08/2017.
 */
public class Radar extends AbstractComponent {
}
