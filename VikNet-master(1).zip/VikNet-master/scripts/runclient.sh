#!/usr/bin/env bash

/c/Program\ Files\ \(x86\)/Minecraft\ Launcher/MinecraftLauncher.exe
