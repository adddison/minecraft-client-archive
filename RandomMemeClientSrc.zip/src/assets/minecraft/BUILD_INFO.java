package assets.minecraft; public class BUILD_INFO {public static String build = "";}
