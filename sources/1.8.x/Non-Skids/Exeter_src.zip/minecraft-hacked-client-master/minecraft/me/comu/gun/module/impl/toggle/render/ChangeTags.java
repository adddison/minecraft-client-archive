package me.comu.gun.module.impl.toggle.render;

import me.comu.api.event.Listener;
import me.comu.gun.command.Argument;
import me.comu.gun.command.Command;
import me.comu.gun.core.Gun;
import me.comu.gun.events.PassSpecialRenderEvent;
import me.comu.gun.events.RenderEvent;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import me.comu.gun.waypoints.Point;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumChatFormatting;

public class ChangeTags extends ToggleableModule {

    String playerName;
    String newName;
    public ChangeTags() {
        super("ChangeTags", new String[]{"changetags"}, 0x54FF33, ModuleType.RENDER);
        this.listeners.add(new Listener<RenderEvent>("change_tags_render_event") {
            @Override
            public void call(RenderEvent event) {
                Gun.getInstance().getCommandManager().register(new Command(new String[] {"changetag","ctag","ctags","ct","chagename"}, new Argument("IGN"), new Argument("name"))
                {
                    @Override
                    public String dispatch()
                    {
                        String playerNameCom = getArgument("IGN").getValue();
                        String newNameCom = getArgument("name").getValue();
                        playerName = playerNameCom;
                        newName = newNameCom;
                        return "Changed " + playerNameCom + " to " + newNameCom + ".";
                    }
                });
                for (Object o : minecraft.theWorld.playerEntities) {
                    Entity entity = (Entity) o;
                    if (entity instanceof EntityPlayer) {
                        if (entity.getName().equalsIgnoreCase(playerName)) {
                            setDisplayName(((EntityPlayer) entity), newName);
                        }
                    }
                }
            }
        });
        this.listeners.add(new Listener<PassSpecialRenderEvent>("name_tags_pass_special_render_listener") {
            @Override
            public void call(PassSpecialRenderEvent event) {
                event.setCanceled(true);
            }
        });
        setRunning(true);
    }
    private String setDisplayName(EntityPlayer player, String newName) {
        String name = player.getDisplayName().getFormattedText();
        name = newName;
        return name;
    }


}
