package me.comu.gun.module.impl.toggle.render;

import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;

public final class ClickGui extends ToggleableModule
{
    public ClickGui()
    {
        super("Click Gui", new String[] {"clickgui","gui"}, ModuleType.RENDER);
    }
    
 //   private final ResourceLocation img = new ResourceLocation("textures/gui/title/minecraft.png");
    
    @Override
    protected void onEnable()
    {
        super.onEnable();
        minecraft.displayGuiScreen(me.comu.gun.module.impl.toggle.render.clickgui.ClickGui.getClickGui());
        setRunning(false);
        
    }
}
