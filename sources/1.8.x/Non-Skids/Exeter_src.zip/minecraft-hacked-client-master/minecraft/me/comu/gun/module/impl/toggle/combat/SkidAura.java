package me.comu.gun.module.impl.toggle.combat;

import me.comu.api.event.Listener;
import me.comu.api.stopwatch.Stopwatch;
import me.comu.gun.core.Gun;
import me.comu.gun.events.MotionUpdateEvent;
import me.comu.gun.logging.Logger;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import me.comu.gun.module.impl.active.render.TextGUI;
import me.comu.gun.properties.EnumProperty;
import me.comu.gun.properties.NumberProperty;
import me.comu.gun.properties.Property;
import me.comu.gun.utils.ClientUtils;
import me.comu.gun.utils.RotationUtils;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class SkidAura extends ToggleableModule
{

    public  static final EnumProperty<Type> type;
    private static final EnumProperty<Rotations> rotations;
    private static final EnumProperty<Priority> priority;
    private  static final Property<Boolean> autoblock;
    private final NumberProperty<Float> range;
    private  final NumberProperty<Float> blockRange;
    private static final Property<Boolean> players;
    private static final Property<Boolean> animals;
    private static final Property<Boolean> teams;
    private  final NumberProperty<Long> hitChance;
    private static final Property<Boolean> walls;
    private static final  Property<Boolean> invisibles;
    private  final NumberProperty<Long> maxAPS;
    private  final NumberProperty<Long> minAPS;
    private static final EnumProperty<AutoBlockMode> autoBlockMode;
    private static final EnumProperty<Mode> mode;
    private static final Property<Boolean>  death;
    private static final Property<Boolean> interact;
    public static EntityLivingBase target;
    public static EntityLivingBase vip;
    public static EntityLivingBase blockTarget;
    private Stopwatch switchTimer;
    public static float sYaw;
    public static float sPitch;
    public static float aacB;
    private double fall;
    int[] randoms;
    private boolean isBlocking;
    private Stopwatch newTarget;
    private Stopwatch lastStep;
    private Stopwatch rtimer;
    private List<EntityLivingBase> loaded;
    private int index;
    private int timer;
    private int crits;
    private int groundTicks;



    static
    {
        autoblock = new Property<Boolean>(true, new String[] { "Auto-Block","b", "ab", "block","autoblock" });
        players = new Property<Boolean>(true, new String[] { "Players", "player", "p", "pl" });
        animals = new Property<Boolean>(true, new String[] { "Others", "animal", "an","monster","monsters","mon","other" });
        invisibles = new Property<Boolean>(true, new String[] { "Invisibles", "invisible", "invis", "inv" });
        interact = new Property<Boolean>(true, new String[] { "Interact"});
        death = new Property<Boolean>(true, new String[] { "Death" });
        walls= new Property<Boolean>(true, new String[] { "Walls","wall" });
        teams = new Property<Boolean>(true, new String[] { "Teams" });
        autoBlockMode = new EnumProperty<AutoBlockMode>(AutoBlockMode.NCP, new String[] { "Block-Mode","autoblockmode", "abm", "bm","blockmode"});
        mode = new EnumProperty<Mode>(Mode.Single, new String[] { "Mode","Targeting", "target", "t" });
        type = new EnumProperty<Type>(Type.PRE, new String[] { "Type", "motionmode", "motiontype" });
        rotations = new EnumProperty<Rotations>(Rotations.Smooth, new String[] { "Rotations", "rotationtype", "rotationmode" });
        priority= new EnumProperty<Priority>(Priority.Angle, new String[] { "Priority"});


    }

    public SkidAura()
    {
        super("Aura" , new String[] {"skidaura", "saura", "skiddedaura"}, 0xF75FFF, ModuleType.COMBAT);
        this.minAPS= new NumberProperty<Long>(Long.valueOf(10L), Long.valueOf(1L), Long.valueOf(20L), new String[] { "Min-APS", "minaps","max"});
        this.maxAPS= new NumberProperty<Long>(Long.valueOf(10L), Long.valueOf(1L), Long.valueOf(20L), new String[] { "Max-APS", "maxaps","min"});
        this.range = new NumberProperty<Float>(Float.valueOf(5f), Float.valueOf(3.0f), Float.valueOf(6.0f), new String[] { "Reach", "range", "r" });
        this.hitChance = new NumberProperty<Long>(Long.valueOf(100L), Long.valueOf(0L), Long.valueOf(100L), new String[] { "Hit-Chance", "hitchance", "chance" });
        this.blockRange = new NumberProperty<Float>(Float.valueOf(5f), Float.valueOf(3.0f), Float.valueOf(6.0f), new String[] { "Block-Range", "brange", "blockrange","breach","blockreach" });
        this.offerProperties(minAPS, maxAPS, range, hitChance, blockRange, autoblock, players, animals, invisibles, interact, walls, teams, autoBlockMode, mode, type, rotations, priority);
        this.listeners.add(new Listener<MotionUpdateEvent>("kill_aura_motion_update_listener")
        {
            @Override
            public void call(MotionUpdateEvent event)
            {
                TextGUI textGUI = (TextGUI) Gun.getInstance().getModuleManager().getModuleByAlias("textgui");
                Property<Boolean> sf = textGUI.getPropertyByAlias("Suffix");
                if (sf.getValue()) {
                    setTag(String.format("Aura \2477" + mode.getFixedValue()));
                }
                boolean shouldMiss = randomNumber(0, 100) > hitChance.getValue();
                Long cps = randomNumber(maxAPS.getValue(), minAPS.getValue());
                EntityLivingBase newT = getOptimalTarget(range.getValue());
                if (event.getTime() == MotionUpdateEvent.Time.BEFORE) {
                    ++timer;
                    if (death.getValue()) {
                        if (!minecraft.thePlayer.isEntityAlive() || (minecraft.currentScreen != null && minecraft.currentScreen instanceof GuiGameOver)) {
                            toggle();
                            Logger.getLogger().printToChat("Aura disabled due to death.");
                            return;
                        }
                        if (minecraft.thePlayer.ticksExisted <= 1) {
                            toggle();
                            Logger.getLogger().printToChat("Aura disabled due to respawn.");
                            return;
                        }
                    }
                    blockTarget = getOptimalTarget(blockRange.getValue());
                    if (mode.getValue() == Mode.Multi) {
                        loaded = getTargets(range.getValue());
                        if (loaded.size() > 0) {
                            target = loaded.get(0);
                            final float[] rot = RotationUtils.getRotations(target);
                            event.setRotationYaw(rot[0]);
                            event.setRotationPitch(rot[1]);
                            sYaw = rot[0];
                            sPitch = rot[1];
                            if (autoblock.getValue()) {
                                if (hasSword()) {
                                    minecraft.thePlayer.itemInUseCount = 999;
                                }
                                else if (minecraft.thePlayer.itemInUseCount == 999) {
                                    minecraft.thePlayer.itemInUseCount = 0;
                                }
                            }
                            else if (minecraft.thePlayer.itemInUseCount == 999) {
                                if (isBlocking && hasSword()) {
                                    unBlock();
                                }
                                minecraft.thePlayer.itemInUseCount = 0;
                            }
                            if (timer >= 20 / cps) {
                                timer = 0;
                                AutoHeal autoHeal = (AutoHeal) Gun.getInstance().getModuleManager().getModuleByAlias("autoheal");
                                AutoHeal2 autoHeal2 = (AutoHeal2) Gun.getInstance().getModuleManager().getModuleByAlias("autopot2");
                                if (autoHeal.isPotting() || autoHeal2.isPotting) {
                                    shouldMiss = true;
                                    minecraft.thePlayer.swingItem();
                                }
                                if (isBlocking && hasSword()) {
                                    unBlock();
                                }
                                if (loaded.size() >= 1 && !shouldMiss) {
                                    minecraft.playerController.syncCurrentPlayItem();
                                    minecraft.thePlayer.swingItem();
                                }
                                for (final EntityLivingBase targ : loaded) {
                                    if (!shouldMiss) {
                                       // final EventAttack ej = (EventAttack)EventSystem.getInstance(EventAttack.class);
                                       // ej.fire(target, true);
                                        minecraft.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(targ, C02PacketUseEntity.Action.ATTACK));
                                        minecraft.thePlayer.attackTargetEntityWithCurrentItem(targ);
                                       // ej.fire(target, false);
                                        attack(targ);
                                    }
                                }
                                if (autoblock.getValue() && (autoBlockMode.getValue() == AutoBlockMode.Basic1) && hasSword()) {
                                    block(target);
                                }
                            }
                            else if (autoblock.getValue() && (autoBlockMode.getValue() == AutoBlockMode.NCP || autoBlockMode.getValue() == AutoBlockMode.Hypixel) && hasSword() && isBlocking) {
                                unBlock();
                            }
                        }
                    }
                    else {
                        if (mode.getValue() == Mode.Switch) {
                            final Long cooldown = rotations.getValue() == Rotations.Smooth  ? 500L : 400L;
                            if (switchTimer.hasCompleted(cooldown)) {
                                loaded = getTargets(range.getValue());
                            }
                            if (index >= loaded.size()) {
                                index = 0;
                            }
                            if (switchTimer.hasCompleted(cooldown) && loaded.size() > 0) {
                                ++index;
                                if (index >= loaded.size()) {
                                    index = 0;
                                }
                                switchTimer.reset();
                            }
                            if (loaded.size() > 0) {
                                newT = loaded.get(index);
                            }
                            else {
                                newT = null;
                            }
                        }
                        else if (mode.getValue() == Mode.Multi2) {
                            loaded = getTargets(range.getValue());
                            if (index >= loaded.size()) {
                                index = 0;
                            }
                            if (timer >= 20 / cps && loaded.size() > 0) {
                                ++index;
                                if (index >= loaded.size()) {
                                    index = 0;
                                }
                            }
                            if (loaded.size() > 0) {
                                newT = loaded.get(index);
                            }
                            else {
                                newT = null;
                            }
                        }
                        if (target != newT) {
                            newTarget.reset();
                            if (!(mode.getValue() == Mode.Multi2)) {
                                shouldMiss = true;
                            }
                            target = newT;
                            if (target == null) {
                                sYaw = minecraft.thePlayer.rotationYaw;
                                sPitch = minecraft.thePlayer.rotationPitch;
                            }
                        }
                        if (target != null) {
                            if ((!validEntity(target, range.getValue()) || !minecraft.theWorld.loadedEntityList.contains(target)) && mode.getValue() == Mode.Switch) {
                                loaded = getTargets(range.getValue());
                                ++index;
                                if (index >= loaded.size()) {
                                    index = 0;
                                }
                                return;
                            }
                            if (!validEntity(target, range.getValue()) && mode.getValue() == Mode.Multi2) {
                                loaded = getTargets(range.getValue());
                                return;
                            }
                            float[] rot = RotationUtils.getRotations(target);
                            switch (rotations.getValue()) {
                                case Basic: {
                                    event.setRotationYaw(rot[0]);
                                    event.setRotationPitch(rot[1]);
                                    sYaw = rot[0];
                                    sPitch = rot[1];
                                    break;
                                }
                                case Smooth: {
                                    smoothAim(event);
                                    break;
                                }
                                case Legit: {
                                    aacB /= 2.0f;
                                    customRots(event, target);
                                    break;
                                }
                                case Predict: {
                                    rot = RotationUtils.getPredictedRotations(target);
                                    event.setRotationYaw(rot[0]);
                                    event.setRotationPitch(rot[1]);
                                    sYaw = rot[0];
                                    sPitch = rot[1];
                                    break;
                                }
                            }
                            if (timer >= 20 / cps && type.getValue() == Type.PRE) {
                                timer = 0;
                                final int XR = randomNumber(1, -1);
                                final int YR = randomNumber(1, -1);
                                final int ZR = randomNumber(1, -1);
                                randoms[0] = XR;
                                randoms[1] = YR;
                                randoms[2] = ZR;
                                float neededYaw = RotationUtils.getYawChange(sYaw, target.posX, target.posZ);
                                if (rotations.getValue() == Rotations.Legit) {
                                    neededYaw = getCustomRotsChange(sYaw, sPitch, target.posX, target.posY, target.posZ)[0];
                                }
                                float interval = 60.0f - minecraft.thePlayer.getDistanceToEntity(target) * 10.0f;
                                if (rotations.getValue() == Rotations.Legit) {
                                    interval = 50.0f - minecraft.thePlayer.getDistanceToEntity(target) * 10.0f;
                                }
                                AutoHeal autoHeal = (AutoHeal) Gun.getInstance().getModuleManager().getModuleByAlias("autoheal");
                                AutoHeal2 autoHeal2 = (AutoHeal2) Gun.getInstance().getModuleManager().getModuleByAlias("autopot2");
                                if (neededYaw > interval || neededYaw < -interval || !newTarget.hasCompleted(70L) || autoHeal.isPotting() || autoHeal2.isPotting) {
                                    shouldMiss = true;
                                }
                                if (!shouldMiss || mode.getValue() == Mode.Multi2) {
                                    //hitEntity(target, autoblock, autoBlockMode.getValue());
                                    attack(target);
                                }
                                else {
                                    minecraft.thePlayer.swingItem();
                                }
                            }
                        }
                    }
                    if (blockTarget != null) {
                        if (autoblock.getValue()) {
                            if (hasSword()) {
                                if (autoBlockMode.getValue() == AutoBlockMode.NCP || autoBlockMode.getValue() == AutoBlockMode.Hypixel) {
                                    if (hasSword() && isBlocking) {
                                        unBlock();
                                    }
                                }
                                else if (minecraft.thePlayer.itemInUseCount == 0) {
                                    block(blockTarget);
                                }
                                minecraft.thePlayer.itemInUseCount = 999;
                            }
                            else if (minecraft.thePlayer.itemInUseCount == 999) {
                                minecraft.thePlayer.itemInUseCount = 0;
                            }
                        }
                        else if (minecraft.thePlayer.itemInUseCount == 999) {
                            if (isBlocking && hasSword()) {
                                unBlock();
                            }
                            minecraft.thePlayer.itemInUseCount = 0;
                        }
                    }
                    else if (minecraft.thePlayer.itemInUseCount == 999) {
                        if (isBlocking && hasSword()) {
                            unBlock();
                        }
                        minecraft.thePlayer.itemInUseCount = 0;
                    }
                } else {
                    if (type.getValue() == Type.POST && target != null) {
                        timer = 0;
                        final int XR2 = randomNumber(1, -1);
                        final int YR2 = randomNumber(1, -1);
                        final int ZR2 = randomNumber(1, -1);
                        randoms[0] = XR2;
                        randoms[1] = YR2;
                        randoms[2] = ZR2;
                        float neededYaw2 = RotationUtils.getYawChange(sYaw, target.posX, target.posZ);
                        if (rotations.getValue() == Rotations.Legit) {
                            neededYaw2 = getCustomRotsChange(sYaw, sPitch, target.posX, target.posY, target.posZ)[0];
                        }
                        float interval2 = 60.0f - minecraft.thePlayer.getDistanceToEntity(target) * 10.0f;
                        if (rotations.getValue() == Rotations.Legit) {
                            interval2 = 50.0f - minecraft.thePlayer.getDistanceToEntity(target) * 10.0f;
                        }
                        AutoHeal autoHeal = (AutoHeal) Gun.getInstance().getModuleManager().getModuleByAlias("autoheal");
                        AutoHeal2 autoHeal2 = (AutoHeal2) Gun.getInstance().getModuleManager().getModuleByAlias("autopot2");
                        if (neededYaw2 > interval2 || neededYaw2 < -interval2 || !newTarget.hasCompleted(70) || autoHeal.isPotting() || autoHeal2.isPotting) {
                            shouldMiss = true;
                        }
                        if (!shouldMiss || mode.getValue() == Mode.Multi2) {
                           // hitEntity(target, autoblock, autoBlockMode.getValue());
                            attack(target);
                        }
                        else {
                            minecraft.thePlayer.swingItem();
                        }
                    }
                    if (blockTarget != null && !isBlocking && autoblock.getValue() && hasSword()) {
                        if (autoBlockMode.getValue() == AutoBlockMode.Hypixel) {
                            blockHypixel(blockTarget);
                        }
                        else if (autoBlockMode.getValue() == AutoBlockMode.NCP) {
                            block(blockTarget);
                        }
                        else if (autoBlockMode.getValue() == AutoBlockMode.Basic2 && timer == 0) {
                            block(blockTarget);
                        }
                    }
                }

            }
        });
    }

    @Override
    protected void onEnable()
    {
        super.onEnable();
        if (minecraft.thePlayer != null) {
            sYaw = minecraft.thePlayer.rotationYaw;
            sPitch = minecraft.thePlayer.rotationPitch;
            // loaded.clear();
            isBlocking = minecraft.thePlayer.isBlocking();
        }
        //newTarget.reset();
        timer = 20;
        groundTicks = (ClientUtils.isOnGround(0.01) ? 1 : 0);
        aacB = 0.0f;
    }

    @Override
    protected void onDisable() {
        super.onDisable();
       // loaded.clear();
        if (minecraft.thePlayer == null) {
            return;
        }
        if (isBlocking && hasSword() && minecraft.thePlayer.getItemInUseCount() == 999) {
            this.unBlock();
        }
        if (minecraft.thePlayer.getItemInUseCount() == 999) {
            minecraft.thePlayer.clearItemInUse();
        }
        target = null;
        blockTarget = null;
    }
    private static void attack(Entity entity)
    {
        boolean wasSprinting = minecraft.thePlayer.isSprinting();
        boolean wasSneaking = minecraft.thePlayer.isSneaking();
        boolean wasBlocking = minecraft.thePlayer.isBlocking();

        if (wasSprinting)
        {
            minecraft.getNetHandler().addToSendQueue(new C0BPacketEntityAction(minecraft.thePlayer, C0BPacketEntityAction.Action.STOP_SPRINTING));
        }

        if (wasSneaking)
        {
            minecraft.getNetHandler().addToSendQueue(new C0BPacketEntityAction(minecraft.thePlayer, C0BPacketEntityAction.Action.STOP_SNEAKING));
        }

        if (wasBlocking)
        {
            minecraft.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
        }

        minecraft.thePlayer.swingItem();


        minecraft.getNetHandler().addToSendQueue(new C02PacketUseEntity(entity, C02PacketUseEntity.Action.ATTACK));


        if (wasBlocking)
        {
            minecraft.getNetHandler().addToSendQueue(new C08PacketPlayerBlockPlacement(minecraft.thePlayer.getCurrentEquippedItem()));
        }

        if (wasSprinting)
        {
            minecraft.getNetHandler().addToSendQueue(new C0BPacketEntityAction(minecraft.thePlayer, C0BPacketEntityAction.Action.START_SPRINTING));
        }

        if (wasSneaking)
        {
            minecraft.getNetHandler().addToSendQueue(new C0BPacketEntityAction(minecraft.thePlayer, C0BPacketEntityAction.Action.START_SNEAKING));
        }
    }
    private void blockHypixel(final EntityLivingBase ent) {
        this.isBlocking = true;
        if (interact.getValue()) {
            minecraft.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(ent, new Vec3(randomNumber(-50, 50) / 100.0, randomNumber(0, 200) / 100.0, randomNumber(-50, 50) / 100.0)));
            minecraft.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(ent, C02PacketUseEntity.Action.INTERACT));
        }
        minecraft.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(ClientUtils.getHypixelBlockpos(minecraft.getSession().getUsername()), 255, minecraft.thePlayer.inventory.getCurrentItem(), 0.0f, 0.0f, 0.0f));
    }
    private void block(final EntityLivingBase ent) {
        this.isBlocking = true;
        if (interact.getValue()) {
            minecraft.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(ent, new Vec3(randomNumber(-50, 50) / 100.0, randomNumber(0, 200) / 100.0, randomNumber(-50, 50) / 100.0)));
            minecraft.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(ent, C02PacketUseEntity.Action.INTERACT));
        }
        minecraft.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(minecraft.thePlayer.inventory.getCurrentItem()));
    }

    public float[] getCustomRotsChange(final float yaw, final float pitch, double x, double y, double z) {
        double xDiff = x - minecraft.thePlayer.posX;
        double zDiff = z - minecraft.thePlayer.posZ;
        double yDiff = y - minecraft.thePlayer.posY;
        final double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        double mult = 1.0 / (dist + 1.0E-4) * 2.0;
        if (mult > 0.2) {
            mult = 0.2;
        }
        if (!minecraft.theWorld.getEntitiesWithinAABBExcludingEntity(minecraft.thePlayer, minecraft.thePlayer.boundingBox).contains(target)) {
            x += 0.3 * this.randoms[0];
            y -= 0.4 + mult * this.randoms[1];
            z += 0.3 * this.randoms[2];
        }
        xDiff = x - minecraft.thePlayer.posX;
        zDiff = z - minecraft.thePlayer.posZ;
        yDiff = y - minecraft.thePlayer.posY;
        final float yawToEntity = (float)(Math.atan2(zDiff, xDiff) * 180.0 / 3.141592653589793) - 90.0f;
        final float pitchToEntity = (float)(-(Math.atan2(yDiff, dist) * 180.0 / 3.141592653589793));
        return new float[] { MathHelper.wrapAngleTo180_float(-(yaw - yawToEntity)), -MathHelper.wrapAngleTo180_float(pitch - pitchToEntity) - 2.5f };
    }
    public void customRots(final MotionUpdateEvent em, final EntityLivingBase ent) {
        final double randomYaw = 0.05;
        final double randomPitch = 0.05;
        final float[] rotsN = getCustomRotsChange(sYaw,sPitch, target.posX + randomNumber(1, -1) * randomYaw, target.posY + randomNumber(1, -1) * randomPitch, target.posZ + randomNumber(1, -1) * randomYaw);
        final float targetYaw = rotsN[0];
        float yawFactor = targetYaw * targetYaw / (4.7f * targetYaw);
        if (targetYaw < 5.0f) {
            yawFactor = targetYaw * targetYaw / (3.7f * targetYaw);
        }
        if (Math.abs(yawFactor) > 7.0f) {
            aacB = yawFactor * 7.0f;
            yawFactor = targetYaw * targetYaw / (3.7f * targetYaw);
        }
        else {
            yawFactor = targetYaw * targetYaw / (6.7f * targetYaw) + aacB;
        }
        em.setRotationYaw(sYaw + yawFactor);
        sYaw += yawFactor;
        final float targetPitch = rotsN[1];
        final float pitchFactor = targetPitch / 3.7f;
        em.setRotationPitch(sPitch + pitchFactor);
        sPitch += pitchFactor;
    }
    private void smoothAim(MotionUpdateEvent em) {
        final double randomYaw = 0.05;
        final double randomPitch = 0.05;
        final float targetYaw = RotationUtils.getYawChange(sYaw, target.posX + randomNumber(1, -1) * randomYaw, target.posZ + randomNumber(1, -1) * randomYaw);
        final float yawFactor = targetYaw / 1.7f;
        em.setRotationYaw(sYaw + yawFactor);
        sYaw += yawFactor;
        final float targetPitch = RotationUtils.getPitchChange(sPitch, target, target.posY + randomNumber(1, -1) * randomPitch);
        final float pitchFactor = targetPitch / 1.7f;
        em.setRotationPitch(sPitch + pitchFactor);
        sPitch += pitchFactor;
    }
    private boolean hasSword() {
        return minecraft.thePlayer.inventory.getCurrentItem() != null && minecraft.thePlayer.inventory.getCurrentItem().getItem() instanceof ItemSword;
    }
    private void unBlock() {
        this.isBlocking = false;
        minecraft.playerController.syncCurrentPlayItem();
        minecraft.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
    }
    public static int randomNumber(final int max, final int min) {
        return Math.round(min + (float)Math.random() * (max - min));
    }
    public static Long randomNumber(final Long max, final Long min) {
        return Math.round(min + Math.random() * (max - min));
    }
    boolean validEntity(final EntityLivingBase entity, final double range) {
        if (minecraft.thePlayer.isEntityAlive() && !(entity instanceof EntityPlayerSP) && minecraft.thePlayer.getDistanceToEntity(entity) <= range) {
            if (!RotationUtils.canEntityBeSeen(entity) && !walls.getValue()) {
                return false;
            }

            if (Gun.getInstance().getFriendManager().isFriend(entity.getName())) {
                return false;
            }
            if (entity instanceof EntityPlayer) {
                if (players.getValue()) {
                    final EntityPlayer player = (EntityPlayer)entity;
                    return (player.isEntityAlive() || player.getHealth() != 0.0) && (!ClientUtils.isTeam(minecraft.thePlayer, player) || !(teams.getValue()) && (!player.isInvisible() || (invisibles.getValue()) && !Gun.getInstance().getFriendManager().isFriend(player.getName())));
                }
            }
            else if (!entity.isEntityAlive()) {
                return false;
            }
            if (animals.getValue() && (entity instanceof EntityMob || entity instanceof EntityIronGolem || entity instanceof EntityAnimal || entity instanceof EntityVillager)) {
                return !entity.getName().equals("Villager") || !(entity instanceof EntityVillager);
            }
        }
        return false;
    }
    private List<EntityLivingBase> getTargets(final double range) {
        final List<EntityLivingBase> targets = new ArrayList<EntityLivingBase>();
        for (final Object o : minecraft.theWorld.loadedEntityList) {
            if (o instanceof EntityLivingBase) {
                final EntityLivingBase entity = (EntityLivingBase)o;
                if (!this.validEntity(entity, range)) {
                    continue;
                }
                targets.add(entity);
            }
        }
        this.sortList(targets);
        return targets;
    }

    private EntityLivingBase getTarget(final List<EntityLivingBase> list) {
        this.sortList(list);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }
    private void sortList(final List<EntityLivingBase> weed) {
        switch (priority.getValue()) {
            case Range: {
                weed.sort((o1, o2) -> (int)(o1.getDistanceToEntity(minecraft.thePlayer) * 1000.0f - o2.getDistanceToEntity(minecraft.thePlayer) * 1000.0f));
                break;
            }
            case FOV: {
                weed.sort(Comparator.comparingDouble(o -> RotationUtils.getDistanceBetweenAngles(minecraft.thePlayer.rotationPitch, RotationUtils.getRotations(o)[0])));
                break;
            }
            case Angle: {

                weed.sort((o1, o2) -> {
                    final float[] rot1;
                    final float[] rot2;
                    rot1 = RotationUtils.getRotations(o1);
                    rot2 = RotationUtils.getRotations(o2);
                    return (int)(minecraft.thePlayer.rotationYaw - rot1[0] - (minecraft.thePlayer.rotationYaw - rot2[0]));
                });
                break;
            }
            case Health: {
                weed.sort((o1, o2) -> (int)(o1.getHealth() - o2.getHealth()));
                break;
            }
            case Armor: {
                weed.sort(Comparator.comparingInt(o -> (o instanceof EntityPlayer) ? ((EntityPlayer) o).inventory.getTotalArmorValue() : ((int)o.getHealth())));
                break;
            }
        }
    }
    private EntityLivingBase getOptimalTarget(final double range) {
        final List<EntityLivingBase> load = new ArrayList<EntityLivingBase>();
        for (final Object o : minecraft.theWorld.loadedEntityList) {
            if (o instanceof EntityLivingBase) {
                final EntityLivingBase ent = (EntityLivingBase)o;
                if (!validEntity(ent, range)) {
                    continue;
                }
                if (ent == vip) {
                    return ent;
                }
                load.add(ent);
            }
        }
        if (load.isEmpty()) {
            return null;
        }
        return getTarget(load);
    }

    private enum Mode
    {
        Switch, Single, Multi, Multi2
    }
    private enum Type
    {
        PRE, POST
    }
    private enum AutoBlockMode
    {
        Basic1, NCP, Hypixel, Basic2
    }
    private enum Rotations
    {
        Basic, Smooth, Legit, Predict
    }
    private enum Priority
    {
        Angle, Range, Health, FOV, Armor
    }
}
