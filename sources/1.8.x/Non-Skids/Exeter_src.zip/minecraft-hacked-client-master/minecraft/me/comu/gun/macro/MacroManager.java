package me.comu.gun.macro;

import org.lwjgl.input.Keyboard;


import me.comu.gun.events.ActionEvent;
import me.comu.gun.plugin.ElementManager;

import java.util.ArrayList;

public final class MacroManager extends ElementManager<Macro> {



    public MacroManager() {

        elements = new ArrayList<>();


//        public void actionPerformed(ActionEvent event) {
//            if (event.getType() == ActionEvent.Type.KEY_PRESS)
//                getElements().forEach(macro -> {
//                    if (macro.getKey() != Keyboard.KEY_NONE && macro.getKey() == event.getKey())
//                        macro.dispatch();
//                });
//        }




    }

    public Macro getUsingKey(int key) {
        for (Macro macro : elements)
            if (key == macro.getKey())
                return macro;
        return null;
    }

    public boolean isMacro(int key) {
        for (Macro macro : elements)
            if (key == macro.getKey())
                return true;
        return false;
    }

    public void remove(int key) {
        Macro macro = getUsingKey(key);
        if (macro != null)
            elements.remove(macro);
    }
}
