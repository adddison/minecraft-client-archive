package me.comu.gun.module.impl.toggle.render.tabgui.item;

import me.comu.gun.properties.Property;

public class GuiPropertyItem {
	
	private final Property property;
	
	public GuiPropertyItem(Property property)
	{
		this.property = property;
	}
	
	public Property getProperties() 
	{
		return property;
	}

}
