package me.comu.gun.module.impl.toggle.render;

import com.sun.org.apache.xpath.internal.operations.Bool;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import me.comu.gun.properties.Property;

public final class ViewClip extends ToggleableModule
{




    public ViewClip()
    {
        super("ViewClip", new String[] {"viewclip", "vc"}, ModuleType.RENDER);

    }
}