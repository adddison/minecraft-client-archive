package me.comu.gun.module.impl.toggle.world;

import me.comu.api.event.Listener;
import me.comu.gun.events.MotionUpdateEvent;
import me.comu.gun.events.RenderEvent;
import me.comu.gun.events.UpdateEvent;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import me.comu.gun.properties.EnumProperty;
import me.comu.gun.utils.GuiUtils;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.init.Blocks;
import net.minecraft.pathfinding.PathEntity;
import net.minecraft.pathfinding.PathFinder;
import net.minecraft.pathfinding.PathPoint;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import org.lwjgl.opengl.GL11;

public final class Control extends ToggleableModule
{
   // private final NumberProperty<Float> speed = new NumberProperty<>(1.1F, 0.1F, 10F, "Speed", "s");
   // private final NumberProperty<Integer> delay = new NumberProperty<>(1, 0, 50, "Delay", "d");
 //   private final Property<Boolean> fastfall = new Property<>(true, "Fastfall", "ff"), autoTool = new Property<>(true, "AutoTool", "at", "tool");
    private final EnumProperty<Mode> mode = new EnumProperty<>(Mode.SURVIVAL, "Mode", "m");    private BlockPos selection;
    private MovingObjectPosition target;
    private float yaw;
    private float pitch;
    private float inputYaw;
    private float inputPitch;
    public PathFinder pathFinder;
    public float oldYaw;
    public float oldPitch;
    private EntityOtherPlayerMP fakePlayer;
    public static Vec3 pos1;
    public static Vec3 pos2;



    public Control()
    {
        super("Control", new String[] {"survival", "survivalnuker", "sn", "nuker", "control"}, 0xFFCC846E, ModuleType.WORLD);
      //  this.offerProperties(speed, fastfall, autoTool, delay);
        this.offerProperties(mode);
        this.listeners.add(new Listener<UpdateEvent>("speedy_gonzales_mining_speed_listener")
        {
            @Override
            public void call(UpdateEvent event)
            {
            	if (Control.this.isRunning()) {
            		oldPitch = Control.minecraft.thePlayer.rotationPitch;
            		oldYaw = Control.minecraft.thePlayer.rotationYaw;
            		 if (selection != null && Control.minecraft.thePlayer.getDistance(selection.getX() + 0.5, selection.getY() + 0.5, selection.getZ() + 0.5) > 3.5) {
            			 final PathEntity pe = pathFinder.func_180782_a(Control.minecraft.theWorld, Control.minecraft.thePlayer, selection, 50.0f);
            			 if (pe != null && pe.getCurrentPathLength() > 1) {
            				 final PathPoint point = pe.getPathPointFromIndex(1);
                             final float[] rot = getRotationTo(new Vec3(point.xCoord + 0.5, point.yCoord + 0.5, point.zCoord + 0.5));
                             Control.minecraft.thePlayer.rotationYaw = rot[0];
                             final EntityPlayerSP thePlayer = Control.minecraft.thePlayer;
                             final EntityPlayerSP thePlayer2 = Control.minecraft.thePlayer;
                             final double n = 0.0;
                             thePlayer2.motionZ = n;
                             thePlayer.motionX = n;
                             final double offset = mode.getValue().equals(Control.Mode.SURVIVAL) ? 0.3f : 0.5f;
                             final double newx = Math.sin(Control.minecraft.thePlayer.rotationYaw * 3.1415927f / 180.0f) * offset;
                             final double newz = Math.cos(Control.minecraft.thePlayer.rotationYaw * 3.1415927f / 180.0f) * offset;
                             final EntityPlayerSP thePlayer3 = Control.minecraft.thePlayer;
                             thePlayer3.motionX -= newx;
                             final EntityPlayerSP thePlayer4 = Control.minecraft.thePlayer;
                             thePlayer4.motionZ += newz;
                             switch (mode.getValue())
                             {
                             case CREATIVE:

                             if (Control.minecraft.thePlayer.isCollidedHorizontally && Control.minecraft.thePlayer.onGround) {
                                 Control.minecraft.thePlayer.setPosition(Control.minecraft.thePlayer.posX, Control.minecraft.thePlayer.posY + 1.0, Control.minecraft.thePlayer.posZ);
                             }
                             case SURVIVAL:
                                 if (Control.minecraft.thePlayer.isCollidedHorizontally && Control.minecraft.thePlayer.onGround) {
                                     Control.minecraft.thePlayer.jump();
                                 }
                             }
                             if ((Control.minecraft.thePlayer.isInWater() || Control.minecraft.thePlayer.isInsideOfMaterial(Material.lava)) && !Control.minecraft.gameSettings.keyBindSneak.pressed && !Control.minecraft.gameSettings.keyBindJump.pressed) {
                                 final EntityPlayerSP thePlayer5 = Control.minecraft.thePlayer;
                             }


            			 }
            		 }
            		    final Vec3 pos1 = Control.pos1;
                        final Vec3 pos2 = Control.pos2;
                        target = null;
                        selection = null;
                        if (pos1 != null && pos2 != null) {
                            final double minX = Math.min(pos1.xCoord, pos2.xCoord);
                            final double maxX = Math.max(pos1.xCoord, pos2.xCoord);
                            final double minY = Math.min(pos1.yCoord, pos2.yCoord);
                            final double maxY = Math.max(pos1.yCoord, pos2.yCoord);
                            final double minZ = Math.min(pos1.zCoord, pos2.zCoord);
                            final double maxZ = Math.max(pos1.zCoord, pos2.zCoord);
                            double x = maxX;
                            double y = maxY;
                            double z = maxZ;
                            boolean xDir = false;
                            boolean zDir = false;
                            while (true) {
                                final BlockPos blockPos = new BlockPos(x, y, z);
                                if (isBlockInSelection(blockPos)) {
                                    final IBlockState state = Control.minecraft.theWorld.getBlockState(blockPos);
                                    if (state.getBlock() != Blocks.air) {
                                        selection = blockPos;
                                        break;
                                    }
                                }
                                x += (xDir ? 1 : -1);
                                if (xDir) {
                                    if (x <= Math.max(pos1.xCoord, pos2.xCoord)) {
                                        continue;
                                    }

                                }
                                else if (x >= Math.min(pos1.xCoord, pos2.xCoord)) {
                                    continue;
                                }
                                xDir = !xDir;
                                z += (zDir ? 1 : -1);
                                if (zDir) {
                                    if (z <= Math.max(pos1.zCoord, pos2.zCoord)) {
                                        continue;
                                    }
                                }
                                else if (z >= Math.min(pos1.zCoord, pos2.zCoord)) {
                                    continue;
                                }
                                --y;
                                zDir = !zDir;
                                xDir = !xDir;
                                if (y < Math.min(pos1.yCoord, pos2.yCoord)) {
                                    break;
                                }


                            }


                        }
                        if (selection != null) {
                            final Block block = Control.minecraft.theWorld.getBlockState(selection).getBlock();
                            block.setBlockBoundsBasedOnState(Control.minecraft.theWorld, selection);
                            final AxisAlignedBB sel = block.getSelectedBoundingBox(Control.minecraft.theWorld, selection);
                            final Vec3 from = Control.minecraft.thePlayer.getPositionVector().addVector(0.0, Control.minecraft.thePlayer.getEyeHeight(), 0.0);
                            final Vec3 to = new Vec3(sel.minX + (sel.maxX - sel.minX) / 2.0, sel.minY + (sel.maxY - sel.minY) / 2.0, sel.minZ + (sel.maxZ - sel.minZ) / 2.0);
                            Vec3 alternate = null;
                            target = Control.minecraft.theWorld.rayTraceBlocks(from, to, true);

                            if (target != null) {
                                final IBlockState state2 = Control.minecraft.theWorld.getBlockState(target.func_178782_a());
                                boolean inSelection = isBlockInSelection(target.func_178782_a());
                                boolean validBlock = state2.getBlock() != Blocks.air;
                                boolean inRange = target.hitVec.distanceTo(from) < Control.minecraft.playerController.getBlockReachDistance() - 0.1 && to.distanceTo(from) < Control.minecraft.playerController.getBlockReachDistance() - 0.1;
                                if (!inRange) {
                                    target = null;
                                }
                                else if (!inSelection || !validBlock) {
                                    boolean done = false;
                                    for (int i = -1; i <= 1; ++i) {
                                        if (done) {
                                            break;
                                        }
                                        for (int j = -1; j <= 1 && !done; ++j) {
                                            for (int k = -1; k <= 1; ++k) {
                                                final Vec3 toNew = to.addVector(i / 2.0f, j / 2.0f, k / 2.0f);
                                                target = Control.minecraft.theWorld.rayTraceBlocks(from, toNew, true);
                                                if (target != null) {
                                                    inSelection = isBlockInSelection(target.func_178782_a());
                                                    validBlock = (state2.getBlock() != Blocks.air);
                                                    inRange = (target.hitVec.distanceTo(from) < Control.minecraft.playerController.getBlockReachDistance() - 0.1 && to.distanceTo(from) < Control.minecraft.playerController.getBlockReachDistance() - 0.1);
                                                    if (inSelection && validBlock && inRange) {
                                                        done = true;
                                                        alternate = target.hitVec;
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            if (target != null) {
                                float[] rot2 = getRotationTo(target);
                                if (alternate != null) {
                                    rot2 = getRotationTo(alternate);
                                }
                                final EntityPlayerSP thePlayer6 = Control.minecraft.thePlayer;
                                thePlayer6.rotationYaw += angleDifference(rot2[0], Control.minecraft.thePlayer.rotationYaw);
                                final EntityPlayerSP thePlayer7 = Control.minecraft.thePlayer;
                                thePlayer7.rotationPitch += angleDifference(rot2[1], Control.minecraft.thePlayer.rotationPitch);
                            }

                        }
            	}

    }
        });
        this.listeners.add(new Listener<MotionUpdateEvent>("phase_motion_update_listener")
        {
            @Override
            public void call(MotionUpdateEvent event)
            {
            	Control.this.isRunning();
            }
        });
        this.listeners.add(new Listener<RenderEvent>("phase_motion_update_listener")
        {
            @Override
            public void call(RenderEvent event)
            {
            	   if (Control.this.isRunning() && Control.pos1 != null && Control.pos2 != null) {
                       drawESP((int)Control.pos1.xCoord, (int)Control.pos1.yCoord, (int)Control.pos1.zCoord + 1, (int)Control.pos2.xCoord, (int)Control.pos2.yCoord, (int)Control.pos2.zCoord + 1, 0.2, 1.0, 0.2);
            }
            }
        });

    }
    protected String positions(final String mode) {
        final String pos = String.valueOf((int)Minecraft.getMinecraft().thePlayer.posX) + ", " + (int)Minecraft.getMinecraft().thePlayer.posY + ", " + (int)Minecraft.getMinecraft().thePlayer.posZ;
        if (mode.contains("pos1")) {
            Control.pos1 = Minecraft.getMinecraft().thePlayer.getPositionVector();
            return "Position 1 set to " + pos;

    }
        if (mode.contains("pos2")) {
            Control.pos2 = Minecraft.getMinecraft().thePlayer.getPositionVector();
            return "Position 2 set to " + pos;
        }
        return "Incorrect Syntax.";
    }

    public void drawESP(final double x, final double y, final double z, final double x2, final double y2, final double z2, final double r, final double g, final double b) {

        Control.minecraft.getRenderManager();
        final double x3 = x - RenderManager.renderPosX;
        Control.minecraft.getRenderManager();
        final double y3 = y - RenderManager.renderPosY;
        Control.minecraft.getRenderManager();
        final double z3 = z - RenderManager.renderPosZ;
        Control.minecraft.getRenderManager();
        final double x4 = x2 - RenderManager.renderPosX;
        Control.minecraft.getRenderManager();
        final double y4 = y2 - RenderManager.renderPosY;
        Control.minecraft.getRenderManager();
        GuiUtils.drawFilledBBESP(new AxisAlignedBB(x3, y3, z3, x4, y4, z2 - RenderManager.renderPosZ), 6719556);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    }
    public static float[] getRotationTo(final MovingObjectPosition mop) {
        final BlockPos pos = mop.func_178782_a();
        final double xD = Control.minecraft.thePlayer.posX - mop.hitVec.xCoord;
        final double yD = Control.minecraft.thePlayer.posY + Control.minecraft.thePlayer.getEyeHeight() - mop.hitVec.yCoord;
        final double zD = Control.minecraft.thePlayer.posZ - mop.hitVec.zCoord;
        final double yaw = Math.atan2(zD, xD);
        final double pitch = Math.atan2(yD, Math.sqrt(Math.pow(xD, 2.0) + Math.pow(zD, 2.0)));
        return new float[] { (float)Math.toDegrees(yaw) + 90.0f, (float)Math.toDegrees(pitch) };
    }
    public static float angleDifference(final float to, final float from) {
        return ((to - from) % 360.0f + 540.0f) % 360.0f - 180.0f;
    }

    public static float[] getRotationTo(final Vec3 pos) {
        final double xD = Control.minecraft.thePlayer.posX - pos.xCoord;
        final double yD = Control.minecraft.thePlayer.posY + Control.minecraft.thePlayer.getEyeHeight() - pos.yCoord;
        final double zD = Control.minecraft.thePlayer.posZ - pos.zCoord;
        final double yaw = Math.atan2(zD, xD);
        final double pitch = Math.atan2(yD, Math.sqrt(Math.pow(xD, 2.0) + Math.pow(zD, 2.0)));
        return new float[] { (float)Math.toDegrees(yaw) + 90.0f, (float)Math.toDegrees(pitch) };
    }
    public boolean isBlockInSelection(final BlockPos pos) {
        return Control.pos1 == null || Control.pos2 == null || (pos.getX() >= Math.min(Control.pos1.xCoord, Control.pos2.xCoord) && pos.getX() <= Math.max(Control.pos1.xCoord, Control.pos2.xCoord) && pos.getY() >= Math.min(Control.pos1.yCoord, Control.pos2.yCoord) && pos.getY() <= Math.max(Control.pos1.yCoord, Control.pos2.yCoord) && pos.getZ() >= Math.min(Control.pos1.zCoord, Control.pos2.zCoord) && pos.getZ() <= Math.max(Control.pos1.zCoord, Control.pos2.zCoord));
    }
    private enum Mode {
    	SURVIVAL, CREATIVE
    }
}
