package me.comu.gun.module.impl.toggle.movement;

import me.comu.api.event.Listener;
import me.comu.api.stopwatch.Stopwatch;
import me.comu.gun.core.Gun;
import me.comu.gun.events.EventTarget;
import me.comu.gun.events.MovePlayerEvent;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import me.comu.gun.module.impl.toggle.miscellaneous.InventoryWalk;
import me.comu.gun.properties.Property;

public final class AutoWalk extends ToggleableModule
{
	
    private final Property<Boolean> jump = new Property<>(false, "Jump","j");
    private final Property<Boolean> swim = new Property<>(false, "Swim","Swimming","s");


    public AutoWalk()
    
    {
        super("AutoWalk", new String[] {"autowalk","aw", "awalk", "automove"}, 0xFFFA8D61, ModuleType.MISCELLANEOUS);
        this.offerProperties(jump, swim);
        this.listeners.add(new Listener<MovePlayerEvent>("auto_eat_update_listener")
        {
            @EventTarget
            public void call(MovePlayerEvent event) {
                minecraft.gameSettings.keyBindForward.pressed = true;


            }
            
        });



    }

    @Override
    public void onDisable() {
        minecraft.gameSettings.keyBindForward.pressed = false;
    }


}
