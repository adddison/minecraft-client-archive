package me.comu.gun.module.impl.toggle.combat;

import me.comu.api.event.Listener;
import me.comu.api.minecraft.helper.EntityHelper;
import me.comu.api.minecraft.helper.PlayerHelper;
import me.comu.api.stopwatch.Stopwatch;
import me.comu.gun.core.Gun;
import me.comu.gun.events.MotionUpdateEvent;
import me.comu.gun.logging.Logger;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import me.comu.gun.module.impl.active.render.TextGUI;
import me.comu.gun.module.impl.toggle.exploits.FastUse;
import me.comu.gun.module.impl.toggle.movement.NoFall;
import me.comu.gun.module.impl.toggle.movement.Speed;
import me.comu.gun.module.impl.toggle.movement.Step;
import me.comu.gun.presets.Preset;
import me.comu.gun.properties.EnumProperty;
import me.comu.gun.properties.NumberProperty;
import me.comu.gun.properties.Property;
import me.comu.gun.utils.ClientUtils;
import me.comu.gun.utils.RotationUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.monster.*;
import net.minecraft.entity.passive.*;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.*;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;

public final class KillAura extends ToggleableModule
{
    private final NumberProperty<Long> aps;
    private static final Property<Boolean> autoBlock;
    private static final Property<Boolean> pSilent;
    private static final Property<Boolean> angle;
    private static final Property<Boolean> armor;
    private static final Property<Boolean> dura;
    public final static Property<Boolean> team;
    private static final Property<Boolean> direction;
    private static final Property<Boolean> smart;
    private static final Property<Boolean> rayTrace;
    private static final Property<Boolean> players;
    private static final Property<Boolean> animals;
    private static final Property<Boolean> monsters;
    private static final Property<Boolean> invisibles;
    private static final Property<Boolean> silent;
    private static final Property<Boolean> noswing;
    private static final Property<Boolean> hvh;
    private static final Property<Boolean> guardian;
    private static final Property<Boolean> print;
    private static final Property<Boolean> friends;
    private static final Property<Boolean> enemies;
    private static final Property<Boolean> staff;
    private static final Property<Boolean> sleeping;
    private static final Property<Boolean> msg;
    private static final Property<Boolean> fakeBlock;
    private static final Property<Boolean> aac;
    private final NumberProperty<Float> reach;
    private final NumberProperty<Integer> fov;
    private final NumberProperty<Integer> tickDelay;
    private final NumberProperty<Integer> livingTicks;
    private static final EnumProperty<Targeting> targeting;
    private final EnumProperty<EntityHelper.Location> bone;
    private static final EnumProperty<Type> type;
    public final List<Entity> validTargets;
    public Entity focusTarget;
    public Entity target;
    private final Stopwatch stopwatch;
    private final Stopwatch pS;
    public static boolean shouldCrit;
    public static boolean sendpacket;
    public boolean enemyPriority = true;
    private int switchTime;
    public static int timeCap;
    private float oldYaw;
    private float oldPitch;

    static
    {
        autoBlock = new Property<Boolean>(true, new String[] { "Auto-Block","b", "ab", "block","autoblock" });
        fakeBlock = new Property<Boolean>(true, new String[] { "Fake-Block","fb", "fakeblock", "fblock" });
        pSilent = new Property<Boolean>(false, new String[] { "pSilent", "Psilent" });
        angle = new Property<Boolean>(false, new String[] { "Angle" });
        armor = new Property<Boolean>(false, new String[] { "Armor", "ArmorCheck","naked","nakeds","n" });
        dura = new Property<Boolean>(false, new String[] { "ArmorBreaker", "dura" });
        hvh = new Property<Boolean>(false, new String[] { "HvH", "hl", "vortex", "hlswap", "swordswap"});
        team = new Property<Boolean>(false, new String[] { "Team", "t", "teams" });
        direction = new Property<Boolean>(false, new String[] { "Direction", "dir" });
        smart = new Property<Boolean>(false, new String[] { "Smart" });
        guardian = new Property<Boolean>(false, new String[] {"Guardian", "guard", "the shittiest anticheat to ever be fucking made by the shittiest coder known to existance lmaooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo"});
        sleeping = new Property<Boolean>(false, new String[] {"Sleep", "mineplex", "sleeping", "slp", "sl"});
        rayTrace = new Property<Boolean>(true, new String[] { "Ray-Trace", "raytrace", "rtrace", "trace", "ray" });
        players = new Property<Boolean>(true, new String[] { "Players", "player", "p", "pl" });
        animals = new Property<Boolean>(true, new String[] { "Animals", "animal", "a","an","ani" });
        monsters = new Property<Boolean>(true, new String[] { "Monsters", "monster", "mon", "m", "mob" });
        invisibles = new Property<Boolean>(true, new String[] { "Invisibles", "invisible", "invis", "inv" });
        noswing = new Property<Boolean>(true, new String[] { "No-Swing", "noswing", "swing", "no" });
        silent = new Property<Boolean>(true, new String[] { "Silent", "s","lockview","lock" });
        targeting = new EnumProperty<Targeting>(Targeting.SWITCH, new String[] { "Targeting", "target", "t" });
        type = new EnumProperty<Type>(Type.PRE, new String[] { "Type", "motionmode", "motiontype" });
        print = new Property<Boolean>(false, new String[] {"Print"});
        msg = new Property<Boolean>(false, new String[] {"Msg","message"});
        friends = new Property<Boolean>(true, new String[] {"Friends","friend","fri","frend","f"});
        enemies = new Property<Boolean>(true, new String[] {"Enemies","enemy","e","enem","enemys",});
        staff = new Property<Boolean>(true, new String[] {"Staff","staffs","staffmember","staff-member","st"});
        aac = new Property<Boolean>(true, new String[] {"AAC"});
        KillAura.sendpacket = false;
        KillAura.timeCap = 3;
    }

    public KillAura()
    {
        super("KillAura" , new String[] {"killaura", "aura", "ka"}, 0xFFBF4B4B, ModuleType.COMBAT);
        this.aps = new NumberProperty<Long>(Long.valueOf(10L), Long.valueOf(1L), Long.valueOf(20L), new String[] { "APS", "d", "delay", "speed" });
        this.reach = new NumberProperty<Float>(Float.valueOf(5f), Float.valueOf(3.0f), Float.valueOf(6.0f), new String[] { "Reach", "range", "r" });
        this.fov = new NumberProperty<Integer>(Integer.valueOf(360), Integer.valueOf(30), Integer.valueOf(360), new String[] { "Fov", "f" });
        this.livingTicks = new NumberProperty<Integer>(Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(100), new String[] { "Living-Ticks", "livingticks", "ticks", "lt" });
        this.tickDelay = new NumberProperty<Integer>(Integer.valueOf(487), Integer.valueOf(0), Integer.valueOf(1000), new String[] { "Tick-Delay","ticks-delay","ticksdelay", "tickdelay", "tick", "td","delaytick","tdelay"     });
        this.bone = new EnumProperty<EntityHelper.Location>(EntityHelper.Location.HEAD, new String[] { "Bone", "b" });
        this.validTargets = new CopyOnWriteArrayList<Entity>();
        this.focusTarget = null;
        this.target = null;
        this.stopwatch = new Stopwatch();
        this.pS = new Stopwatch();
        this.offerProperties(targeting, print, fov, enemies, friends, staff, autoBlock, direction, players, bone, smart, rayTrace, animals, monsters, invisibles,noswing ,aps, silent, reach, livingTicks, team, dura, hvh, armor, angle, pSilent, tickDelay, type);
        this.offsetPresets(new Preset("Legit")
                           {
                               @Override
                               public void onSet()
                               {
                                   aps.setValue(9L);
                                   reach.setValue(3.8F);
                                   livingTicks.setValue(0);
                                   fov.setValue(90);
                                   targeting.setValue(Targeting.SINGLE);
                                   invisibles.setValue(false);
                                   rayTrace.setValue(false);
                                   animals.setValue(false);
                                   direction.setValue(true);
                                   monsters.setValue(false);
                                   autoBlock.setValue(false);
                                   //    minecraft.thePlayer.sendChatMessage("ok im rdy to hack with the legit preset!!!");
                               }
                           }, new Preset("Rage")
                           {
                               @Override
                               public void onSet()
                               {
                                   aps.setValue(14L);
                                   fov.setValue(360);
                                   reach.setValue(6.0F);
                                   livingTicks.setValue(0);
                                   targeting.setValue(Targeting.SWITCH);
                                   rayTrace.setValue(true);
                                   animals.setValue(false);
                                   monsters.setValue(false);
                                   direction.setValue(true);
                                   invisibles.setValue(true);
                                   autoBlock.setValue(true);
                                   //    minecraft.thePlayer.sendChatMessage("ok im rdy to hack with the rage preset!!!");
                               }
                           },
                new Preset("VortexHvH")
                {
                    @Override
                    public void onSet()
                    {
                        aps.setValue(10L);
                        fov.setValue(360);
                        reach.setValue(3.7F);
                        livingTicks.setValue(0);
                        targeting.setValue(Targeting.SWITCH);
                        rayTrace.setValue(true);
                        direction.setValue(true);
                        animals.setValue(true);
                        monsters.setValue(true);
                        invisibles.setValue(true);
                        autoBlock.setValue(true);
                        Logger.getLogger().printToChat("Switch range to 6 if aura is raping its mom.");
                        //	minecraft.thePlayer.sendChatMessage("ok im rdy to hack with the vortexhvh preset!!!");
                    }
                },
                new Preset("Beaner")
                {
                    @Override
                    public void onSet()
                    {
                        aps.setValue(8L);
                        fov.setValue(360);
                        reach.setValue(6.0F);
                        livingTicks.setValue(0);
                        targeting.setValue(Targeting.SWITCH);
                        rayTrace.setValue(true);
                        animals.setValue(false);
                        monsters.setValue(false);
                        invisibles.setValue(true);
                        direction.setValue(true);
                        autoBlock.setValue(true);
                        //	minecraft.thePlayer.sendChatMessage("ok im rdy to hack with the beener preset!!!");
                    }
                },
                new Preset("Archon")
                {
                    @Override
                    public void onSet()
                    {
                        aps.setValue(10L);
                        fov.setValue(360);
                        reach.setValue(6.0f);
                        livingTicks.setValue(0);
                        targeting.setValue(Targeting.SWITCH);
                        rayTrace.setValue(true);
                        animals.setValue(false);
                        direction.setValue(true);
                        monsters.setValue(false);
                        invisibles.setValue(true);
                        autoBlock.setValue(true);
                        //		minecraft.thePlayer.sendChatMessage("ok im rdy to hack with the arkon preset!!!");
                    }
                },
                new Preset("Guardian") {
                    @Override
                    public void onSet() {
                        aps.setValue(10L);
                        animals.setValue(false);
                        monsters.setValue(false);
                        autoBlock.setValue(true);
                        direction.setValue(true);
                        invisibles.setValue(false);
                        rayTrace.setValue(true);
                        reach.setValue(4.0f);
                        livingTicks.setValue(5);
                        targeting.setValue(Targeting.SINGLE);
                        //Speed sp = (Speed) Gun.getInstance().getModuleManager().getModuleByAlias("speed");
                        //sp.getPropertyByAlias("mode");
                        //	sp.equals(Speed.Mode.GUARDIAN);
                    }
                },
                new Preset("AAC") {
                    @Override
                    public void onSet() {
                        aps.setValue(8l);
                        animals.setValue(false);
                        monsters.setValue(false);
                        direction.setValue(true);
                        invisibles.setValue(false);
                        reach.setValue(5.0f);
                        rayTrace.setValue(true); // just made these up i was too lazyy to aktaully make raeal 1s 4/4/18
                    }
                },
                new Preset("Hypixel") {
                    @Override
                    public void onSet() {
                        aps.setValue(9l);
                        animals.setValue(false);
                        monsters.setValue(false);
                        direction.setValue(true);
                        invisibles.setValue(false);
                        reach.setValue(4.3f);
                        rayTrace.setValue(true);
                        Logger.getLogger().printToChat("fucking step got me banned after 40 hours of mining in uhc im so triggered 12/20/17 6:51 am");
                        Step step = (Step) Gun.getInstance().getModuleManager().getModuleByAlias("step");
                        if (step.isRunning()) {
                            step.toggle();
                        }
                    }
                },
                new Preset("Mineplex")
                {
                    @Override
                    public void onSet()
                    {
                        aps.setValue(14L);
                        fov.setValue(360);
                        reach.setValue(6.0f);
                        livingTicks.setValue(0);
                        targeting.setValue(Targeting.SINGLE);
                        rayTrace.setValue(true);
                        animals.setValue(false);
                        direction.setValue(true);
                        monsters.setValue(false);
                        invisibles.setValue(false);
                        sleeping.setValue(false);
                        autoBlock.setValue(true);
                        AntiBot antibot = (AntiBot) Gun.getInstance().getModuleManager().getModuleByAlias("antibot");

                        if (!antibot.isRunning())
                        {
                            antibot.toggle();
                            NoFall nofall = (NoFall) Gun.getInstance().getModuleManager().getModuleByAlias("antibot");

                            if (!nofall.isRunning())
                            {
                                nofall.toggle();
                                Criticals crit3 = (Criticals) Gun.getInstance().getModuleManager().getModuleByAlias("antibot");

                                if (crit3.isRunning())
                                {
                                    crit3.toggle();;
                                    FastUse fast = (FastUse) Gun.getInstance().getModuleManager().getModuleByAlias("antibot");

                                    if (fast.isRunning())
                                    {
                                        fast.toggle();
                                    }
                                }
                            }
                        }
                    }
                },
                new Preset("Cringo")
                {
                    @Override
                    public void onSet()
                    {
                        aps.setValue(13L);
                        fov.setValue(360);
                        reach.setValue(5.0F);
                        livingTicks.setValue(0);
                        targeting.setValue(Targeting.SWITCH);
                        direction.setValue(true);
                        animals.setValue(true);
                        monsters.setValue(true);
                        invisibles.setValue(true);
                        autoBlock.setValue(true);
                        // 		minecraft.thePlayer.sendChatMessage("ok im rdy to hack with the cringo preset!!!");
                    }
                });
        this.listeners.add(new Listener<MotionUpdateEvent>("kill_aura_motion_update_listener")
        {
            @Override
            public void call(MotionUpdateEvent event)
            {
                TextGUI textGUI = (TextGUI) Gun.getInstance().getModuleManager().getModuleByAlias("textgui");
                Property<Boolean> sf = textGUI.getPropertyByAlias("Suffix");
                if (sf.getValue()) {
                    setTag(String.format("KillAura \2477" + targeting.getFixedValue()));

                }
                switch (event.getTime())
                {
                    case BEFORE:
                            if (validTargets.isEmpty()) {
                                for (Object object : minecraft.theWorld.loadedEntityList) {
                                    Entity entity = (Entity) object;

                                    if (entity instanceof EntityLivingBase) {
                                        EntityLivingBase entityLivingBase = (EntityLivingBase) entity;

                                        if (isValidTarget(entityLivingBase) && !validTargets.contains(entityLivingBase)) {
                                            validTargets.add(entityLivingBase);
                                        }
                                    }
                                }
                            } else {
                                validTargets.forEach(target ->
                                {
                                    if (!isValidTarget(target)) {
                                        validTargets.remove(target);
                                    }
                                });
                            }

                            if (validTargets.isEmpty()) {
                                return;
                            }

                            if (target == null) {
                                Optional<Entity> entity = validTargets.stream().filter(ent -> PlayerHelper.isAiming(EntityHelper.getRotations(ent)[0], EntityHelper.getRotations(ent)[1], fov.getValue())).filter(ent -> isValidTarget(ent)).sorted((entity1, entity2) ->
                                {
                                    float entityFOV = PlayerHelper.getFOV(EntityHelper.getRotations(entity1));
                                    float entity2FOV = PlayerHelper.getFOV(EntityHelper.getRotations(entity2));

                                    return entityFOV > entity2FOV ? 1 : entityFOV < entity2FOV ? -1 : 0;
                                }).findFirst();

                                if (entity.isPresent()) {
                                    target = entity.get();
                                }
                            }

                            if (pSilent.getValue()) {
                                oldPitch = minecraft.thePlayer.rotationPitch;
                                oldYaw = minecraft.thePlayer.rotationYaw;

                            }

                            if (direction.getValue() && silent.getValue()) {
                                event.setRotationPitch(90);
                            }

                            if (dura.getValue() && targeting.getValue() == Targeting.TICK && KillAura.this.isRunning()) {
                                shouldCrit = true;
                            } else {
                                shouldCrit = false;
                            }

                            if (autoBlock.getValue() && minecraft.thePlayer.inventory.getCurrentItem() != null) {
                                if (minecraft.thePlayer.inventory.getCurrentItem().getItem() instanceof ItemSword) {
                                    minecraft.thePlayer.setItemInUse(minecraft.thePlayer.inventory.getCurrentItem(), minecraft.thePlayer.inventory.getCurrentItem().getMaxItemUseDuration());
                                }
                            }
                            if (autoBlock.getValue() && minecraft.thePlayer.inventory.getCurrentItem() != null) {
                                if (minecraft.thePlayer.inventory.getCurrentItem().getItem() instanceof ItemSword) {
                                    minecraft.thePlayer.inventory.getCurrentItem().getItemUseAction();

                                }
                            }

                            if (hvh.getValue()) {
                                minecraft.playerController.windowClick(minecraft.thePlayer.inventoryContainer.windowId, 9, minecraft.thePlayer.inventory.currentItem, 2, minecraft.thePlayer);
                                minecraft.playerController.windowClick(minecraft.thePlayer.inventoryContainer.windowId, 18, minecraft.thePlayer.inventory.currentItem, 2, minecraft.thePlayer);
                                minecraft.playerController.windowClick(minecraft.thePlayer.inventoryContainer.windowId, 27, minecraft.thePlayer.inventory.currentItem, 2, minecraft.thePlayer);
                                minecraft.playerController.windowClick(minecraft.thePlayer.inventoryContainer.windowId, 0, minecraft.thePlayer.inventory.currentItem, 2, minecraft.thePlayer);
                            }
                            if (noswing.getValue()) {
                                if (!noswing.getValue()) {
                                    minecraft.thePlayer.swingItem();
                                }
                            }

                            {
                                if (isValidTarget(target)) {
                                    AutoHeal autoHeal = (AutoHeal) Gun.getInstance().getModuleManager().getModuleByAlias("autoheal");
                                    AutoHeal2 autoHeal2 = (AutoHeal2) Gun.getInstance().getModuleManager().getModuleByAlias("autopot2");
                                    EnumProperty<AutoHeal.Mode> mode = (EnumProperty<AutoHeal.Mode>) autoHeal.getPropertyByAlias("Mode");

                                    if (autoHeal != null && autoHeal.isRunning() && mode.getValue() == AutoHeal.Mode.POTION && autoHeal.isPotting()) {
                                        return;
                                    }

                                    if (autoHeal2.isRunning() && autoHeal2.isPotting) {
                                        return;
                                    }


                                    float[] rotations = EntityHelper.getRotationsAtLocation(bone.getValue(), target);
                                    event.setLockview(!silent.getValue());

                                    if (silent.getValue()) {
                                        if (pSilent.getValue() && pS.hasCompleted(1000L / aps.getValue())) {
                                            if (!sendpacket) {
                                                if (targeting.getValue() == Targeting.AAC) {
                                                    // event.setRotationYaw(PlayerHelper.wrapAngleTo180(rotations[0]));
                                                    // event.setRotationPitch(PlayerHelper.wrapAngleTo180(rotations[1]));
                                                    smoothAim(event);
                                                }
                                                minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(PlayerHelper.wrapAngleTo180(rotations[0]), PlayerHelper.wrapAngleTo180(rotations[1]), true));
                                                attack(target);
                                                System.out.println("fuckniggers");
                                                validTargets.remove(target);
                                                target = null;
                                                sendpacket = true;
                                                pS.reset();
                                            }

                                            if (sendpacket) {
                                                if (targeting.getValue() == Targeting.AAC) {
                                                    // event.setRotationYaw(PlayerHelper.wrapAngleTo180(oldYaw));
                                                    // event.setRotationPitch(PlayerHelper.wrapAngleTo180(oldPitch));
                                                    smoothAim(event);
                                                }
                                                minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(oldYaw, oldPitch, false));
                                                System.out.println(sendpacket);
                                                sendpacket = false;
                                                pS.reset();
                                            }
                                        } else if (!pSilent.getValue()) {
                                            event.setRotationYaw(PlayerHelper.wrapAngleTo180(rotations[0]));
                                            event.setRotationPitch(PlayerHelper.wrapAngleTo180(rotations[1]));
                                        }
                                    } else {
                                        minecraft.thePlayer.rotationYaw = PlayerHelper.wrapAngleTo180(rotations[0]);
                                        minecraft.thePlayer.rotationPitch = PlayerHelper.wrapAngleTo180(rotations[1]);
                                    }
                                } else {
                                    validTargets.remove(target);
                                    target = null;
                                }
                            }

                    break;

                    case AFTER:

                            AutoHeal autoHeal = (AutoHeal) Gun.getInstance().getModuleManager().getModuleByAlias("autoheal");
                            EnumProperty<AutoHeal.Mode> mode = (EnumProperty<AutoHeal.Mode>) autoHeal.getPropertyByAlias("Mode");
                            if (autoHeal != null && autoHeal.isRunning() && (mode.getValue() == AutoHeal.Mode.POTION && autoHeal.isPotting() || mode.getValue() == AutoHeal.Mode.SOUP && autoHeal.isSouping())) {
                                return;
                            }

                            if (pSilent.getValue()) {
                                return;
                            }

                            switch (targeting.getValue()) {
                                case SINGLE:
                                    if (isValidTarget(target) && stopwatch.hasCompleted(1000L / aps.getValue())) {
                                        attack(target);

                                        if (angle.getValue()) {
                                            attack(target);
                                        }
                                        target = null;
                                        stopwatch.reset();

                                    }

                                    break;


                                case TICK:
                                    if (isValidTarget(target) && stopwatch.hasCompleted(tickDelay.getValue())) /*487*/ {
                                        if (dura.getValue()) {
                                            minecraft.playerController.windowClick(minecraft.thePlayer.inventoryContainer.windowId, 9, minecraft.thePlayer.inventory.currentItem, 2, minecraft.thePlayer);
                                            attack(target);
                                            minecraft.playerController.windowClick(minecraft.thePlayer.inventoryContainer.windowId, 9, minecraft.thePlayer.inventory.currentItem, 2, minecraft.thePlayer);
                                            attack(target);
                                            final ItemStack[] items = target.getInventory();
                                            if (print.getValue()) {
                                                if (items[3] != null) {
                                                    ItemStack helm = null;
                                                    helm = items[3];
                                                    Logger.getLogger().printToChat(target.getName() + "'s helmet durability is " + String.valueOf(helm.getMaxDamage() - helm.getItemDamage()));
                                                }
                                            }
                                        } else {
                                            attack(target);
                                        }
                                        validTargets.remove(target);
                                        target = null;
                                        stopwatch.reset();
                                    }
                                    break;
                                case SINGLETICK:
                                    if (isValidTarget(target) && stopwatch.hasCompleted(tickDelay.getValue())) /*487*/ {
                                        if (dura.getValue()) {
                                            minecraft.playerController.windowClick(minecraft.thePlayer.inventoryContainer.windowId, 9, minecraft.thePlayer.inventory.currentItem, 2, minecraft.thePlayer);
                                            attack(target);
                                            minecraft.playerController.windowClick(minecraft.thePlayer.inventoryContainer.windowId, 9, minecraft.thePlayer.inventory.currentItem, 2, minecraft.thePlayer);
                                            attack(target);
                                            final ItemStack[] items = target.getInventory();
                                            if (print.getValue()) {
                                                if (items[3] != null) {
                                                    ItemStack helm = null;
                                                    helm = items[3];
                                                    Logger.getLogger().printToChat(target.getName() + "'s helmet durability is " + String.valueOf(helm.getMaxDamage() - helm.getItemDamage()));
                                                }
                                            }
                                        } else {
                                            attack(target);
                                        }
                                        target = null;
                                        stopwatch.reset();
                                    }
                                    break;

                                case SWITCH:
                                    if (isValidTarget(target) && stopwatch.hasCompleted(1000L / aps.getValue())) {

                                        attack(target);
                                        if (angle.getValue()) {
                                            attack(target);
                                        }


                                        validTargets.remove(target);
                                        target = null;
                                        stopwatch.reset();
                                    }

                                    break;
                                case AAC:
                                    aac.setValue(true);
                                    if (isValidTarget(target) && stopwatch.hasCompleted(1000L / aps.getValue())) {
                                        attack(target);
                                        if (angle.getValue()) {
                                            attack(target);
                                        }
                                        target = null;
                                        stopwatch.reset();

                                    }
                                    aac.setValue(false);
                                    break;

                                case TEST:
                                    if (isValidTarget(target) && stopwatch.hasCompleted(1000L / aps.getValue())) {
                                        attack(target);
                                        if (angle.getValue()) {
                                            attack(target);
                                        }
                                       // attack(target);
                                        minecraft.getNetHandler().addToSendQueue(new C02PacketUseEntity(null, C02PacketUseEntity.Action.ATTACK));
                                        target = null;
                                        stopwatch.reset();

                                    }

                                    break;
                                case NULL:

                                    break;
                                case VANILLA:
                                    if (isValidTarget(target) && stopwatch.hasCompleted(1000L / aps.getValue())) {
                                        if (stopwatch.hasCompleted(ClientUtils.player().getLastAttackerTime())) {
                                            attack(target);
                                            //stopwatch.reset();
                                        }

                                        if (angle.getValue()) {
                                            attack(target);
                                        }

                                        validTargets.remove(target);
                                        target = null;
                                        stopwatch.reset();
                                    }
                            }

                            validTargets.forEach(target ->
                            {
                                if (!isValidTarget(target)) {
                                    validTargets.remove(target);
                                }
                            });
                            break;
                }
            }
        });
//        this.listeners.add(new Listener<EntityKillEvent>("entity_kill_event") {
//            @Override
//            public void call(EntityKillEvent event) {
//                minecraft.thePlayer.sendChatMessage("Killed " + getEvent().getName());
//            }
//        });
    }

    @Override
    protected void onEnable()
    {
        super.onEnable();
        validTargets.clear();
        target = null;
        shouldCrit = false;
    }

    private static void attack(Entity entity)
    {
        boolean wasSprinting = minecraft.thePlayer.isSprinting();
        boolean wasSneaking = minecraft.thePlayer.isSneaking();
        boolean wasBlocking = minecraft.thePlayer.isBlocking();

        if (wasSprinting)
        {
            minecraft.getNetHandler().addToSendQueue(new C0BPacketEntityAction(minecraft.thePlayer, C0BPacketEntityAction.Action.STOP_SPRINTING));
        }

        if (wasSneaking)
        {
            minecraft.getNetHandler().addToSendQueue(new C0BPacketEntityAction(minecraft.thePlayer, C0BPacketEntityAction.Action.STOP_SNEAKING));
        }

        if (wasBlocking)
        {
            minecraft.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
        }

        minecraft.thePlayer.swingItem();

        if (dura.getValue() && (targeting.getValue() == Targeting.TICK || targeting.getValue() == Targeting.SINGLETICK))
        {
            minecraft.getNetHandler().addToSendQueue(new C03PacketPlayer(true));
        }

        minecraft.getNetHandler().addToSendQueue(new C02PacketUseEntity(entity, C02PacketUseEntity.Action.ATTACK));

// this cancer is so we aren't sending extra block and packet nigger shit.
        if (dura.getValue() && (targeting.getValue() == Targeting.TICK || targeting.getValue() == Targeting.SINGLETICK))
        {
            minecraft.thePlayer.swingItem();
            Speed speed = (Speed) Gun.getInstance().getModuleManager().getModuleByAlias("speed");
            EnumProperty<Speed.Mode> speedMode = (EnumProperty<Speed.Mode>) speed.getPropertyByAlias("Mode");

            if (speed != null && speed.isRunning() && speedMode.getValue() == Speed.Mode.YPORT)
            {
                return;
            }
            else
            {
                Criticals.crit();
            }

            minecraft.getNetHandler().addToSendQueue(new C02PacketUseEntity(entity, C02PacketUseEntity.Action.ATTACK));
        }



        if (wasBlocking)
        {
            minecraft.getNetHandler().addToSendQueue(new C08PacketPlayerBlockPlacement(minecraft.thePlayer.getCurrentEquippedItem()));
        }

        if (wasSprinting)
        {
            minecraft.getNetHandler().addToSendQueue(new C0BPacketEntityAction(minecraft.thePlayer, C0BPacketEntityAction.Action.START_SPRINTING));
        }

        if (wasSneaking)
        {
            minecraft.getNetHandler().addToSendQueue(new C0BPacketEntityAction(minecraft.thePlayer, C0BPacketEntityAction.Action.START_SNEAKING));
        }
    }

    private boolean isValidTarget(Entity entity)
    {
        EntityLivingBase entityLivingBase = (EntityLivingBase) entity;

        if ((entity == null) || (!rayTrace.getValue() && !minecraft.thePlayer.canEntityBeSeen(entity)) || entity.isDead || !entity.isEntityAlive() || (minecraft.thePlayer.getDistanceToEntity(entity) > reach.getValue()) || (entity.ticksExisted < livingTicks.getValue()))
        {
            return false;
        }

        if (sleeping.getValue() && minecraft.thePlayer.isPlayerSleeping())
        {
            return false;
        }

        if (team.getValue() && ClientUtils.isTeam(minecraft.thePlayer, (EntityPlayer) entityLivingBase))
        {
            return false;
        }

        if (players.getValue() && entity instanceof EntityPlayer)
        {
            EntityPlayer entityPlayer = (EntityPlayer) entity;

            if (armor.getValue() && !hasArmor(entityPlayer))
            {
                return false;
            }

            if (friends.getValue() && Gun.getInstance().getFriendManager().isFriend(entityPlayer.getName())) {
                return false;
            }

            return !entityPlayer.equals(minecraft.thePlayer) && !(smart.getValue() && !entityPlayer.onGround && entityPlayer.fallDistance == 0D) && !((!invisibles.getValue() && entityPlayer.isInvisible()) || entityPlayer.capabilities.isCreativeMode);
        }
        if (enemyPriority = true && Gun.getInstance().getEnemyManager().isEnemy(entity.getName())) {
            return true;
        }

        return (animals.getValue() && (entity instanceof EntityAnimal) || (animals.getValue() && (entity instanceof EntityVillager)) || (animals.getValue() && (entity instanceof EntitySquid)) || (animals.getValue() && (entity instanceof EntityWolf))||(animals.getValue() && (entity instanceof EntityBat)) || (monsters.getValue() && (entity instanceof EntityMob) || (monsters.getValue() && (entity instanceof EntityMagmaCube)) || (monsters.getValue() && (entity instanceof EntityDragon)) || (monsters.getValue() && (entity instanceof EntityGhast)) || (monsters.getValue() && (entity instanceof EntitySlime))||monsters.getValue() && (entity instanceof EntityIronGolem)));
    }

    private long switchTime()
    {
        if (validTargets.size() == 1)
        {
            switchTime = 500;
        }
        else if (validTargets.size() > 1)
        {
            if (dura.getValue())
            {
                switchTime = 500;
            }
            else
            {
                switchTime = 250;
            }
        }

        return switchTime;
    }

    private boolean hasArmor(EntityPlayer player)
    {
        ItemStack boots = player.inventory.armorInventory[0];
        ItemStack pants = player.inventory.armorInventory[1];
        ItemStack chest = player.inventory.armorInventory[2];
        ItemStack head = player.inventory.armorInventory[3];

        if ((boots != null) || (pants != null) || (chest != null) || (head != null))
        {
            return true;
        }

        return false;
    }

    private void smoothAim(final MotionUpdateEvent em) {
        final double randomYaw = 0.05;
        final double randomPitch = 0.05;
        final float targetYaw = RotationUtils.getYawChange(minecraft.thePlayer.rotationYaw , this.target.posX + ClientUtils.randomNumber(1, -1) * randomYaw, this.target.posZ + ClientUtils.randomNumber(1, -1) * randomYaw);
        final float yawFactor = targetYaw / 1.7f;
        em.setRotationYaw(minecraft.thePlayer.rotationYaw + yawFactor);
        this.target.rotationYaw += yawFactor;
        final float targetPitch = RotationUtils.getPitchChange(minecraft.thePlayer.rotationPitch , this.target, this.target.posY + ClientUtils.randomNumber(1, -1) * randomPitch);
        final float pitchFactor = targetPitch / 1.7f;
        em.setRotationPitch(minecraft.thePlayer.rotationPitch + pitchFactor);
        minecraft.thePlayer.rotationPitch += pitchFactor;
    }

    private enum Targeting
    {
        SINGLE, SWITCH, TICK, VANILLA, AAC, NULL, TEST, SINGLETICK
    }
    private enum Type
    {
        PRE, POST
    }
}
