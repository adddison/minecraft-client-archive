//package me.comu.gun.command.impl.client;
/*package me.comu.gun.command.impl.client;

import me.comu.gun.command.Argument;
import me.comu.gun.command.Command;
import me.comu.gun.core.Gun;
import me.comu.gun.friend.Friend;
import me.comu.gun.macro.MacroManager;;

public final class Macro
{
    public static final class Add extends Command
    {
        public Add()
        {
            super(new String[] {"add", "a"}, new Argument("command"), new Argument("key"));
        }

        @Override
        public String dispatch()
        {
            String command = getArgument("command").getValue();
            String keycode = getArgument("keycode").getValue();
// TODO: MAKE MACRO METHODS
      //      if (Gun.getInstance().getFriendManager().isFriend(username))
            {
                return "That user is already a friend.";
            }

        //    Gun.getInstance().getFriendManager().register(new Friend(username, alias));
          //  return String.format("Added friend with alias %s.", alias);
        }
    }

    public static final class Remove extends Command
    {
        public Remove()
        {
            super(new String[] {"remove", "rem"}, new Argument("username/alias"));
        }

        @Override
        public String dispatch()
        {
            String name = getArgument("username/alias").getValue();

            if (!Gun.getInstance().getFriendManager().isFriend(name))
            {
                return "That user is not a friend.";
            }

            Friend friend = Gun.getInstance().getFriendManager().getFriendByAliasOrLabel(name);
            String oldAlias = friend.getAlias();
            Gun.getInstance().getFriendManager().unregister(friend);
            return String.format("Removed friend with alias %s.", oldAlias);
        }
    }
}
*/
