package me.comu.gun.notification;

    public enum NotificationType {
        INFO, WARNING, ERROR
    }
