package me.comu.gun.command.impl.client;

import me.comu.gun.command.Argument;
import me.comu.gun.command.Command;
import me.comu.gun.core.Gun;
import me.comu.gun.module.impl.toggle.combat.KillAura;
import me.comu.gun.utils.Helper;
import net.minecraft.entity.Entity;

/**
 * Created by august on 12/11/2018
 */
public final class Target extends Command {

    public static Entity targetEntity;

    public Target() {
        super(new String[] {"target","tar","targ","focus","foc"}, new Argument("target"));
    }
    @Override
        public String dispatch() {
        String target = getArgument("target").getValue();
        KillAura ka = (KillAura) Gun.getInstance().getModuleManager().getModuleByAlias("killaura");
        if (target.equalsIgnoreCase("clear") || target.equalsIgnoreCase("c")) {
            ka.focusTarget = null;
            return "KillAura target cleared!";
        }
        if (Helper.world().getPlayerEntityByName(target) != null) {
            targetEntity = ka.focusTarget = Helper.world().getPlayerEntityByName(target);
        } else {
            return "Player not found!";
        }


        return "KillAura focused on &e" + target + "&7.";
    }
}
