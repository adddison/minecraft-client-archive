package me.comu.gun.module.impl.toggle.miscellaneous;

import me.comu.api.event.Listener;
import me.comu.api.stopwatch.Stopwatch;
import me.comu.gun.events.EventTarget;
import me.comu.gun.events.MotionUpdateEvent;
import me.comu.gun.events.PacketEvent;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import net.minecraft.network.play.server.S02PacketChat;

public final class AntiLimbo extends ToggleableModule
{
    private final Stopwatch stopwatch = new Stopwatch();

    private boolean messageb = true;

    public AntiLimbo()
    {
        super("AntiLimbo", new String[] {"antilimbo", "alimbo", "anti-lambo","limbo"}, 0xFFFA8D61, ModuleType.MISCELLANEOUS);
        this.listeners.add(new Listener<PacketEvent>("auto_eat_update_listener")
        {
            @EventTarget
            public void call(PacketEvent e)
            {
            	
            	 if (e.getPacket() instanceof S02PacketChat) {
                     final S02PacketChat message = (S02PacketChat)e.getPacket();
            	if (message.getChatComponent().getUnformattedText().contains("You were spawned in Limbo.")) {
            		minecraft.thePlayer.sendChatMessage("/pig");
            	}
            	if (message.getChatComponent().getUnformattedText().contains("Warping to piggrinder.")) {
            		if (stopwatch.hasCompleted(5000l)) {
            	  		messageb = true;
            			minecraft.thePlayer.sendChatMessage("messages");
             		minecraft.gameSettings.keyBindForward.pressed = true;
            		stopwatch.reset();
            		}
            		//minecraft.gameSettings.keyBindForward.pressed = true;
            	//	stopwatch.hasCompleted(500L);
            		//Helper.player().motionX = .2;
            		//Helper.player().motionX = -(Math.sin(Math.toRadians(Helper.player().getRotationYawHead())) * 2);
            		//Helper.player().motionZ = (Math.cos(Math.toRadians(Helper.player().getRotationYawHead())) * 2);
            		
            	}
            	
            	
               
            }
            	
        };
        private void move() {
   		 minecraft.gameSettings.keyBindForward.pressed = true;
   	 }
        public void unMove() {
        	minecraft.gameSettings.keyBindForward.pressed = false;
        }
        });
        
        this.listeners.add(new Listener<MotionUpdateEvent>("auto_eat_update_listener")
       		{
        	
        		

		@Override
	public void call(MotionUpdateEvent e) {
		 if (messageb = true && stopwatch.hasCompleted(5000l)) {
			 minecraft.gameSettings.keyBindForward.pressed = true;
			 stopwatch.reset();
		 }
		 
			

		        	}
		
			
	
        		});
        
  
    }
}

// TODO: get instance of limbo in chat then player send message for /pig walk forward and go right 