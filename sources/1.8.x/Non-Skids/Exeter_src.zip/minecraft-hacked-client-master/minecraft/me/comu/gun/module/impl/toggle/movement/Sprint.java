package me.comu.gun.module.impl.toggle.movement;

import me.comu.api.event.Listener;
import me.comu.gun.events.MotionUpdateEvent;
import me.comu.gun.events.SprintingAttackEvent;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import me.comu.gun.properties.Property;

public final class Sprint extends ToggleableModule
{
    private final Property<Boolean> keepSprint = new Property<>(true, "KeepSprint", "sprint", "ks", "keep");
    private final Property<Boolean> multiDir = new Property<>(true, "Multi-Direction", "MultiDirection", "multi-dir", "multidir", "direction", "dir", "Multi");

    public Sprint()
    {
        super("Sprint", new String[] {"sprint", "autosprint", "as"}, 0xFF4D7ED1, ModuleType.MOVEMENT);
        this.offerProperties(keepSprint);
        this.listeners.add(new Listener<MotionUpdateEvent>("sprint_motion_update_listener")
        {
            @Override
            public void call(MotionUpdateEvent event)
            {
                if (canSprint())
                {
                    minecraft.thePlayer.setSprinting(true);
                }
            }
        });
        this.listeners.add(new Listener<SprintingAttackEvent>("sprint_sprinting_attack_listener")
        {
            @Override
            public void call(SprintingAttackEvent event)
            {
                if (keepSprint.getValue())
                {
                    event.setCanceled(true);
                }

                if (multiDir.getValue() && canSprint())
                {
                    minecraft.thePlayer.setSprinting(true);
                    
                }
            }
        });
    }

    @Override
    protected void onDisable()
    {
        super.onDisable();
        minecraft.thePlayer.setSprinting(false);
    }

    public boolean canSprint()
    {
        return !minecraft.thePlayer.isSneaking() && minecraft.gameSettings.keyBindForward.getIsKeyPressed() && !minecraft.thePlayer.isCollidedHorizontally && minecraft.thePlayer.moveForward > 0D && minecraft.thePlayer.getFoodStats().getFoodLevel() > 6 && (multiDir.getValue() ? (minecraft.getMinecraft().thePlayer.movementInput.moveForward != 0.0f || minecraft.getMinecraft().thePlayer.movementInput.moveStrafe != 0.0f) : (minecraft.getMinecraft().thePlayer.movementInput.moveForward > 0.0f));
    }
}
