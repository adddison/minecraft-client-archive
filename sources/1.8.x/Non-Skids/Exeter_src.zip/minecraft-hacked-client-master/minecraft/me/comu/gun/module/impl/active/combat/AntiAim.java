package me.comu.gun.module.impl.active.combat;

import me.comu.api.event.Listener;
import me.comu.gun.core.Gun;
import me.comu.gun.events.PacketEvent;
import me.comu.gun.module.Module;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;

public final class AntiAim extends Module
{
    public AntiAim()
    {
        super("Anti Aim", new String[] {"antiaim", "aa"});
        Gun.getInstance().getEventManager().register(new Listener<PacketEvent>("anti_aim_packet_listener")
        {
            @Override
            public void call(PacketEvent event)
            {
                if (event.getPacket() instanceof S08PacketPlayerPosLook)
                {
                    S08PacketPlayerPosLook packet = (S08PacketPlayerPosLook) event.getPacket();

                    if (minecraft.thePlayer.rotationYaw != -180 && minecraft.thePlayer.rotationPitch != 0)
                    {
                        packet.setYaw(minecraft.thePlayer.rotationYaw);
                        packet.setPitch(minecraft.thePlayer.rotationPitch);
                    }
                }
            }
        });
    }
}
