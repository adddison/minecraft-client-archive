package me.comu.gun.module.impl.toggle.combat;

import me.comu.api.event.Listener;
import me.comu.gun.events.MotionUpdateEvent;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import me.comu.gun.properties.NumberProperty;


public final class Reach extends ToggleableModule {

    private final  NumberProperty<Float> range = new NumberProperty<>(4.73F, 3F, 6F, "Range","reach","re","r");


    public Reach() {
        super("Reach", new String[] {"re","range"}, 0xFF64A0, ModuleType.COMBAT);
        this.offerProperties(range);
        this.listeners.add(new Listener<MotionUpdateEvent>("auto_armor_tick_listener")
        {
            @Override
            public void call(MotionUpdateEvent event) {
                if (minecraft.thePlayer.isEntityAlive() && minecraft.playerController.isNotCreative()) {
                    
                }
            }

        });
    }
}
