package me.comu.gun.module.impl.toggle.render.tabgui.item;

import me.comu.gun.module.ToggleableModule;
import me.comu.gun.properties.Property;

public class GuiItem
{
    private final ToggleableModule toggleableModule;
//    private final Property<Boolean> property;

    public GuiItem(ToggleableModule toggleableModule)
    {
        this.toggleableModule = toggleableModule;
        
    }
//    public GuiItem(Property<Boolean> property) {
//        this.property = getToggleableModule().getProperties();
//    }

//    public Property getProperty() {return property;}

    public ToggleableModule getToggleableModule()
    {
        return toggleableModule;
    }
    
}
