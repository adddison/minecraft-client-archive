package me.comu.gun.events;

import me.comu.api.event.Event;

/**
 * Created by comu on 10/29/2018
 */
public class EntityKillEvent extends Event {
}
