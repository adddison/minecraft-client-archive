package me.comu.gun.command.impl.client;

import me.comu.gun.command.Command;

import java.awt.*;
import java.awt.datatransfer.StringSelection;


/**
 * Created by comu on 12/31/2018
 */


public final class IGN extends Command
{
    public IGN()
    {
        super(new String[] {"IGN", "name"});
    }

    @Override
    public String dispatch()
    {
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(minecraft.thePlayer.getName()), null);
        return minecraft.thePlayer.getName() + " (Copied to clipboard)";
    }
}
