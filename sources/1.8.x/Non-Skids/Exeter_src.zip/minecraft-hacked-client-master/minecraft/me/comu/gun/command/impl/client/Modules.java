package me.comu.gun.command.impl.client;

import java.util.List;
import java.util.StringJoiner;

import me.comu.api.interfaces.Toggleable;
import me.comu.gun.command.Command;
import me.comu.gun.core.Gun;
import me.comu.gun.module.Module;
import me.comu.gun.module.ToggleableModule;


public final class Modules extends Command
{
    public Modules()
    {
        super(new String[] {"modules", "mods", "ms", "ml", "lm"});
    }

    @Override
    public String dispatch()
    {
        StringJoiner stringJoiner = new StringJoiner(", ");
        List<Module> modules = Gun.getInstance().getModuleManager().getRegistry();
        modules.sort((mod1, mod2) -> mod1.getLabel().compareTo(mod2.getLabel()));
        modules.forEach(module ->
        {
            if (module instanceof Toggleable)
            {
                ToggleableModule toggleableModule = (ToggleableModule) module;
                stringJoiner.add(String.format("%s%s&7", toggleableModule.isRunning() ?  "&a" : "&c", toggleableModule.getLabel()));
            }
        });
        return String.format("Modules (%s) %s", Gun.getInstance().getModuleManager().getRegistry().size(), stringJoiner.toString());
    }
}
