package me.comu.gun.module.impl.toggle.combat;


import me.comu.api.event.Listener;
import me.comu.api.minecraft.helper.EntityHelper;
import me.comu.gun.core.Gun;
import me.comu.gun.events.MotionUpdateEvent;
import me.comu.gun.logging.Logger;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import me.comu.gun.properties.EnumProperty;
import me.comu.gun.properties.NumberProperty;
import me.comu.gun.properties.Property;
import me.comu.gun.utils.ClientUtils;
import me.comu.gun.utils.RotationUtils;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;

public final class SmoothAim extends ToggleableModule {
    private final NumberProperty<Float> reach = new NumberProperty<>(6F, 3F, 10F, "Reach", "range", "re");
    private final NumberProperty<Integer> fov = new NumberProperty<>(60, 30, 360, "Fov", "view");
    private final NumberProperty<Float> speed = new NumberProperty<>(5.0F,1.0F,30.0F,"Rate","aps","speed","r");
    private final Property<Boolean> invis = new Property<>(true, "Invisibles","invis","invisible","i");
    private final EnumProperty<EntityHelper.Location> bone = new EnumProperty<>(EntityHelper.Location.HEAD, "Bone","b");
    private final Property<Boolean> armor = new Property<>(true, "Nakeds","Armor","a","n","naked");
    private EntityLivingBase target;

    public SmoothAim() {
        super("SmoothAim", new String[]{"SmoothAim", "smooth", "sa", "aimassist","aa","aima","smooth-aim","aim-assist"}, 0xFFF57F99, ModuleType.COMBAT);
        this.offerProperties(speed, reach, fov, invis, bone, armor);
        this.target = null;
        this.listeners.add(new Listener<MotionUpdateEvent>("smooth_aim_motion_update_listener") {
			@Override
            public void call(MotionUpdateEvent event) {

            	 if (ClientUtils.player().isEntityAlive()) {
                     for (final Object o : ClientUtils.world().loadedEntityList) {
                         if (o instanceof EntityLivingBase) {
                             final EntityLivingBase entity = (EntityLivingBase)o;
                             if (isEntityValid(entity) && entity.isEntityAlive()) {
                                 target = entity;
                        //         Logger.getLogger().printToChat("Target set to " + entity.getName());
                             }
                             else {
                                 target = null;
                             }
                             if (target == null) {
                                 continue;
                             }
                             final EntityPlayerSP player = ClientUtils.player();
                             player.rotationPitch += (getPitchChange(target) / speed.getValue());
                      //       Logger.getLogger().printToChat("pitch arranged to " + player.rotationPitch);
                             player.rotationYaw += (getYawChange(target) / speed.getValue());
                       //      Logger.getLogger().printToChat("yaw arranged to " + player.rotationYaw);
                         }

                     }

                 }
            }
        });
    }
    @Override
    protected void onEnable()
    {
        super.onEnable();
        target = null;
    }
    private boolean isEntityValid(final Entity entity) {
        if (entity instanceof EntityLivingBase) {
            final EntityLivingBase entityLiving = (EntityLivingBase)entity;
            if (entity == minecraft.thePlayer || (entity.isInvisible() && !invis.getValue()) || !ClientUtils.player().isEntityAlive() || !entityLiving.isEntityAlive() || entityLiving.getDistanceToEntity(ClientUtils.player()) > (ClientUtils.player().canEntityBeSeen(entityLiving) ? reach.getValue() : 3.0)) {
                return false;
            }
            final double x = entity.posX - ClientUtils.player().posX;
            final double z = entity.posZ - ClientUtils.player().posZ;
            final double h = ClientUtils.player().posY + ClientUtils.player().getEyeHeight() - (entity.posY + entity.getEyeHeight());
            final double h2 = Math.sqrt(x * x + z * z);
            final float yaw = (float)(Math.atan2(z, x) * 180.0 / 3.141592653589793) - 90.0f;
            final float pitch = (float)(Math.atan2(h, h2) * 180.0 / 3.141592653589793);
            final double xDist = RotationUtils.getDistanceBetweenAngles(yaw, ClientUtils.player().rotationYaw % 360.0f);
            final double yDist = RotationUtils.getDistanceBetweenAngles(pitch, ClientUtils.player().rotationPitch % 360.0f);
            final double angleDistance = Math.sqrt(xDist * xDist + yDist * yDist);
            if (angleDistance > fov.getValue()) {
                return false;
            }
            if (entityLiving instanceof EntityPlayer) {
                final EntityPlayer entityPlayer = (EntityPlayer)entityLiving;
                return !(Gun.getInstance().getFriendManager().isFriend(entityPlayer.getName()));
            }
        }
        return false;
    }

    public float getPitchChange(final Entity entity) {
        final double deltaX = entity.posX - ClientUtils.mc().thePlayer.posX;
        final double deltaZ = entity.posZ - ClientUtils.mc().thePlayer.posZ;
        final double deltaY = entity.posY - 2.2 + entity.getEyeHeight() - ClientUtils.mc().thePlayer.posY;
        final double distanceXZ = MathHelper.sqrt_double(deltaX * deltaX + deltaZ * deltaZ);
        final double pitchToEntity = -Math.toDegrees(Math.atan(deltaY / distanceXZ));
        return -MathHelper.wrapAngleTo180_float(ClientUtils.mc().thePlayer.rotationPitch - (float)pitchToEntity) - 2.5f;
    }

    public float getYawChange(final Entity entity) {
        final double deltaX = entity.posX - ClientUtils.mc().thePlayer.posX;
        final double deltaZ = entity.posZ - ClientUtils.mc().thePlayer.posZ;
        double yawToEntity = 0.0;
        if (deltaZ < 0.0 && deltaX < 0.0) {
            yawToEntity = 90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX));
        }
        else if (deltaZ < 0.0 && deltaX > 0.0) {
            yawToEntity = -90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX));
        }
        else {
            yawToEntity = Math.toDegrees(-Math.atan(deltaX / deltaZ));
        }
        return MathHelper.wrapAngleTo180_float(-(ClientUtils.mc().thePlayer.rotationYaw - (float)yawToEntity));
    }


}


