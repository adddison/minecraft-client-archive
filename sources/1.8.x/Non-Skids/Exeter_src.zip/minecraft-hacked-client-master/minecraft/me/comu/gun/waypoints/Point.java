package me.comu.gun.waypoints;

import me.comu.api.interfaces.Labeled;

public class Point implements Labeled
{
    private final String label;
    private final int x, y, z;

    public Point(String label, int x, int y, int z)
    {
        this.label = label;
        this.x = x;
        this.y = y;
        this.z = z;
    }

    @Override
    public String getLabel()
    {
        return label;
    }

    public int getZ()
    {
        return z;
    }

    public int getX()
    {
        return x;
    }

    public int getY()
    {
        return y;
    }
}