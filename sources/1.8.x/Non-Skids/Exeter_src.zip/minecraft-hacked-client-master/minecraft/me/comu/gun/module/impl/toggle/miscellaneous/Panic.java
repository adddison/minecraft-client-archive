package me.comu.gun.module.impl.toggle.miscellaneous;

import me.comu.gun.core.Gun;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import me.comu.gun.module.impl.active.render.TextGUI;
import me.comu.gun.module.impl.toggle.render.NameTags;
import me.comu.gun.module.impl.toggle.render.TabGui;
import me.comu.gun.properties.Property;

/**
 * Created by comu on 12/15/2018
 */
public class Panic extends ToggleableModule {

    public Panic() {
        super("Panic", new String[] {"pan"}, ModuleType.MISCELLANEOUS);
        TabGui tabGui = (TabGui) Gun.getInstance().getModuleManager().getModuleByAlias("tabgui");
        NameTags nameTags = (NameTags) Gun.getInstance().getModuleManager().getModuleByAlias("nametags");
        TextGUI textGUI = (TextGUI) Gun.getInstance().getModuleManager().getModuleByAlias("textgui");
        Property<Boolean> arrayList = textGUI.getPropertyByAlias("arraylist");
        Property<Boolean> armor = textGUI.getPropertyByAlias("armor");
        Property<Boolean> fps = textGUI.getPropertyByAlias("fps");
        Property<Boolean> ping = textGUI.getPropertyByAlias("ping");
        Property<Boolean> direction = textGUI.getPropertyByAlias("direction");
        Property<Boolean> time = textGUI.getPropertyByAlias("time");
        Property<Boolean> watermark = textGUI.getPropertyByAlias("watermark");
        Property<Boolean> potions = textGUI.getPropertyByAlias("potions");
        Property<Boolean> arraylist = textGUI.getPropertyByAlias("arraylist");
        if (arrayList.getValue() == true)
            arrayList.setValue(false);
        if (potions.getValue() == true)
            potions.setValue(false);
        if (watermark.getValue() == true)
            watermark.setValue(false);
        if (time.getValue() == true)
            time.setValue(false);
        if (direction.getValue() == true)
            direction.setValue(false);
        if (ping.getValue() == true)
            ping.setValue(false);
        if (fps.getValue() == true)
            fps.setValue(false);
        if (nameTags.isRunning())
            nameTags.toggle();
        if (armor.getValue() == true)
            armor.setValue(false);
        if (arrayList.getValue() == true)
            arrayList.setValue(false);
        if (tabGui.isRunning() )
        tabGui.toggle();
    }

    @Override
    public void onEnable() {

    }


}
