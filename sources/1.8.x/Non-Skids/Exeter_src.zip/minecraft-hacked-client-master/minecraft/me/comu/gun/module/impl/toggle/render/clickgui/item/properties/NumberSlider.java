package me.comu.gun.module.impl.toggle.render.clickgui.item.properties;

import me.comu.api.minecraft.render.CustomFont;
import me.comu.api.minecraft.render.RenderMethods;
import me.comu.gun.module.impl.toggle.render.clickgui.ClickGui;
import me.comu.gun.module.impl.toggle.render.clickgui.Panel;
import me.comu.gun.module.impl.toggle.render.clickgui.item.Item;
import me.comu.gun.properties.NumberProperty;

public class NumberSlider extends Item
{
    private NumberProperty numberProperty;

    public NumberSlider(NumberProperty numberProperty)
    {
        super(numberProperty.getAliases()[0]);
        this.numberProperty = numberProperty;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks)
    {
        RenderMethods.drawRect(x, y, x + getValueWidth(), y + height, !isHovering(mouseX, mouseY) ? 0x775CE843 : 0x995CE843);
        ClickGui.getClickGui().guiFont.drawString(String.format("%s\2477 %s", getLabel(), numberProperty.getValue()), x + 2.3F, y - 1F, CustomFont.FontType.SHADOW_THIN, 0xFFFFFFFF);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton)
    {
        super.mouseClicked(mouseX, mouseY, mouseButton);

        if (isHovering(mouseX, mouseY) && mouseButton == 0)
        {

        }
    }

    @Override
    public int getHeight()
    {
        return 14;
    }

    private boolean isHovering(int mouseX, int mouseY)
    {
        for (Panel panel : ClickGui.getClickGui().getPanels())
        {
            if (panel.drag)
            {
                return false;
            } 
        }

        return mouseX >= getX() && mouseX <= getX() + getWidth() && mouseY >= getY() && mouseY <= getY() + height;
    }

    private float getValueWidth()
    { 
        return (numberProperty.getMaximum().floatValue() - numberProperty.getMinimum().floatValue()) + ((Number) numberProperty.getValue()).floatValue();
    }

}
