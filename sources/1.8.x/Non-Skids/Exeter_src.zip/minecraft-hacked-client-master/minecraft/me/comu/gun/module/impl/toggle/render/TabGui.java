package me.comu.gun.module.impl.toggle.render;

import me.comu.api.event.Listener;
import me.comu.gun.core.Gun;
import me.comu.gun.events.InputEvent;
import me.comu.gun.events.RenderGameOverlayEvent;
import me.comu.gun.events.RenderGameOverlayEvent.Type;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import me.comu.gun.module.impl.active.render.TextGUI;
import me.comu.gun.module.impl.toggle.render.tabgui.GuiTabHandler;
import me.comu.gun.properties.Property;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;

public final class TabGui extends ToggleableModule
{
    private static final ResourceLocation iconCombat = new ResourceLocation("textures/misc/combaticon");
    private final Property<Boolean> icons = new Property<>(true, "Icons","icon","ic","i");
    private GuiTabHandler guiTabHandler;
    private int waypointStage;
    public TabGui()
    {

        super("TabGui", new String[] {"tabgui", "tg"}, ModuleType.RENDER);
        this.offerProperties();
        this.listeners.add(new Listener<RenderGameOverlayEvent>("tab_gui_render_game_overlay_listener")
        {
            @Override
            public void call(RenderGameOverlayEvent event)
            {
                if (event.getType() == Type.GUI)
                {
                    TextGUI textGUI = (TextGUI) Gun.getInstance().getModuleManager().getModuleByAlias("textgui");
                    Property<Boolean> watermark = textGUI.getPropertyByAlias("Watermark");

                    if (guiTabHandler == null)
                    {
                        guiTabHandler = new GuiTabHandler();
                    }

                    if (minecraft.gameSettings.showDebugInfo)
                    {
                        return;
                    }

                    GlStateManager.pushMatrix();
                    GlStateManager.enableBlend();
                    guiTabHandler.drawGui(3, watermark.getValue() ? 13 : 3);
                    GlStateManager.disableBlend();
                    GlStateManager.popMatrix();
                }
            }
        });
        this.listeners.add(new Listener<InputEvent>("tab_gui_input_listener")
        {
            @Override
            public void call(InputEvent event)
            {
                Waypoints waypoints = (Waypoints) Gun.getInstance().getModuleManager().getModuleByAlias("waypoints");
                Property<Boolean> textDisplay = waypoints.getPropertyByAlias("textdisplay");

                if (event.getType() == InputEvent.Type.KEYBOARD_KEY_PRESS)
                {
                    switch (event.getKey())
                    {
                        case Keyboard.KEY_UP:
                        {
                            if (guiTabHandler.visible)
                            {
                                if (guiTabHandler.mainMenu)
                                {
                                    guiTabHandler.selectedTab--;

                                    if (guiTabHandler.selectedTab < 0)
                                    {
                                        guiTabHandler.selectedTab = guiTabHandler.tabs.size() - 1;
                                    }

                                    guiTabHandler.transition = 11;
                                }
                                else
                                {
                                    guiTabHandler.selectedItem--;

                                    if (guiTabHandler.selectedItem < 0)
                                    {
                                        guiTabHandler.selectedItem = (guiTabHandler.tabs.get(guiTabHandler.selectedTab)).getMods().size() - 1;
                                    }

                                    if (guiTabHandler.tabs.get(guiTabHandler.selectedTab).getMods().size() > 1)
                                    {
                                        guiTabHandler.transition = 11;
                                    }
                                }
                            }

                            break;
                        }

                        case Keyboard.KEY_DOWN:
                        {
                            if (guiTabHandler.visible)
                            {
                                if (guiTabHandler.mainMenu)
                                {
                                    guiTabHandler.selectedTab++;

                                    if (guiTabHandler.selectedTab > guiTabHandler.tabs.size() - 1)
                                    {
                                        guiTabHandler.selectedTab = 0;
                                    }

                                    guiTabHandler.transition = -11;
                                }
                                else
                                {
                                    guiTabHandler.selectedItem++;

                                    if (guiTabHandler.selectedItem > (guiTabHandler.tabs.get(guiTabHandler.selectedTab)).getMods().size() - 1)
                                    {
                                        guiTabHandler.selectedItem = 0;
                                    }

                                    if (guiTabHandler.tabs.get(guiTabHandler.selectedTab).getMods().size() > 1)
                                    {
                                        guiTabHandler.transition = -11;
                                    }
                                }
                            }

                            break;
                        }

                        case Keyboard.KEY_LEFT:
                        {
                            if (guiTabHandler.mainMenu)
                            {
                                //guiTabHandler.visible = false;
                                //guiTabHandler.mainMenu = false;
                            }
                            else
                            {
                                if (waypointStage == 1) {
                                    textDisplay.setValue(true);
                                    waypointStage = 0;

                                }
                                guiTabHandler.mainMenu = true;
                            }

                            break;
                        }

                        case Keyboard.KEY_RIGHT:
                        {
                            if (guiTabHandler.mainMenu)
                            {
                                if (textDisplay.getValue() == true) {
                                    textDisplay.setValue(false);
                                    waypointStage = 1;
                                }
                                guiTabHandler.mainMenu = false;
                                guiTabHandler.selectedItem = 0;
                            }
                            else if (!guiTabHandler.visible)
                            {
                                guiTabHandler.visible = true;
                                guiTabHandler.mainMenu = true;
                                textDisplay.setValue(!textDisplay.getValue());
                            }
                            else
                            {
                                ((guiTabHandler.tabs.get(guiTabHandler.selectedTab)).getMods().get(guiTabHandler.selectedItem)).getToggleableModule().toggle();
                            }

                            break;
                        }

                        case Keyboard.KEY_RETURN:
                        {
                            if (!guiTabHandler.mainMenu && guiTabHandler.visible)
                            {
                                ((guiTabHandler.tabs.get(guiTabHandler.selectedTab)).getMods().get(guiTabHandler.selectedItem)).getToggleableModule().toggle();
                            }

                            break;
                        }
                    }
                }
            }
        });
        this.listeners.add(new Listener<RenderGameOverlayEvent>("tab_gui_input_listener") {
            @Override
            public void call(RenderGameOverlayEvent event) {
                ScaledResolution sr = event.getScaledResolution();
                    if (icons.getValue()) {
             //           getClassLoader().getResource("textures/misc/combaticon");
               //         minecraft.getTextureManager().bindTexture(iconCombat);
                 //       minecraft.getTextureManager().bindTexture(iconExploits);
                   //     minecraft.getTextureManager().bindTexture(iconExploits);
                     //   minecraft.getTextureManager().bindTexture(iconMovement);
                       // minecraft.getTextureManager().bindTexture(iconRender);
                        //minecraft.getTextureManager().bindTexture(iconMovement);



                    }
                               }
                           });
        setRunning(true);
    }
}
