package me.comu.gun.command.impl.client;

public class Panic {
}
