package me.comu.gun.module.impl.toggle.render;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.util.AxisAlignedBB;

import java.util.List;

import me.comu.api.event.Listener;
import me.comu.api.minecraft.render.RenderMethods;
import me.comu.gun.events.RenderEvent;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;

public final class Seeker extends ToggleableModule
{
    public Seeker()
    {
        super("Seeker", new String[] {"seeker", "seek", "hide"}, 0xFF90D4C4, ModuleType.RENDER);
        this.listeners.add(new Listener<RenderEvent>("tracers_render_listener")
        {
            @Override
            public void call(RenderEvent event)
            {
                GlStateManager.pushMatrix();
                RenderMethods.enableGL3D();
                double x, y, z;

                for (Entity entity : (List<Entity>) minecraft.theWorld.loadedEntityList)
                {
                    if (!entity.isEntityAlive() || !(entity instanceof EntityFallingBlock))
                    {
                        continue;
                    }

                    x = interpolate(entity.lastTickPosX, entity.posX, event.getPartialTicks(),
                                    minecraft.getRenderManager().renderPosX);
                    y = interpolate(entity.lastTickPosY, entity.posY, event.getPartialTicks(),
                                    minecraft.getRenderManager().renderPosY);
                    z = interpolate(entity.lastTickPosZ, entity.posZ, event.getPartialTicks(),
                                    minecraft.getRenderManager().renderPosZ);
                    AxisAlignedBB axisAlignedBB = new AxisAlignedBB(x - 0.5D, y, z - 0.5D, x  + 0.5D, y + 1D, z + 0.5D);
                    float distance = minecraft.thePlayer.getDistanceToEntity(entity);

                    if (distance <= 32)
                    {
                        GlStateManager.color(1F, distance / 32F, 0F, 0.35F);
                    }
                    else
                    {
                        GlStateManager.color(0F, 0.9F, 0F, 0.35F);
                    }

                    RenderMethods.drawBox(axisAlignedBB);
                }

                RenderMethods.disableGL3D();
                GlStateManager.popMatrix();
            }
        });
    }

    private double interpolate(double lastI, double i, float ticks, double ownI)
    {
        return (lastI + (i - lastI) * ticks) - ownI;
    }
}
