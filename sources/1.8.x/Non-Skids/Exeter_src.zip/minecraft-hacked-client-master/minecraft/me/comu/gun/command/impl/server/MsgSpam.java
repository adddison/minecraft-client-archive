package me.comu.gun.command.impl.server;

import java.util.Random;

import me.comu.api.stopwatch.Stopwatch;
import me.comu.gun.command.Argument;
import me.comu.gun.command.Command;
import me.comu.gun.utils.ClientUtils;
import net.minecraft.network.play.client.C01PacketChatMessage;

/**
 * TODO: fix this shit
 */
public final class MsgSpam extends Command
{
    private int lastUsed;
    private String[] phraseList = new String[] {"how much wood can a woodchuck chuck if a woodchuck could chuck wood","boonk gang","whole lotta gang shit","u gay nerd","you man thot","i dont really care waht you say","is that a threat?","poop","pee","fart","LOL ddos threat?!?!?!?!","is that a ddos threat?","im not 9 im 8 idiot","i put a sticky note on my camera because the government is always watching","you use fullbright i have recording!!!","can you pls stop spamming??","Loading Resources...","she thought it was my cock but my glcok very hard","school was very hard","i could shit out alphabet soup and make more sense than you","why would you ban me","im cheating right now but u have no proof","i dont have that option on my keyboard","ever heard of micropenis? because i think your diagnosed with it","you are a tart","you tart","i kinda feel bad for you","getting a tattoo is like getting a texturepack","stay salty random","hyothetically speaking of course","ur mental capability is so minimum","i swear if u swat my fish im calling the police","logging means imputting into chat something","did your goldfish like the swat team at its fishtank?","when you drop out of school to play a blockgame","its the flash!","unfreeze me so i can type in chat","i wanna fart on ur beautiful face","call me dexter","please call me comu","please call me comu i insist","hackity hacking we gotta send him backity back","comu doesnt do drugs","comu dropped out of school and got rich","superior cheater comu here alongside with inferior cheater gringo :D","jim has sex with emily","im not hacking?!?! screenshare me","Yes, I am hacking","new phone who dis?","im not a bot","dad <3","sauce!","omg i love this server it lets u say bad words!","comu cried about his discord tag being changed","sauce","dab on my c0ck","its called someone on a vpn having the same ip as you","i bangbang ur mom?","my friend system doesnt work on this server","stop crying over a block game","im not hacking???","im not hacking im cheating","its not a joke i actually mean it","Hey want to fight me without hacks u mother fcker?","anyone have skype?","thats racist","wanna get erpm banned","hello superior cheater comu here","why u suck penile areas","egirl finneser","imgay","am gay","2fast4u","Comu rules this server?","U scummed me D:","cant touch this na na na","how much for an gun sub","gun client op!","but does it bypass?","is the json ratted?","Gas the jews","you pay for those cheats lol?","LOL!","BUT BABE!","its only toxic if its not true","send json or scam","The clients clickgui and tabgui is private at the moment the owners wont let us ss it.","#FREEMCCLIENTS","superior cheater","superior cheaters","fuck 12!","how u custom it","Staff has been alerted","why is my autopot hitting u","losertard","i had to take the n word out of my spammer becuz i kept getting muted fr it","stay silent kid","my water is more clear than ur future","a laptop is not a computer","you can see the salt in rigas eyes","raging?","blocked","I'd rather creampie my lovely wife over playing this stupid game.","You have 5minutes to join teamspeak","70 nigguh","fly reach killaura and more","dad?","blitz speaks like a spic","aris said my virtue skid is the only good skid - blitz","nebula more like suck a dick-ula","drop a pin nigga","drop a pin bitch","blitz does drive bys with bananas","the password to this minecraft account is  gayman123","hey guys blitzthunder here","get better get gamesense", "is it ratted or is it just a virus?","im rich unlike your dad","1", "your mom sucks me hard","refund your cheats lol", "I doxed my self since I'm a winner!", "sorry didnt mean to flex on you with my minecraft bypass", "we gon' $ave d@t m0ney", "GRINGO GOT YO ASS", "ok fat fuck", "gf","keep talking that shit and i'll forceop my self with a sign", "i cant hear you over the ctrl c and ctrl v sounds of your keyboard u fukkin skid", "in new york i milly rock o>", "this is minecraft all you can do is mine and craft","and i have screenshots", "comu cant chode", "stop watermarking stuff or i'll activate my rat", "i got one shotted and i dont fucking know how", "dark is a god and can chode very well!!!!", "squah is fast as FUCK boiiiiiiiiis", "if jesus makes u walk on water does banana give u b0ner??", "hey asshat! suck my oranges", "your honestly an waste of oxygen", "free ice cream in dis van", "mc.thePlayer() hahha i can chode!", "hye little man i stole ur mom and put my d0ng in her hole", "stop! u cant win hes huzuni!", "tomato client haxers r gods", "gun has best dora da explorers", "huzuni is using a hax cloient with ora", "im gonna phase ur base NIGLET", "fuck my shleemies!", "1v1 me kiddo b4 i dong u", "add me on skype... oh wait who tf uses that shit anymore", "add me on discord", "apoblo clarinet = bleach", "i got a real big d0nger", "some people call me a god but most people call me gay", "mad cuz bad","Did you paste that client??","did you paste that?","ravioli ravioli toaster in the bathiloi","cheating and cringing at the same time","Client more pasted than your essays", "mad cuz bad", "CYBERBULLY CHANNELS ARE CANCER CANCER CANCER", "well clearly your an idiot","Laughing at your security since '09","nosies!", "CYBERBULLY CHANNELS ARE CANCER CANCER CANCER", "toggle is anonymous fanboy confirmed", "virtue 0.9 leak", "trol monitor is a square","kudos","why do i keep coming back to this shitty game?","im superior than all of you","i might get on an alt and cheat","dark leaked his own skidded client for clout","i nutted on her cheek her new name is baby face","Decompiling...","how do u boost fps with no virus??!!","are these your cs binds?","if youre hacking, that means youre a noob.", "toggle is latematt fanboy confirmed", "nikko was here" , "dox ddos and swatted", "ddox", "if you play on here then youre a god", "north korea more like bunch of 9 year olds", "rippedgaming is the wurst", "promchacks releases altlists just to get views", "lithe was made by rice", "cracked by hne", "hne got pulled up on and got finnad yall know the deal", "toggle computer name was del", "no proof no ban", "why are you reading this?", "tell your friends", "hey bro im spooky bitch", "virustotal is bullshit", "indigo has reversestep", "comu renamed indigo", "gringo used to get 1 shotted", "gringo is a fanboy of everything", "wanna hear a joke? lucids autopot", "toggle is 1", "ur kinda cringy", "wtf is watchdog", "spooky isnt spooky", "hackinglord renamed latemod", "disco party more like deluge rename", "exile squad, ha! eggsiles","ez xD","you are a rat", "nya wont gameshare", "avix is ratted","lol jk","its just a prank!", "syncing world","better than your favorite cheat","better than your cheat","gassed up shawty said i need about forty yah yah yah", "promchacks altlist 1/600 working", "all clients are shit", "jacked by del", "ez keylogged","no you can also build","get good get gamesense","what is a autoclicker???","trinity is a ghost client that trains you to be better - blitz","no im hacking","i have a pussy piercing","i wanna be gay cause ur fucked and i wanna savour it","trol trying to speak english gives me cancer", "columbine happened because of you","nice client", "nobody likes u", "lulzsec","lulz","imagine doing the math for trajectories","if you're reading this it's too late","i read the minecraft handbook dont johnny test me bro","do you get vote keys from voting????", "rat.exe", "toggle will kill you for gapples", "toggle cuts gapples up into small pieces and sniffs them", "stop removing watermarks or ill activate my rat", "join or ban", "fight me bitch", "look how he runs", "i got one shotted i dont know fucking how", "toggle did you take my golden apples?", "like my killaura is just going to do all the work", "am0d v17 is the best client", "comu now has control of your pc", "no hacks at all", "nodus is the best client", "notch is a sellout", "promchacks is the most pro hacker of all time", "recording hackers while hacking yourself", "you slick motherfukker", "w0w hacker abuse", "hackinglord is always invis on discord itz kinda ghay tbh", "faithful blacklisted spooky for ddos threats", "vagitanus aura", "dark wasnt born, he was skidded", "if you guys did enjoy the mc phasing montage dont forget to SMASH that like button!", "aye shoutout my nigga friendly hes a fucking god", "friendly is a god at the trombone on momz", "Add me on discord cuz i have no friends", "your the type of person to bhop on a client with yport in it", "oh shit the command block overheated", "why isnt my autopot working", "" };

    private Stopwatch stopwatch = new Stopwatch();
    private boolean isSpamming;
    private String name;
    private int count;

    public MsgSpam()
    {
        super(new String[] {"spam", "spammsg", "msgspam"}, new Argument("Name"), new Argument("Count"));
    }
    @Override
    public String dispatch()
    {

                name = getArgument("Name").getValue();
                count = Integer.parseInt(getArgument("Count").getValue());
                for(int i = 0; i < count; i++) {
                        ClientUtils.mc().getNetHandler().addToSendQueue(new C01PacketChatMessage("/msg " + name + " " + randomPhrase()));
                        isSpamming = true;
                }
                    isSpamming = false;
                    return "Spammed " + name +".";
}

    private String randomPhrase() {
        Random rand;
        int randInt;

        for (rand = new Random(), randInt = rand.nextInt(this.phraseList.length); this.lastUsed == randInt; randInt = rand.nextInt(this.phraseList.length)) {
        }

        lastUsed = randInt;
        return phraseList[randInt];
    }



    private long randomDelay()
    {
        final Random randy = new Random();
        final int randyInt = randy.nextInt(2000) + 2000;
        return randyInt;
    }

}