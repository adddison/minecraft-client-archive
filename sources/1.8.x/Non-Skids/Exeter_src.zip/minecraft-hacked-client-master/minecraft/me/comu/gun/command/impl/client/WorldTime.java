package me.comu.gun.command.impl.client;

import me.comu.gun.command.Argument;
import me.comu.gun.command.Command;

/**
 * Created by comu on 11/15/2018
 */
public final class WorldTime extends Command {
    public WorldTime() {
        super(new String[] {"worldtime","wtime"}, new Argument("Time"));
    }

    @Override
    public String dispatch() {
        int time = Integer.parseInt(getArgument("Time").getValue());
        minecraft.theWorld.setWorldTime((long)time);
        return "Set world time to: &e" + time;
    }
}
