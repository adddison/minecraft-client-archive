package me.comu.gun.module.impl.active.render;

import me.comu.api.event.Listener;
import me.comu.api.minecraft.render.RenderMethods;
import me.comu.gun.core.Gun;
import me.comu.gun.events.RenderEvent;
import me.comu.gun.events.RenderGameInfoEvent;
import me.comu.gun.events.RenderGameOverlayEvent;
import me.comu.gun.events.ViewmodelEvent;
import me.comu.gun.module.Module;
import me.comu.gun.properties.EnumProperty;
import me.comu.gun.properties.NumberProperty;
import me.comu.gun.properties.Property;
import me.comu.gun.utils.ClientUtils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockSign;
import net.minecraft.block.material.Material;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import org.lwjgl.opengl.GL11;


public final class Render extends Module
{
    private final Property<Boolean> rotations = new Property<Boolean>(true, "Rotations","f5","realyaw","realpitch","rotationset","rotation","realrotation"), customBars = new Property<>(true, "CustomBars", "c", "custom", "cb"), blockpos = new Property<>(false, "BlockPos","block","blockoutline","blockfill"),blind = new Property<>(true,"Blidnness","blind"), blockAnimation = new Property<>(true, "BlockAnimation", "ba", "block"), nofov = new Property<>(false, "NoFOV", "nf"), pumpkin = new Property<>(true, "NoPumpkin", "p", "np"), fire = new Property<>(true, "NoFire", "fire", "nf"), hurtcam = new Property<>(false, "NoHurtcam", "hurtcam", "nh"), arrows = new Property<>(true,"Arrows","Arrow","arr","a"), items = new Property<>(false, "NoItems", "noitem" ,"items", "item", "ni"), notifications = new Property<>(true, "Notifications","notif","notification","notifs");
    public final Property<Float> blockHeight = new NumberProperty<>(-0.2F, -1.5F, 1.5F, "BlockHeight");
    private final EnumProperty<BlockMode> blockMode = new EnumProperty<>(BlockMode.VANILLA, "BlockMode","Mode","bmode", "m");
    public Render()
    {
        super("Render", new String[] {"render", "norender", "nr"});
        this.offerProperties(rotations, pumpkin, blockpos,  customBars, fire, hurtcam, items, nofov, blockAnimation, blockHeight, notifications, blockMode);
        Gun.getInstance().getEventManager().register(new Listener<RenderGameOverlayEvent>("norender_render_game_overlay_listener")
        {
            @Override
            public void call(RenderGameOverlayEvent event) {
                switch (event.getType()) {
                    case FIRE:
                        event.setRenderFire(fire.getValue());
                        break;

                    case HURTCAM:
                        event.setRenderHurtcam(hurtcam.getValue());
                        break;

                    case ITEM:
                        event.setRenderItems(items.getValue());

                        if (items.getValue()) {
                            minecraft.theWorld.removeEntity(event.getEntityItem());
                        }

                        break;

                    case PUMPKIN:
                        event.setRenderPumpkin(pumpkin.getValue());
                        break;
                }

            }
        });

        Gun.getInstance().getEventManager().register(new Listener<RenderEvent>("textgui_render_game_info_listener") {
        @Override
        public void call( RenderEvent event) {
            if (blockpos.getValue()) {
                GL11.glPushMatrix();
                RenderMethods.enableGL3D();
                final int x = getBlinkBlock().func_178782_a().getX();
               final int y = getBlinkBlock().func_178782_a().getY();
                final int z = getBlinkBlock().func_178782_a().getZ();
                final Block block1 = getBlock(x, y, z);
                final Block block2 = getBlock(x, y + 1, z);
                final Block block3 = getBlock(x, y + 2, z);
                final boolean blockBelow = !(block1 instanceof BlockSign) && block1.getMaterial().isSolid();
                final boolean blockLevel = !(block2 instanceof BlockSign) && block1.getMaterial().isSolid();
                final boolean blockAbove = !(block3 instanceof BlockSign) && block1.getMaterial().isSolid();
                if (getBlock(getBlinkBlock().func_178782_a()).getMaterial() != Material.air && blockBelow && blockLevel && blockAbove) {
                                GL11.glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
                                ClientUtils.drawOutlinedBox((AxisAlignedBB.fromBounds(x - RenderManager.renderPosX, y - RenderManager.renderPosY, z - RenderManager.renderPosZ, x - RenderManager.renderPosX + 1.0, y + 1 - RenderManager.renderPosY, z - RenderManager.renderPosZ + 1.0)));
                }
                RenderMethods.disableGL3D();
                GL11.glPopMatrix();

            }
            }
        });

        Gun.getInstance().getEventManager().register(new Listener<RenderGameInfoEvent>("textgui_render_game_info_listener")
        {
            @Override
            public void call(RenderGameInfoEvent event)
            {
                ScaledResolution scaledResolution = event.getScaledResolution();
//                if (arrows.getValue()) {
//                	int arrow = 0;
//                	 for (int index = 9; index < 45; index++)
//                     {
//                         ItemStack itemStack = minecraft.thePlayer.inventoryContainer.getSlot(index).getStack();
//                         if (itemStack == null)
//                        	 continue;
//                         if (itemStack.getDisplayName().equalsIgnoreCase("Arrow")) {
//                        	 arrow += itemStack.stackSize;
//
//                         }
//
//                     }
//                	if (minecraft.thePlayer.getCurrentEquippedItem() != null && minecraft.thePlayer.getCurrentEquippedItem().getItem() instanceof ItemBow)
//                	minecraft.fontRenderer.drawStringWithShadow(Integer.toString(arrow), scaledResolution.getScaledWidth() / 2 + 100, scaledResolution.getScaledHeight() / 2 + 330, 0xFFFFFFFF);
//                }
                if (customBars.getValue())
                {
                    int minusHealth = (int) minecraft.thePlayer.getHealth();
                    int minusFood = minecraft.thePlayer.getFoodStats().getFoodLevel();

                    if (minusFood > 20)
                    {
                        minusFood = 20;
                    }

                    if (minusHealth > 20)
                    {
                        minusHealth = 20;
                    }

                    // health
                    RenderMethods.drawGradientBorderedRect(scaledResolution.getScaledWidth() / 2 - 91, scaledResolution.getScaledHeight() - 39, scaledResolution.getScaledWidth() / 2 - 10, scaledResolution.getScaledHeight() - 30, 1F, 0xDD000000, 0xFF444444, 0xFF222222);
                    RenderMethods.drawGradientBorderedRect(scaledResolution.getScaledWidth() / 2 - 91, scaledResolution.getScaledHeight() - 39, scaledResolution.getScaledWidth() / 2 - 90 + minusHealth * 4, scaledResolution.getScaledHeight() - 30, 1F, 0xDD000000, 0xDD990000, 0xDD440000);
                    minecraft.fontRenderer.drawStringWithShadow(String.format("%s", (int) minecraft.thePlayer.getHealth()), scaledResolution.getScaledWidth() / 2 - 56, scaledResolution.getScaledHeight() - 38, 0xFFFFFFFF);
                    // food
                    RenderMethods.drawGradientBorderedRect(scaledResolution.getScaledWidth() / 2 + 10, scaledResolution.getScaledHeight() - 39, scaledResolution.getScaledWidth() / 2 + 91, scaledResolution.getScaledHeight() - 30, 1F, 0xDD000000, 0xFF444444, 0xFF222222);
                    RenderMethods.drawGradientBorderedRect(scaledResolution.getScaledWidth() / 2 + 90 - minusFood * 4, scaledResolution.getScaledHeight() - 39, scaledResolution.getScaledWidth() / 2 + 91, scaledResolution.getScaledHeight() - 30, 1F, 0xDD000000, 0xDD09BA00, 0xDD056300);
                    minecraft.fontRenderer.drawStringWithShadow(String.format("%s", minecraft.thePlayer.getFoodStats().getFoodLevel()), scaledResolution.getScaledWidth() / 2 + 45, scaledResolution.getScaledHeight() - 38, 0xFFFFFFFF);
                }

                if (blockAnimation.getValue())
                {
                        if (blockMode.getValue() == BlockMode.VANILLA) {
                            ItemRenderer.blockHeigh = blockHeight.getValue();
                            ItemRenderer.blockAnimation = true;
                        }
                        if (blockMode.getValue() == BlockMode.SWEEP) {
                            ItemRenderer.shouldSweepBlock = true;
                        } else {
                            ItemRenderer.shouldSweepBlock = false;
                        }

                }
                else
                {
                    ItemRenderer.blockAnimation = false;
                    ItemRenderer.blockHeigh = -0.2F;
                }
            }
        });
        Gun.getInstance().getEventManager().register(new Listener<ViewmodelEvent>("textgui_view_model_listener")
        {
            @Override
            public void call(ViewmodelEvent event)
            {
                if (nofov.getValue())
                {
                    event.setCanceled(true);
                }
            }
        });

    }
    public MovingObjectPosition getBlinkBlock() {
        final Vec3 var4 = minecraft.thePlayer.func_174824_e(minecraft.timer.renderPartialTicks);
        final Vec3 var5 = minecraft.thePlayer.getLook(minecraft.timer.renderPartialTicks);
        final Vec3 var6 = var4.addVector(var5.xCoord * 70.0, var5.yCoord * 70.0, var5.zCoord * 70.0);
        return minecraft.thePlayer.worldObj.rayTraceBlocks(var4, var6, false, false, true);
    }
    private Block getBlock(final int x, final int y, final int z) {
        return minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
    }

    private Block getBlock(final BlockPos pos) {
        return minecraft.theWorld.getBlockState(pos).getBlock();
    }

    public enum BlockMode {
        VANILLA, SWEEP
    }
}
