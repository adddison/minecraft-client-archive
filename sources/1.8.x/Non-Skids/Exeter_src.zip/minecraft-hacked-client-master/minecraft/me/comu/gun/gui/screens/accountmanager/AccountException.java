package me.comu.gun.gui.screens.accountmanager;

public class AccountException extends Exception
{
    public AccountException(String message)
    {
        super(message);
    }
}
