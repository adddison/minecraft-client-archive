package me.comu.gun.keybind;

public abstract class Action {

    public abstract void dispatch();

}
