package me.comu.gun.module.impl.toggle.miscellaneous;

import me.comu.api.interfaces.Toggleable;
import me.comu.gun.core.Gun;
import me.comu.gun.module.Module;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.util.ResourceLocation;

import java.util.List;

public final class ToggleSounds extends ToggleableModule
{
    public ToggleSounds()
    {
        super("ModuleSounds", new String[] {"togglesounds", "togglesound","modsound","modulesounds","modulesund","sound","sounds"}, ModuleType.MISCELLANEOUS);

        List<Module> modules = Gun.getInstance().getModuleManager().getRegistry();
        for (Module module : modules) {
            if (module instanceof Toggleable) {
                ToggleableModule toggleableModule = (ToggleableModule) module;

                if (toggleableModule.isDrawn() && toggleableModule.getColor() != 0 && toggleableModule.isRunning()) {
                    Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.createPositionedSoundRecord(new ResourceLocation("random.click"), 1F));
                }
            }
        }

    }
    
}