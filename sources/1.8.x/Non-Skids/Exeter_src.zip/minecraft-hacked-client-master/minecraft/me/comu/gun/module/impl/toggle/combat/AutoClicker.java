package me.comu.gun.module.impl.toggle.combat;

import javafx.beans.property.BooleanProperty;
import me.comu.gun.core.Gun;
import me.comu.gun.properties.Property;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.C02PacketUseEntity;
import org.lwjgl.input.Mouse;

import me.comu.api.event.Listener;
import me.comu.api.stopwatch.Stopwatch;
import me.comu.gun.events.PacketEvent;
import me.comu.gun.events.TickEvent;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import me.comu.gun.properties.NumberProperty;

import java.util.Random;

public final class AutoClicker extends ToggleableModule
{
    private final NumberProperty<Integer> cps = new NumberProperty<>(13, 1, 25, "CPS", "clicks", "click");
    private final Property<Boolean> randomize = new Property<>(false, "Randomize","random","r");

    private final Stopwatch stopwatch = new Stopwatch();

    public AutoClicker()
    {
        super("AutoClicker", new String[] {"autoclicker", "ac", "clicker"}, 0xFFB990D4, ModuleType.COMBAT);
        this.offerProperties(cps, randomize);
        this.listeners.add(new Listener<TickEvent>("auto_clicker_tick_listener")
        {
            @Override
            public void call(TickEvent event)
            {
                if (minecraft.currentScreen == null)
                {
                    if (Mouse.isButtonDown(0))
                    {
                        if (stopwatch.hasCompleted(1000L / cps.getValue()))
                        {
                            int preVal = cps.getValue();
                            KeyBinding.setKeyBindState(-100, true);
                            KeyBinding.onTick(-100);
                            stopwatch.reset();
                        }
                        else
                        {
                            KeyBinding.setKeyBindState(-100, false);
                        }
                    }
                }
            }

        });
        this.listeners.add(new Listener<PacketEvent>("auto_clicker_packet_listener")
        {
            @Override
            public void call(PacketEvent event)
            {
                if (event.getPacket() instanceof C02PacketUseEntity)
                {
                    C02PacketUseEntity c02PacketUseEntity = (C02PacketUseEntity) event.getPacket();

                    if (c02PacketUseEntity.getAction() == C02PacketUseEntity.Action.ATTACK)
                    {
                        if (c02PacketUseEntity.getEntityFromWorld(minecraft.theWorld) instanceof EntityPlayer)
                        {
                            EntityPlayer entityPlayer = (EntityPlayer) c02PacketUseEntity.getEntityFromWorld(minecraft.theWorld);

                            if (Gun.getInstance().getFriendManager().isFriend(entityPlayer.getName()))
                            {
                                event.setCanceled(true);
                            }
                        }
                    }
                }
            }
        });
    }

    private int getRandom(int[] array) {
        final int random = new Random().nextInt(array.length);
        return array[random];
    }
}
