package me.comu.gun.plugin;

public abstract class Manager<T>
{
    public void create() { }

    public void destroy() { }
}
