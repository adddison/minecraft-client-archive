package me.comu.gun.module.impl.toggle.miscellaneous;

import me.comu.gun.core.Gun;
import me.comu.gun.logging.Logger;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;

public final class SaveConfig extends ToggleableModule
{
    public SaveConfig()
    {
        super("Save Config", new String[] {"saveconfig","config","sc"}, ModuleType.MISCELLANEOUS);
    }

    @Override
    protected void onEnable()
    {
        Logger.getLogger().printToChat("Saving Config...");
        Gun.getInstance().getConfigManager().getRegistry().forEach(config -> config.save());
        Logger.getLogger().print("Config Saved.");
        setRunning(false);

    }
}
