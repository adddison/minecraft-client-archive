package me.comu.gun.module.impl.toggle.world;

import me.comu.api.event.Listener;
import me.comu.gun.events.MotionUpdateEvent;
import me.comu.gun.events.PacketEvent;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import me.comu.gun.properties.EnumProperty;
import net.minecraft.network.play.server.S03PacketTimeUpdate;


/**
 * Created by comu on 11/15/2018
 */
public class WorldTime extends ToggleableModule {

    private final EnumProperty<Mode> mode = new EnumProperty<Mode>(Mode.NIGHT, "Time", "t");

    public WorldTime() {
        super("Ambiance", new String[] {"ambiance","ambi","WorldTime","World-Time","time","wtime"}, ModuleType.WORLD);
        super.offerProperties(mode);
        this.listeners.add(new Listener<PacketEvent>("ambiance_packet_event") {
            @Override
            public void call(PacketEvent event) {
            if (event.getPacket() instanceof S03PacketTimeUpdate)
                event.setCanceled(true);
            }
        });
            this.listeners.add(new Listener<MotionUpdateEvent>("ambiance_packet_event") {
                @Override
                public void call(MotionUpdateEvent event) {
                    if (event.getTime() == MotionUpdateEvent.Time.AFTER) {
                        switch (mode.getValue()) {
                            case DAY:
                            minecraft.theWorld.setWorldTime(1000);
                                break;
                            case SUNSET:
                            minecraft.theWorld.setWorldTime(12000);
                                break;
                            case NIGHT:
                                minecraft.theWorld.setWorldTime(13000);
                                break;
                            case SUNRISE:
                            minecraft.theWorld.setWorldTime(23000);
                                break;
                            case MIDNIGHT:
                                minecraft.theWorld.setWorldTime(16000);
                        }
                    }
                }
            });
    }


    private enum Mode {
        DAY, SUNSET, NIGHT, SUNRISE, MIDNIGHT
    }

}
