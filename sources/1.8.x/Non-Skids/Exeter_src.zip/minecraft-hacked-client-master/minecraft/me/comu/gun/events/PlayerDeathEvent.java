package me.comu.gun.events;

import me.comu.api.event.Event;

public class PlayerDeathEvent extends Event{

}
