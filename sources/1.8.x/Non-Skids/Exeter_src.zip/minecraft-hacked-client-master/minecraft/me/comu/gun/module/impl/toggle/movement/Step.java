package me.comu.gun.module.impl.toggle.movement;

import me.comu.api.event.Listener;
import me.comu.api.minecraft.helper.PlayerHelper;
import me.comu.api.stopwatch.Stopwatch;
import me.comu.gun.core.Gun;
import me.comu.gun.events.MotionUpdateEvent;
import me.comu.gun.events.PacketEvent;
import me.comu.gun.events.StepEvent;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import me.comu.gun.properties.EnumProperty;
import me.comu.gun.properties.NumberProperty;
import net.minecraft.network.play.client.C03PacketPlayer;

/**
 * Created by nuf on 5/22/2016.
 */
public final class Step extends ToggleableModule {
    private final NumberProperty<Float> height = new NumberProperty<>(1.1F, 1.1F, 10F, "Height", "h");
    private final EnumProperty<Mode> mode = new EnumProperty<>(Mode.PACKET, "Mode", "m");
    private final Stopwatch stopwatch = new Stopwatch();

    private double moveSpeed;
    private double lastDist;
    public static int stage;
    public boolean isHigh;
    public boolean jump;
    private int fix;
    private double oldY;

    public Step() {
        super("Step", new String[]{"step", "autojump"}, 0xc6d43c, ModuleType.MOVEMENT);
        offerProperties(height, mode);
        listeners.add(new Listener<StepEvent>("step_step_listener") {
            @Override
            public void call(StepEvent event) {
            	setDrawn(true);
                Speed speed = (Speed) Gun.getInstance().getModuleManager().getModuleByAlias("speed");
                EnumProperty<Speed.Mode> mode = (EnumProperty) speed.getPropertyByAlias("Mode");
                if (speed != null && speed.isRunning() && mode.getValue() == Speed.Mode.HOP) {
                    return;
                }
                if (!PlayerHelper.isMoving() || !minecraft.thePlayer.onGround || PlayerHelper.isInLiquid() || PlayerHelper.isOnLiquid() || !minecraft.thePlayer.isCollidedHorizontally || !minecraft.thePlayer.isCollidedVertically || minecraft.thePlayer.isOnLadder()) {
                    return;
                }
                switch (event.getTime()) {
                    case BEFORE:
                        if (fix == 0) {
                            oldY = minecraft.thePlayer.posY;
                            event.setHeight(canStep() ? height.getValue() : 0.5F);
                        }
                        break;
                    case AFTER:
                        double offset = minecraft.thePlayer.getEntityBoundingBox().minY - oldY;
                        if (offset > 0.6 && fix == 0 && canStep() && stopwatch.hasCompleted(65L)) {
                            minecraft.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(minecraft.thePlayer.posX, minecraft.thePlayer.posY + 0.42D, minecraft.thePlayer.posZ, true));
                            minecraft.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(minecraft.thePlayer.posX, minecraft.thePlayer.posY + 0.75D, minecraft.thePlayer.posZ, true));
                            fix = 2;
                        }
                        break;
                }
            }
        });
        listeners.add(new Listener<MotionUpdateEvent>("step_motion_update_listener") {
            @Override
            public void call(MotionUpdateEvent event) {
                switch (mode.getValue()) {
                    case PACKET:
                        if (event.getTime() == MotionUpdateEvent.Time.BEFORE) {
                            if (event.getPositionY() - event.getOldPositionY() >= 0.75 && !minecraft.theWorld.getCollidingBoundingBoxes(minecraft.thePlayer, minecraft.thePlayer.getEntityBoundingBox().addCoord(0.0, -0.1, 0.0)).isEmpty())
                                stopwatch.reset();
                            if (fix > 0) {
                                event.setCanceled(true);
                                fix--;
                            }
                        }
                        break;
                    case VANILLA:
                        minecraft.thePlayer.stepHeight = height.getValue();
                        break;
                    case SPIDER:
                   spider();
                }
            }
        });
        listeners.add(new Listener<PacketEvent>("step_motion_update_listener") {
            @Override
            public void call(PacketEvent event) {
                    if (event.getPacket() instanceof C03PacketPlayer && isHigh ) {
                        final C03PacketPlayer localC03PacketPlayer = (C03PacketPlayer)event.getPacket();
                        localC03PacketPlayer.setOnGround(true);
                        isHigh = false;
                    }
                }
        });
    }

    private boolean canStep() {
        return !PlayerHelper.isOnLiquid() && !PlayerHelper.isInLiquid() && minecraft.thePlayer.onGround && !minecraft.gameSettings.keyBindJump.getIsKeyPressed() && minecraft.thePlayer.isCollidedVertically && minecraft.thePlayer.isCollidedHorizontally;
    }

    @Override
    protected  void onEnable() {
        super.onEnable();
        stage = 1;
    }
    @Override
    protected void onDisable() {
        super.onDisable();
        minecraft.thePlayer.stepHeight = 0.5F;
    }
    public void spider() {
        if (minecraft.thePlayer.isCollidedHorizontally) {
            minecraft.thePlayer.motionX = 0.0;
            minecraft.thePlayer.motionZ = 0.0;
            jump = true;
            if (minecraft.thePlayer.motionY < -0.19) {
                if (minecraft.thePlayer.onGround) {
                    minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(false));
                    isHigh = true;
                }
                else {
                    minecraft.thePlayer.motionY = 0.42;
                    isHigh = true;
                    minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(true));
                }
            }
        }
        else {
            jump = false;
        }
    }

    public enum Mode {
        PACKET, VANILLA, SPIDER
    }
}
