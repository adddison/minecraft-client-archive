package me.comu.gun.module.impl.toggle.miscellaneous;

import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;

public final class ClientCapes extends ToggleableModule
{
    public ClientCapes()
    {
        super("Capes", new String[] {"capes", "cape","cloaks","cloak"}, ModuleType.RENDER);
        
    }
}