package me.comu.gun.command.impl.server;

import me.comu.api.stopwatch.Stopwatch;
import me.comu.gun.command.Command;
import me.comu.gun.events.EventManager;
import me.comu.gun.events.EventTarget;
import me.comu.gun.events.PacketEvent;
import net.minecraft.network.play.client.C14PacketTabComplete;
import net.minecraft.network.play.server.S3APacketTabComplete;

public final class Plugins extends Command
{
    public Plugins()
    {
        super(new String[] {"plugins", "pl"});
    }
    private final Stopwatch stopwatch = new Stopwatch();
    @Override
    public String dispatch()
    {
        stopwatch.reset();;
        EventManager.register(this);
        minecraft.getNetHandler().addToSendQueue(new C14PacketTabComplete("/"));
        return "if only i cared e§cnuf§7f to finish this";
    }

    @EventTarget
    public void onReceivePacket(final PacketEvent event)
    {
        if (event.getPacket() instanceof S3APacketTabComplete)
        {
            final S3APacketTabComplete packet = (S3APacketTabComplete)
                                                event.getPacket();
            final String[] commands = packet.func_149630_c();
            String message = "";
            int size = 0;
            String[] array;

            for (int length = (array = commands).length, i = 0; i < length; ++i)
            {
                final String command = array[i];
                final String pluginName = command.split(":")[0].substring(1);

                if (!message.contains(pluginName) && command.contains(":") && !pluginName.equalsIgnoreCase("minecraft") && !pluginName.equalsIgnoreCase("bukkit"))
                {
                    ++size;

                    if (message.isEmpty())
                    {
                        message = String.valueOf(message) + pluginName;
                    }
                    else
                    {
                        message = String.valueOf(message) + "\u00c2§8, \u00c2§7" + pluginName;
                    }
                }
            }

            if (!message.isEmpty())
            {
                String.format("Plugins (" + size + "): §7" + message + "§8.");
            }
            else
            {
                String.format("Plugins: None Found!");
            }

            event.setCanceled(true);
            EventManager.unregister(this);
        }

        if (stopwatch.hasCompleted((long) 20000.0))
        {
            EventManager.unregister(this);
            String.format("Stopped listening for an S3APacketTabComplete! Took too long (20s)!");
        }
    }
}
