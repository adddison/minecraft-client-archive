package me.comu.gun.events;

/**
 * Created by comu on 4/20/2018
 */
public class BlindnessEvent extends Event {
}
