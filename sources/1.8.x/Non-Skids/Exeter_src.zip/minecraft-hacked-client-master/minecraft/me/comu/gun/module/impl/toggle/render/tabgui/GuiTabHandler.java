package me.comu.gun.module.impl.toggle.render.tabgui;

import me.comu.gun.core.Gun;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import me.comu.api.interfaces.Toggleable;
import me.comu.api.minecraft.render.RenderMethods;
import me.comu.gun.module.Module;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import me.comu.gun.module.impl.toggle.render.tabgui.item.GuiItem;
import me.comu.gun.module.impl.toggle.render.tabgui.item.GuiTab;
import me.comu.gun.properties.Property;

public final class GuiTabHandler
{
    private Minecraft mc = Minecraft.getMinecraft();
    private float width = 0.7F;
    private int guiHeight = 0;
    public boolean mainMenu = true;
    public int selectedItem = 0;
    public int selectedTab = 0;
    private int tabHeight = 12;
    public final ArrayList<GuiTab> tabs = new ArrayList<>();
    public int transition = 0;
    public boolean visible = true;

    public GuiTabHandler()
    {


        // TODO: add properties to tabgui
        

        List<Module> modules = Gun.getInstance().getModuleManager().getRegistry();
        modules.sort((mod1, mod2) -> mod1.getLabel().compareTo(mod2.getLabel()));


        
        if (selectedTab == 0 && selectedItem == 8)
        {
        	Gui.drawRect(tabHeight, guiHeight, selectedTab, guiHeight, 255);
        }
        for (ModuleType moduleType : ModuleType.values())
        {
        	
            GuiTab guiTab = new GuiTab(this, moduleType.getLabel());
            modules.stream().forEach(module ->
            
            {
                if (module instanceof Toggleable)
                {
                    ToggleableModule toggle = (ToggleableModule) module;
                    List<Property> properties = module.getProperties();

                   

                    if (toggle.getModuleType() == moduleType && toggle.getProperties() == properties && !toggle.getLabel().equalsIgnoreCase("Click Gui") && !toggle.getLabel().equalsIgnoreCase("Tab Gui"))
                    {
                    	
                        guiTab.getMods().add(new GuiItem(toggle));
//                        guiTab.getProperties().add(new GuiItem(properties));
                        //Gui.drawRect(4, guiHeight, 10, 17 + 15, 255);
//                        guiTab.getProperties().add(new GuiItem(p));
                        
                    }
                
             
                }
            });
            this.tabs.add(guiTab);
        }

        Collections.sort(tabs, (category1, category2) -> category1.getLabel().compareTo(category2.getLabel()));
        this.guiHeight = this.tabs.size() * this.tabHeight;
    }

    public void drawGui(int x, int y)
    {
        if (!this.visible)
        {
            return;
        }

        int guiWidth = 73;
        //   RenderMethods.enableGL2D();
        RenderMethods.drawBorderedRectReliant(x, y - 0.4F, x + guiWidth - 2, y + this.guiHeight + 0.4F, 1.5F, 0x66000000, 0x88000000);

        for (int i = 0; i < tabs.size(); i++)
        {
            int transitionTop = !this.mainMenu ? 0
                                : this.transition + (this.selectedTab == 0 && this.transition < 0 ? -this.transition : 0);
            int transitionBottom = !this.mainMenu ? 0
                                   : this.transition
                                   + (this.selectedTab == this.tabs.size() - 1 && this.transition > 0 ? -this.transition : 0);

            if (this.selectedTab == i)
            {
                RenderMethods.drawGradientBorderedRectReliant(x, i * 12 + y + transitionTop - 0.3F, x + guiWidth - 2.2F, i + (y + 12 + (i * 11)) + transitionBottom + 0.3F, 1.5F, 0x88000000, 0xFF610342, 0xFF610342);
            }
         /*   if (this.guiTab == 2) {
            	RenderMethods.drawGradientBorderedRectReliant(x, i * 12 + y + transitionTop - 0.3F, x + guiWidth - 2.2F, i + (y + 12 + (i * 11)) + transitionBottom + 0.3F, 1.5F, 0x88000000, 0xbb3C2CFF, 0xbb3C2CFF);
                	
            }
            */
        }

        int yOff = y + 2;

        for (int index = 0; index < this.tabs.size(); index++)
        {
            GuiTab tab = this.tabs.get(index);
            mc.fontRenderer.drawStringWithShadow(tab.getLabel(), x + 2, yOff, 0xfdfeff);

            if (this.selectedTab == index && !this.mainMenu)
            {
                tab.drawTabMenu(this.mc, x + guiWidth, yOff - 2);
            }

            yOff += this.tabHeight;
        }

        if (this.transition > 0)
        {
            this.transition -= 1;
        }
        else if (this.transition < 0)
        {
            this.transition += 1;
        }

        //   RenderMethods.disableGL2D();
    }

    public float getWidth()
    {
        return width;
    }

    public void setWidth(float width)
    {
        this.width = width;
    }

    public int getSelectedItem()
    {
        return selectedItem;
    }

    public int getTabHeight()
    {
        return tabHeight;
    }

    public int getTransition()
    {
        return transition;
    }
}
