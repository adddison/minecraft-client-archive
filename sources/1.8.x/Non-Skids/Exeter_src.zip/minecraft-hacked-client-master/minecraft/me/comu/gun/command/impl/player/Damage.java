package me.comu.gun.command.impl.player;

import me.comu.api.minecraft.helper.PlayerHelper;
import me.comu.gun.command.Command;

public final class Damage extends Command
{
    public Damage()
    {
        super(new String[] {"damage", "dmg", "td"});
    }

    @Override
    public String dispatch()
    {
        if (!PlayerHelper.isInLiquid())
        {
            PlayerHelper.damagePlayer();
        }
        else
        {
            PlayerHelper.drownPlayer();
        }

        return "Damaged.";
    }
}
