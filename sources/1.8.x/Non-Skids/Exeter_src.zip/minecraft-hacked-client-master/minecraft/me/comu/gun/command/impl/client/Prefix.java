package me.comu.gun.command.impl.client;

import me.comu.gun.command.Argument;
import me.comu.gun.command.Command;
import me.comu.gun.core.Gun;


public final class Prefix extends Command
{
    public Prefix()
    {
        super(new String[] {"prefix"}, new Argument("character"));
    }

    @Override
    public String dispatch()
    {
        String prefix = getArgument("character").getValue();
        Gun.getInstance().getCommandManager().setPrefix(prefix);
        return String.format("&e%s&7 is now your prefix.", prefix);
    }
}
