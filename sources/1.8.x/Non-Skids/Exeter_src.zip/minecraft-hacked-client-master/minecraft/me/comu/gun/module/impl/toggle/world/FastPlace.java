package me.comu.gun.module.impl.toggle.world;

import me.comu.api.event.Listener;
import me.comu.gun.events.TickEvent;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import me.comu.gun.properties.NumberProperty;

public final class FastPlace extends ToggleableModule
{
    private final NumberProperty<Integer> delay = new NumberProperty<>(0, 0, 10, "Delay", "d");
    public FastPlace()
    {
        super("FastPlace", new String[] {"fastplace", "fp", "place"}, 0xFFCC90D4, ModuleType.WORLD);
        this.offerProperties(delay);
        this.listeners.add(new Listener<TickEvent>("fast_place_tick_listener")
        {
            @Override
            public void call(TickEvent event)
            {
                minecraft.rightClickDelayTimer = delay.getValue();
            }
        });
    }
}
