package me.comu.gun.events;

import me.comu.api.event.Event;
import me.comu.gun.events.Event.State;

public class UpdateEvent extends Event
{
    private State state;
    private float yaw;
    private float pitch;
    private double x;
    private double y;
    private double z;
    private boolean onground;
    private boolean alwaysSend;

    public UpdateEvent()
    {
        this.state = State.POST;
    }

    public UpdateEvent(final double y, final float yaw, final float pitch, final boolean ground)
    {
        this.state = State.PRE;
        this.yaw = yaw;
        this.pitch = pitch;
        this.y = y;
        this.onground = ground;
    }

    public State getState()
    {
        return this.state;
    }

    public float getYaw()
    {
        return this.yaw;
    }

    public float getPitch()
    {
        return this.pitch;
    }

    public double getY()
    {
        return this.y;
    }

    public boolean isOnground()
    {
        return this.onground;
    }

    public boolean shouldAlwaysSend()
    {
        return this.alwaysSend;
    }

    public void setYaw(final float yaw)
    {
        this.yaw = yaw;
    }

    public void setPitch(final float pitch)
    {
        this.pitch = pitch;
    }
    public void setX(final double x) {
    	this.x = x;
    }

    public void setY(final double y)
    {
        this.y = y;
    }
    public void setZ(final double z) {
    	this.z = z;
    }

    public void setGround(final boolean ground)
    {
        this.onground = ground;
    }

    public void setAlwaysSend(final boolean alwaysSend)
    {
        this.alwaysSend = alwaysSend;
    }
}
