package me.comu.gun.keybind;

import org.lwjgl.input.Keyboard;

import me.comu.api.event.Listener;
import me.comu.api.registry.ListRegistry;
import me.comu.gun.core.Gun;
import me.comu.gun.events.InputEvent;

import java.util.ArrayList;

public final class KeybindManager extends ListRegistry<Keybind>
{
    public KeybindManager()
    {
        registry = new ArrayList<>();
        Gun.getInstance().getEventManager().register(new Listener<InputEvent>("keybinds_input_listener")
        {
            @Override
            public void call(InputEvent event)
            {
                if (event.getType() == InputEvent.Type.KEYBOARD_KEY_PRESS)
                {
                    registry.forEach(keybind ->
                    {
                        if (keybind.getKey() != Keyboard.KEY_NONE && keybind.getKey() == event.getKey())
                        {
                            keybind.onPressed();
                        }
                    });
                }
            }
        });
    }

    public Keybind getKeybindByLabel(String label)
    {
        for (Keybind keybind : registry)
        {
            if (label.equalsIgnoreCase(keybind.getLabel()))
            {
                return keybind;
            }
        }

        return null;
    }
}
