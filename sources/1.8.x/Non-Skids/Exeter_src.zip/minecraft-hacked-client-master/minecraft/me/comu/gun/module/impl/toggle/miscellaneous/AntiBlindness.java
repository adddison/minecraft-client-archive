package me.comu.gun.module.impl.toggle.miscellaneous;

import me.comu.api.event.Listener;
import me.comu.gun.events.PacketEvent;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import net.minecraft.potion.Potion;

/**
 * Created by comu on 4/20/2018
 */
public final class AntiBlindness extends ToggleableModule {

    Potion potion = Potion.blindness;

    public AntiBlindness() {
        super("AntiCommand", new String[] {"anticommand", "antic"}, 0xFFC690D4, ModuleType.MISCELLANEOUS);
        this.listeners.add(new Listener<PacketEvent>("anti_command_packet_listener") {

        @Override
        public void call(PacketEvent event) {

        }
    });
    }

}
