package me.comu.gun.module.impl.toggle.miscellaneous;

import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import me.comu.gun.properties.Property;

public final class AntiHCF extends ToggleableModule
{
    private final Property<Boolean> p2h = new Property<>(false, "p2h", "/p2h", "p2", "plot", "/p", "p", "plot2h");
    public AntiHCF()
    {
        super("AntiHCF", new String[] {"AntiHCF", "Anti-HCF", "hcf","ahcf"}, ModuleType.MISCELLANEOUS);
        this.offerProperties(p2h);
    }

    public void onEnable() {
        if (p2h.getValue() && minecraft.theWorld != null) {
            minecraft.thePlayer.sendChatMessage("/p2 h");
        }
    }
}
