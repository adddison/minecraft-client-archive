package me.comu.gun.module.impl.toggle.movement;

import me.comu.api.event.Listener;
import me.comu.gun.events.MotionUpdateEvent;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;

public final class BPS extends ToggleableModule
{
    private static double bps = 0.0;

    public BPS()
    {
        super("BPS", new String[] {"bps","bp/s","blockspersecond","blockspersec"}, ModuleType.MOVEMENT);
        listeners.add(new Listener<MotionUpdateEvent>("speed_motion_update_listener") {

            @Override
            public void call(MotionUpdateEvent event) {
                if (minecraft.thePlayer.isEntityAlive() && minecraft.theWorld != null) {
                     // sprinting = 5.612 walking = 4.317 sneaking = 1.31
                    bps = Math.sqrt(minecraft.thePlayer.motionX * minecraft.thePlayer.motionX + minecraft.thePlayer.motionZ * minecraft.thePlayer.motionZ);
               //     bps = minecraft.thePlayer.distanceWalkedModified;
                 }
            }
        });
    }

    public static double getBPS() {
        return bps;
    }


}
