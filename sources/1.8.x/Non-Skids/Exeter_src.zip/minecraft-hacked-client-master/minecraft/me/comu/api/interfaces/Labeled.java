package me.comu.api.interfaces;


public interface Labeled
{
    String getLabel();
}
