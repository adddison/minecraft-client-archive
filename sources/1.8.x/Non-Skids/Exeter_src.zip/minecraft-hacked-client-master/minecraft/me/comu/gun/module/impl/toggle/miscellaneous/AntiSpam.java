package me.comu.gun.module.impl.toggle.miscellaneous;

import me.comu.api.event.Listener;
import me.comu.api.stopwatch.Stopwatch;
import me.comu.gun.core.Gun;
import me.comu.gun.events.PacketEvent;
import me.comu.gun.events.ShowMessageEvent;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import me.comu.gun.properties.Property;
import net.minecraft.network.play.server.S02PacketChat;
import net.minecraft.util.IChatComponent;
import tv.twitch.chat.ChatEvent;

public final class AntiSpam extends ToggleableModule
{

    public AntiSpam()
    {
        super("AntiSpam", new String[] {"antispam", "anti-spam"}, ModuleType.MISCELLANEOUS);
        this.listeners.add(new Listener<PacketEvent>("auto_accept_packet_listener")
        {
            @Override
            public void call(PacketEvent event)
            {
                if (event.getPacket() instanceof S02PacketChat)
                {
                    S02PacketChat packet = new S02PacketChat();
                    IChatComponent chatComponent = packet.getChatComponent();


                }
            }
        });
    }
}
