package me.comu.gun.core;

import me.comu.api.event.basic.BasicEventManager;
import me.comu.api.minecraft.render.CustomFont;
import me.comu.gun.command.CommandManager;
import me.comu.gun.config.ConfigManager;
import me.comu.gun.enemy.EnemyManager;
import me.comu.gun.friend.FriendManager;
import me.comu.gun.gui.screens.accountmanager.AccountManager;
import me.comu.gun.keybind.KeybindManager;
import me.comu.gun.logging.Logger;
import me.comu.gun.module.ModuleManager;
import me.comu.gun.plugin.PluginManager;
import me.comu.gun.staff.StaffManager;
import me.comu.gun.utils.HWIDUtils;
import me.comu.gun.utils.WebUtils;
import me.comu.gun.waypoints.WaypointManager;
import me.comu.gun.notification.NotificationManager;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.Display;

import java.io.File;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

//import me.comu.gun.macro.MacroManager;



// TODO:
// show hugner on nametags
// worldtime
// cheststealer drop and store
// autopot 2 not potting in 21 slot
// TPS!!!
// calculator command
// make fake name tag hacker using getdisplayname from nametags
// make alt manager save alts as soon as alt array is updated
// fix self nametag rendering for how many people are in chnk
// add webhook permissiom adder to bot
// fix antivanish notifications to make new lines for certain number of chars
// sweep blockanimation
// add store in cheststealer
// add modes for distance/health colors for esp
// add embed msgs
// add warn command
// update scaffold (blocks on screen and stuff)
// add tower to scaffold
// nameprotect for scorreboard and shit

public final class Gun
{
    private static Gun instance = null;
    public final CustomFont textFont = new CustomFont("Futura Std Medium", 18);
    public final CustomFont textFont1 = new CustomFont("Verdana", 18);
    
    private ThreadLocal<Map<String, Object>> authors;

    public static String TITLE = "Client"; // flax xd! 10/26/17
    public static int BUILD = 1;
    public static final String AUTHORS = "Comu, Gringo, Tarik, Friendly, Nuf";
    private static final String HWIDURL = "https://pastebin.com/raw/V91R2VbQ";

    public final long startTime;

    private final BasicEventManager eventManager;
    private final KeybindManager keybindManager;
    private final ModuleManager moduleManager;
    private final CommandManager commandManager;
    private final FriendManager friendManager;
    private final ConfigManager configManager;
    private final AccountManager accountManager;
  //  private final MacroManager macroManager;
    private final WaypointManager wayPointManager;
    private final PluginManager pluginManager;
    private final EnemyManager enemyManager;
    private final StaffManager staffManager;
    private final NotificationManager notificationManager;
    private final File directory;

    public Gun()
    {
        startTime = System.nanoTime() / 1000000L;
        Logger.getLogger().print("Initializing...");
        instance = this;
        directory = new File(System.getProperty("user.home"), "clarinet");

        if (!directory.exists())
        {
            Logger.getLogger().print(String.format("%s client directory.", directory.mkdir() ? "Created" : "Failed to create"));
        }

        eventManager = new BasicEventManager();
        configManager = new ConfigManager();
        friendManager = new FriendManager();
     //   macroManager = new MacroManager();
        wayPointManager = new WaypointManager();
        enemyManager = new EnemyManager();
        staffManager = new StaffManager();
        keybindManager = new KeybindManager();
        commandManager = new CommandManager();
        moduleManager = new ModuleManager();
        accountManager = new AccountManager();
        pluginManager = new PluginManager();
        notificationManager = new NotificationManager();
        getConfigManager().getRegistry().forEach(config -> config.load());

        try
        {
            pluginManager.onLoad();
            System.out.println("Plugin manager started.");
            System.out.println(pluginManager.getList() + "has been loaded.");
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        Runtime.getRuntime().addShutdownHook(new Thread("Shutdown Hook Thread")
        {
            @Override
            public void run()
            {
                Logger.getLogger().print("Shutting down...");
                getConfigManager().getRegistry(). forEach(config -> config.save());
                Logger.getLogger().print("Shutdown.");
            }
        });
        Display.setTitle("Minecraft 1.8");



    //    Display.setTitle(String.format("%s b%s  ", TITLE, BUILD));
        // SessionUtils.login("", "");
        // SessionUtils.changeCrackedName("CodedByComu");
        Logger.getLogger().print(String.format("Initialized, took %s milliseconds.", ((System.nanoTime() / 1000000L) - startTime)));
        try {
            if (!WebUtils.get(HWIDURL).contains(HWIDUtils.getHWID())) {
                Logger.getLogger().print("Unauthorized Access! Shutting Down");
                Minecraft.getMinecraft().shutdownMinecraftApplet();
            } else {
                Logger.getLogger().print("Access Authorized!");
            }
        } catch (IOException | NoSuchAlgorithmException e) {
            Logger.getLogger().print("Caught Exception! Shutting Down");
            Minecraft.getMinecraft().shutdownMinecraftApplet();
        }
    }

    public static Gun getInstance()
    {
        return instance;
    }

    public ModuleManager getModuleManager()
    {
        return moduleManager;
    }

    public CommandManager getCommandManager()
    {
        return commandManager;
    }

    public KeybindManager getKeybindManager()
    {
        return keybindManager;
    }

    public NotificationManager getNotificationManager() {return notificationManager;}

    public FriendManager getFriendManager()
    {
        return friendManager;
    }

    public EnemyManager getEnemyManager() {return enemyManager; }
 //   public final MacroManager getMacroManager() { return macroManager;}

    public WaypointManager  getWaypointManager() {return wayPointManager;}

    public StaffManager getStaffManager() { return staffManager;}

    public BasicEventManager getEventManager()
    {
        return eventManager;
    }

    public ConfigManager getConfigManager()
    {
        return configManager;
    }

    public AccountManager getAccountManager()
    {
        return accountManager;
    }

    public PluginManager getPluginManager()
    {
        return pluginManager;
    }

    public File getDirectory() { return directory; }
}