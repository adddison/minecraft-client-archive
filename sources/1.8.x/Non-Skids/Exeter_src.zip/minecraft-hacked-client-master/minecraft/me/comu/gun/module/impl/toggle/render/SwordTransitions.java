package me.comu.gun.module.impl.toggle.render;

import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import me.comu.gun.properties.NumberProperty;

public class SwordTransitions extends ToggleableModule
{
    private double xx, yy, zz;
    private final NumberProperty<Double>  x = new NumberProperty<Double>(xx, 1.0, 2.0, "z");
    private final NumberProperty<Double> y = new NumberProperty<Double>(yy, 1.0, 2.0, "x");
    private final NumberProperty<Double> z = new NumberProperty<Double>(zz, 1.0, 2.0, "y");

    public SwordTransitions()
    {
        super("SwordTransitions", new String[] {"swordtransitions", "stransitions", "swordtrans","st"}, ModuleType.RENDER);;
        this.offerProperties(x,y,z);
    }

    public double getX()
    {
        return this.xx;
    }

    public double getY()
    {
        return this.yy;
    }

    public double getZ()
    {
        return this.zz;
    }
}
