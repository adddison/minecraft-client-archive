package me.comu.gun.module.impl.toggle.miscellaneous;

import me.comu.api.event.Listener;
import me.comu.gun.events.MotionUpdateEvent;
import me.comu.gun.module.ModuleType;
import me.comu.gun.module.ToggleableModule;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.BlockPos;

public final class Notebot extends ToggleableModule
{
    public Notebot()
    {
        super("Notebot", new String[] {"notebot", "nb", "note", "bot"}, 0xFFB2E665, ModuleType.MISCELLANEOUS);
        this.listeners.add(new Listener<MotionUpdateEvent>("note_bot_motion_update_listener")
        {
            @Override
            public void call(MotionUpdateEvent event)
            {
            }
        });
    }

    private void playNoteblock(BlockPos blockPos)
    {
        minecraft.getNetHandler().addToSendQueue(new C08PacketPlayerBlockPlacement(blockPos, -1, minecraft.thePlayer.getCurrentEquippedItem(), -1, -1, -1));
    }
}
