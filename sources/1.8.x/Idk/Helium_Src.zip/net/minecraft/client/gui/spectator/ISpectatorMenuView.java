// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.gui.spectator;

import net.minecraft.util.IChatComponent;
import java.util.List;

public interface ISpectatorMenuView
{
    List<ISpectatorMenuObject> func_178669_a();
    
    IChatComponent func_178670_b();
}
