// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.gui.inventory;

import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import java.util.List;
import net.minecraft.inventory.Container;
import a.a.a.a;
import net.minecraft.inventory.ICrafting;

public class CreativeCrafting implements ICrafting
{
    private final a mc;
    
    public CreativeCrafting(final a mc) {
        this.mc = mc;
    }
    
    @Override
    public void updateCraftingInventory(final Container containerToSend, final List<ItemStack> itemsList) {
    }
    
    @Override
    public void sendSlotContents(final Container containerToSend, final int slotInd, final ItemStack stack) {
        this.mc.pms.sendSlotPacket(stack, slotInd);
    }
    
    @Override
    public void sendProgressBarUpdate(final Container containerIn, final int varToUpdate, final int newValue) {
    }
    
    @Override
    public void func_175173_a(final Container p_175173_1_, final IInventory p_175173_2_) {
    }
}
