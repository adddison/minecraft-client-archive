// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.gui;

public interface GuiYesNoCallback
{
    void confirmClicked(final boolean p0, final int p1);
}
