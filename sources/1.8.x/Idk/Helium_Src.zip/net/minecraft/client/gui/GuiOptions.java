// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.gui;

import java.io.IOException;
import net.minecraft.client.stream.IStream;
import net.minecraft.client.gui.stream.GuiStreamUnavailable;
import net.minecraft.client.gui.stream.GuiStreamOptions;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.ChatComponentText;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.client.audio.SoundEventAccessorComposite;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.audio.SoundCategory;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;

public class GuiOptions extends GuiScreen implements GuiYesNoCallback
{
    private static final GameSettings.Options[] field_146440_f;
    private final GuiScreen field_146441_g;
    private final GameSettings game_settings_1;
    private GuiButton field_175357_i;
    private GuiLockIconButton field_175356_r;
    protected String field_146442_a;
    
    static {
        field_146440_f = new GameSettings.Options[] { GameSettings.Options.FOV };
    }
    
    public GuiOptions(final GuiScreen p_i1046_1_, final GameSettings p_i1046_2_) {
        this.field_146442_a = "Options";
        this.field_146441_g = p_i1046_1_;
        this.game_settings_1 = p_i1046_2_;
    }
    
    @Override
    public void initGui() {
        int i = 0;
        this.field_146442_a = I18n.format("options.title", new Object[0]);
        GameSettings.Options[] field_146440_f;
        for (int length = (field_146440_f = GuiOptions.field_146440_f).length, j = 0; j < length; ++j) {
            final GameSettings.Options gamesettings$options = field_146440_f[j];
            if (gamesettings$options.getEnumFloat()) {
                this.buttonList.add(new GuiOptionSlider(gamesettings$options.returnEnumOrdinal(), GuiOptions.width / 2 - 155 + i % 2 * 160, GuiOptions.height / 6 - 12 + 24 * (i >> 1), gamesettings$options));
            }
            else {
                final GuiOptionButton guioptionbutton = new GuiOptionButton(gamesettings$options.returnEnumOrdinal(), GuiOptions.width / 2 - 155 + i % 2 * 160, GuiOptions.height / 6 - 12 + 24 * (i >> 1), gamesettings$options, this.game_settings_1.getKeyBinding(gamesettings$options));
                this.buttonList.add(guioptionbutton);
            }
            ++i;
        }
        if (this.mc.pnc != null) {
            final EnumDifficulty enumdifficulty = this.mc.pnc.getDifficulty();
            this.field_175357_i = new GuiButton(108, GuiOptions.width / 2 - 155 + i % 2 * 160, GuiOptions.height / 6 - 12 + 24 * (i >> 1), 150, 20, this.func_175355_a(enumdifficulty));
            this.buttonList.add(this.field_175357_i);
            if (this.mc.bs() && !this.mc.pnc.getWorldInfo().isHardcoreModeEnabled()) {
                this.field_175357_i.setWidth(this.field_175357_i.getButtonWidth() - 20);
                this.field_175356_r = new GuiLockIconButton(109, this.field_175357_i.xPosition + this.field_175357_i.getButtonWidth(), this.field_175357_i.yPosition);
                this.buttonList.add(this.field_175356_r);
                this.field_175356_r.func_175229_b(this.mc.pnc.getWorldInfo().isDifficultyLocked());
                this.field_175356_r.enabled = !this.field_175356_r.func_175230_c();
                this.field_175357_i.enabled = !this.field_175356_r.func_175230_c();
            }
            else {
                this.field_175357_i.enabled = false;
            }
        }
        this.buttonList.add(new GuiButton(110, GuiOptions.width / 2 - 155, GuiOptions.height / 6 + 48 - 6, 150, 20, I18n.format("options.skinCustomisation", new Object[0])));
        this.buttonList.add(new GuiButton(8675309, GuiOptions.width / 2 + 5, GuiOptions.height / 6 + 48 - 6, 150, 20, "Super Secret Settings...") {
            @Override
            public void playPressSound(final SoundHandler soundHandlerIn) {
                final SoundEventAccessorComposite soundeventaccessorcomposite = soundHandlerIn.getRandomSoundFromCategories(SoundCategory.ANIMALS, SoundCategory.BLOCKS, SoundCategory.MOBS, SoundCategory.PLAYERS, SoundCategory.WEATHER);
                if (soundeventaccessorcomposite != null) {
                    soundHandlerIn.playSound(PositionedSoundRecord.create(soundeventaccessorcomposite.getSoundEventLocation(), 0.5f));
                }
            }
        });
        this.buttonList.add(new GuiButton(106, GuiOptions.width / 2 - 155, GuiOptions.height / 6 + 72 - 6, 150, 20, I18n.format("options.sounds", new Object[0])));
        this.buttonList.add(new GuiButton(107, GuiOptions.width / 2 + 5, GuiOptions.height / 6 + 72 - 6, 150, 20, I18n.format("options.stream", new Object[0])));
        this.buttonList.add(new GuiButton(101, GuiOptions.width / 2 - 155, GuiOptions.height / 6 + 96 - 6, 150, 20, I18n.format("options.video", new Object[0])));
        this.buttonList.add(new GuiButton(100, GuiOptions.width / 2 + 5, GuiOptions.height / 6 + 96 - 6, 150, 20, I18n.format("options.controls", new Object[0])));
        this.buttonList.add(new GuiButton(102, GuiOptions.width / 2 - 155, GuiOptions.height / 6 + 120 - 6, 150, 20, I18n.format("options.language", new Object[0])));
        this.buttonList.add(new GuiButton(103, GuiOptions.width / 2 + 5, GuiOptions.height / 6 + 120 - 6, 150, 20, I18n.format("options.chat.title", new Object[0])));
        this.buttonList.add(new GuiButton(105, GuiOptions.width / 2 - 155, GuiOptions.height / 6 + 144 - 6, 150, 20, I18n.format("options.resourcepack", new Object[0])));
        this.buttonList.add(new GuiButton(104, GuiOptions.width / 2 + 5, GuiOptions.height / 6 + 144 - 6, 150, 20, I18n.format("options.snooper.view", new Object[0])));
        this.buttonList.add(new GuiButton(200, GuiOptions.width / 2 - 100, GuiOptions.height / 6 + 168, I18n.format("gui.done", new Object[0])));
    }
    
    public String func_175355_a(final EnumDifficulty p_175355_1_) {
        final IChatComponent ichatcomponent = new ChatComponentText("");
        ichatcomponent.appendSibling(new ChatComponentTranslation("options.difficulty", new Object[0]));
        ichatcomponent.appendText(": ");
        ichatcomponent.appendSibling(new ChatComponentTranslation(p_175355_1_.getDifficultyResourceKey(), new Object[0]));
        return ichatcomponent.getFormattedText();
    }
    
    @Override
    public void confirmClicked(final boolean result, final int id) {
        this.mc.a(this);
        if (id == 109 && result && this.mc.pnc != null) {
            this.mc.pnc.getWorldInfo().setDifficultyLocked(true);
            this.field_175356_r.func_175229_b(true);
            this.field_175356_r.enabled = false;
            this.field_175357_i.enabled = false;
        }
    }
    
    @Override
    protected void actionPerformed(final GuiButton button) throws IOException {
        if (button.enabled) {
            if (button.id < 100 && button instanceof GuiOptionButton) {
                final GameSettings.Options gamesettings$options = ((GuiOptionButton)button).returnEnumOptions();
                this.game_settings_1.setOptionValue(gamesettings$options, 1);
                button.displayString = this.game_settings_1.getKeyBinding(GameSettings.Options.getEnumOptions(button.id));
            }
            if (button.id == 108) {
                this.mc.pnc.getWorldInfo().setDifficulty(EnumDifficulty.getDifficultyEnum(this.mc.pnc.getDifficulty().getDifficultyId() + 1));
                this.field_175357_i.displayString = this.func_175355_a(this.mc.pnc.getDifficulty());
            }
            if (button.id == 109) {
                this.mc.a(new GuiYesNo(this, new ChatComponentTranslation("difficulty.lock.title", new Object[0]).getFormattedText(), new ChatComponentTranslation("difficulty.lock.question", new Object[] { new ChatComponentTranslation(this.mc.pnc.getWorldInfo().getDifficulty().getDifficultyResourceKey(), new Object[0]) }).getFormattedText(), 109));
            }
            if (button.id == 110) {
                this.mc.poa.saveOptions();
                this.mc.a(new GuiCustomizeSkin(this));
            }
            if (button.id == 8675309) {
                this.mc.pnr.activateNextShader();
            }
            if (button.id == 101) {
                this.mc.poa.saveOptions();
                this.mc.a(new GuiVideoSettings(this, this.game_settings_1));
            }
            if (button.id == 100) {
                this.mc.poa.saveOptions();
                this.mc.a(new GuiControls(this, this.game_settings_1));
            }
            if (button.id == 102) {
                this.mc.poa.saveOptions();
                this.mc.a(new GuiLanguage(this, this.game_settings_1, this.mc.cf()));
            }
            if (button.id == 103) {
                this.mc.poa.saveOptions();
                this.mc.a(new ScreenChatOptions(this, this.game_settings_1));
            }
            if (button.id == 104) {
                this.mc.poa.saveOptions();
                this.mc.a(new GuiSnooper(this, this.game_settings_1));
            }
            if (button.id == 200) {
                this.mc.poa.saveOptions();
                this.mc.a(this.field_146441_g);
            }
            if (button.id == 105) {
                this.mc.poa.saveOptions();
                this.mc.a(new GuiScreenResourcePacks(this));
            }
            if (button.id == 106) {
                this.mc.poa.saveOptions();
                this.mc.a(new GuiScreenOptionsSounds(this, this.game_settings_1));
            }
            if (button.id == 107) {
                this.mc.poa.saveOptions();
                final IStream istream = this.mc.cl();
                if (istream.func_152936_l() && istream.func_152928_D()) {
                    this.mc.a(new GuiStreamOptions(this, this.game_settings_1));
                }
                else {
                    GuiStreamUnavailable.func_152321_a(this);
                }
            }
        }
    }
    
    @Override
    public void drawScreen(final int mouseX, final int mouseY, final float partialTicks) {
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRendererObj, this.field_146442_a, GuiOptions.width / 2, 15, 16777215);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }
}
