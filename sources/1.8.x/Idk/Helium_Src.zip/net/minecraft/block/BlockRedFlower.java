// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.block;

public class BlockRedFlower extends BlockFlower
{
    @Override
    public EnumFlowerColor getBlockType() {
        return EnumFlowerColor.RED;
    }
}
