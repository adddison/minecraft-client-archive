// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.block;

public class BlockHalfStoneSlab extends BlockStoneSlab
{
    @Override
    public boolean isDouble() {
        return false;
    }
}
