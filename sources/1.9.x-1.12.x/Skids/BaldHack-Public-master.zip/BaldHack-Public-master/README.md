# BaldHack
everything is pasted except for capes and some modules
not working on current state. removed baldcrash/baldcrashbypass cuz code is gross and ew 
plz dont learn from this it is very icky and gross :(
Creds to Mc_Ren (for the idea of making a KAMI based client)
Crystallinqq (for doing 99% of the work)
Meedou (for writing some modules and being cool burger man)
Everyone I pasted from <3 luv u


For a better, and nonpasted utility mod, join Mercury discord at https://discord.io/mercurymod
