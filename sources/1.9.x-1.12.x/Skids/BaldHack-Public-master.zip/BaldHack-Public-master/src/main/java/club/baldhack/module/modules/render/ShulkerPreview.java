package club.baldhack.module.modules.render;

import club.baldhack.mixin.client.MixinGuiScreen;
import club.baldhack.module.Module;

/**
 * Created by 086 on 24/12/2017.
 * @see MixinGuiScreen
 */
@Module.Info(name = "ShulkerPreview", category = Module.Category.RENDER)
public class ShulkerPreview extends Module {
}
