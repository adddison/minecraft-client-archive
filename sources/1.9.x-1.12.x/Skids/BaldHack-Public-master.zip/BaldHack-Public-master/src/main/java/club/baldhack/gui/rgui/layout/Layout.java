package club.baldhack.gui.rgui.layout;

import club.baldhack.gui.rgui.component.container.Container;

/**
 * Created by 086 on 26/06/2017.
 */
public interface Layout {

    public void organiseContainer(Container container);

}
