package club.baldhack.event.events;

import club.baldhack.event.KamiEvent;

public class ServerTick extends KamiEvent {
}

