package club.baldhack.setting;

/**
 * Created by 086 on 12/10/2018.
 */
public interface Named {

    String getName();

}
