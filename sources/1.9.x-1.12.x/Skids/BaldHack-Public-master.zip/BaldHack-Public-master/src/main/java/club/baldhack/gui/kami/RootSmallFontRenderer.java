package club.baldhack.gui.kami;


/**
 * Created by 086 on 26/06/2017.
 */
public class RootSmallFontRenderer extends RootFontRenderer {

    public RootSmallFontRenderer() {
        super(.75f);
    }

}
