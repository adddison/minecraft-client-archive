package club.baldhack.gui.rgui.layout;

import club.baldhack.gui.rgui.component.container.Container;

/**
 * Created by 086 on 5/08/2017.
 */
public class UselessLayout implements Layout {
    @Override
    public void organiseContainer(Container container) {
        // Do absolutely nothing
    }


}
