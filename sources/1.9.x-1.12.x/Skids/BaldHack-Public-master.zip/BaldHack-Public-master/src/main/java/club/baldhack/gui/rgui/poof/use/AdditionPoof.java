package club.baldhack.gui.rgui.poof.use;

import club.baldhack.gui.rgui.component.Component;
import club.baldhack.gui.rgui.poof.PoofInfo;

/**
 * Created by 086 on 21/07/2017.
 */
public abstract class AdditionPoof<T extends Component, S extends PoofInfo> extends Poof<T, S> {
}
