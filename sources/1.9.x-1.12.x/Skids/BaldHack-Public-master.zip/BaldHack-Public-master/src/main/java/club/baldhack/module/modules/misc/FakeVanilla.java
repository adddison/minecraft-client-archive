package club.baldhack.module.modules.misc;

import club.baldhack.module.Module;

/**
 * Created by 086 on 9/04/2018.
 */
@Module.Info(name = "FakeVanilla", description = "Fakes a modless client when connecting", category = Module.Category.MISC)
public class FakeVanilla extends Module {
}
