package club.baldhack.gui.kami.component;

import club.baldhack.gui.rgui.component.use.CheckButton;

/**
 * Created by 086 on 8/08/2017.
 */
public class ColorizedCheckButton extends CheckButton {
    public ColorizedCheckButton(String name) {
        super(name);
    }
}
