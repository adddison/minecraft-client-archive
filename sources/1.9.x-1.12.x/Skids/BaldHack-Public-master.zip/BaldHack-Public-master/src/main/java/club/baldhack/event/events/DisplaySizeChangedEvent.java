package club.baldhack.event.events;

/**
 * Created by 086 on 12/12/2017.
 */
public class DisplaySizeChangedEvent {
}
