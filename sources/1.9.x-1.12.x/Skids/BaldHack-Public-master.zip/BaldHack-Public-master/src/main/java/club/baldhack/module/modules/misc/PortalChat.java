package club.baldhack.module.modules.misc;

import club.baldhack.mixin.client.MixinEntityPlayerSP;
import club.baldhack.module.Module;

/**
 * Created by 086 on 12/12/2017.
 * @see MixinEntityPlayerSP
 */
@Module.Info(name = "PortalChat", category = Module.Category.MISC, description = "Allows you to open GUIs in portals")
public class PortalChat extends Module {
}
