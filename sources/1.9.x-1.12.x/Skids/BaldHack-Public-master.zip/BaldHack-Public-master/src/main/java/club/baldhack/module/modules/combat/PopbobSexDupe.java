package club.baldhack.module.modules.combat;

import club.baldhack.module.Module;

@Module.Info(name = "PopbobSexDupe", description = "Used by popbob and itristan fitmc", category = Module.Category.MISC)
public class PopbobSexDupe extends Module {
}
