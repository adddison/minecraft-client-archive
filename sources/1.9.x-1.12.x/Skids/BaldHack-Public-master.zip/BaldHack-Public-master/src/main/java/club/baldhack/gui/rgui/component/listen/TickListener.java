package club.baldhack.gui.rgui.component.listen;

/**
 * Created by 086 on 5/08/2017.
 */
public interface TickListener {
    void onTick();
}
