package club.baldhack.gui.rgui.poof;

/**
 * Created by 086 on 21/07/2017.
 */
public class PoofInfo {
}
