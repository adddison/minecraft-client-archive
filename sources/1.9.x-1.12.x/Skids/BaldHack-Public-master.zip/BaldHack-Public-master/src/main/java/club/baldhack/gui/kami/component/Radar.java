package club.baldhack.gui.kami.component;

import club.baldhack.gui.rgui.component.AbstractComponent;

/**
 * Created by 086 on 11/08/2017.
 */
public class Radar extends AbstractComponent {
}
