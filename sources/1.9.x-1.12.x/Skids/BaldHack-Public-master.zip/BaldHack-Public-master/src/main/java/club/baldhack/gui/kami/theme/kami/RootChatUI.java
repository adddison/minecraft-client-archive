package club.baldhack.gui.kami.theme.kami;

import club.baldhack.gui.kami.component.Chat;
import club.baldhack.gui.rgui.render.AbstractComponentUI;

/**
 * Created by 086 on 2/08/2017.
 */
public class RootChatUI extends AbstractComponentUI<Chat> {
}
