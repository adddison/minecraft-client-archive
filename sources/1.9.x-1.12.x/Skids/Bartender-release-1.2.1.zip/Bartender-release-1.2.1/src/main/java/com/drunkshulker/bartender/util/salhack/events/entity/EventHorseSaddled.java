package com.drunkshulker.bartender.util.salhack.events.entity;

import com.drunkshulker.bartender.util.salhack.events.MinecraftEvent;


public class EventHorseSaddled extends MinecraftEvent
{
}
