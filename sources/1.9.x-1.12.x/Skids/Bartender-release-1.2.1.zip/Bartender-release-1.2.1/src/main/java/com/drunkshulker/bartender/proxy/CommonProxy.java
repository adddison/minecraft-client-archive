package com.drunkshulker.bartender.proxy;

public class CommonProxy {

	public void init() {
		
	}

}
