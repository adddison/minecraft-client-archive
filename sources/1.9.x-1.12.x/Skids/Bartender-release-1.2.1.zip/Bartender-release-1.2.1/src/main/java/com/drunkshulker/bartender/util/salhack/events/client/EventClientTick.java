package com.drunkshulker.bartender.util.salhack.events.client;

import com.drunkshulker.bartender.util.salhack.events.MinecraftEvent;

public class EventClientTick extends MinecraftEvent
{

}
