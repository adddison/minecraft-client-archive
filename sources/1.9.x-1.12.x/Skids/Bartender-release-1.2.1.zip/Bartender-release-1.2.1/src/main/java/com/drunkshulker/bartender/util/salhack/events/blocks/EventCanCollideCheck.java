package com.drunkshulker.bartender.util.salhack.events.blocks;

import com.drunkshulker.bartender.util.salhack.events.MinecraftEvent;

public class EventCanCollideCheck extends MinecraftEvent
{

}
