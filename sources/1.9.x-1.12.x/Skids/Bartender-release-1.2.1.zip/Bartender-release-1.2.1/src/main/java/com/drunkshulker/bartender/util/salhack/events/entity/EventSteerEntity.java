package com.drunkshulker.bartender.util.salhack.events.entity;

import com.drunkshulker.bartender.util.salhack.events.MinecraftEvent;


public class EventSteerEntity extends MinecraftEvent
{
}
