package com.drunkshulker.bartender.util.salhack.events.player;

import com.drunkshulker.bartender.util.salhack.events.MinecraftEvent;
public class EventPlayerMotionUpdate extends MinecraftEvent
{
    public EventPlayerMotionUpdate(Era p_Era)
    {
        super(p_Era);
    }
}
