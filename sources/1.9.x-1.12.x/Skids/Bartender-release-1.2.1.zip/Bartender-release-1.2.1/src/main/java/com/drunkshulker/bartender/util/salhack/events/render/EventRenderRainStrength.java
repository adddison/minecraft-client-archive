package com.drunkshulker.bartender.util.salhack.events.render;

import com.drunkshulker.bartender.util.salhack.events.MinecraftEvent;
public class EventRenderRainStrength extends MinecraftEvent
{

}
