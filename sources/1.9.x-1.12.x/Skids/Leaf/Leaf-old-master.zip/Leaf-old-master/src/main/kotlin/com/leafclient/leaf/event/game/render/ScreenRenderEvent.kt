package com.leafclient.leaf.event.game.render

/**
 * Event invoked when the overlay is rendered (pre-render)
 */
class ScreenRenderEvent(val partialTicks: Float)