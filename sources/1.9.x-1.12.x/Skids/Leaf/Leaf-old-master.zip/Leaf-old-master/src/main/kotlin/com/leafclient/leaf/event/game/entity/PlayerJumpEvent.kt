package com.leafclient.leaf.event.game.entity

class PlayerJumpEvent(var rotationYaw: Float)