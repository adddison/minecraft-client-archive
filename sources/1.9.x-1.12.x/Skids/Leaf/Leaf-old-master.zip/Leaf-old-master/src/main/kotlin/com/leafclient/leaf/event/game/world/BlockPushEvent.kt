package com.leafclient.leaf.event.game.world

import fr.shyrogan.publisher4k.Cancellable

class BlockPushEvent: Cancellable()