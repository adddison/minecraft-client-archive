package com.leafclient.leaf.event.game.entity

class PlayerLivingUpdateEvent