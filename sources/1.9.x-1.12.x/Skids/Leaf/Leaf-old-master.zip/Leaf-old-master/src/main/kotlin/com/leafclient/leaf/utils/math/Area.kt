package com.leafclient.leaf.utils.math

data class Area(var x: Float = 0F, var y: Float = 0F, var width: Float = 0F, var height: Float = 0F)