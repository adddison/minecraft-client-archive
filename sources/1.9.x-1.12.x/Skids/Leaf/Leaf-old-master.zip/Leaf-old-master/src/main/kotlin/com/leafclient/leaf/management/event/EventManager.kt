package com.leafclient.leaf.management.event

import fr.shyrogan.publisher4k.Publisher

/**
 * An extension of [Publisher] that represents Spicy's [EventManager]
 */
object EventManager: Publisher()