package com.leafclient.leaf.management.ui.utils

/**
 * Represents a [Transition] to [Animation]
 */
typealias Transition = (Double) -> Double