package com.leafclient.leaf.event.game.input

class KeyboardTickEvent