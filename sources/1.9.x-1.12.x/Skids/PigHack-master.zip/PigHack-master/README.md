# snitch nigga thats that shit i dont like :yawning_face:
*uncracked and a shit ton of errors, no updates/fixes will be provided anymore*
https://www.youtube.com/watch?v=tt4Ox0ozhnE guide to pighack
