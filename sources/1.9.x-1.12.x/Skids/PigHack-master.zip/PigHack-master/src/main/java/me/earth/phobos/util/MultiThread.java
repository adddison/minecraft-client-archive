package me.earth.phobos.util;

public class MultiThread {
    public static void startThreadLoop() {
    }
}

