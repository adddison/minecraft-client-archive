package me.earth.phobos.event.events;


import me.earth.phobos.event.EventStage;

public class EventPlayerUpdate extends EventStage
{
    public EventPlayerUpdate()
    {
        super();
    }
}