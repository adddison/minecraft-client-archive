package me.earth.phobos.features.modules.render;

import me.earth.phobos.features.modules.Module;

public class CustomView extends Module {
    public CustomView() {
        super("CustomView", "Message friends when their armor is low", Category.RENDER, true, false, false);
    }
}