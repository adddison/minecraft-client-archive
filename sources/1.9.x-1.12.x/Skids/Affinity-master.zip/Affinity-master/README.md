# Affinity+ Client

Discord: https://discord.gg/bFMFbc

Current version: 2.1.2

Developers:
-programmer
-jimbo
-scsw

-sehcs dupe
