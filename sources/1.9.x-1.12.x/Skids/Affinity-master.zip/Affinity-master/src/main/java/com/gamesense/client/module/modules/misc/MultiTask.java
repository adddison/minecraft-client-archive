package com.gamesense.client.module.modules.misc;

import com.gamesense.client.module.Module;

public class MultiTask extends Module {
    public MultiTask() {
        super("MultiTask", Category.Misc);
    }

}
