package com.gamesense.client.module.modules.render;

import com.gamesense.client.module.Module;

/**
 * GameSense epic shulker preview... I hope :D
 * Check com.gamesense.api.mixin.mixins.MixinShulkerViewer
 */

public class ShulkerViewer extends Module {
    public ShulkerViewer() {
        super("ShulkerViewer", Category.Render);
    }
}
