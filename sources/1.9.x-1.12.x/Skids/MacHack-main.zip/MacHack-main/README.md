# MacHack 1.16.4 
[![discord](https://img.shields.io/badge/Discord-h8EQyuYTK7-9080c2)](https://discord.gg/h8EQyuYTK7)
![](https://img.shields.io/github/languages/code-size/ChiquitaV2/MacHack.svg)

Very cool client made by Bleach and epearl 

This is designed for people who want to use Bleach had epearl edition
but can't because they are on mac or linux. Anyone should be able to use this no matter their OS.
The only big difference between MacHack and MacHack+, is that MacHack+ has BA and gets modules faster but those modules will come to MacHack with time(like a day or two)

Works on fabric 1.16.2/3/4

> Join The Discord Cuz I want clout https://discord.gg/h8EQyuYTK7

## Installation:

Download [fabric for minecraft 1.16.4](https://fabricmc.net/use/)  
Download the lastest compiled version of MacHack for your Minecraft version [from the Actions section](https://github.com/ChiquitaV2/MacHack/actions)  
Extract the zip and put the jar into your mods folder  

##Credits
This is a Bleachhack port/fork so I owe tons of credit to Bleach, epearl,
 and everyone who has done anything for bleachhack
 and also thanks to ionar for salhack.
