package mac.hack.utils;

public class TempCalculate {
}
