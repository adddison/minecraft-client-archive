package mac.hack.module.mods;

import mac.hack.module.Category;
import mac.hack.module.Module;

public class CameraClip  extends Module {
    public CameraClip() {
        super("CameraClip", KEY_UNBOUND, Category.RENDER, "Better f5"
               );
    }
}
