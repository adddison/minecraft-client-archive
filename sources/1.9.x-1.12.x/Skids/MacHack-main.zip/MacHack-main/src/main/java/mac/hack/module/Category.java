package mac.hack.module;

public enum Category {
	COMBAT,
	MISC,
	MOVEMENT,
	PLAYER,
	RENDER,
	WORLD,
	EXPLOITS,
	CHAT,
	CLIENT
}