package mac.hack.module.mods;

import mac.hack.module.Category;
import mac.hack.module.Module;

public class AllahHaram extends Module {

    public AllahHaram() {
        super("AllahHaram", KEY_UNBOUND, Category.RENDER, "ﮗﮃﭹﭫﭗﭿﭬﭸﮔﭤﮙﭮﮉﭝﭸﮕﭡﭶﭪﭼﭟﮇﭜﮋﮐﮒﭯﮚﭯﮜﮇﭭﮔﮐﮠﭦﮟﮑﭤﮅﮍﮖﭵﭘﭓﮟﮍﭦﭟﭰﭪﮎﮅﭛﮍﮒ");
    }

}
