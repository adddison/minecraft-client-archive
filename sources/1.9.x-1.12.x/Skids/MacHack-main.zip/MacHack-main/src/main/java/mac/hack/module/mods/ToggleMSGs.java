package mac.hack.module.mods;

import mac.hack.module.Category;
import mac.hack.module.Module;

public class ToggleMSGs extends Module{

    public ToggleMSGs()
    {
        super("ToggleMSGs", KEY_UNBOUND, Category.CHAT, "Messages in chat when you turn on/off a module");
    }
}