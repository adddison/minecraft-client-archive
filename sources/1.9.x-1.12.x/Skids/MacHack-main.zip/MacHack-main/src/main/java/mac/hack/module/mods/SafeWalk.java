package mac.hack.module.mods;

import mac.hack.module.Category;
import mac.hack.module.Module;

public class SafeWalk extends Module {

	public SafeWalk() {
		super("SafeWalk", KEY_UNBOUND, Category.MOVEMENT, "Stops you walking off blocks");
	}
}
