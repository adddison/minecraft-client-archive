package me.han.muffin.client.event.events.gui

import me.han.muffin.client.event.EventCancellable

class RenderGuiBackgroundEvent: EventCancellable()