package me.han.muffin.client.event.events.entity

import net.minecraft.entity.Entity

data class TotemPopEvent(
    val entity: Entity
)