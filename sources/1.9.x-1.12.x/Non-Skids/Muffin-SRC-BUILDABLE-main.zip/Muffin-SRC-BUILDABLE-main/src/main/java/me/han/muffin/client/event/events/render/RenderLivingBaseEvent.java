package me.han.muffin.client.event.events.render;
/*
public class RenderLivingBaseEvent {
    private float prevRenderYawOffset;
    private float renderYawOffset;
    private float prevRotationYawHead;
    private float rotationYawHead;
    private float prevRotationPitch;
    private float rotationPitch;

    private float cachedPrevRenderYawOffset;
    private float cachedRenderYawOffset;
    private float cachedPrevRotationYawHead;
    private float cachedRotationYawHead;
    private float cachedPrevRotationPitch;
    private float cachedRotationPitch;

    public RenderLivingBaseEvent(float prevRenderYawOffset, float renderYawOffset, float prevRotationYawHead, float rotationYawHead, float prevRotationPitch, float rotationPitch) {
        this.prevRenderYawOffset = this.cachedPrevRenderYawOffset = prevRenderYawOffset;
        0.f$B = 0.f$b = f;
        kg.f$a = kg.f$j = f2;
        kg2.f$C = kg2.f$i = f3;
        kg3.f$e = kg3.f$M = f4;
        kg4.f$I = kg4.f$g = f5;
        kg5.f$K = kg5.f$d = f6;
    }


}
 */