package me.han.muffin.client.event.events.render

import me.han.muffin.client.event.EventStageable

data class RenderCrystalSizeEvent(val stage: EventStageable.EventStage)