package me.han.muffin.client.event.events.network

import me.han.muffin.client.event.EventCancellable

class OversizedProtocolEvent: EventCancellable()