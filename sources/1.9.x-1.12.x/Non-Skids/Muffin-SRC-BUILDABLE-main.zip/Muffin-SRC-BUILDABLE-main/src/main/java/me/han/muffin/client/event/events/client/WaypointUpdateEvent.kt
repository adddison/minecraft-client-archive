package me.han.muffin.client.event.events.client
/*
class WaypointUpdateEvent(val type: Type, val waypoint: WaypointManager.Waypoint?) {
    enum class Type {
        GET, ADD, REMOVE, CLEAR, RELOAD
    }
}
 */