package me.han.muffin.client.event.events.world

import me.han.muffin.client.event.EventCancellable

class OnItemPlaceEvent: EventCancellable()