package me.han.muffin.client.imixin.gui

import net.minecraft.util.text.ITextComponent

interface IGuiGameOver {

    val causeOfDeath: ITextComponent

}