package me.han.muffin.client.event.events.entity.living

import net.minecraft.entity.EntityLivingBase

data class EntityUseItemFinishEvent(val entity: EntityLivingBase)