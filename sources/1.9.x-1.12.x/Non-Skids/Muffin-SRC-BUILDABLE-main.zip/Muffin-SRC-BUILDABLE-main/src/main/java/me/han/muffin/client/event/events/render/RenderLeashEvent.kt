package me.han.muffin.client.event.events.render

import me.han.muffin.client.event.EventCancellable

class RenderLeashEvent: EventCancellable()