package me.han.muffin.client.commons.interfaces

interface DisplayEnum {
    val displayName: String
}