package me.han.muffin.client.event.events.entity.player

import net.minecraft.entity.player.EntityPlayer

class PlayerDeathEvent(val player: EntityPlayer)