package me.han.muffin.client.mixin.mixins.gui;

import net.minecraft.client.gui.inventory.GuiContainerCreative;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value = GuiContainerCreative.class)
public class MixinGuiContainerCreative {
}