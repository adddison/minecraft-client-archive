package me.han.muffin.client.imixin.render

interface IRenderManager {

    val renderPosX: Double
    val renderPosY: Double
    val renderPosZ: Double

}