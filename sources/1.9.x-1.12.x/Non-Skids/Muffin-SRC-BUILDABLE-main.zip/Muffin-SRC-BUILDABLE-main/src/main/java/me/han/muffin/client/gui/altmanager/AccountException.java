package me.han.muffin.client.gui.altmanager;

public class AccountException extends Exception {
    public AccountException(String message) {
        super(message);
    }
}