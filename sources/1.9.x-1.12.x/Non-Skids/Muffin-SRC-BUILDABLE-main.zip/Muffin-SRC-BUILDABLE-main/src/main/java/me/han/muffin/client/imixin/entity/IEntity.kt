package me.han.muffin.client.imixin.entity

interface IEntity {
    var isIsInWeb: Boolean
}