package me.han.muffin.client.event.events.render.entity

import me.han.muffin.client.event.EventCancellable

class RenderPlayerTagsEvent: EventCancellable()