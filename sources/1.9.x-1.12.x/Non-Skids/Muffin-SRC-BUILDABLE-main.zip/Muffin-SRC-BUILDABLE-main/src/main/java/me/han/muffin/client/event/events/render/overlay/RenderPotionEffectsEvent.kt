package me.han.muffin.client.event.events.render.overlay

import me.han.muffin.client.event.EventCancellable

class RenderPotionEffectsEvent: EventCancellable()