package me.han.muffin.client.event.events.client

data class KeyPressedEvent(val key: Int)