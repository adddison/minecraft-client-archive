package me.han.muffin.client.imixin.netty.packet.server

interface ISPacketExplosion {

    fun setMotionX(motionX: Float)
    fun setMotionY(motionY: Float)
    fun setMotionZ(motionZ: Float)

}