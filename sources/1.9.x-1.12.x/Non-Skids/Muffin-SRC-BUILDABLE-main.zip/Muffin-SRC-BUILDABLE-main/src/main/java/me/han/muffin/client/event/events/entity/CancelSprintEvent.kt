package me.han.muffin.client.event.events.entity

class CancelSprintEvent(var shouldCancel: Boolean) {}