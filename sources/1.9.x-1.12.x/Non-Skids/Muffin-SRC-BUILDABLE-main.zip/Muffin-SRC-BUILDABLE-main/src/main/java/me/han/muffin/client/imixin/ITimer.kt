package me.han.muffin.client.imixin

interface ITimer {

    var tickLength: Float
    val lastSyncSysClock: Long

}