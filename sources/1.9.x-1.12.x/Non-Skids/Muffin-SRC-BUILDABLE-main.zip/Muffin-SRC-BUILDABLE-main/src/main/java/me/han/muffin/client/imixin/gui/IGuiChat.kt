package me.han.muffin.client.imixin.gui

interface IGuiChat {

    var historyBuffer: String

    var sentHistoryCursor: Int

}