package me.han.muffin.client.event.events.render.item

import me.han.muffin.client.event.EventStageable

class RenderItemEvent(val stage: EventStageable.EventStage)