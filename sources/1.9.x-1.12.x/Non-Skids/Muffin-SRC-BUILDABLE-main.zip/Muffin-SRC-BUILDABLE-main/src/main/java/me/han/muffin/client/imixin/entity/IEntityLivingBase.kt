package me.han.muffin.client.imixin.entity

interface IEntityLivingBase {
    val isElytraFlying: Boolean
}