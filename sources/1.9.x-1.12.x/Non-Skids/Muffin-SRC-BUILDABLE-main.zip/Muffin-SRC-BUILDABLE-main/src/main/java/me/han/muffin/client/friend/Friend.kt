package me.han.muffin.client.friend

data class Friend(val name: String, val alias: String)