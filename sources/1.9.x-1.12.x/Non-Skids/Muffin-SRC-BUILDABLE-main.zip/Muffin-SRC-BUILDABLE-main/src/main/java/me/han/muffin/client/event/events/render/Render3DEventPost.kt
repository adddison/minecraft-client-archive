package me.han.muffin.client.event.events.render

data class Render3DEventPost(
    var partialTicks: Float
)