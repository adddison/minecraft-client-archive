package me.han.muffin.client.imixin

interface IItemStack {
    var stackSize: Int
}