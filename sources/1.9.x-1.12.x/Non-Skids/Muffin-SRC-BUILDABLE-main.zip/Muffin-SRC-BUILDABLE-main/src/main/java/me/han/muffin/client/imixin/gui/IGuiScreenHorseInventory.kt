package me.han.muffin.client.imixin.gui

import net.minecraft.inventory.IInventory

interface IGuiScreenHorseInventory {

    val horseInventory: IInventory

}