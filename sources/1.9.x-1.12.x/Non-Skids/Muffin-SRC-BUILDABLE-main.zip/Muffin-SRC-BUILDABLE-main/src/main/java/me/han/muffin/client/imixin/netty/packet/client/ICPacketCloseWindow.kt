package me.han.muffin.client.imixin.netty.packet.client

interface ICPacketCloseWindow {
    var windowId: Int
}