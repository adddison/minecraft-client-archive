# Muffin-SRC-BUILDABLE
Src for muffin client.

Modifications:
Fully removed the hwid system,
Changed the main menu shader option to be off by default (it can cause crashes on some clients)


There seems to be some other bugs in the client that I will fix later.


Credit to [AzGOD-qwq](https://github.com/AzGOD-qwq) for the leak
