/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.physics.bullet.BulletBase;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;

public class DISTANCE_PLANE_3D_FUNC
extends BulletBase {
    private long swigCPtr;

    protected DISTANCE_PLANE_3D_FUNC(String className, long cPtr, boolean cMemoryOwn) {
        super(className, cPtr, cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public DISTANCE_PLANE_3D_FUNC(long cPtr, boolean cMemoryOwn) {
        this("DISTANCE_PLANE_3D_FUNC", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(this.swigCPtr, cMemoryOwn);
    }

    public static long getCPtr(DISTANCE_PLANE_3D_FUNC obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_DISTANCE_PLANE_3D_FUNC(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public DISTANCE_PLANE_3D_FUNC() {
        this(CollisionJNI.new_DISTANCE_PLANE_3D_FUNC(), true);
    }
}

