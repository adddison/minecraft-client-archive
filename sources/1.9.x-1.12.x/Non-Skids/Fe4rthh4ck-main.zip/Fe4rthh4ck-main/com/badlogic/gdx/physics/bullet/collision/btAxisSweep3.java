/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.btAxisSweep3InternalShort;
import com.badlogic.gdx.physics.bullet.collision.btOverlappingPairCache;

public class btAxisSweep3
extends btAxisSweep3InternalShort {
    private long swigCPtr;

    protected btAxisSweep3(String className, long cPtr, boolean cMemoryOwn) {
        super(className, CollisionJNI.btAxisSweep3_SWIGUpcast(cPtr), cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public btAxisSweep3(long cPtr, boolean cMemoryOwn) {
        this("btAxisSweep3", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(CollisionJNI.btAxisSweep3_SWIGUpcast(this.swigCPtr), cMemoryOwn);
    }

    public static long getCPtr(btAxisSweep3 obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_btAxisSweep3(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public btAxisSweep3(Vector3 worldAabbMin, Vector3 worldAabbMax, int maxHandles, btOverlappingPairCache pairCache, boolean disableRaycastAccelerator) {
        this(CollisionJNI.new_btAxisSweep3__SWIG_0(worldAabbMin, worldAabbMax, maxHandles, btOverlappingPairCache.getCPtr(pairCache), pairCache, disableRaycastAccelerator), true);
    }

    public btAxisSweep3(Vector3 worldAabbMin, Vector3 worldAabbMax, int maxHandles, btOverlappingPairCache pairCache) {
        this(CollisionJNI.new_btAxisSweep3__SWIG_1(worldAabbMin, worldAabbMax, maxHandles, btOverlappingPairCache.getCPtr(pairCache), pairCache), true);
    }

    public btAxisSweep3(Vector3 worldAabbMin, Vector3 worldAabbMax, int maxHandles) {
        this(CollisionJNI.new_btAxisSweep3__SWIG_2(worldAabbMin, worldAabbMax, maxHandles), true);
    }

    public btAxisSweep3(Vector3 worldAabbMin, Vector3 worldAabbMax) {
        this(CollisionJNI.new_btAxisSweep3__SWIG_3(worldAabbMin, worldAabbMax), true);
    }
}

