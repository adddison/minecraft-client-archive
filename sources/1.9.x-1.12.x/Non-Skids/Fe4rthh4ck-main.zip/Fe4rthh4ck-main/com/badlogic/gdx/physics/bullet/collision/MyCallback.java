/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.btTriangleRaycastCallback;

public class MyCallback
extends btTriangleRaycastCallback {
    private long swigCPtr;

    protected MyCallback(String className, long cPtr, boolean cMemoryOwn) {
        super(className, CollisionJNI.MyCallback_SWIGUpcast(cPtr), cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public MyCallback(long cPtr, boolean cMemoryOwn) {
        this("MyCallback", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(CollisionJNI.MyCallback_SWIGUpcast(this.swigCPtr), cMemoryOwn);
    }

    public static long getCPtr(MyCallback obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_MyCallback(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public void setIgnorePart(int value) {
        CollisionJNI.MyCallback_ignorePart_set(this.swigCPtr, this, value);
    }

    public int getIgnorePart() {
        return CollisionJNI.MyCallback_ignorePart_get(this.swigCPtr, this);
    }

    public void setIgnoreTriangleIndex(int value) {
        CollisionJNI.MyCallback_ignoreTriangleIndex_set(this.swigCPtr, this, value);
    }

    public int getIgnoreTriangleIndex() {
        return CollisionJNI.MyCallback_ignoreTriangleIndex_get(this.swigCPtr, this);
    }

    public MyCallback(Vector3 from, Vector3 to, int ignorePart, int ignoreTriangleIndex) {
        this(CollisionJNI.new_MyCallback(from, to, ignorePart, ignoreTriangleIndex), true);
    }
}

