/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.net;

import com.badlogic.gdx.Net;
import com.badlogic.gdx.net.Socket;
import com.badlogic.gdx.net.SocketHints;
import com.badlogic.gdx.utils.Disposable;

public interface ServerSocket
extends Disposable {
    public Net.Protocol getProtocol();

    public Socket accept(SocketHints var1);
}

