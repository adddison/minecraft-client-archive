/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.btActivatingCollisionAlgorithm;
import com.badlogic.gdx.physics.bullet.collision.btCollisionAlgorithmConstructionInfo;
import com.badlogic.gdx.physics.bullet.collision.btCollisionAlgorithmCreateFunc;
import com.badlogic.gdx.physics.bullet.collision.btCollisionObjectWrapper;
import com.badlogic.gdx.physics.bullet.collision.btPersistentManifold;

public class btBoxBoxCollisionAlgorithm
extends btActivatingCollisionAlgorithm {
    private long swigCPtr;

    protected btBoxBoxCollisionAlgorithm(String className, long cPtr, boolean cMemoryOwn) {
        super(className, CollisionJNI.btBoxBoxCollisionAlgorithm_SWIGUpcast(cPtr), cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public btBoxBoxCollisionAlgorithm(long cPtr, boolean cMemoryOwn) {
        this("btBoxBoxCollisionAlgorithm", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(CollisionJNI.btBoxBoxCollisionAlgorithm_SWIGUpcast(this.swigCPtr), cMemoryOwn);
    }

    public static long getCPtr(btBoxBoxCollisionAlgorithm obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_btBoxBoxCollisionAlgorithm(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public btBoxBoxCollisionAlgorithm(btCollisionAlgorithmConstructionInfo ci) {
        this(CollisionJNI.new_btBoxBoxCollisionAlgorithm__SWIG_0(btCollisionAlgorithmConstructionInfo.getCPtr(ci), ci), true);
    }

    public btBoxBoxCollisionAlgorithm(btPersistentManifold mf, btCollisionAlgorithmConstructionInfo ci, btCollisionObjectWrapper body0Wrap, btCollisionObjectWrapper body1Wrap) {
        this(CollisionJNI.new_btBoxBoxCollisionAlgorithm__SWIG_1(btPersistentManifold.getCPtr(mf), mf, btCollisionAlgorithmConstructionInfo.getCPtr(ci), ci, btCollisionObjectWrapper.getCPtr(body0Wrap), body0Wrap, btCollisionObjectWrapper.getCPtr(body1Wrap), body1Wrap), true);
    }

    public static class CreateFunc
    extends btCollisionAlgorithmCreateFunc {
        private long swigCPtr;

        protected CreateFunc(String className, long cPtr, boolean cMemoryOwn) {
            super(className, CollisionJNI.btBoxBoxCollisionAlgorithm_CreateFunc_SWIGUpcast(cPtr), cMemoryOwn);
            this.swigCPtr = cPtr;
        }

        public CreateFunc(long cPtr, boolean cMemoryOwn) {
            this("CreateFunc", cPtr, cMemoryOwn);
            this.construct();
        }

        @Override
        protected void reset(long cPtr, boolean cMemoryOwn) {
            if (!this.destroyed) {
                this.destroy();
            }
            this.swigCPtr = cPtr;
            super.reset(CollisionJNI.btBoxBoxCollisionAlgorithm_CreateFunc_SWIGUpcast(this.swigCPtr), cMemoryOwn);
        }

        public static long getCPtr(CreateFunc obj) {
            return obj == null ? 0L : obj.swigCPtr;
        }

        @Override
        protected void finalize() throws Throwable {
            if (!this.destroyed) {
                this.destroy();
            }
            super.finalize();
        }

        @Override
        protected synchronized void delete() {
            if (this.swigCPtr != 0L) {
                if (this.swigCMemOwn) {
                    this.swigCMemOwn = false;
                    CollisionJNI.delete_btBoxBoxCollisionAlgorithm_CreateFunc(this.swigCPtr);
                }
                this.swigCPtr = 0L;
            }
            super.delete();
        }

        public CreateFunc() {
            this(CollisionJNI.new_btBoxBoxCollisionAlgorithm_CreateFunc(), true);
        }
    }
}

