/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.btGimQuantizedBvhNodeArray;

public class GIM_QUANTIZED_BVH_NODE_ARRAY
extends btGimQuantizedBvhNodeArray {
    private long swigCPtr;

    protected GIM_QUANTIZED_BVH_NODE_ARRAY(String className, long cPtr, boolean cMemoryOwn) {
        super(className, CollisionJNI.GIM_QUANTIZED_BVH_NODE_ARRAY_SWIGUpcast(cPtr), cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public GIM_QUANTIZED_BVH_NODE_ARRAY(long cPtr, boolean cMemoryOwn) {
        this("GIM_QUANTIZED_BVH_NODE_ARRAY", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(CollisionJNI.GIM_QUANTIZED_BVH_NODE_ARRAY_SWIGUpcast(this.swigCPtr), cMemoryOwn);
    }

    public static long getCPtr(GIM_QUANTIZED_BVH_NODE_ARRAY obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_GIM_QUANTIZED_BVH_NODE_ARRAY(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public GIM_QUANTIZED_BVH_NODE_ARRAY() {
        this(CollisionJNI.new_GIM_QUANTIZED_BVH_NODE_ARRAY(), true);
    }
}

