/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.bullet.collision.ClosestConvexResultCallback;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.btBroadphaseProxy;
import com.badlogic.gdx.physics.bullet.collision.btCollisionObject;

public class ClosestNotMeConvexResultCallback
extends ClosestConvexResultCallback {
    private long swigCPtr;

    protected ClosestNotMeConvexResultCallback(String className, long cPtr, boolean cMemoryOwn) {
        super(className, CollisionJNI.ClosestNotMeConvexResultCallback_SWIGUpcast(cPtr), cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public ClosestNotMeConvexResultCallback(long cPtr, boolean cMemoryOwn) {
        this("ClosestNotMeConvexResultCallback", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(CollisionJNI.ClosestNotMeConvexResultCallback_SWIGUpcast(this.swigCPtr), cMemoryOwn);
    }

    public static long getCPtr(ClosestNotMeConvexResultCallback obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_ClosestNotMeConvexResultCallback(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public void setMe(btCollisionObject value) {
        CollisionJNI.ClosestNotMeConvexResultCallback_me_set(this.swigCPtr, this, btCollisionObject.getCPtr(value), value);
    }

    public btCollisionObject getMe() {
        return btCollisionObject.getInstance(CollisionJNI.ClosestNotMeConvexResultCallback_me_get(this.swigCPtr, this), false);
    }

    public void setAllowedPenetration(float value) {
        CollisionJNI.ClosestNotMeConvexResultCallback_allowedPenetration_set(this.swigCPtr, this, value);
    }

    public float getAllowedPenetration() {
        return CollisionJNI.ClosestNotMeConvexResultCallback_allowedPenetration_get(this.swigCPtr, this);
    }

    public ClosestNotMeConvexResultCallback(btCollisionObject me, Vector3 fromA, Vector3 toA) {
        this(CollisionJNI.new_ClosestNotMeConvexResultCallback(btCollisionObject.getCPtr(me), me, fromA, toA), true);
    }

    @Override
    public boolean needsCollision(btBroadphaseProxy proxy0) {
        return CollisionJNI.ClosestNotMeConvexResultCallback_needsCollision(this.swigCPtr, this, btBroadphaseProxy.getCPtr(proxy0), proxy0);
    }
}

