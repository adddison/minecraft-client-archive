/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.btCompoundShape;
import com.badlogic.gdx.physics.bullet.collision.btGImpactMeshShape;
import com.badlogic.gdx.physics.bullet.collision.btInternalTriangleIndexCallback;

public class MyInternalTriangleIndexCallback
extends btInternalTriangleIndexCallback {
    private long swigCPtr;

    protected MyInternalTriangleIndexCallback(String className, long cPtr, boolean cMemoryOwn) {
        super(className, CollisionJNI.MyInternalTriangleIndexCallback_SWIGUpcast(cPtr), cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public MyInternalTriangleIndexCallback(long cPtr, boolean cMemoryOwn) {
        this("MyInternalTriangleIndexCallback", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(CollisionJNI.MyInternalTriangleIndexCallback_SWIGUpcast(this.swigCPtr), cMemoryOwn);
    }

    public static long getCPtr(MyInternalTriangleIndexCallback obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_MyInternalTriangleIndexCallback(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public void setGimpactShape(btGImpactMeshShape value) {
        CollisionJNI.MyInternalTriangleIndexCallback_gimpactShape_set(this.swigCPtr, this, btGImpactMeshShape.getCPtr(value), value);
    }

    public btGImpactMeshShape getGimpactShape() {
        long cPtr = CollisionJNI.MyInternalTriangleIndexCallback_gimpactShape_get(this.swigCPtr, this);
        return cPtr == 0L ? null : new btGImpactMeshShape(cPtr, false);
    }

    public void setColShape(btCompoundShape value) {
        CollisionJNI.MyInternalTriangleIndexCallback_colShape_set(this.swigCPtr, this, btCompoundShape.getCPtr(value), value);
    }

    public btCompoundShape getColShape() {
        long cPtr = CollisionJNI.MyInternalTriangleIndexCallback_colShape_get(this.swigCPtr, this);
        return cPtr == 0L ? null : new btCompoundShape(cPtr, false);
    }

    public void setDepth(float value) {
        CollisionJNI.MyInternalTriangleIndexCallback_depth_set(this.swigCPtr, this, value);
    }

    public float getDepth() {
        return CollisionJNI.MyInternalTriangleIndexCallback_depth_get(this.swigCPtr, this);
    }

    public MyInternalTriangleIndexCallback(btCompoundShape colShape, btGImpactMeshShape meshShape, float depth) {
        this(CollisionJNI.new_MyInternalTriangleIndexCallback(btCompoundShape.getCPtr(colShape), colShape, btGImpactMeshShape.getCPtr(meshShape), meshShape, depth), true);
    }
}

