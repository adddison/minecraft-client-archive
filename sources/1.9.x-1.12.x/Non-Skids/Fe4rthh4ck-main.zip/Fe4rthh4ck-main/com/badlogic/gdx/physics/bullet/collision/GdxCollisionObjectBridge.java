/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.physics.bullet.BulletBase;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;

public class GdxCollisionObjectBridge
extends BulletBase {
    private long swigCPtr;

    protected GdxCollisionObjectBridge(String className, long cPtr, boolean cMemoryOwn) {
        super(className, cPtr, cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public GdxCollisionObjectBridge(long cPtr, boolean cMemoryOwn) {
        this("GdxCollisionObjectBridge", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(this.swigCPtr, cMemoryOwn);
    }

    public static long getCPtr(GdxCollisionObjectBridge obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_GdxCollisionObjectBridge(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public void setUserValue(int value) {
        CollisionJNI.GdxCollisionObjectBridge_userValue_set(this.swigCPtr, this, value);
    }

    public int getUserValue() {
        return CollisionJNI.GdxCollisionObjectBridge_userValue_get(this.swigCPtr, this);
    }

    public void setContactCallbackFlag(int value) {
        CollisionJNI.GdxCollisionObjectBridge_contactCallbackFlag_set(this.swigCPtr, this, value);
    }

    public int getContactCallbackFlag() {
        return CollisionJNI.GdxCollisionObjectBridge_contactCallbackFlag_get(this.swigCPtr, this);
    }

    public void setContactCallbackFilter(int value) {
        CollisionJNI.GdxCollisionObjectBridge_contactCallbackFilter_set(this.swigCPtr, this, value);
    }

    public int getContactCallbackFilter() {
        return CollisionJNI.GdxCollisionObjectBridge_contactCallbackFilter_get(this.swigCPtr, this);
    }

    public GdxCollisionObjectBridge() {
        this(CollisionJNI.new_GdxCollisionObjectBridge(), true);
    }
}

