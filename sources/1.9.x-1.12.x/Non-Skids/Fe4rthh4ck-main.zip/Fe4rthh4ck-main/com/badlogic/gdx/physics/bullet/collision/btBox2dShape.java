/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.btPolyhedralConvexShape;
import com.badlogic.gdx.physics.bullet.linearmath.btVector3;
import com.badlogic.gdx.physics.bullet.linearmath.btVector4;

public class btBox2dShape
extends btPolyhedralConvexShape {
    private long swigCPtr;

    protected btBox2dShape(String className, long cPtr, boolean cMemoryOwn) {
        super(className, CollisionJNI.btBox2dShape_SWIGUpcast(cPtr), cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public btBox2dShape(long cPtr, boolean cMemoryOwn) {
        this("btBox2dShape", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(CollisionJNI.btBox2dShape_SWIGUpcast(this.swigCPtr), cMemoryOwn);
    }

    public static long getCPtr(btBox2dShape obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_btBox2dShape(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    @Override
    public long operatorNew(long sizeInBytes) {
        return CollisionJNI.btBox2dShape_operatorNew__SWIG_0(this.swigCPtr, this, sizeInBytes);
    }

    @Override
    public void operatorDelete(long ptr) {
        CollisionJNI.btBox2dShape_operatorDelete__SWIG_0(this.swigCPtr, this, ptr);
    }

    @Override
    public long operatorNew(long arg0, long ptr) {
        return CollisionJNI.btBox2dShape_operatorNew__SWIG_1(this.swigCPtr, this, arg0, ptr);
    }

    @Override
    public void operatorDelete(long arg0, long arg1) {
        CollisionJNI.btBox2dShape_operatorDelete__SWIG_1(this.swigCPtr, this, arg0, arg1);
    }

    @Override
    public long operatorNewArray(long sizeInBytes) {
        return CollisionJNI.btBox2dShape_operatorNewArray__SWIG_0(this.swigCPtr, this, sizeInBytes);
    }

    @Override
    public void operatorDeleteArray(long ptr) {
        CollisionJNI.btBox2dShape_operatorDeleteArray__SWIG_0(this.swigCPtr, this, ptr);
    }

    @Override
    public long operatorNewArray(long arg0, long ptr) {
        return CollisionJNI.btBox2dShape_operatorNewArray__SWIG_1(this.swigCPtr, this, arg0, ptr);
    }

    @Override
    public void operatorDeleteArray(long arg0, long arg1) {
        CollisionJNI.btBox2dShape_operatorDeleteArray__SWIG_1(this.swigCPtr, this, arg0, arg1);
    }

    public Vector3 getHalfExtentsWithMargin() {
        return CollisionJNI.btBox2dShape_getHalfExtentsWithMargin(this.swigCPtr, this);
    }

    public Vector3 getHalfExtentsWithoutMargin() {
        return CollisionJNI.btBox2dShape_getHalfExtentsWithoutMargin(this.swigCPtr, this);
    }

    public btBox2dShape(Vector3 boxHalfExtents) {
        this(CollisionJNI.new_btBox2dShape(boxHalfExtents), true);
    }

    public int getVertexCount() {
        return CollisionJNI.btBox2dShape_getVertexCount(this.swigCPtr, this);
    }

    public btVector3 getVertices() {
        long cPtr = CollisionJNI.btBox2dShape_getVertices(this.swigCPtr, this);
        return cPtr == 0L ? null : new btVector3(cPtr, false);
    }

    public btVector3 getNormals() {
        long cPtr = CollisionJNI.btBox2dShape_getNormals(this.swigCPtr, this);
        return cPtr == 0L ? null : new btVector3(cPtr, false);
    }

    public Vector3 getCentroid() {
        return CollisionJNI.btBox2dShape_getCentroid(this.swigCPtr, this);
    }

    public void getPlaneEquation(btVector4 plane, int i) {
        CollisionJNI.btBox2dShape_getPlaneEquation(this.swigCPtr, this, btVector4.getCPtr(plane), plane, i);
    }
}

