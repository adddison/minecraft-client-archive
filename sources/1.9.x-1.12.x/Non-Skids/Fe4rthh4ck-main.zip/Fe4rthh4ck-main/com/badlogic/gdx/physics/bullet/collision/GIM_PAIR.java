/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.physics.bullet.BulletBase;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;

public class GIM_PAIR
extends BulletBase {
    private long swigCPtr;

    protected GIM_PAIR(String className, long cPtr, boolean cMemoryOwn) {
        super(className, cPtr, cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public GIM_PAIR(long cPtr, boolean cMemoryOwn) {
        this("GIM_PAIR", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(this.swigCPtr, cMemoryOwn);
    }

    public static long getCPtr(GIM_PAIR obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_GIM_PAIR(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public void setIndex1(int value) {
        CollisionJNI.GIM_PAIR_index1_set(this.swigCPtr, this, value);
    }

    public int getIndex1() {
        return CollisionJNI.GIM_PAIR_index1_get(this.swigCPtr, this);
    }

    public void setIndex2(int value) {
        CollisionJNI.GIM_PAIR_index2_set(this.swigCPtr, this, value);
    }

    public int getIndex2() {
        return CollisionJNI.GIM_PAIR_index2_get(this.swigCPtr, this);
    }

    public GIM_PAIR() {
        this(CollisionJNI.new_GIM_PAIR__SWIG_0(), true);
    }

    public GIM_PAIR(GIM_PAIR p) {
        this(CollisionJNI.new_GIM_PAIR__SWIG_1(GIM_PAIR.getCPtr(p), p), true);
    }

    public GIM_PAIR(int index1, int index2) {
        this(CollisionJNI.new_GIM_PAIR__SWIG_2(index1, index2), true);
    }
}

