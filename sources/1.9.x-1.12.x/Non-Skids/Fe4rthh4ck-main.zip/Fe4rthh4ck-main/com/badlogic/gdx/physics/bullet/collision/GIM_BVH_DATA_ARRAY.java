/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.btGimBvhDataArray;

public class GIM_BVH_DATA_ARRAY
extends btGimBvhDataArray {
    private long swigCPtr;

    protected GIM_BVH_DATA_ARRAY(String className, long cPtr, boolean cMemoryOwn) {
        super(className, CollisionJNI.GIM_BVH_DATA_ARRAY_SWIGUpcast(cPtr), cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public GIM_BVH_DATA_ARRAY(long cPtr, boolean cMemoryOwn) {
        this("GIM_BVH_DATA_ARRAY", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(CollisionJNI.GIM_BVH_DATA_ARRAY_SWIGUpcast(this.swigCPtr), cMemoryOwn);
    }

    public static long getCPtr(GIM_BVH_DATA_ARRAY obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_GIM_BVH_DATA_ARRAY(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public GIM_BVH_DATA_ARRAY() {
        this(CollisionJNI.new_GIM_BVH_DATA_ARRAY(), true);
    }
}

