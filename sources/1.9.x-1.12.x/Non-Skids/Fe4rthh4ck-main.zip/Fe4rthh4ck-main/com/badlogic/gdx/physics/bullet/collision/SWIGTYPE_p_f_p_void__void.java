/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

public class SWIGTYPE_p_f_p_void__void {
    private transient long swigCPtr;

    protected SWIGTYPE_p_f_p_void__void(long cPtr, boolean futureUse) {
        this.swigCPtr = cPtr;
    }

    protected SWIGTYPE_p_f_p_void__void() {
        this.swigCPtr = 0L;
    }

    protected static long getCPtr(SWIGTYPE_p_f_p_void__void obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }
}

