/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.bullet.BulletBase;
import com.badlogic.gdx.physics.bullet.collision.BT_BOX_BOX_TRANSFORM_CACHE;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.SWIGTYPE_p_float;
import com.badlogic.gdx.physics.bullet.linearmath.btVector3;
import com.badlogic.gdx.physics.bullet.linearmath.btVector4;

public class btAABB
extends BulletBase {
    private long swigCPtr;

    protected btAABB(String className, long cPtr, boolean cMemoryOwn) {
        super(className, cPtr, cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public btAABB(long cPtr, boolean cMemoryOwn) {
        this("btAABB", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(this.swigCPtr, cMemoryOwn);
    }

    public static long getCPtr(btAABB obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_btAABB(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public void setMin(btVector3 value) {
        CollisionJNI.btAABB_min_set(this.swigCPtr, this, btVector3.getCPtr(value), value);
    }

    public btVector3 getMin() {
        long cPtr = CollisionJNI.btAABB_min_get(this.swigCPtr, this);
        return cPtr == 0L ? null : new btVector3(cPtr, false);
    }

    public void setMax(btVector3 value) {
        CollisionJNI.btAABB_max_set(this.swigCPtr, this, btVector3.getCPtr(value), value);
    }

    public btVector3 getMax() {
        long cPtr = CollisionJNI.btAABB_max_get(this.swigCPtr, this);
        return cPtr == 0L ? null : new btVector3(cPtr, false);
    }

    public btAABB() {
        this(CollisionJNI.new_btAABB__SWIG_0(), true);
    }

    public btAABB(Vector3 V1, Vector3 V2, Vector3 V3) {
        this(CollisionJNI.new_btAABB__SWIG_1(V1, V2, V3), true);
    }

    public btAABB(Vector3 V1, Vector3 V2, Vector3 V3, float margin) {
        this(CollisionJNI.new_btAABB__SWIG_2(V1, V2, V3, margin), true);
    }

    public btAABB(btAABB other) {
        this(CollisionJNI.new_btAABB__SWIG_3(btAABB.getCPtr(other), other), true);
    }

    public btAABB(btAABB other, float margin) {
        this(CollisionJNI.new_btAABB__SWIG_4(btAABB.getCPtr(other), other, margin), true);
    }

    public void invalidate() {
        CollisionJNI.btAABB_invalidate(this.swigCPtr, this);
    }

    public void increment_margin(float margin) {
        CollisionJNI.btAABB_increment_margin(this.swigCPtr, this, margin);
    }

    public void copy_with_margin(btAABB other, float margin) {
        CollisionJNI.btAABB_copy_with_margin(this.swigCPtr, this, btAABB.getCPtr(other), other, margin);
    }

    public void appy_transform(Matrix4 trans) {
        CollisionJNI.btAABB_appy_transform(this.swigCPtr, this, trans);
    }

    public void appy_transform_trans_cache(BT_BOX_BOX_TRANSFORM_CACHE trans) {
        CollisionJNI.btAABB_appy_transform_trans_cache(this.swigCPtr, this, BT_BOX_BOX_TRANSFORM_CACHE.getCPtr(trans), trans);
    }

    public void merge(btAABB box) {
        CollisionJNI.btAABB_merge(this.swigCPtr, this, btAABB.getCPtr(box), box);
    }

    public void get_center_extend(Vector3 center, Vector3 extend) {
        CollisionJNI.btAABB_get_center_extend(this.swigCPtr, this, center, extend);
    }

    public void find_intersection(btAABB other, btAABB intersection) {
        CollisionJNI.btAABB_find_intersection(this.swigCPtr, this, btAABB.getCPtr(other), other, btAABB.getCPtr(intersection), intersection);
    }

    public boolean has_collision(btAABB other) {
        return CollisionJNI.btAABB_has_collision(this.swigCPtr, this, btAABB.getCPtr(other), other);
    }

    public boolean collide_ray(Vector3 vorigin, Vector3 vdir) {
        return CollisionJNI.btAABB_collide_ray(this.swigCPtr, this, vorigin, vdir);
    }

    public void projection_interval(Vector3 direction, SWIGTYPE_p_float vmin, SWIGTYPE_p_float vmax) {
        CollisionJNI.btAABB_projection_interval(this.swigCPtr, this, direction, SWIGTYPE_p_float.getCPtr(vmin), SWIGTYPE_p_float.getCPtr(vmax));
    }

    public int plane_classify(btVector4 plane) {
        return CollisionJNI.btAABB_plane_classify(this.swigCPtr, this, btVector4.getCPtr(plane), plane);
    }

    public boolean overlapping_trans_conservative(btAABB box, Matrix4 trans1_to_0) {
        return CollisionJNI.btAABB_overlapping_trans_conservative(this.swigCPtr, this, btAABB.getCPtr(box), box, trans1_to_0);
    }

    public boolean overlapping_trans_conservative2(btAABB box, BT_BOX_BOX_TRANSFORM_CACHE trans1_to_0) {
        return CollisionJNI.btAABB_overlapping_trans_conservative2(this.swigCPtr, this, btAABB.getCPtr(box), box, BT_BOX_BOX_TRANSFORM_CACHE.getCPtr(trans1_to_0), trans1_to_0);
    }

    public boolean overlapping_trans_cache(btAABB box, BT_BOX_BOX_TRANSFORM_CACHE transcache, boolean fulltest) {
        return CollisionJNI.btAABB_overlapping_trans_cache(this.swigCPtr, this, btAABB.getCPtr(box), box, BT_BOX_BOX_TRANSFORM_CACHE.getCPtr(transcache), transcache, fulltest);
    }

    public boolean collide_plane(btVector4 plane) {
        return CollisionJNI.btAABB_collide_plane(this.swigCPtr, this, btVector4.getCPtr(plane), plane);
    }

    public boolean collide_triangle_exact(Vector3 p1, Vector3 p2, Vector3 p3, btVector4 triangle_plane) {
        return CollisionJNI.btAABB_collide_triangle_exact(this.swigCPtr, this, p1, p2, p3, btVector4.getCPtr(triangle_plane), triangle_plane);
    }
}

