/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx;

public interface Screen {
    public void show();

    public void render(float var1);

    public void resize(int var1, int var2);

    public void pause();

    public void resume();

    public void hide();

    public void dispose();
}

