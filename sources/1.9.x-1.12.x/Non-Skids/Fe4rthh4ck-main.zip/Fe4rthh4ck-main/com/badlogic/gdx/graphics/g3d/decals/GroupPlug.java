/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.graphics.g3d.decals;

import com.badlogic.gdx.graphics.g3d.decals.Decal;
import com.badlogic.gdx.utils.Array;

public interface GroupPlug {
    public void beforeGroup(Array<Decal> var1);

    public void afterGroup();
}

