/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.physics.bullet.BulletBase;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.btBroadphaseProxy;
import com.badlogic.gdx.physics.bullet.collision.btCollisionObjectWrapper;
import com.badlogic.gdx.physics.bullet.collision.btManifoldPoint;

public class ContactResultCallback
extends BulletBase {
    private long swigCPtr;

    protected ContactResultCallback(String className, long cPtr, boolean cMemoryOwn) {
        super(className, cPtr, cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public ContactResultCallback(long cPtr, boolean cMemoryOwn) {
        this("ContactResultCallback", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(this.swigCPtr, cMemoryOwn);
    }

    public static long getCPtr(ContactResultCallback obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_ContactResultCallback(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    protected void swigDirectorDisconnect() {
        this.swigCMemOwn = false;
        this.delete();
    }

    public void swigReleaseOwnership() {
        this.swigCMemOwn = false;
        CollisionJNI.ContactResultCallback_change_ownership(this, this.swigCPtr, false);
    }

    public void swigTakeOwnership() {
        this.swigCMemOwn = true;
        CollisionJNI.ContactResultCallback_change_ownership(this, this.swigCPtr, true);
    }

    public void setCollisionFilterGroup(int value) {
        CollisionJNI.ContactResultCallback_collisionFilterGroup_set(this.swigCPtr, this, value);
    }

    public int getCollisionFilterGroup() {
        return CollisionJNI.ContactResultCallback_collisionFilterGroup_get(this.swigCPtr, this);
    }

    public void setCollisionFilterMask(int value) {
        CollisionJNI.ContactResultCallback_collisionFilterMask_set(this.swigCPtr, this, value);
    }

    public int getCollisionFilterMask() {
        return CollisionJNI.ContactResultCallback_collisionFilterMask_get(this.swigCPtr, this);
    }

    public void setClosestDistanceThreshold(float value) {
        CollisionJNI.ContactResultCallback_closestDistanceThreshold_set(this.swigCPtr, this, value);
    }

    public float getClosestDistanceThreshold() {
        return CollisionJNI.ContactResultCallback_closestDistanceThreshold_get(this.swigCPtr, this);
    }

    public ContactResultCallback() {
        this(CollisionJNI.new_ContactResultCallback(), true);
        CollisionJNI.ContactResultCallback_director_connect(this, this.swigCPtr, this.swigCMemOwn, true);
    }

    public boolean needsCollision(btBroadphaseProxy proxy0) {
        return this.getClass() == ContactResultCallback.class ? CollisionJNI.ContactResultCallback_needsCollision(this.swigCPtr, this, btBroadphaseProxy.getCPtr(proxy0), proxy0) : CollisionJNI.ContactResultCallback_needsCollisionSwigExplicitContactResultCallback(this.swigCPtr, this, btBroadphaseProxy.getCPtr(proxy0), proxy0);
    }

    public float addSingleResult(btManifoldPoint cp, btCollisionObjectWrapper colObj0Wrap, int partId0, int index0, btCollisionObjectWrapper colObj1Wrap, int partId1, int index1) {
        return CollisionJNI.ContactResultCallback_addSingleResult(this.swigCPtr, this, btManifoldPoint.getCPtr(cp), cp, btCollisionObjectWrapper.getCPtr(colObj0Wrap), colObj0Wrap, partId0, index0, btCollisionObjectWrapper.getCPtr(colObj1Wrap), colObj1Wrap, partId1, index1);
    }
}

