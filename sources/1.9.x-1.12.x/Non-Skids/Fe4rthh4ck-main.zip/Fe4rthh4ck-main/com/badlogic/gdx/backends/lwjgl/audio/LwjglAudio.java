/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.backends.lwjgl.audio;

import com.badlogic.gdx.Audio;
import com.badlogic.gdx.utils.Disposable;

public interface LwjglAudio
extends Audio,
Disposable {
    public void update();
}

