/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.graphics.g3d.model.data;

import com.badlogic.gdx.graphics.g3d.model.data.ModelNodeAnimation;
import com.badlogic.gdx.utils.Array;

public class ModelAnimation {
    public String id;
    public Array<ModelNodeAnimation> nodeAnimations = new Array();
}

