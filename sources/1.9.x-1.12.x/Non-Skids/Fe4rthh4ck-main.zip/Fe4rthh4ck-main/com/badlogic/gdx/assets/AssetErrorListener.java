/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.assets;

import com.badlogic.gdx.assets.AssetDescriptor;

public interface AssetErrorListener {
    public void error(AssetDescriptor var1, Throwable var2);
}

