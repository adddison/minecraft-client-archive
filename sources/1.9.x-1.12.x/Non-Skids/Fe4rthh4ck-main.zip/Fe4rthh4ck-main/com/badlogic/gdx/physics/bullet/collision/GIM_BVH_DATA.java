/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.physics.bullet.BulletBase;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.btAABB;

public class GIM_BVH_DATA
extends BulletBase {
    private long swigCPtr;

    protected GIM_BVH_DATA(String className, long cPtr, boolean cMemoryOwn) {
        super(className, cPtr, cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public GIM_BVH_DATA(long cPtr, boolean cMemoryOwn) {
        this("GIM_BVH_DATA", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(this.swigCPtr, cMemoryOwn);
    }

    public static long getCPtr(GIM_BVH_DATA obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_GIM_BVH_DATA(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public void setBound(btAABB value) {
        CollisionJNI.GIM_BVH_DATA_bound_set(this.swigCPtr, this, btAABB.getCPtr(value), value);
    }

    public btAABB getBound() {
        long cPtr = CollisionJNI.GIM_BVH_DATA_bound_get(this.swigCPtr, this);
        return cPtr == 0L ? null : new btAABB(cPtr, false);
    }

    public void setData(int value) {
        CollisionJNI.GIM_BVH_DATA_data_set(this.swigCPtr, this, value);
    }

    public int getData() {
        return CollisionJNI.GIM_BVH_DATA_data_get(this.swigCPtr, this);
    }

    public GIM_BVH_DATA() {
        this(CollisionJNI.new_GIM_BVH_DATA(), true);
    }
}

