/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.LocalRayResult;
import com.badlogic.gdx.physics.bullet.collision.RayResultCallback;
import com.badlogic.gdx.physics.bullet.collision.btCollisionObjectConstArray;
import com.badlogic.gdx.physics.bullet.linearmath.btScalarArray;
import com.badlogic.gdx.physics.bullet.linearmath.btVector3Array;

public class AllHitsRayResultCallback
extends RayResultCallback {
    private long swigCPtr;

    protected AllHitsRayResultCallback(String className, long cPtr, boolean cMemoryOwn) {
        super(className, CollisionJNI.AllHitsRayResultCallback_SWIGUpcast(cPtr), cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public AllHitsRayResultCallback(long cPtr, boolean cMemoryOwn) {
        this("AllHitsRayResultCallback", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(CollisionJNI.AllHitsRayResultCallback_SWIGUpcast(this.swigCPtr), cMemoryOwn);
    }

    public static long getCPtr(AllHitsRayResultCallback obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_AllHitsRayResultCallback(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    @Override
    protected void swigDirectorDisconnect() {
        this.swigCMemOwn = false;
        this.delete();
    }

    @Override
    public void swigReleaseOwnership() {
        this.swigCMemOwn = false;
        CollisionJNI.AllHitsRayResultCallback_change_ownership(this, this.swigCPtr, false);
    }

    @Override
    public void swigTakeOwnership() {
        this.swigCMemOwn = true;
        CollisionJNI.AllHitsRayResultCallback_change_ownership(this, this.swigCPtr, true);
    }

    public AllHitsRayResultCallback(Vector3 rayFromWorld, Vector3 rayToWorld) {
        this(CollisionJNI.new_AllHitsRayResultCallback(rayFromWorld, rayToWorld), true);
        CollisionJNI.AllHitsRayResultCallback_director_connect(this, this.swigCPtr, this.swigCMemOwn, true);
    }

    public void setCollisionObjects(btCollisionObjectConstArray value) {
        CollisionJNI.AllHitsRayResultCallback_collisionObjects_set(this.swigCPtr, this, btCollisionObjectConstArray.getCPtr(value), value);
    }

    public btCollisionObjectConstArray getCollisionObjects() {
        long cPtr = CollisionJNI.AllHitsRayResultCallback_collisionObjects_get(this.swigCPtr, this);
        return cPtr == 0L ? null : new btCollisionObjectConstArray(cPtr, false);
    }

    public void setHitNormalWorld(btVector3Array value) {
        CollisionJNI.AllHitsRayResultCallback_hitNormalWorld_set(this.swigCPtr, this, btVector3Array.getCPtr(value), value);
    }

    public btVector3Array getHitNormalWorld() {
        long cPtr = CollisionJNI.AllHitsRayResultCallback_hitNormalWorld_get(this.swigCPtr, this);
        return cPtr == 0L ? null : new btVector3Array(cPtr, false);
    }

    public void setHitPointWorld(btVector3Array value) {
        CollisionJNI.AllHitsRayResultCallback_hitPointWorld_set(this.swigCPtr, this, btVector3Array.getCPtr(value), value);
    }

    public btVector3Array getHitPointWorld() {
        long cPtr = CollisionJNI.AllHitsRayResultCallback_hitPointWorld_get(this.swigCPtr, this);
        return cPtr == 0L ? null : new btVector3Array(cPtr, false);
    }

    public void setHitFractions(btScalarArray value) {
        CollisionJNI.AllHitsRayResultCallback_hitFractions_set(this.swigCPtr, this, btScalarArray.getCPtr(value), value);
    }

    public btScalarArray getHitFractions() {
        long cPtr = CollisionJNI.AllHitsRayResultCallback_hitFractions_get(this.swigCPtr, this);
        return cPtr == 0L ? null : new btScalarArray(cPtr, false);
    }

    @Override
    public float addSingleResult(LocalRayResult rayResult, boolean normalInWorldSpace) {
        return this.getClass() == AllHitsRayResultCallback.class ? CollisionJNI.AllHitsRayResultCallback_addSingleResult(this.swigCPtr, this, LocalRayResult.getCPtr(rayResult), rayResult, normalInWorldSpace) : CollisionJNI.AllHitsRayResultCallback_addSingleResultSwigExplicitAllHitsRayResultCallback(this.swigCPtr, this, LocalRayResult.getCPtr(rayResult), rayResult, normalInWorldSpace);
    }

    public void getRayFromWorld(Vector3 out) {
        CollisionJNI.AllHitsRayResultCallback_getRayFromWorld(this.swigCPtr, this, out);
    }

    public void setRayFromWorld(Vector3 value) {
        CollisionJNI.AllHitsRayResultCallback_setRayFromWorld(this.swigCPtr, this, value);
    }

    public void getRayToWorld(Vector3 out) {
        CollisionJNI.AllHitsRayResultCallback_getRayToWorld(this.swigCPtr, this, out);
    }

    public void setRayToWorld(Vector3 value) {
        CollisionJNI.AllHitsRayResultCallback_setRayToWorld(this.swigCPtr, this, value);
    }
}

