/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.bullet.BulletBase;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.SWIGTYPE_p_a_4__GREAL;
import com.badlogic.gdx.physics.bullet.linearmath.btMatrix3x3;
import com.badlogic.gdx.physics.bullet.linearmath.btVector3;

public class GIM_BOX_BOX_TRANSFORM_CACHE
extends BulletBase {
    private long swigCPtr;

    protected GIM_BOX_BOX_TRANSFORM_CACHE(String className, long cPtr, boolean cMemoryOwn) {
        super(className, cPtr, cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public GIM_BOX_BOX_TRANSFORM_CACHE(long cPtr, boolean cMemoryOwn) {
        this("GIM_BOX_BOX_TRANSFORM_CACHE", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(this.swigCPtr, cMemoryOwn);
    }

    public static long getCPtr(GIM_BOX_BOX_TRANSFORM_CACHE obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_GIM_BOX_BOX_TRANSFORM_CACHE(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public void setT1to0(btVector3 value) {
        CollisionJNI.GIM_BOX_BOX_TRANSFORM_CACHE_T1to0_set(this.swigCPtr, this, btVector3.getCPtr(value), value);
    }

    public btVector3 getT1to0() {
        long cPtr = CollisionJNI.GIM_BOX_BOX_TRANSFORM_CACHE_T1to0_get(this.swigCPtr, this);
        return cPtr == 0L ? null : new btVector3(cPtr, false);
    }

    public void setR1to0(btMatrix3x3 value) {
        CollisionJNI.GIM_BOX_BOX_TRANSFORM_CACHE_R1to0_set(this.swigCPtr, this, btMatrix3x3.getCPtr(value), value);
    }

    public btMatrix3x3 getR1to0() {
        long cPtr = CollisionJNI.GIM_BOX_BOX_TRANSFORM_CACHE_R1to0_get(this.swigCPtr, this);
        return cPtr == 0L ? null : new btMatrix3x3(cPtr, false);
    }

    public void setAR(btMatrix3x3 value) {
        CollisionJNI.GIM_BOX_BOX_TRANSFORM_CACHE_AR_set(this.swigCPtr, this, btMatrix3x3.getCPtr(value), value);
    }

    public btMatrix3x3 getAR() {
        long cPtr = CollisionJNI.GIM_BOX_BOX_TRANSFORM_CACHE_AR_get(this.swigCPtr, this);
        return cPtr == 0L ? null : new btMatrix3x3(cPtr, false);
    }

    public void calc_absolute_matrix() {
        CollisionJNI.GIM_BOX_BOX_TRANSFORM_CACHE_calc_absolute_matrix(this.swigCPtr, this);
    }

    public GIM_BOX_BOX_TRANSFORM_CACHE() {
        this(CollisionJNI.new_GIM_BOX_BOX_TRANSFORM_CACHE__SWIG_0(), true);
    }

    public GIM_BOX_BOX_TRANSFORM_CACHE(SWIGTYPE_p_a_4__GREAL trans1_to_0) {
        this(CollisionJNI.new_GIM_BOX_BOX_TRANSFORM_CACHE__SWIG_1(SWIGTYPE_p_a_4__GREAL.getCPtr(trans1_to_0)), true);
    }

    public void calc_from_homogenic(Matrix4 trans0, Matrix4 trans1) {
        CollisionJNI.GIM_BOX_BOX_TRANSFORM_CACHE_calc_from_homogenic(this.swigCPtr, this, trans0, trans1);
    }

    public void calc_from_full_invert(Matrix4 trans0, Matrix4 trans1) {
        CollisionJNI.GIM_BOX_BOX_TRANSFORM_CACHE_calc_from_full_invert(this.swigCPtr, this, trans0, trans1);
    }

    public Vector3 transform(Vector3 point) {
        return CollisionJNI.GIM_BOX_BOX_TRANSFORM_CACHE_transform(this.swigCPtr, this, point);
    }
}

