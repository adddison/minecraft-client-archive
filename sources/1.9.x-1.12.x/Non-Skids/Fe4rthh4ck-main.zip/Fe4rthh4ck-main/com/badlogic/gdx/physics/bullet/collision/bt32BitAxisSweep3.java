/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.btAxisSweep3InternalInt;
import com.badlogic.gdx.physics.bullet.collision.btOverlappingPairCache;

public class bt32BitAxisSweep3
extends btAxisSweep3InternalInt {
    private long swigCPtr;

    protected bt32BitAxisSweep3(String className, long cPtr, boolean cMemoryOwn) {
        super(className, CollisionJNI.bt32BitAxisSweep3_SWIGUpcast(cPtr), cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public bt32BitAxisSweep3(long cPtr, boolean cMemoryOwn) {
        this("bt32BitAxisSweep3", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(CollisionJNI.bt32BitAxisSweep3_SWIGUpcast(this.swigCPtr), cMemoryOwn);
    }

    public static long getCPtr(bt32BitAxisSweep3 obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_bt32BitAxisSweep3(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public bt32BitAxisSweep3(Vector3 worldAabbMin, Vector3 worldAabbMax, long maxHandles, btOverlappingPairCache pairCache, boolean disableRaycastAccelerator) {
        this(CollisionJNI.new_bt32BitAxisSweep3__SWIG_0(worldAabbMin, worldAabbMax, maxHandles, btOverlappingPairCache.getCPtr(pairCache), pairCache, disableRaycastAccelerator), true);
    }

    public bt32BitAxisSweep3(Vector3 worldAabbMin, Vector3 worldAabbMax, long maxHandles, btOverlappingPairCache pairCache) {
        this(CollisionJNI.new_bt32BitAxisSweep3__SWIG_1(worldAabbMin, worldAabbMax, maxHandles, btOverlappingPairCache.getCPtr(pairCache), pairCache), true);
    }

    public bt32BitAxisSweep3(Vector3 worldAabbMin, Vector3 worldAabbMax, long maxHandles) {
        this(CollisionJNI.new_bt32BitAxisSweep3__SWIG_2(worldAabbMin, worldAabbMax, maxHandles), true);
    }

    public bt32BitAxisSweep3(Vector3 worldAabbMin, Vector3 worldAabbMax) {
        this(CollisionJNI.new_bt32BitAxisSweep3__SWIG_3(worldAabbMin, worldAabbMax), true);
    }
}

