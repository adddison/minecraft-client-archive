/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.LocalRayResult;
import com.badlogic.gdx.physics.bullet.collision.RayResultCallback;

public class ClosestRayResultCallback
extends RayResultCallback {
    private long swigCPtr;

    protected ClosestRayResultCallback(String className, long cPtr, boolean cMemoryOwn) {
        super(className, CollisionJNI.ClosestRayResultCallback_SWIGUpcast(cPtr), cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public ClosestRayResultCallback(long cPtr, boolean cMemoryOwn) {
        this("ClosestRayResultCallback", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(CollisionJNI.ClosestRayResultCallback_SWIGUpcast(this.swigCPtr), cMemoryOwn);
    }

    public static long getCPtr(ClosestRayResultCallback obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_ClosestRayResultCallback(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    @Override
    protected void swigDirectorDisconnect() {
        this.swigCMemOwn = false;
        this.delete();
    }

    @Override
    public void swigReleaseOwnership() {
        this.swigCMemOwn = false;
        CollisionJNI.ClosestRayResultCallback_change_ownership(this, this.swigCPtr, false);
    }

    @Override
    public void swigTakeOwnership() {
        this.swigCMemOwn = true;
        CollisionJNI.ClosestRayResultCallback_change_ownership(this, this.swigCPtr, true);
    }

    public ClosestRayResultCallback(Vector3 rayFromWorld, Vector3 rayToWorld) {
        this(CollisionJNI.new_ClosestRayResultCallback(rayFromWorld, rayToWorld), true);
        CollisionJNI.ClosestRayResultCallback_director_connect(this, this.swigCPtr, this.swigCMemOwn, true);
    }

    @Override
    public float addSingleResult(LocalRayResult rayResult, boolean normalInWorldSpace) {
        return this.getClass() == ClosestRayResultCallback.class ? CollisionJNI.ClosestRayResultCallback_addSingleResult(this.swigCPtr, this, LocalRayResult.getCPtr(rayResult), rayResult, normalInWorldSpace) : CollisionJNI.ClosestRayResultCallback_addSingleResultSwigExplicitClosestRayResultCallback(this.swigCPtr, this, LocalRayResult.getCPtr(rayResult), rayResult, normalInWorldSpace);
    }

    public void getRayFromWorld(Vector3 out) {
        CollisionJNI.ClosestRayResultCallback_getRayFromWorld(this.swigCPtr, this, out);
    }

    public void setRayFromWorld(Vector3 value) {
        CollisionJNI.ClosestRayResultCallback_setRayFromWorld(this.swigCPtr, this, value);
    }

    public void getRayToWorld(Vector3 out) {
        CollisionJNI.ClosestRayResultCallback_getRayToWorld(this.swigCPtr, this, out);
    }

    public void setRayToWorld(Vector3 value) {
        CollisionJNI.ClosestRayResultCallback_setRayToWorld(this.swigCPtr, this, value);
    }

    public void getHitNormalWorld(Vector3 out) {
        CollisionJNI.ClosestRayResultCallback_getHitNormalWorld(this.swigCPtr, this, out);
    }

    public void setHitNormalWorld(Vector3 value) {
        CollisionJNI.ClosestRayResultCallback_setHitNormalWorld(this.swigCPtr, this, value);
    }

    public void getHitPointWorld(Vector3 out) {
        CollisionJNI.ClosestRayResultCallback_getHitPointWorld(this.swigCPtr, this, out);
    }

    public void setHitPointWorld(Vector3 value) {
        CollisionJNI.ClosestRayResultCallback_setHitPointWorld(this.swigCPtr, this, value);
    }
}

