/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.btPolyhedralConvexAabbCachingShape;

public class btBU_Simplex1to4
extends btPolyhedralConvexAabbCachingShape {
    private long swigCPtr;

    protected btBU_Simplex1to4(String className, long cPtr, boolean cMemoryOwn) {
        super(className, CollisionJNI.btBU_Simplex1to4_SWIGUpcast(cPtr), cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public btBU_Simplex1to4(long cPtr, boolean cMemoryOwn) {
        this("btBU_Simplex1to4", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(CollisionJNI.btBU_Simplex1to4_SWIGUpcast(this.swigCPtr), cMemoryOwn);
    }

    public static long getCPtr(btBU_Simplex1to4 obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_btBU_Simplex1to4(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    @Override
    public long operatorNew(long sizeInBytes) {
        return CollisionJNI.btBU_Simplex1to4_operatorNew__SWIG_0(this.swigCPtr, this, sizeInBytes);
    }

    @Override
    public void operatorDelete(long ptr) {
        CollisionJNI.btBU_Simplex1to4_operatorDelete__SWIG_0(this.swigCPtr, this, ptr);
    }

    @Override
    public long operatorNew(long arg0, long ptr) {
        return CollisionJNI.btBU_Simplex1to4_operatorNew__SWIG_1(this.swigCPtr, this, arg0, ptr);
    }

    @Override
    public void operatorDelete(long arg0, long arg1) {
        CollisionJNI.btBU_Simplex1to4_operatorDelete__SWIG_1(this.swigCPtr, this, arg0, arg1);
    }

    @Override
    public long operatorNewArray(long sizeInBytes) {
        return CollisionJNI.btBU_Simplex1to4_operatorNewArray__SWIG_0(this.swigCPtr, this, sizeInBytes);
    }

    @Override
    public void operatorDeleteArray(long ptr) {
        CollisionJNI.btBU_Simplex1to4_operatorDeleteArray__SWIG_0(this.swigCPtr, this, ptr);
    }

    @Override
    public long operatorNewArray(long arg0, long ptr) {
        return CollisionJNI.btBU_Simplex1to4_operatorNewArray__SWIG_1(this.swigCPtr, this, arg0, ptr);
    }

    @Override
    public void operatorDeleteArray(long arg0, long arg1) {
        CollisionJNI.btBU_Simplex1to4_operatorDeleteArray__SWIG_1(this.swigCPtr, this, arg0, arg1);
    }

    public btBU_Simplex1to4() {
        this(CollisionJNI.new_btBU_Simplex1to4__SWIG_0(), true);
    }

    public btBU_Simplex1to4(Vector3 pt0) {
        this(CollisionJNI.new_btBU_Simplex1to4__SWIG_1(pt0), true);
    }

    public btBU_Simplex1to4(Vector3 pt0, Vector3 pt1) {
        this(CollisionJNI.new_btBU_Simplex1to4__SWIG_2(pt0, pt1), true);
    }

    public btBU_Simplex1to4(Vector3 pt0, Vector3 pt1, Vector3 pt2) {
        this(CollisionJNI.new_btBU_Simplex1to4__SWIG_3(pt0, pt1, pt2), true);
    }

    public btBU_Simplex1to4(Vector3 pt0, Vector3 pt1, Vector3 pt2, Vector3 pt3) {
        this(CollisionJNI.new_btBU_Simplex1to4__SWIG_4(pt0, pt1, pt2, pt3), true);
    }

    public void reset() {
        CollisionJNI.btBU_Simplex1to4_reset(this.swigCPtr, this);
    }

    public void addVertex(Vector3 pt) {
        CollisionJNI.btBU_Simplex1to4_addVertex(this.swigCPtr, this, pt);
    }

    public int getIndex(int i) {
        return CollisionJNI.btBU_Simplex1to4_getIndex(this.swigCPtr, this, i);
    }
}

