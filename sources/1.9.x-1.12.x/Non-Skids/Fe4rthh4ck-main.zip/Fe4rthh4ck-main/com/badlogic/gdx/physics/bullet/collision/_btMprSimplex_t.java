/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.physics.bullet.BulletBase;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision._btMprSupport_t;

public class _btMprSimplex_t
extends BulletBase {
    private long swigCPtr;

    protected _btMprSimplex_t(String className, long cPtr, boolean cMemoryOwn) {
        super(className, cPtr, cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public _btMprSimplex_t(long cPtr, boolean cMemoryOwn) {
        this("_btMprSimplex_t", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(this.swigCPtr, cMemoryOwn);
    }

    public static long getCPtr(_btMprSimplex_t obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete__btMprSimplex_t(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public void setPs(_btMprSupport_t value) {
        CollisionJNI._btMprSimplex_t_ps_set(this.swigCPtr, this, _btMprSupport_t.getCPtr(value), value);
    }

    public _btMprSupport_t getPs() {
        long cPtr = CollisionJNI._btMprSimplex_t_ps_get(this.swigCPtr, this);
        return cPtr == 0L ? null : new _btMprSupport_t(cPtr, false);
    }

    public void setLast(int value) {
        CollisionJNI._btMprSimplex_t_last_set(this.swigCPtr, this, value);
    }

    public int getLast() {
        return CollisionJNI._btMprSimplex_t_last_get(this.swigCPtr, this);
    }

    public _btMprSimplex_t() {
        this(CollisionJNI.new__btMprSimplex_t(), true);
    }
}

