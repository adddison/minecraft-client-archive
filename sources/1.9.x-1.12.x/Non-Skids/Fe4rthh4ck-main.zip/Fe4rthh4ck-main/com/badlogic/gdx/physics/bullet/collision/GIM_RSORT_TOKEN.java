/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.physics.bullet.BulletBase;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;

public class GIM_RSORT_TOKEN
extends BulletBase {
    private long swigCPtr;

    protected GIM_RSORT_TOKEN(String className, long cPtr, boolean cMemoryOwn) {
        super(className, cPtr, cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public GIM_RSORT_TOKEN(long cPtr, boolean cMemoryOwn) {
        this("GIM_RSORT_TOKEN", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(this.swigCPtr, cMemoryOwn);
    }

    public static long getCPtr(GIM_RSORT_TOKEN obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_GIM_RSORT_TOKEN(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public void setKey(long value) {
        CollisionJNI.GIM_RSORT_TOKEN_key_set(this.swigCPtr, this, value);
    }

    public long getKey() {
        return CollisionJNI.GIM_RSORT_TOKEN_key_get(this.swigCPtr, this);
    }

    public void setValue(long value) {
        CollisionJNI.GIM_RSORT_TOKEN_value_set(this.swigCPtr, this, value);
    }

    public long getValue() {
        return CollisionJNI.GIM_RSORT_TOKEN_value_get(this.swigCPtr, this);
    }

    public GIM_RSORT_TOKEN() {
        this(CollisionJNI.new_GIM_RSORT_TOKEN__SWIG_0(), true);
    }

    public GIM_RSORT_TOKEN(GIM_RSORT_TOKEN rtoken) {
        this(CollisionJNI.new_GIM_RSORT_TOKEN__SWIG_1(GIM_RSORT_TOKEN.getCPtr(rtoken), rtoken), true);
    }

    public boolean operatorLessThan(GIM_RSORT_TOKEN other) {
        return CollisionJNI.GIM_RSORT_TOKEN_operatorLessThan(this.swigCPtr, this, GIM_RSORT_TOKEN.getCPtr(other), other);
    }

    public boolean operatorGreaterThan(GIM_RSORT_TOKEN other) {
        return CollisionJNI.GIM_RSORT_TOKEN_operatorGreaterThan(this.swigCPtr, this, GIM_RSORT_TOKEN.getCPtr(other), other);
    }
}

