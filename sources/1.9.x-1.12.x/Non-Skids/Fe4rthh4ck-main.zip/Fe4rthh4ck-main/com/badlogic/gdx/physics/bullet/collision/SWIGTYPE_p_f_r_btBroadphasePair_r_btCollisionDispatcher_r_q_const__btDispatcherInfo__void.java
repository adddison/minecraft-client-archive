/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

public class SWIGTYPE_p_f_r_btBroadphasePair_r_btCollisionDispatcher_r_q_const__btDispatcherInfo__void {
    private transient long swigCPtr;

    protected SWIGTYPE_p_f_r_btBroadphasePair_r_btCollisionDispatcher_r_q_const__btDispatcherInfo__void(long cPtr, boolean futureUse) {
        this.swigCPtr = cPtr;
    }

    protected SWIGTYPE_p_f_r_btBroadphasePair_r_btCollisionDispatcher_r_q_const__btDispatcherInfo__void() {
        this.swigCPtr = 0L;
    }

    protected static long getCPtr(SWIGTYPE_p_f_r_btBroadphasePair_r_btCollisionDispatcher_r_q_const__btDispatcherInfo__void obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }
}

