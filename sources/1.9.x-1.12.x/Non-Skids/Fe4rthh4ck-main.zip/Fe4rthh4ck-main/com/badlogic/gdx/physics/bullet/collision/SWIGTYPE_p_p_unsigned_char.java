/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

public class SWIGTYPE_p_p_unsigned_char {
    private transient long swigCPtr;

    protected SWIGTYPE_p_p_unsigned_char(long cPtr, boolean futureUse) {
        this.swigCPtr = cPtr;
    }

    protected SWIGTYPE_p_p_unsigned_char() {
        this.swigCPtr = 0L;
    }

    protected static long getCPtr(SWIGTYPE_p_p_unsigned_char obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }
}

