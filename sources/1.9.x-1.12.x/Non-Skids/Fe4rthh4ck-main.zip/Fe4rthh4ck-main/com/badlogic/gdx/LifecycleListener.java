/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx;

public interface LifecycleListener {
    public void pause();

    public void resume();

    public void dispose();
}

