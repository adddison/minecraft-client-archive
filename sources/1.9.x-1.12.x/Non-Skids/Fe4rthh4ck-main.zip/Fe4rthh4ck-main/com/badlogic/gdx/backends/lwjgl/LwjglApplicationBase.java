/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.backends.lwjgl;

import com.badlogic.gdx.Application;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.badlogic.gdx.backends.lwjgl.LwjglInput;
import com.badlogic.gdx.backends.lwjgl.audio.LwjglAudio;

public interface LwjglApplicationBase
extends Application {
    public LwjglAudio createAudio(LwjglApplicationConfiguration var1);

    public LwjglInput createInput(LwjglApplicationConfiguration var1);
}

