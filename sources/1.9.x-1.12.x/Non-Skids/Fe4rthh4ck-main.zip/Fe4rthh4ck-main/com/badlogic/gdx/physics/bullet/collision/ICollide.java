/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.physics.bullet.BulletBase;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.btDbvtNode;

public class ICollide
extends BulletBase {
    private long swigCPtr;

    protected ICollide(String className, long cPtr, boolean cMemoryOwn) {
        super(className, cPtr, cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public ICollide(long cPtr, boolean cMemoryOwn) {
        this("ICollide", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(this.swigCPtr, cMemoryOwn);
    }

    public static long getCPtr(ICollide obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_ICollide(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    protected void swigDirectorDisconnect() {
        this.swigCMemOwn = false;
        this.delete();
    }

    public void swigReleaseOwnership() {
        this.swigCMemOwn = false;
        CollisionJNI.ICollide_change_ownership(this, this.swigCPtr, false);
    }

    public void swigTakeOwnership() {
        this.swigCMemOwn = true;
        CollisionJNI.ICollide_change_ownership(this, this.swigCPtr, true);
    }

    public void Process(btDbvtNode arg0, btDbvtNode arg1) {
        if (this.getClass() == ICollide.class) {
            CollisionJNI.ICollide_Process__SWIG_0(this.swigCPtr, this, btDbvtNode.getCPtr(arg0), arg0, btDbvtNode.getCPtr(arg1), arg1);
        } else {
            CollisionJNI.ICollide_ProcessSwigExplicitICollide__SWIG_0(this.swigCPtr, this, btDbvtNode.getCPtr(arg0), arg0, btDbvtNode.getCPtr(arg1), arg1);
        }
    }

    public void Process(btDbvtNode arg0) {
        if (this.getClass() == ICollide.class) {
            CollisionJNI.ICollide_Process__SWIG_1(this.swigCPtr, this, btDbvtNode.getCPtr(arg0), arg0);
        } else {
            CollisionJNI.ICollide_ProcessSwigExplicitICollide__SWIG_1(this.swigCPtr, this, btDbvtNode.getCPtr(arg0), arg0);
        }
    }

    public void Process(btDbvtNode n, float arg1) {
        if (this.getClass() == ICollide.class) {
            CollisionJNI.ICollide_Process__SWIG_2(this.swigCPtr, this, btDbvtNode.getCPtr(n), n, arg1);
        } else {
            CollisionJNI.ICollide_ProcessSwigExplicitICollide__SWIG_2(this.swigCPtr, this, btDbvtNode.getCPtr(n), n, arg1);
        }
    }

    public boolean Descent(btDbvtNode arg0) {
        return this.getClass() == ICollide.class ? CollisionJNI.ICollide_Descent(this.swigCPtr, this, btDbvtNode.getCPtr(arg0), arg0) : CollisionJNI.ICollide_DescentSwigExplicitICollide(this.swigCPtr, this, btDbvtNode.getCPtr(arg0), arg0);
    }

    public boolean AllLeaves(btDbvtNode arg0) {
        return this.getClass() == ICollide.class ? CollisionJNI.ICollide_AllLeaves(this.swigCPtr, this, btDbvtNode.getCPtr(arg0), arg0) : CollisionJNI.ICollide_AllLeavesSwigExplicitICollide(this.swigCPtr, this, btDbvtNode.getCPtr(arg0), arg0);
    }

    public ICollide() {
        this(CollisionJNI.new_ICollide(), true);
        CollisionJNI.ICollide_director_connect(this, this.swigCPtr, this.swigCMemOwn, true);
    }
}

