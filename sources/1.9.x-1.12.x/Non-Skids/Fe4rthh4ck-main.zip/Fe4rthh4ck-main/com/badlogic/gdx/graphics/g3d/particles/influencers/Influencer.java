/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.graphics.g3d.particles.influencers;

import com.badlogic.gdx.graphics.g3d.particles.ParticleControllerComponent;

public abstract class Influencer
extends ParticleControllerComponent {
}

