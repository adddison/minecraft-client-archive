/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx;

public interface ApplicationListener {
    public void create();

    public void resize(int var1, int var2);

    public void render();

    public void pause();

    public void resume();

    public void dispose();
}

