/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.physics.bullet.BulletBase;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.linearmath.btVector3;
import com.badlogic.gdx.physics.bullet.linearmath.btVector4;

public class GIM_TRIANGLE_CONTACT
extends BulletBase {
    private long swigCPtr;

    protected GIM_TRIANGLE_CONTACT(String className, long cPtr, boolean cMemoryOwn) {
        super(className, cPtr, cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public GIM_TRIANGLE_CONTACT(long cPtr, boolean cMemoryOwn) {
        this("GIM_TRIANGLE_CONTACT", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(this.swigCPtr, cMemoryOwn);
    }

    public static long getCPtr(GIM_TRIANGLE_CONTACT obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_GIM_TRIANGLE_CONTACT(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public void setPenetration_depth(float value) {
        CollisionJNI.GIM_TRIANGLE_CONTACT_penetration_depth_set(this.swigCPtr, this, value);
    }

    public float getPenetration_depth() {
        return CollisionJNI.GIM_TRIANGLE_CONTACT_penetration_depth_get(this.swigCPtr, this);
    }

    public void setPoint_count(int value) {
        CollisionJNI.GIM_TRIANGLE_CONTACT_point_count_set(this.swigCPtr, this, value);
    }

    public int getPoint_count() {
        return CollisionJNI.GIM_TRIANGLE_CONTACT_point_count_get(this.swigCPtr, this);
    }

    public void setSeparating_normal(btVector4 value) {
        CollisionJNI.GIM_TRIANGLE_CONTACT_separating_normal_set(this.swigCPtr, this, btVector4.getCPtr(value), value);
    }

    public btVector4 getSeparating_normal() {
        long cPtr = CollisionJNI.GIM_TRIANGLE_CONTACT_separating_normal_get(this.swigCPtr, this);
        return cPtr == 0L ? null : new btVector4(cPtr, false);
    }

    public void setPoints(btVector3 value) {
        CollisionJNI.GIM_TRIANGLE_CONTACT_points_set(this.swigCPtr, this, btVector3.getCPtr(value), value);
    }

    public btVector3 getPoints() {
        long cPtr = CollisionJNI.GIM_TRIANGLE_CONTACT_points_get(this.swigCPtr, this);
        return cPtr == 0L ? null : new btVector3(cPtr, false);
    }

    public void copy_from(GIM_TRIANGLE_CONTACT other) {
        CollisionJNI.GIM_TRIANGLE_CONTACT_copy_from(this.swigCPtr, this, GIM_TRIANGLE_CONTACT.getCPtr(other), other);
    }

    public GIM_TRIANGLE_CONTACT() {
        this(CollisionJNI.new_GIM_TRIANGLE_CONTACT__SWIG_0(), true);
    }

    public GIM_TRIANGLE_CONTACT(GIM_TRIANGLE_CONTACT other) {
        this(CollisionJNI.new_GIM_TRIANGLE_CONTACT__SWIG_1(GIM_TRIANGLE_CONTACT.getCPtr(other), other), true);
    }

    public void merge_points(btVector4 plane, float margin, btVector3 points, int point_count) {
        CollisionJNI.GIM_TRIANGLE_CONTACT_merge_points(this.swigCPtr, this, btVector4.getCPtr(plane), plane, margin, btVector3.getCPtr(points), points, point_count);
    }
}

