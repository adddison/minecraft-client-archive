/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

public class SWIGTYPE_p_GUINT {
    private transient long swigCPtr;

    protected SWIGTYPE_p_GUINT(long cPtr, boolean futureUse) {
        this.swigCPtr = cPtr;
    }

    protected SWIGTYPE_p_GUINT() {
        this.swigCPtr = 0L;
    }

    protected static long getCPtr(SWIGTYPE_p_GUINT obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }
}

