/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.physics.bullet.BulletBase;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.LocalConvexResult;
import com.badlogic.gdx.physics.bullet.collision.btBroadphaseProxy;

public class ConvexResultCallback
extends BulletBase {
    private long swigCPtr;

    protected ConvexResultCallback(String className, long cPtr, boolean cMemoryOwn) {
        super(className, cPtr, cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public ConvexResultCallback(long cPtr, boolean cMemoryOwn) {
        this("ConvexResultCallback", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(this.swigCPtr, cMemoryOwn);
    }

    public static long getCPtr(ConvexResultCallback obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_ConvexResultCallback(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    protected void swigDirectorDisconnect() {
        this.swigCMemOwn = false;
        this.delete();
    }

    public void swigReleaseOwnership() {
        this.swigCMemOwn = false;
        CollisionJNI.ConvexResultCallback_change_ownership(this, this.swigCPtr, false);
    }

    public void swigTakeOwnership() {
        this.swigCMemOwn = true;
        CollisionJNI.ConvexResultCallback_change_ownership(this, this.swigCPtr, true);
    }

    public void setClosestHitFraction(float value) {
        CollisionJNI.ConvexResultCallback_closestHitFraction_set(this.swigCPtr, this, value);
    }

    public float getClosestHitFraction() {
        return CollisionJNI.ConvexResultCallback_closestHitFraction_get(this.swigCPtr, this);
    }

    public void setCollisionFilterGroup(int value) {
        CollisionJNI.ConvexResultCallback_collisionFilterGroup_set(this.swigCPtr, this, value);
    }

    public int getCollisionFilterGroup() {
        return CollisionJNI.ConvexResultCallback_collisionFilterGroup_get(this.swigCPtr, this);
    }

    public void setCollisionFilterMask(int value) {
        CollisionJNI.ConvexResultCallback_collisionFilterMask_set(this.swigCPtr, this, value);
    }

    public int getCollisionFilterMask() {
        return CollisionJNI.ConvexResultCallback_collisionFilterMask_get(this.swigCPtr, this);
    }

    public ConvexResultCallback() {
        this(CollisionJNI.new_ConvexResultCallback(), true);
        CollisionJNI.ConvexResultCallback_director_connect(this, this.swigCPtr, this.swigCMemOwn, true);
    }

    public boolean hasHit() {
        return CollisionJNI.ConvexResultCallback_hasHit(this.swigCPtr, this);
    }

    public boolean needsCollision(btBroadphaseProxy proxy0) {
        return this.getClass() == ConvexResultCallback.class ? CollisionJNI.ConvexResultCallback_needsCollision(this.swigCPtr, this, btBroadphaseProxy.getCPtr(proxy0), proxy0) : CollisionJNI.ConvexResultCallback_needsCollisionSwigExplicitConvexResultCallback(this.swigCPtr, this, btBroadphaseProxy.getCPtr(proxy0), proxy0);
    }

    public float addSingleResult(LocalConvexResult convexResult, boolean normalInWorldSpace) {
        return CollisionJNI.ConvexResultCallback_addSingleResult(this.swigCPtr, this, LocalConvexResult.getCPtr(convexResult), convexResult, normalInWorldSpace);
    }
}

