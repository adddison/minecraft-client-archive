/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

public class SWIGTYPE_p_unsigned_int {
    private transient long swigCPtr;

    protected SWIGTYPE_p_unsigned_int(long cPtr, boolean futureUse) {
        this.swigCPtr = cPtr;
    }

    protected SWIGTYPE_p_unsigned_int() {
        this.swigCPtr = 0L;
    }

    protected static long getCPtr(SWIGTYPE_p_unsigned_int obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }
}

