/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.math.Matrix3;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Quaternion;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.bullet.collision.AllHitsRayResultCallback;
import com.badlogic.gdx.physics.bullet.collision.BT_BOX_BOX_TRANSFORM_CACHE;
import com.badlogic.gdx.physics.bullet.collision.BT_QUANTIZED_BVH_NODE;
import com.badlogic.gdx.physics.bullet.collision.ClosestConvexResultCallback;
import com.badlogic.gdx.physics.bullet.collision.ClosestNotMeConvexResultCallback;
import com.badlogic.gdx.physics.bullet.collision.ClosestRayResultCallback;
import com.badlogic.gdx.physics.bullet.collision.CollisionObjectWrapper;
import com.badlogic.gdx.physics.bullet.collision.ContactCache;
import com.badlogic.gdx.physics.bullet.collision.ContactListener;
import com.badlogic.gdx.physics.bullet.collision.ContactResultCallback;
import com.badlogic.gdx.physics.bullet.collision.ConvexResultCallback;
import com.badlogic.gdx.physics.bullet.collision.CustomCollisionDispatcher;
import com.badlogic.gdx.physics.bullet.collision.GIM_AABB;
import com.badlogic.gdx.physics.bullet.collision.GIM_BOX_BOX_TRANSFORM_CACHE;
import com.badlogic.gdx.physics.bullet.collision.GIM_BVH_DATA;
import com.badlogic.gdx.physics.bullet.collision.GIM_BVH_DATA_ARRAY;
import com.badlogic.gdx.physics.bullet.collision.GIM_BVH_TREE_NODE;
import com.badlogic.gdx.physics.bullet.collision.GIM_CONTACT;
import com.badlogic.gdx.physics.bullet.collision.GIM_PAIR;
import com.badlogic.gdx.physics.bullet.collision.GIM_RSORT_TOKEN;
import com.badlogic.gdx.physics.bullet.collision.GIM_RSORT_TOKEN_COMPARATOR;
import com.badlogic.gdx.physics.bullet.collision.GIM_TRIANGLE;
import com.badlogic.gdx.physics.bullet.collision.GIM_TRIANGLE_CONTACT;
import com.badlogic.gdx.physics.bullet.collision.GIM_TRIANGLE_CONTACT_DATA;
import com.badlogic.gdx.physics.bullet.collision.GdxCollisionObjectBridge;
import com.badlogic.gdx.physics.bullet.collision.ICollide;
import com.badlogic.gdx.physics.bullet.collision.LocalConvexResult;
import com.badlogic.gdx.physics.bullet.collision.LocalRayResult;
import com.badlogic.gdx.physics.bullet.collision.LocalShapeInfo;
import com.badlogic.gdx.physics.bullet.collision.MyCallback;
import com.badlogic.gdx.physics.bullet.collision.MyInternalTriangleIndexCallback;
import com.badlogic.gdx.physics.bullet.collision.RayResultCallback;
import com.badlogic.gdx.physics.bullet.collision.SphereTriangleDetector;
import com.badlogic.gdx.physics.bullet.collision._btMprSimplex_t;
import com.badlogic.gdx.physics.bullet.collision._btMprSupport_t;
import com.badlogic.gdx.physics.bullet.collision.btAABB;
import com.badlogic.gdx.physics.bullet.collision.btAxisSweep3InternalInt;
import com.badlogic.gdx.physics.bullet.collision.btAxisSweep3InternalShort;
import com.badlogic.gdx.physics.bullet.collision.btBU_Simplex1to4;
import com.badlogic.gdx.physics.bullet.collision.btBox2dShape;
import com.badlogic.gdx.physics.bullet.collision.btBoxBoxDetector;
import com.badlogic.gdx.physics.bullet.collision.btBoxShape;
import com.badlogic.gdx.physics.bullet.collision.btBroadphaseAabbCallback;
import com.badlogic.gdx.physics.bullet.collision.btBroadphaseInterface;
import com.badlogic.gdx.physics.bullet.collision.btBroadphasePair;
import com.badlogic.gdx.physics.bullet.collision.btBroadphasePairArray;
import com.badlogic.gdx.physics.bullet.collision.btBroadphasePairSortPredicate;
import com.badlogic.gdx.physics.bullet.collision.btBroadphaseProxy;
import com.badlogic.gdx.physics.bullet.collision.btBroadphaseRayCallback;
import com.badlogic.gdx.physics.bullet.collision.btBvhSubtreeInfo;
import com.badlogic.gdx.physics.bullet.collision.btBvhSubtreeInfoData;
import com.badlogic.gdx.physics.bullet.collision.btBvhTree;
import com.badlogic.gdx.physics.bullet.collision.btBvhTriangleMeshShape;
import com.badlogic.gdx.physics.bullet.collision.btCapsuleShape;
import com.badlogic.gdx.physics.bullet.collision.btCapsuleShapeData;
import com.badlogic.gdx.physics.bullet.collision.btCharIndexTripletData;
import com.badlogic.gdx.physics.bullet.collision.btCollisionAlgorithm;
import com.badlogic.gdx.physics.bullet.collision.btCollisionAlgorithmConstructionInfo;
import com.badlogic.gdx.physics.bullet.collision.btCollisionAlgorithmCreateFunc;
import com.badlogic.gdx.physics.bullet.collision.btCollisionConfiguration;
import com.badlogic.gdx.physics.bullet.collision.btCollisionDispatcher;
import com.badlogic.gdx.physics.bullet.collision.btCollisionObject;
import com.badlogic.gdx.physics.bullet.collision.btCollisionObjectArray;
import com.badlogic.gdx.physics.bullet.collision.btCollisionObjectConstArray;
import com.badlogic.gdx.physics.bullet.collision.btCollisionObjectDoubleData;
import com.badlogic.gdx.physics.bullet.collision.btCollisionObjectFloatData;
import com.badlogic.gdx.physics.bullet.collision.btCollisionObjectWrapper;
import com.badlogic.gdx.physics.bullet.collision.btCollisionShape;
import com.badlogic.gdx.physics.bullet.collision.btCollisionShapeData;
import com.badlogic.gdx.physics.bullet.collision.btCollisionWorld;
import com.badlogic.gdx.physics.bullet.collision.btCollisionWorldImporter;
import com.badlogic.gdx.physics.bullet.collision.btCompoundCollisionAlgorithm;
import com.badlogic.gdx.physics.bullet.collision.btCompoundFromGimpactShape;
import com.badlogic.gdx.physics.bullet.collision.btCompoundShape;
import com.badlogic.gdx.physics.bullet.collision.btCompoundShapeChild;
import com.badlogic.gdx.physics.bullet.collision.btCompoundShapeChildData;
import com.badlogic.gdx.physics.bullet.collision.btCompoundShapeData;
import com.badlogic.gdx.physics.bullet.collision.btConcaveShape;
import com.badlogic.gdx.physics.bullet.collision.btConeShape;
import com.badlogic.gdx.physics.bullet.collision.btConeShapeData;
import com.badlogic.gdx.physics.bullet.collision.btConstraintRow;
import com.badlogic.gdx.physics.bullet.collision.btContactArray;
import com.badlogic.gdx.physics.bullet.collision.btConvex2dConvex2dAlgorithm;
import com.badlogic.gdx.physics.bullet.collision.btConvex2dShape;
import com.badlogic.gdx.physics.bullet.collision.btConvexCast;
import com.badlogic.gdx.physics.bullet.collision.btConvexConcaveCollisionAlgorithm;
import com.badlogic.gdx.physics.bullet.collision.btConvexConvexAlgorithm;
import com.badlogic.gdx.physics.bullet.collision.btConvexHullShape;
import com.badlogic.gdx.physics.bullet.collision.btConvexHullShapeData;
import com.badlogic.gdx.physics.bullet.collision.btConvexInternalAabbCachingShape;
import com.badlogic.gdx.physics.bullet.collision.btConvexInternalShape;
import com.badlogic.gdx.physics.bullet.collision.btConvexInternalShapeData;
import com.badlogic.gdx.physics.bullet.collision.btConvexPenetrationDepthSolver;
import com.badlogic.gdx.physics.bullet.collision.btConvexPlaneCollisionAlgorithm;
import com.badlogic.gdx.physics.bullet.collision.btConvexPointCloudShape;
import com.badlogic.gdx.physics.bullet.collision.btConvexPolyhedron;
import com.badlogic.gdx.physics.bullet.collision.btConvexShape;
import com.badlogic.gdx.physics.bullet.collision.btConvexTriangleCallback;
import com.badlogic.gdx.physics.bullet.collision.btConvexTriangleMeshShape;
import com.badlogic.gdx.physics.bullet.collision.btCylinderShape;
import com.badlogic.gdx.physics.bullet.collision.btCylinderShapeData;
import com.badlogic.gdx.physics.bullet.collision.btCylinderShapeX;
import com.badlogic.gdx.physics.bullet.collision.btCylinderShapeZ;
import com.badlogic.gdx.physics.bullet.collision.btDbvt;
import com.badlogic.gdx.physics.bullet.collision.btDbvtAabbMm;
import com.badlogic.gdx.physics.bullet.collision.btDbvtBroadphase;
import com.badlogic.gdx.physics.bullet.collision.btDbvtNode;
import com.badlogic.gdx.physics.bullet.collision.btDbvtProxy;
import com.badlogic.gdx.physics.bullet.collision.btDefaultCollisionConfiguration;
import com.badlogic.gdx.physics.bullet.collision.btDefaultCollisionConstructionInfo;
import com.badlogic.gdx.physics.bullet.collision.btDiscreteCollisionDetectorInterface;
import com.badlogic.gdx.physics.bullet.collision.btDispatcher;
import com.badlogic.gdx.physics.bullet.collision.btDispatcherInfo;
import com.badlogic.gdx.physics.bullet.collision.btElement;
import com.badlogic.gdx.physics.bullet.collision.btEmptyShape;
import com.badlogic.gdx.physics.bullet.collision.btFace;
import com.badlogic.gdx.physics.bullet.collision.btGImpactBvh;
import com.badlogic.gdx.physics.bullet.collision.btGImpactCollisionAlgorithm;
import com.badlogic.gdx.physics.bullet.collision.btGImpactCompoundShape;
import com.badlogic.gdx.physics.bullet.collision.btGImpactMeshShape;
import com.badlogic.gdx.physics.bullet.collision.btGImpactMeshShapeData;
import com.badlogic.gdx.physics.bullet.collision.btGImpactMeshShapePart;
import com.badlogic.gdx.physics.bullet.collision.btGImpactQuantizedBvh;
import com.badlogic.gdx.physics.bullet.collision.btGImpactShapeInterface;
import com.badlogic.gdx.physics.bullet.collision.btGenericMemoryPool;
import com.badlogic.gdx.physics.bullet.collision.btGenericPoolAllocator;
import com.badlogic.gdx.physics.bullet.collision.btGhostObject;
import com.badlogic.gdx.physics.bullet.collision.btGhostPairCallback;
import com.badlogic.gdx.physics.bullet.collision.btGimBvhDataArray;
import com.badlogic.gdx.physics.bullet.collision.btGimBvhTreeNodeArray;
import com.badlogic.gdx.physics.bullet.collision.btGimContactArray;
import com.badlogic.gdx.physics.bullet.collision.btGimPairArray;
import com.badlogic.gdx.physics.bullet.collision.btGimQuantizedBvhNodeArray;
import com.badlogic.gdx.physics.bullet.collision.btGjkCollisionDescription;
import com.badlogic.gdx.physics.bullet.collision.btGjkEpaSolver2;
import com.badlogic.gdx.physics.bullet.collision.btGjkEpaSolver3;
import com.badlogic.gdx.physics.bullet.collision.btGjkPairDetector;
import com.badlogic.gdx.physics.bullet.collision.btHashMapInternalShortBtHashIntBtTriangleInfo;
import com.badlogic.gdx.physics.bullet.collision.btHashedOverlappingPairCache;
import com.badlogic.gdx.physics.bullet.collision.btHashedSimplePairCache;
import com.badlogic.gdx.physics.bullet.collision.btHeightfieldTerrainShape;
import com.badlogic.gdx.physics.bullet.collision.btIndexedMesh;
import com.badlogic.gdx.physics.bullet.collision.btIntIndexData;
import com.badlogic.gdx.physics.bullet.collision.btInternalTriangleIndexCallback;
import com.badlogic.gdx.physics.bullet.collision.btManifoldPoint;
import com.badlogic.gdx.physics.bullet.collision.btManifoldResult;
import com.badlogic.gdx.physics.bullet.collision.btMaterial;
import com.badlogic.gdx.physics.bullet.collision.btMaterialProperties;
import com.badlogic.gdx.physics.bullet.collision.btMeshPartData;
import com.badlogic.gdx.physics.bullet.collision.btMinkowskiSumShape;
import com.badlogic.gdx.physics.bullet.collision.btMprCollisionDescription;
import com.badlogic.gdx.physics.bullet.collision.btMprDistanceInfo;
import com.badlogic.gdx.physics.bullet.collision.btMultiSphereShape;
import com.badlogic.gdx.physics.bullet.collision.btMultiSphereShapeData;
import com.badlogic.gdx.physics.bullet.collision.btMultimaterialTriangleMeshShape;
import com.badlogic.gdx.physics.bullet.collision.btNodeOverlapCallback;
import com.badlogic.gdx.physics.bullet.collision.btOptimizedBvh;
import com.badlogic.gdx.physics.bullet.collision.btOptimizedBvhNode;
import com.badlogic.gdx.physics.bullet.collision.btOptimizedBvhNodeDoubleData;
import com.badlogic.gdx.physics.bullet.collision.btOptimizedBvhNodeFloatData;
import com.badlogic.gdx.physics.bullet.collision.btOverlapCallback;
import com.badlogic.gdx.physics.bullet.collision.btOverlapFilterCallback;
import com.badlogic.gdx.physics.bullet.collision.btOverlappingPairCache;
import com.badlogic.gdx.physics.bullet.collision.btOverlappingPairCallback;
import com.badlogic.gdx.physics.bullet.collision.btPairCachingGhostObject;
import com.badlogic.gdx.physics.bullet.collision.btPairSet;
import com.badlogic.gdx.physics.bullet.collision.btPersistentManifold;
import com.badlogic.gdx.physics.bullet.collision.btPersistentManifoldArray;
import com.badlogic.gdx.physics.bullet.collision.btPointCollector;
import com.badlogic.gdx.physics.bullet.collision.btPolyhedralConvexAabbCachingShape;
import com.badlogic.gdx.physics.bullet.collision.btPolyhedralConvexShape;
import com.badlogic.gdx.physics.bullet.collision.btPositionAndRadius;
import com.badlogic.gdx.physics.bullet.collision.btPrimitiveManagerBase;
import com.badlogic.gdx.physics.bullet.collision.btPrimitiveTriangle;
import com.badlogic.gdx.physics.bullet.collision.btQuantizedBvh;
import com.badlogic.gdx.physics.bullet.collision.btQuantizedBvhDoubleData;
import com.badlogic.gdx.physics.bullet.collision.btQuantizedBvhFloatData;
import com.badlogic.gdx.physics.bullet.collision.btQuantizedBvhNode;
import com.badlogic.gdx.physics.bullet.collision.btQuantizedBvhNodeData;
import com.badlogic.gdx.physics.bullet.collision.btQuantizedBvhTree;
import com.badlogic.gdx.physics.bullet.collision.btScaledBvhTriangleMeshShape;
import com.badlogic.gdx.physics.bullet.collision.btScaledTriangleMeshShapeData;
import com.badlogic.gdx.physics.bullet.collision.btShapeHull;
import com.badlogic.gdx.physics.bullet.collision.btShortIntIndexData;
import com.badlogic.gdx.physics.bullet.collision.btShortIntIndexTripletData;
import com.badlogic.gdx.physics.bullet.collision.btSimpleBroadphase;
import com.badlogic.gdx.physics.bullet.collision.btSimpleBroadphaseProxy;
import com.badlogic.gdx.physics.bullet.collision.btSimplePair;
import com.badlogic.gdx.physics.bullet.collision.btSimulationIslandManager;
import com.badlogic.gdx.physics.bullet.collision.btSortedOverlappingPairCache;
import com.badlogic.gdx.physics.bullet.collision.btSphereBoxCollisionAlgorithm;
import com.badlogic.gdx.physics.bullet.collision.btSphereShape;
import com.badlogic.gdx.physics.bullet.collision.btStaticPlaneShape;
import com.badlogic.gdx.physics.bullet.collision.btStaticPlaneShapeData;
import com.badlogic.gdx.physics.bullet.collision.btStorageResult;
import com.badlogic.gdx.physics.bullet.collision.btStridingMeshInterface;
import com.badlogic.gdx.physics.bullet.collision.btStridingMeshInterfaceData;
import com.badlogic.gdx.physics.bullet.collision.btSubSimplexClosestResult;
import com.badlogic.gdx.physics.bullet.collision.btTetrahedronShapeEx;
import com.badlogic.gdx.physics.bullet.collision.btTriangle;
import com.badlogic.gdx.physics.bullet.collision.btTriangleBuffer;
import com.badlogic.gdx.physics.bullet.collision.btTriangleCallback;
import com.badlogic.gdx.physics.bullet.collision.btTriangleConvexcastCallback;
import com.badlogic.gdx.physics.bullet.collision.btTriangleIndexVertexArray;
import com.badlogic.gdx.physics.bullet.collision.btTriangleIndexVertexMaterialArray;
import com.badlogic.gdx.physics.bullet.collision.btTriangleInfo;
import com.badlogic.gdx.physics.bullet.collision.btTriangleInfoData;
import com.badlogic.gdx.physics.bullet.collision.btTriangleInfoMap;
import com.badlogic.gdx.physics.bullet.collision.btTriangleInfoMapData;
import com.badlogic.gdx.physics.bullet.collision.btTriangleMesh;
import com.badlogic.gdx.physics.bullet.collision.btTriangleMeshShape;
import com.badlogic.gdx.physics.bullet.collision.btTriangleMeshShapeData;
import com.badlogic.gdx.physics.bullet.collision.btTriangleRaycastCallback;
import com.badlogic.gdx.physics.bullet.collision.btTriangleShape;
import com.badlogic.gdx.physics.bullet.collision.btTriangleShapeEx;
import com.badlogic.gdx.physics.bullet.collision.btUniformScalingShape;
import com.badlogic.gdx.physics.bullet.collision.btUnionFind;
import com.badlogic.gdx.physics.bullet.collision.btUsageBitfield;
import com.badlogic.gdx.physics.bullet.collision.btVoronoiSimplexSolver;
import com.badlogic.gdx.physics.bullet.collision.gim_bitset;
import com.badlogic.gdx.physics.bullet.collision.gim_contact_array;
import com.badlogic.gdx.physics.bullet.collision.gim_contact_array_internal;
import com.badlogic.gdx.physics.bullet.linearmath.btBulletSerializedArrays;
import com.badlogic.gdx.physics.bullet.linearmath.btHashInt;
import com.badlogic.gdx.physics.bullet.linearmath.btIDebugDraw;
import com.badlogic.gdx.physics.bullet.linearmath.btMatrix3x3;
import com.badlogic.gdx.physics.bullet.linearmath.btPoolAllocator;
import com.badlogic.gdx.physics.bullet.linearmath.btScalarArray;
import com.badlogic.gdx.physics.bullet.linearmath.btSerializer;
import com.badlogic.gdx.physics.bullet.linearmath.btTransform;
import com.badlogic.gdx.physics.bullet.linearmath.btTransformDoubleData;
import com.badlogic.gdx.physics.bullet.linearmath.btTransformFloatData;
import com.badlogic.gdx.physics.bullet.linearmath.btVector3;
import com.badlogic.gdx.physics.bullet.linearmath.btVector3Array;
import com.badlogic.gdx.physics.bullet.linearmath.btVector3DoubleData;
import com.badlogic.gdx.physics.bullet.linearmath.btVector3FloatData;
import com.badlogic.gdx.physics.bullet.linearmath.btVector4;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.LongBuffer;
import java.nio.ShortBuffer;

public class CollisionJNI {
    public static final native void delete_btDiscreteCollisionDetectorInterface_Result(long var0);

    public static final native void btDiscreteCollisionDetectorInterface_Result_setShapeIdentifiersA(long var0, btDiscreteCollisionDetectorInterface.Result var2, int var3, int var4);

    public static final native void btDiscreteCollisionDetectorInterface_Result_setShapeIdentifiersB(long var0, btDiscreteCollisionDetectorInterface.Result var2, int var3, int var4);

    public static final native void btDiscreteCollisionDetectorInterface_Result_addContactPoint(long var0, btDiscreteCollisionDetectorInterface.Result var2, Vector3 var3, Vector3 var4, float var5);

    public static final native long new_btDiscreteCollisionDetectorInterface_ClosestPointInput();

    public static final native void btDiscreteCollisionDetectorInterface_ClosestPointInput_transformA_set(long var0, btDiscreteCollisionDetectorInterface.ClosestPointInput var2, long var3, btTransform var5);

    public static final native long btDiscreteCollisionDetectorInterface_ClosestPointInput_transformA_get(long var0, btDiscreteCollisionDetectorInterface.ClosestPointInput var2);

    public static final native void btDiscreteCollisionDetectorInterface_ClosestPointInput_transformB_set(long var0, btDiscreteCollisionDetectorInterface.ClosestPointInput var2, long var3, btTransform var5);

    public static final native long btDiscreteCollisionDetectorInterface_ClosestPointInput_transformB_get(long var0, btDiscreteCollisionDetectorInterface.ClosestPointInput var2);

    public static final native void btDiscreteCollisionDetectorInterface_ClosestPointInput_maximumDistanceSquared_set(long var0, btDiscreteCollisionDetectorInterface.ClosestPointInput var2, float var3);

    public static final native float btDiscreteCollisionDetectorInterface_ClosestPointInput_maximumDistanceSquared_get(long var0, btDiscreteCollisionDetectorInterface.ClosestPointInput var2);

    public static final native void delete_btDiscreteCollisionDetectorInterface_ClosestPointInput(long var0);

    public static final native void delete_btDiscreteCollisionDetectorInterface(long var0);

    public static final native void btDiscreteCollisionDetectorInterface_getClosestPoints__SWIG_0(long var0, btDiscreteCollisionDetectorInterface var2, long var3, btDiscreteCollisionDetectorInterface.ClosestPointInput var5, long var6, btDiscreteCollisionDetectorInterface.Result var8, long var9, btIDebugDraw var11, boolean var12);

    public static final native void btDiscreteCollisionDetectorInterface_getClosestPoints__SWIG_1(long var0, btDiscreteCollisionDetectorInterface var2, long var3, btDiscreteCollisionDetectorInterface.ClosestPointInput var5, long var6, btDiscreteCollisionDetectorInterface.Result var8, long var9, btIDebugDraw var11);

    public static final native void btStorageResult_normalOnSurfaceB_set(long var0, btStorageResult var2, long var3, btVector3 var5);

    public static final native long btStorageResult_normalOnSurfaceB_get(long var0, btStorageResult var2);

    public static final native void btStorageResult_closestPointInB_set(long var0, btStorageResult var2, long var3, btVector3 var5);

    public static final native long btStorageResult_closestPointInB_get(long var0, btStorageResult var2);

    public static final native void btStorageResult_distance_set(long var0, btStorageResult var2, float var3);

    public static final native float btStorageResult_distance_get(long var0, btStorageResult var2);

    public static final native void delete_btStorageResult(long var0);

    public static final native long btBroadphaseProxy_operatorNew__SWIG_0(long var0, btBroadphaseProxy var2, long var3);

    public static final native void btBroadphaseProxy_operatorDelete__SWIG_0(long var0, btBroadphaseProxy var2, long var3);

    public static final native long btBroadphaseProxy_operatorNew__SWIG_1(long var0, btBroadphaseProxy var2, long var3, long var5);

    public static final native void btBroadphaseProxy_operatorDelete__SWIG_1(long var0, btBroadphaseProxy var2, long var3, long var5);

    public static final native long btBroadphaseProxy_operatorNewArray__SWIG_0(long var0, btBroadphaseProxy var2, long var3);

    public static final native void btBroadphaseProxy_operatorDeleteArray__SWIG_0(long var0, btBroadphaseProxy var2, long var3);

    public static final native long btBroadphaseProxy_operatorNewArray__SWIG_1(long var0, btBroadphaseProxy var2, long var3, long var5);

    public static final native void btBroadphaseProxy_operatorDeleteArray__SWIG_1(long var0, btBroadphaseProxy var2, long var3, long var5);

    public static final native void btBroadphaseProxy_clientObject_set(long var0, btBroadphaseProxy var2, long var3);

    public static final native long btBroadphaseProxy_clientObject_get(long var0, btBroadphaseProxy var2);

    public static final native void btBroadphaseProxy_collisionFilterGroup_set(long var0, btBroadphaseProxy var2, int var3);

    public static final native int btBroadphaseProxy_collisionFilterGroup_get(long var0, btBroadphaseProxy var2);

    public static final native void btBroadphaseProxy_collisionFilterMask_set(long var0, btBroadphaseProxy var2, int var3);

    public static final native int btBroadphaseProxy_collisionFilterMask_get(long var0, btBroadphaseProxy var2);

    public static final native void btBroadphaseProxy_uniqueId_set(long var0, btBroadphaseProxy var2, int var3);

    public static final native int btBroadphaseProxy_uniqueId_get(long var0, btBroadphaseProxy var2);

    public static final native void btBroadphaseProxy_aabbMin_set(long var0, btBroadphaseProxy var2, long var3, btVector3 var5);

    public static final native long btBroadphaseProxy_aabbMin_get(long var0, btBroadphaseProxy var2);

    public static final native void btBroadphaseProxy_aabbMax_set(long var0, btBroadphaseProxy var2, long var3, btVector3 var5);

    public static final native long btBroadphaseProxy_aabbMax_get(long var0, btBroadphaseProxy var2);

    public static final native int btBroadphaseProxy_getUid(long var0, btBroadphaseProxy var2);

    public static final native long new_btBroadphaseProxy__SWIG_0();

    public static final native long new_btBroadphaseProxy__SWIG_1(Vector3 var0, Vector3 var1, long var2, int var4, int var5);

    public static final native boolean btBroadphaseProxy_isPolyhedral(int var0);

    public static final native boolean btBroadphaseProxy_isConvex(int var0);

    public static final native boolean btBroadphaseProxy_isNonMoving(int var0);

    public static final native boolean btBroadphaseProxy_isConcave(int var0);

    public static final native boolean btBroadphaseProxy_isCompound(int var0);

    public static final native boolean btBroadphaseProxy_isSoftBody(int var0);

    public static final native boolean btBroadphaseProxy_isInfinite(int var0);

    public static final native boolean btBroadphaseProxy_isConvex2d(int var0);

    public static final native void delete_btBroadphaseProxy(long var0);

    public static final native long new_btBroadphasePair__SWIG_0();

    public static final native long btBroadphasePair_operatorNew__SWIG_0(long var0, btBroadphasePair var2, long var3);

    public static final native void btBroadphasePair_operatorDelete__SWIG_0(long var0, btBroadphasePair var2, long var3);

    public static final native long btBroadphasePair_operatorNew__SWIG_1(long var0, btBroadphasePair var2, long var3, long var5);

    public static final native void btBroadphasePair_operatorDelete__SWIG_1(long var0, btBroadphasePair var2, long var3, long var5);

    public static final native long btBroadphasePair_operatorNewArray__SWIG_0(long var0, btBroadphasePair var2, long var3);

    public static final native void btBroadphasePair_operatorDeleteArray__SWIG_0(long var0, btBroadphasePair var2, long var3);

    public static final native long btBroadphasePair_operatorNewArray__SWIG_1(long var0, btBroadphasePair var2, long var3, long var5);

    public static final native void btBroadphasePair_operatorDeleteArray__SWIG_1(long var0, btBroadphasePair var2, long var3, long var5);

    public static final native long new_btBroadphasePair__SWIG_1(btBroadphasePair var0);

    public static final native long new_btBroadphasePair__SWIG_2(btBroadphaseProxy var0, btBroadphaseProxy var1);

    public static final native void btBroadphasePair_pProxy0_set(long var0, btBroadphasePair var2, long var3, btBroadphaseProxy var5);

    public static final native long btBroadphasePair_pProxy0_get(long var0, btBroadphasePair var2);

    public static final native void btBroadphasePair_pProxy1_set(long var0, btBroadphasePair var2, long var3, btBroadphaseProxy var5);

    public static final native long btBroadphasePair_pProxy1_get(long var0, btBroadphasePair var2);

    public static final native void btBroadphasePair_algorithm_set(long var0, btBroadphasePair var2, long var3, btCollisionAlgorithm var5);

    public static final native long btBroadphasePair_algorithm_get(long var0, btBroadphasePair var2);

    public static final native void btBroadphasePair_internalInfo1_set(long var0, btBroadphasePair var2, long var3);

    public static final native long btBroadphasePair_internalInfo1_get(long var0, btBroadphasePair var2);

    public static final native void btBroadphasePair_internalTmpValue_set(long var0, btBroadphasePair var2, int var3);

    public static final native int btBroadphasePair_internalTmpValue_get(long var0, btBroadphasePair var2);

    public static final native void delete_btBroadphasePair(long var0);

    public static final native boolean btBroadphasePairSortPredicate_operatorFunctionCall(long var0, btBroadphasePairSortPredicate var2, btBroadphasePair var3, btBroadphasePair var4);

    public static final native long new_btBroadphasePairSortPredicate();

    public static final native void delete_btBroadphasePairSortPredicate(long var0);

    public static final native boolean operatorEqualTo__SWIG_3(btBroadphasePair var0, btBroadphasePair var1);

    public static final native void delete_btBroadphaseAabbCallback(long var0);

    public static final native boolean btBroadphaseAabbCallback_process(long var0, btBroadphaseAabbCallback var2, long var3, btBroadphaseProxy var5);

    public static final native long new_btBroadphaseAabbCallback();

    public static final native void btBroadphaseAabbCallback_director_connect(btBroadphaseAabbCallback var0, long var1, boolean var3, boolean var4);

    public static final native void btBroadphaseAabbCallback_change_ownership(btBroadphaseAabbCallback var0, long var1, boolean var3);

    public static final native void btBroadphaseRayCallback_rayDirectionInverse_set(long var0, btBroadphaseRayCallback var2, long var3, btVector3 var5);

    public static final native long btBroadphaseRayCallback_rayDirectionInverse_get(long var0, btBroadphaseRayCallback var2);

    public static final native void btBroadphaseRayCallback_signs_set(long var0, btBroadphaseRayCallback var2, long[] var3);

    public static final native long[] btBroadphaseRayCallback_signs_get(long var0, btBroadphaseRayCallback var2);

    public static final native void btBroadphaseRayCallback_lambda_max_set(long var0, btBroadphaseRayCallback var2, float var3);

    public static final native float btBroadphaseRayCallback_lambda_max_get(long var0, btBroadphaseRayCallback var2);

    public static final native void delete_btBroadphaseRayCallback(long var0);

    public static final native long new_btBroadphaseRayCallback();

    public static final native void btBroadphaseRayCallback_director_connect(btBroadphaseRayCallback var0, long var1, boolean var3, boolean var4);

    public static final native void btBroadphaseRayCallback_change_ownership(btBroadphaseRayCallback var0, long var1, boolean var3);

    public static final native void delete_btBroadphaseInterface(long var0);

    public static final native long btBroadphaseInterface_createProxy(long var0, btBroadphaseInterface var2, Vector3 var3, Vector3 var4, int var5, long var6, int var8, int var9, long var10, btDispatcher var12);

    public static final native void btBroadphaseInterface_destroyProxy(long var0, btBroadphaseInterface var2, long var3, btBroadphaseProxy var5, long var6, btDispatcher var8);

    public static final native void btBroadphaseInterface_setAabb(long var0, btBroadphaseInterface var2, long var3, btBroadphaseProxy var5, Vector3 var6, Vector3 var7, long var8, btDispatcher var10);

    public static final native void btBroadphaseInterface_getAabb(long var0, btBroadphaseInterface var2, long var3, btBroadphaseProxy var5, Vector3 var6, Vector3 var7);

    public static final native void btBroadphaseInterface_rayTest__SWIG_0(long var0, btBroadphaseInterface var2, Vector3 var3, Vector3 var4, long var5, btBroadphaseRayCallback var7, Vector3 var8, Vector3 var9);

    public static final native void btBroadphaseInterface_rayTest__SWIG_1(long var0, btBroadphaseInterface var2, Vector3 var3, Vector3 var4, long var5, btBroadphaseRayCallback var7, Vector3 var8);

    public static final native void btBroadphaseInterface_rayTest__SWIG_2(long var0, btBroadphaseInterface var2, Vector3 var3, Vector3 var4, long var5, btBroadphaseRayCallback var7);

    public static final native void btBroadphaseInterface_aabbTest(long var0, btBroadphaseInterface var2, Vector3 var3, Vector3 var4, long var5, btBroadphaseAabbCallback var7);

    public static final native void btBroadphaseInterface_calculateOverlappingPairs(long var0, btBroadphaseInterface var2, long var3, btDispatcher var5);

    public static final native long btBroadphaseInterface_getOverlappingPairCache(long var0, btBroadphaseInterface var2);

    public static final native long btBroadphaseInterface_getOverlappingPairCacheConst(long var0, btBroadphaseInterface var2);

    public static final native void btBroadphaseInterface_getBroadphaseAabb(long var0, btBroadphaseInterface var2, Vector3 var3, Vector3 var4);

    public static final native void btBroadphaseInterface_resetPool(long var0, btBroadphaseInterface var2, long var3, btDispatcher var5);

    public static final native void btBroadphaseInterface_printStats(long var0, btBroadphaseInterface var2);

    public static final native long btQuantizedBvhNode_operatorNew__SWIG_0(long var0, btQuantizedBvhNode var2, long var3);

    public static final native void btQuantizedBvhNode_operatorDelete__SWIG_0(long var0, btQuantizedBvhNode var2, long var3);

    public static final native long btQuantizedBvhNode_operatorNew__SWIG_1(long var0, btQuantizedBvhNode var2, long var3, long var5);

    public static final native void btQuantizedBvhNode_operatorDelete__SWIG_1(long var0, btQuantizedBvhNode var2, long var3, long var5);

    public static final native long btQuantizedBvhNode_operatorNewArray__SWIG_0(long var0, btQuantizedBvhNode var2, long var3);

    public static final native void btQuantizedBvhNode_operatorDeleteArray__SWIG_0(long var0, btQuantizedBvhNode var2, long var3);

    public static final native long btQuantizedBvhNode_operatorNewArray__SWIG_1(long var0, btQuantizedBvhNode var2, long var3, long var5);

    public static final native void btQuantizedBvhNode_operatorDeleteArray__SWIG_1(long var0, btQuantizedBvhNode var2, long var3, long var5);

    public static final native void btQuantizedBvhNode_quantizedAabbMin_set(long var0, btQuantizedBvhNode var2, int[] var3);

    public static final native int[] btQuantizedBvhNode_quantizedAabbMin_get(long var0, btQuantizedBvhNode var2);

    public static final native void btQuantizedBvhNode_quantizedAabbMax_set(long var0, btQuantizedBvhNode var2, int[] var3);

    public static final native int[] btQuantizedBvhNode_quantizedAabbMax_get(long var0, btQuantizedBvhNode var2);

    public static final native void btQuantizedBvhNode_escapeIndexOrTriangleIndex_set(long var0, btQuantizedBvhNode var2, int var3);

    public static final native int btQuantizedBvhNode_escapeIndexOrTriangleIndex_get(long var0, btQuantizedBvhNode var2);

    public static final native boolean btQuantizedBvhNode_isLeafNode(long var0, btQuantizedBvhNode var2);

    public static final native int btQuantizedBvhNode_getEscapeIndex(long var0, btQuantizedBvhNode var2);

    public static final native int btQuantizedBvhNode_getTriangleIndex(long var0, btQuantizedBvhNode var2);

    public static final native int btQuantizedBvhNode_getPartId(long var0, btQuantizedBvhNode var2);

    public static final native long new_btQuantizedBvhNode();

    public static final native void delete_btQuantizedBvhNode(long var0);

    public static final native long btOptimizedBvhNode_operatorNew__SWIG_0(long var0, btOptimizedBvhNode var2, long var3);

    public static final native void btOptimizedBvhNode_operatorDelete__SWIG_0(long var0, btOptimizedBvhNode var2, long var3);

    public static final native long btOptimizedBvhNode_operatorNew__SWIG_1(long var0, btOptimizedBvhNode var2, long var3, long var5);

    public static final native void btOptimizedBvhNode_operatorDelete__SWIG_1(long var0, btOptimizedBvhNode var2, long var3, long var5);

    public static final native long btOptimizedBvhNode_operatorNewArray__SWIG_0(long var0, btOptimizedBvhNode var2, long var3);

    public static final native void btOptimizedBvhNode_operatorDeleteArray__SWIG_0(long var0, btOptimizedBvhNode var2, long var3);

    public static final native long btOptimizedBvhNode_operatorNewArray__SWIG_1(long var0, btOptimizedBvhNode var2, long var3, long var5);

    public static final native void btOptimizedBvhNode_operatorDeleteArray__SWIG_1(long var0, btOptimizedBvhNode var2, long var3, long var5);

    public static final native void btOptimizedBvhNode_aabbMinOrg_set(long var0, btOptimizedBvhNode var2, long var3, btVector3 var5);

    public static final native long btOptimizedBvhNode_aabbMinOrg_get(long var0, btOptimizedBvhNode var2);

    public static final native void btOptimizedBvhNode_aabbMaxOrg_set(long var0, btOptimizedBvhNode var2, long var3, btVector3 var5);

    public static final native long btOptimizedBvhNode_aabbMaxOrg_get(long var0, btOptimizedBvhNode var2);

    public static final native void btOptimizedBvhNode_escapeIndex_set(long var0, btOptimizedBvhNode var2, int var3);

    public static final native int btOptimizedBvhNode_escapeIndex_get(long var0, btOptimizedBvhNode var2);

    public static final native void btOptimizedBvhNode_subPart_set(long var0, btOptimizedBvhNode var2, int var3);

    public static final native int btOptimizedBvhNode_subPart_get(long var0, btOptimizedBvhNode var2);

    public static final native void btOptimizedBvhNode_triangleIndex_set(long var0, btOptimizedBvhNode var2, int var3);

    public static final native int btOptimizedBvhNode_triangleIndex_get(long var0, btOptimizedBvhNode var2);

    public static final native void btOptimizedBvhNode_padding_set(long var0, btOptimizedBvhNode var2, String var3);

    public static final native String btOptimizedBvhNode_padding_get(long var0, btOptimizedBvhNode var2);

    public static final native long new_btOptimizedBvhNode();

    public static final native void delete_btOptimizedBvhNode(long var0);

    public static final native long btBvhSubtreeInfo_operatorNew__SWIG_0(long var0, btBvhSubtreeInfo var2, long var3);

    public static final native void btBvhSubtreeInfo_operatorDelete__SWIG_0(long var0, btBvhSubtreeInfo var2, long var3);

    public static final native long btBvhSubtreeInfo_operatorNew__SWIG_1(long var0, btBvhSubtreeInfo var2, long var3, long var5);

    public static final native void btBvhSubtreeInfo_operatorDelete__SWIG_1(long var0, btBvhSubtreeInfo var2, long var3, long var5);

    public static final native long btBvhSubtreeInfo_operatorNewArray__SWIG_0(long var0, btBvhSubtreeInfo var2, long var3);

    public static final native void btBvhSubtreeInfo_operatorDeleteArray__SWIG_0(long var0, btBvhSubtreeInfo var2, long var3);

    public static final native long btBvhSubtreeInfo_operatorNewArray__SWIG_1(long var0, btBvhSubtreeInfo var2, long var3, long var5);

    public static final native void btBvhSubtreeInfo_operatorDeleteArray__SWIG_1(long var0, btBvhSubtreeInfo var2, long var3, long var5);

    public static final native void btBvhSubtreeInfo_quantizedAabbMin_set(long var0, btBvhSubtreeInfo var2, int[] var3);

    public static final native int[] btBvhSubtreeInfo_quantizedAabbMin_get(long var0, btBvhSubtreeInfo var2);

    public static final native void btBvhSubtreeInfo_quantizedAabbMax_set(long var0, btBvhSubtreeInfo var2, int[] var3);

    public static final native int[] btBvhSubtreeInfo_quantizedAabbMax_get(long var0, btBvhSubtreeInfo var2);

    public static final native void btBvhSubtreeInfo_rootNodeIndex_set(long var0, btBvhSubtreeInfo var2, int var3);

    public static final native int btBvhSubtreeInfo_rootNodeIndex_get(long var0, btBvhSubtreeInfo var2);

    public static final native void btBvhSubtreeInfo_subtreeSize_set(long var0, btBvhSubtreeInfo var2, int var3);

    public static final native int btBvhSubtreeInfo_subtreeSize_get(long var0, btBvhSubtreeInfo var2);

    public static final native void btBvhSubtreeInfo_padding_set(long var0, btBvhSubtreeInfo var2, int[] var3);

    public static final native int[] btBvhSubtreeInfo_padding_get(long var0, btBvhSubtreeInfo var2);

    public static final native long new_btBvhSubtreeInfo();

    public static final native void btBvhSubtreeInfo_setAabbFromQuantizeNode(long var0, btBvhSubtreeInfo var2, long var3, btQuantizedBvhNode var5);

    public static final native void delete_btBvhSubtreeInfo(long var0);

    public static final native void delete_btNodeOverlapCallback(long var0);

    public static final native void btNodeOverlapCallback_processNode(long var0, btNodeOverlapCallback var2, int var3, int var4);

    public static final native long new_btNodeOverlapCallback();

    public static final native void btNodeOverlapCallback_director_connect(btNodeOverlapCallback var0, long var1, boolean var3, boolean var4);

    public static final native void btNodeOverlapCallback_change_ownership(btNodeOverlapCallback var0, long var1, boolean var3);

    public static final native long btQuantizedBvh_operatorNew__SWIG_0(long var0, btQuantizedBvh var2, long var3);

    public static final native void btQuantizedBvh_operatorDelete__SWIG_0(long var0, btQuantizedBvh var2, long var3);

    public static final native long btQuantizedBvh_operatorNew__SWIG_1(long var0, btQuantizedBvh var2, long var3, long var5);

    public static final native void btQuantizedBvh_operatorDelete__SWIG_1(long var0, btQuantizedBvh var2, long var3, long var5);

    public static final native long btQuantizedBvh_operatorNewArray__SWIG_0(long var0, btQuantizedBvh var2, long var3);

    public static final native void btQuantizedBvh_operatorDeleteArray__SWIG_0(long var0, btQuantizedBvh var2, long var3);

    public static final native long btQuantizedBvh_operatorNewArray__SWIG_1(long var0, btQuantizedBvh var2, long var3, long var5);

    public static final native void btQuantizedBvh_operatorDeleteArray__SWIG_1(long var0, btQuantizedBvh var2, long var3, long var5);

    public static final native long new_btQuantizedBvh();

    public static final native void delete_btQuantizedBvh(long var0);

    public static final native void btQuantizedBvh_setQuantizationValues__SWIG_0(long var0, btQuantizedBvh var2, Vector3 var3, Vector3 var4, float var5);

    public static final native void btQuantizedBvh_setQuantizationValues__SWIG_1(long var0, btQuantizedBvh var2, Vector3 var3, Vector3 var4);

    public static final native long btQuantizedBvh_getLeafNodeArray(long var0, btQuantizedBvh var2);

    public static final native void btQuantizedBvh_buildInternal(long var0, btQuantizedBvh var2);

    public static final native void btQuantizedBvh_reportAabbOverlappingNodex(long var0, btQuantizedBvh var2, long var3, btNodeOverlapCallback var5, Vector3 var6, Vector3 var7);

    public static final native void btQuantizedBvh_reportRayOverlappingNodex(long var0, btQuantizedBvh var2, long var3, btNodeOverlapCallback var5, Vector3 var6, Vector3 var7);

    public static final native void btQuantizedBvh_reportBoxCastOverlappingNodex(long var0, btQuantizedBvh var2, long var3, btNodeOverlapCallback var5, Vector3 var6, Vector3 var7, Vector3 var8, Vector3 var9);

    public static final native void btQuantizedBvh_quantize(long var0, btQuantizedBvh var2, IntBuffer var3, Vector3 var4, int var5);

    public static final native void btQuantizedBvh_quantizeWithClamp(long var0, btQuantizedBvh var2, IntBuffer var3, Vector3 var4, int var5);

    public static final native Vector3 btQuantizedBvh_unQuantize(long var0, btQuantizedBvh var2, IntBuffer var3);

    public static final native void btQuantizedBvh_setTraversalMode(long var0, btQuantizedBvh var2, int var3);

    public static final native long btQuantizedBvh_getQuantizedNodeArray(long var0, btQuantizedBvh var2);

    public static final native long btQuantizedBvh_getSubtreeInfoArray(long var0, btQuantizedBvh var2);

    public static final native long btQuantizedBvh_calculateSerializeBufferSize(long var0, btQuantizedBvh var2);

    public static final native boolean btQuantizedBvh_serialize__SWIG_0(long var0, btQuantizedBvh var2, long var3, long var5, boolean var7);

    public static final native long btQuantizedBvh_deSerializeInPlace(long var0, long var2, boolean var4);

    public static final native long btQuantizedBvh_getAlignmentSerializationPadding();

    public static final native int btQuantizedBvh_calculateSerializeBufferSizeNew(long var0, btQuantizedBvh var2);

    public static final native String btQuantizedBvh_serialize__SWIG_1(long var0, btQuantizedBvh var2, long var3, long var5, btSerializer var7);

    public static final native void btQuantizedBvh_deSerializeFloat(long var0, btQuantizedBvh var2, long var3, btQuantizedBvhFloatData var5);

    public static final native void btQuantizedBvh_deSerializeDouble(long var0, btQuantizedBvh var2, long var3, btQuantizedBvhDoubleData var5);

    public static final native boolean btQuantizedBvh_isQuantized(long var0, btQuantizedBvh var2);

    public static final native void btBvhSubtreeInfoData_rootNodeIndex_set(long var0, btBvhSubtreeInfoData var2, int var3);

    public static final native int btBvhSubtreeInfoData_rootNodeIndex_get(long var0, btBvhSubtreeInfoData var2);

    public static final native void btBvhSubtreeInfoData_subtreeSize_set(long var0, btBvhSubtreeInfoData var2, int var3);

    public static final native int btBvhSubtreeInfoData_subtreeSize_get(long var0, btBvhSubtreeInfoData var2);

    public static final native void btBvhSubtreeInfoData_quantizedAabbMin_set(long var0, btBvhSubtreeInfoData var2, int[] var3);

    public static final native int[] btBvhSubtreeInfoData_quantizedAabbMin_get(long var0, btBvhSubtreeInfoData var2);

    public static final native void btBvhSubtreeInfoData_quantizedAabbMax_set(long var0, btBvhSubtreeInfoData var2, int[] var3);

    public static final native int[] btBvhSubtreeInfoData_quantizedAabbMax_get(long var0, btBvhSubtreeInfoData var2);

    public static final native long new_btBvhSubtreeInfoData();

    public static final native void delete_btBvhSubtreeInfoData(long var0);

    public static final native void btOptimizedBvhNodeFloatData_aabbMinOrg_set(long var0, btOptimizedBvhNodeFloatData var2, long var3, btVector3FloatData var5);

    public static final native long btOptimizedBvhNodeFloatData_aabbMinOrg_get(long var0, btOptimizedBvhNodeFloatData var2);

    public static final native void btOptimizedBvhNodeFloatData_aabbMaxOrg_set(long var0, btOptimizedBvhNodeFloatData var2, long var3, btVector3FloatData var5);

    public static final native long btOptimizedBvhNodeFloatData_aabbMaxOrg_get(long var0, btOptimizedBvhNodeFloatData var2);

    public static final native void btOptimizedBvhNodeFloatData_escapeIndex_set(long var0, btOptimizedBvhNodeFloatData var2, int var3);

    public static final native int btOptimizedBvhNodeFloatData_escapeIndex_get(long var0, btOptimizedBvhNodeFloatData var2);

    public static final native void btOptimizedBvhNodeFloatData_subPart_set(long var0, btOptimizedBvhNodeFloatData var2, int var3);

    public static final native int btOptimizedBvhNodeFloatData_subPart_get(long var0, btOptimizedBvhNodeFloatData var2);

    public static final native void btOptimizedBvhNodeFloatData_triangleIndex_set(long var0, btOptimizedBvhNodeFloatData var2, int var3);

    public static final native int btOptimizedBvhNodeFloatData_triangleIndex_get(long var0, btOptimizedBvhNodeFloatData var2);

    public static final native void btOptimizedBvhNodeFloatData_pad_set(long var0, btOptimizedBvhNodeFloatData var2, String var3);

    public static final native String btOptimizedBvhNodeFloatData_pad_get(long var0, btOptimizedBvhNodeFloatData var2);

    public static final native long new_btOptimizedBvhNodeFloatData();

    public static final native void delete_btOptimizedBvhNodeFloatData(long var0);

    public static final native void btOptimizedBvhNodeDoubleData_aabbMinOrg_set(long var0, btOptimizedBvhNodeDoubleData var2, long var3, btVector3DoubleData var5);

    public static final native long btOptimizedBvhNodeDoubleData_aabbMinOrg_get(long var0, btOptimizedBvhNodeDoubleData var2);

    public static final native void btOptimizedBvhNodeDoubleData_aabbMaxOrg_set(long var0, btOptimizedBvhNodeDoubleData var2, long var3, btVector3DoubleData var5);

    public static final native long btOptimizedBvhNodeDoubleData_aabbMaxOrg_get(long var0, btOptimizedBvhNodeDoubleData var2);

    public static final native void btOptimizedBvhNodeDoubleData_escapeIndex_set(long var0, btOptimizedBvhNodeDoubleData var2, int var3);

    public static final native int btOptimizedBvhNodeDoubleData_escapeIndex_get(long var0, btOptimizedBvhNodeDoubleData var2);

    public static final native void btOptimizedBvhNodeDoubleData_subPart_set(long var0, btOptimizedBvhNodeDoubleData var2, int var3);

    public static final native int btOptimizedBvhNodeDoubleData_subPart_get(long var0, btOptimizedBvhNodeDoubleData var2);

    public static final native void btOptimizedBvhNodeDoubleData_triangleIndex_set(long var0, btOptimizedBvhNodeDoubleData var2, int var3);

    public static final native int btOptimizedBvhNodeDoubleData_triangleIndex_get(long var0, btOptimizedBvhNodeDoubleData var2);

    public static final native void btOptimizedBvhNodeDoubleData_pad_set(long var0, btOptimizedBvhNodeDoubleData var2, String var3);

    public static final native String btOptimizedBvhNodeDoubleData_pad_get(long var0, btOptimizedBvhNodeDoubleData var2);

    public static final native long new_btOptimizedBvhNodeDoubleData();

    public static final native void delete_btOptimizedBvhNodeDoubleData(long var0);

    public static final native void btQuantizedBvhNodeData_quantizedAabbMin_set(long var0, btQuantizedBvhNodeData var2, int[] var3);

    public static final native int[] btQuantizedBvhNodeData_quantizedAabbMin_get(long var0, btQuantizedBvhNodeData var2);

    public static final native void btQuantizedBvhNodeData_quantizedAabbMax_set(long var0, btQuantizedBvhNodeData var2, int[] var3);

    public static final native int[] btQuantizedBvhNodeData_quantizedAabbMax_get(long var0, btQuantizedBvhNodeData var2);

    public static final native void btQuantizedBvhNodeData_escapeIndexOrTriangleIndex_set(long var0, btQuantizedBvhNodeData var2, int var3);

    public static final native int btQuantizedBvhNodeData_escapeIndexOrTriangleIndex_get(long var0, btQuantizedBvhNodeData var2);

    public static final native long new_btQuantizedBvhNodeData();

    public static final native void delete_btQuantizedBvhNodeData(long var0);

    public static final native void btQuantizedBvhFloatData_bvhAabbMin_set(long var0, btQuantizedBvhFloatData var2, long var3, btVector3FloatData var5);

    public static final native long btQuantizedBvhFloatData_bvhAabbMin_get(long var0, btQuantizedBvhFloatData var2);

    public static final native void btQuantizedBvhFloatData_bvhAabbMax_set(long var0, btQuantizedBvhFloatData var2, long var3, btVector3FloatData var5);

    public static final native long btQuantizedBvhFloatData_bvhAabbMax_get(long var0, btQuantizedBvhFloatData var2);

    public static final native void btQuantizedBvhFloatData_bvhQuantization_set(long var0, btQuantizedBvhFloatData var2, long var3, btVector3FloatData var5);

    public static final native long btQuantizedBvhFloatData_bvhQuantization_get(long var0, btQuantizedBvhFloatData var2);

    public static final native void btQuantizedBvhFloatData_curNodeIndex_set(long var0, btQuantizedBvhFloatData var2, int var3);

    public static final native int btQuantizedBvhFloatData_curNodeIndex_get(long var0, btQuantizedBvhFloatData var2);

    public static final native void btQuantizedBvhFloatData_useQuantization_set(long var0, btQuantizedBvhFloatData var2, int var3);

    public static final native int btQuantizedBvhFloatData_useQuantization_get(long var0, btQuantizedBvhFloatData var2);

    public static final native void btQuantizedBvhFloatData_numContiguousLeafNodes_set(long var0, btQuantizedBvhFloatData var2, int var3);

    public static final native int btQuantizedBvhFloatData_numContiguousLeafNodes_get(long var0, btQuantizedBvhFloatData var2);

    public static final native void btQuantizedBvhFloatData_numQuantizedContiguousNodes_set(long var0, btQuantizedBvhFloatData var2, int var3);

    public static final native int btQuantizedBvhFloatData_numQuantizedContiguousNodes_get(long var0, btQuantizedBvhFloatData var2);

    public static final native void btQuantizedBvhFloatData_contiguousNodesPtr_set(long var0, btQuantizedBvhFloatData var2, long var3, btOptimizedBvhNodeFloatData var5);

    public static final native long btQuantizedBvhFloatData_contiguousNodesPtr_get(long var0, btQuantizedBvhFloatData var2);

    public static final native void btQuantizedBvhFloatData_quantizedContiguousNodesPtr_set(long var0, btQuantizedBvhFloatData var2, long var3, btQuantizedBvhNodeData var5);

    public static final native long btQuantizedBvhFloatData_quantizedContiguousNodesPtr_get(long var0, btQuantizedBvhFloatData var2);

    public static final native void btQuantizedBvhFloatData_subTreeInfoPtr_set(long var0, btQuantizedBvhFloatData var2, long var3, btBvhSubtreeInfoData var5);

    public static final native long btQuantizedBvhFloatData_subTreeInfoPtr_get(long var0, btQuantizedBvhFloatData var2);

    public static final native void btQuantizedBvhFloatData_traversalMode_set(long var0, btQuantizedBvhFloatData var2, int var3);

    public static final native int btQuantizedBvhFloatData_traversalMode_get(long var0, btQuantizedBvhFloatData var2);

    public static final native void btQuantizedBvhFloatData_numSubtreeHeaders_set(long var0, btQuantizedBvhFloatData var2, int var3);

    public static final native int btQuantizedBvhFloatData_numSubtreeHeaders_get(long var0, btQuantizedBvhFloatData var2);

    public static final native long new_btQuantizedBvhFloatData();

    public static final native void delete_btQuantizedBvhFloatData(long var0);

    public static final native void btQuantizedBvhDoubleData_bvhAabbMin_set(long var0, btQuantizedBvhDoubleData var2, long var3, btVector3DoubleData var5);

    public static final native long btQuantizedBvhDoubleData_bvhAabbMin_get(long var0, btQuantizedBvhDoubleData var2);

    public static final native void btQuantizedBvhDoubleData_bvhAabbMax_set(long var0, btQuantizedBvhDoubleData var2, long var3, btVector3DoubleData var5);

    public static final native long btQuantizedBvhDoubleData_bvhAabbMax_get(long var0, btQuantizedBvhDoubleData var2);

    public static final native void btQuantizedBvhDoubleData_bvhQuantization_set(long var0, btQuantizedBvhDoubleData var2, long var3, btVector3DoubleData var5);

    public static final native long btQuantizedBvhDoubleData_bvhQuantization_get(long var0, btQuantizedBvhDoubleData var2);

    public static final native void btQuantizedBvhDoubleData_curNodeIndex_set(long var0, btQuantizedBvhDoubleData var2, int var3);

    public static final native int btQuantizedBvhDoubleData_curNodeIndex_get(long var0, btQuantizedBvhDoubleData var2);

    public static final native void btQuantizedBvhDoubleData_useQuantization_set(long var0, btQuantizedBvhDoubleData var2, int var3);

    public static final native int btQuantizedBvhDoubleData_useQuantization_get(long var0, btQuantizedBvhDoubleData var2);

    public static final native void btQuantizedBvhDoubleData_numContiguousLeafNodes_set(long var0, btQuantizedBvhDoubleData var2, int var3);

    public static final native int btQuantizedBvhDoubleData_numContiguousLeafNodes_get(long var0, btQuantizedBvhDoubleData var2);

    public static final native void btQuantizedBvhDoubleData_numQuantizedContiguousNodes_set(long var0, btQuantizedBvhDoubleData var2, int var3);

    public static final native int btQuantizedBvhDoubleData_numQuantizedContiguousNodes_get(long var0, btQuantizedBvhDoubleData var2);

    public static final native void btQuantizedBvhDoubleData_contiguousNodesPtr_set(long var0, btQuantizedBvhDoubleData var2, long var3, btOptimizedBvhNodeDoubleData var5);

    public static final native long btQuantizedBvhDoubleData_contiguousNodesPtr_get(long var0, btQuantizedBvhDoubleData var2);

    public static final native void btQuantizedBvhDoubleData_quantizedContiguousNodesPtr_set(long var0, btQuantizedBvhDoubleData var2, long var3, btQuantizedBvhNodeData var5);

    public static final native long btQuantizedBvhDoubleData_quantizedContiguousNodesPtr_get(long var0, btQuantizedBvhDoubleData var2);

    public static final native void btQuantizedBvhDoubleData_traversalMode_set(long var0, btQuantizedBvhDoubleData var2, int var3);

    public static final native int btQuantizedBvhDoubleData_traversalMode_get(long var0, btQuantizedBvhDoubleData var2);

    public static final native void btQuantizedBvhDoubleData_numSubtreeHeaders_set(long var0, btQuantizedBvhDoubleData var2, int var3);

    public static final native int btQuantizedBvhDoubleData_numSubtreeHeaders_get(long var0, btQuantizedBvhDoubleData var2);

    public static final native void btQuantizedBvhDoubleData_subTreeInfoPtr_set(long var0, btQuantizedBvhDoubleData var2, long var3, btBvhSubtreeInfoData var5);

    public static final native long btQuantizedBvhDoubleData_subTreeInfoPtr_get(long var0, btQuantizedBvhDoubleData var2);

    public static final native long new_btQuantizedBvhDoubleData();

    public static final native void delete_btQuantizedBvhDoubleData(long var0);

    public static final native void btSimpleBroadphaseProxy_nextFree_set(long var0, btSimpleBroadphaseProxy var2, int var3);

    public static final native int btSimpleBroadphaseProxy_nextFree_get(long var0, btSimpleBroadphaseProxy var2);

    public static final native long new_btSimpleBroadphaseProxy__SWIG_0();

    public static final native long new_btSimpleBroadphaseProxy__SWIG_1(Vector3 var0, Vector3 var1, int var2, long var3, int var5, int var6);

    public static final native void btSimpleBroadphaseProxy_SetNextFree(long var0, btSimpleBroadphaseProxy var2, int var3);

    public static final native int btSimpleBroadphaseProxy_GetNextFree(long var0, btSimpleBroadphaseProxy var2);

    public static final native void delete_btSimpleBroadphaseProxy(long var0);

    public static final native long new_btSimpleBroadphase__SWIG_0(int var0, long var1, btOverlappingPairCache var3);

    public static final native long new_btSimpleBroadphase__SWIG_1(int var0);

    public static final native long new_btSimpleBroadphase__SWIG_2();

    public static final native void delete_btSimpleBroadphase(long var0);

    public static final native boolean btSimpleBroadphase_aabbOverlap(long var0, btSimpleBroadphaseProxy var2, long var3, btSimpleBroadphaseProxy var5);

    public static final native void btSimpleBroadphase_rayTest__SWIG_0(long var0, btSimpleBroadphase var2, Vector3 var3, Vector3 var4, long var5, btBroadphaseRayCallback var7, Vector3 var8, Vector3 var9);

    public static final native void btSimpleBroadphase_rayTest__SWIG_1(long var0, btSimpleBroadphase var2, Vector3 var3, Vector3 var4, long var5, btBroadphaseRayCallback var7, Vector3 var8);

    public static final native void btSimpleBroadphase_rayTest__SWIG_2(long var0, btSimpleBroadphase var2, Vector3 var3, Vector3 var4, long var5, btBroadphaseRayCallback var7);

    public static final native boolean btSimpleBroadphase_testAabbOverlap(long var0, btSimpleBroadphase var2, long var3, btBroadphaseProxy var5, long var6, btBroadphaseProxy var8);

    public static final native long new_btCollisionAlgorithmConstructionInfo__SWIG_0();

    public static final native long new_btCollisionAlgorithmConstructionInfo__SWIG_1(long var0, btDispatcher var2, int var3);

    public static final native void btCollisionAlgorithmConstructionInfo_dispatcher1_set(long var0, btCollisionAlgorithmConstructionInfo var2, long var3, btDispatcher var5);

    public static final native long btCollisionAlgorithmConstructionInfo_dispatcher1_get(long var0, btCollisionAlgorithmConstructionInfo var2);

    public static final native void btCollisionAlgorithmConstructionInfo_manifold_set(long var0, btCollisionAlgorithmConstructionInfo var2, long var3, btPersistentManifold var5);

    public static final native long btCollisionAlgorithmConstructionInfo_manifold_get(long var0, btCollisionAlgorithmConstructionInfo var2);

    public static final native void delete_btCollisionAlgorithmConstructionInfo(long var0);

    public static final native void delete_btCollisionAlgorithm(long var0);

    public static final native void btCollisionAlgorithm_processCollision(long var0, btCollisionAlgorithm var2, long var3, btCollisionObjectWrapper var5, long var6, btCollisionObjectWrapper var8, long var9, btDispatcherInfo var11, long var12, btManifoldResult var14);

    public static final native float btCollisionAlgorithm_calculateTimeOfImpact(long var0, btCollisionAlgorithm var2, long var3, btCollisionObject var5, long var6, btCollisionObject var8, long var9, btDispatcherInfo var11, long var12, btManifoldResult var14);

    public static final native void btCollisionAlgorithm_getAllContactManifolds(long var0, btCollisionAlgorithm var2, long var3, btPersistentManifoldArray var5);

    public static final native void delete_btOverlappingPairCallback(long var0);

    public static final native long btOverlappingPairCallback_addOverlappingPair(long var0, btOverlappingPairCallback var2, long var3, btBroadphaseProxy var5, long var6, btBroadphaseProxy var8);

    public static final native long btOverlappingPairCallback_removeOverlappingPair(long var0, btOverlappingPairCallback var2, long var3, btBroadphaseProxy var5, long var6, btBroadphaseProxy var8, long var9, btDispatcher var11);

    public static final native void btOverlappingPairCallback_removeOverlappingPairsContainingProxy(long var0, btOverlappingPairCallback var2, long var3, btBroadphaseProxy var5, long var6, btDispatcher var8);

    public static final native void gOverlappingPairs_set(int var0);

    public static final native int gOverlappingPairs_get();

    public static final native long btAxisSweep3InternalShort_operatorNew__SWIG_0(long var0, btAxisSweep3InternalShort var2, long var3);

    public static final native void btAxisSweep3InternalShort_operatorDelete__SWIG_0(long var0, btAxisSweep3InternalShort var2, long var3);

    public static final native long btAxisSweep3InternalShort_operatorNew__SWIG_1(long var0, btAxisSweep3InternalShort var2, long var3, long var5);

    public static final native void btAxisSweep3InternalShort_operatorDelete__SWIG_1(long var0, btAxisSweep3InternalShort var2, long var3, long var5);

    public static final native long btAxisSweep3InternalShort_operatorNewArray__SWIG_0(long var0, btAxisSweep3InternalShort var2, long var3);

    public static final native void btAxisSweep3InternalShort_operatorDeleteArray__SWIG_0(long var0, btAxisSweep3InternalShort var2, long var3);

    public static final native long btAxisSweep3InternalShort_operatorNewArray__SWIG_1(long var0, btAxisSweep3InternalShort var2, long var3, long var5);

    public static final native void btAxisSweep3InternalShort_operatorDeleteArray__SWIG_1(long var0, btAxisSweep3InternalShort var2, long var3, long var5);

    public static final native void btAxisSweep3InternalShort_Edge_pos_set(long var0, btAxisSweep3InternalShort.Edge var2, int var3);

    public static final native int btAxisSweep3InternalShort_Edge_pos_get(long var0, btAxisSweep3InternalShort.Edge var2);

    public static final native void btAxisSweep3InternalShort_Edge_handle_set(long var0, btAxisSweep3InternalShort.Edge var2, int var3);

    public static final native int btAxisSweep3InternalShort_Edge_handle_get(long var0, btAxisSweep3InternalShort.Edge var2);

    public static final native int btAxisSweep3InternalShort_Edge_IsMax(long var0, btAxisSweep3InternalShort.Edge var2);

    public static final native long new_btAxisSweep3InternalShort_Edge();

    public static final native void delete_btAxisSweep3InternalShort_Edge(long var0);

    public static final native long btAxisSweep3InternalShort_Handle_operatorNew__SWIG_0(long var0, btAxisSweep3InternalShort.Handle var2, long var3);

    public static final native void btAxisSweep3InternalShort_Handle_operatorDelete__SWIG_0(long var0, btAxisSweep3InternalShort.Handle var2, long var3);

    public static final native long btAxisSweep3InternalShort_Handle_operatorNew__SWIG_1(long var0, btAxisSweep3InternalShort.Handle var2, long var3, long var5);

    public static final native void btAxisSweep3InternalShort_Handle_operatorDelete__SWIG_1(long var0, btAxisSweep3InternalShort.Handle var2, long var3, long var5);

    public static final native long btAxisSweep3InternalShort_Handle_operatorNewArray__SWIG_0(long var0, btAxisSweep3InternalShort.Handle var2, long var3);

    public static final native void btAxisSweep3InternalShort_Handle_operatorDeleteArray__SWIG_0(long var0, btAxisSweep3InternalShort.Handle var2, long var3);

    public static final native long btAxisSweep3InternalShort_Handle_operatorNewArray__SWIG_1(long var0, btAxisSweep3InternalShort.Handle var2, long var3, long var5);

    public static final native void btAxisSweep3InternalShort_Handle_operatorDeleteArray__SWIG_1(long var0, btAxisSweep3InternalShort.Handle var2, long var3, long var5);

    public static final native void btAxisSweep3InternalShort_Handle_minEdges_set(long var0, btAxisSweep3InternalShort.Handle var2, int[] var3);

    public static final native int[] btAxisSweep3InternalShort_Handle_minEdges_get(long var0, btAxisSweep3InternalShort.Handle var2);

    public static final native void btAxisSweep3InternalShort_Handle_maxEdges_set(long var0, btAxisSweep3InternalShort.Handle var2, int[] var3);

    public static final native int[] btAxisSweep3InternalShort_Handle_maxEdges_get(long var0, btAxisSweep3InternalShort.Handle var2);

    public static final native void btAxisSweep3InternalShort_Handle_dbvtProxy_set(long var0, btAxisSweep3InternalShort.Handle var2, long var3, btBroadphaseProxy var5);

    public static final native long btAxisSweep3InternalShort_Handle_dbvtProxy_get(long var0, btAxisSweep3InternalShort.Handle var2);

    public static final native void btAxisSweep3InternalShort_Handle_SetNextFree(long var0, btAxisSweep3InternalShort.Handle var2, int var3);

    public static final native int btAxisSweep3InternalShort_Handle_GetNextFree(long var0, btAxisSweep3InternalShort.Handle var2);

    public static final native long new_btAxisSweep3InternalShort_Handle();

    public static final native void delete_btAxisSweep3InternalShort_Handle(long var0);

    public static final native long new_btAxisSweep3InternalShort__SWIG_0(Vector3 var0, Vector3 var1, int var2, int var3, int var4, long var5, btOverlappingPairCache var7, boolean var8);

    public static final native long new_btAxisSweep3InternalShort__SWIG_1(Vector3 var0, Vector3 var1, int var2, int var3, int var4, long var5, btOverlappingPairCache var7);

    public static final native long new_btAxisSweep3InternalShort__SWIG_2(Vector3 var0, Vector3 var1, int var2, int var3, int var4);

    public static final native long new_btAxisSweep3InternalShort__SWIG_3(Vector3 var0, Vector3 var1, int var2, int var3);

    public static final native void delete_btAxisSweep3InternalShort(long var0);

    public static final native int btAxisSweep3InternalShort_getNumHandles(long var0, btAxisSweep3InternalShort var2);

    public static final native int btAxisSweep3InternalShort_addHandle(long var0, btAxisSweep3InternalShort var2, Vector3 var3, Vector3 var4, long var5, int var7, int var8, long var9, btDispatcher var11);

    public static final native void btAxisSweep3InternalShort_removeHandle(long var0, btAxisSweep3InternalShort var2, int var3, long var4, btDispatcher var6);

    public static final native void btAxisSweep3InternalShort_updateHandle(long var0, btAxisSweep3InternalShort var2, int var3, Vector3 var4, Vector3 var5, long var6, btDispatcher var8);

    public static final native long btAxisSweep3InternalShort_getHandle(long var0, btAxisSweep3InternalShort var2, int var3);

    public static final native void btAxisSweep3InternalShort_rayTest__SWIG_0(long var0, btAxisSweep3InternalShort var2, Vector3 var3, Vector3 var4, long var5, btBroadphaseRayCallback var7, Vector3 var8, Vector3 var9);

    public static final native void btAxisSweep3InternalShort_rayTest__SWIG_1(long var0, btAxisSweep3InternalShort var2, Vector3 var3, Vector3 var4, long var5, btBroadphaseRayCallback var7, Vector3 var8);

    public static final native void btAxisSweep3InternalShort_rayTest__SWIG_2(long var0, btAxisSweep3InternalShort var2, Vector3 var3, Vector3 var4, long var5, btBroadphaseRayCallback var7);

    public static final native void btAxisSweep3InternalShort_quantize(long var0, btAxisSweep3InternalShort var2, IntBuffer var3, Vector3 var4, int var5);

    public static final native void btAxisSweep3InternalShort_unQuantize(long var0, btAxisSweep3InternalShort var2, long var3, btBroadphaseProxy var5, Vector3 var6, Vector3 var7);

    public static final native boolean btAxisSweep3InternalShort_testAabbOverlap(long var0, btAxisSweep3InternalShort var2, long var3, btBroadphaseProxy var5, long var6, btBroadphaseProxy var8);

    public static final native void btAxisSweep3InternalShort_setOverlappingPairUserCallback(long var0, btAxisSweep3InternalShort var2, long var3, btOverlappingPairCallback var5);

    public static final native long btAxisSweep3InternalShort_getOverlappingPairUserCallback(long var0, btAxisSweep3InternalShort var2);

    public static final native long btAxisSweep3InternalInt_operatorNew__SWIG_0(long var0, btAxisSweep3InternalInt var2, long var3);

    public static final native void btAxisSweep3InternalInt_operatorDelete__SWIG_0(long var0, btAxisSweep3InternalInt var2, long var3);

    public static final native long btAxisSweep3InternalInt_operatorNew__SWIG_1(long var0, btAxisSweep3InternalInt var2, long var3, long var5);

    public static final native void btAxisSweep3InternalInt_operatorDelete__SWIG_1(long var0, btAxisSweep3InternalInt var2, long var3, long var5);

    public static final native long btAxisSweep3InternalInt_operatorNewArray__SWIG_0(long var0, btAxisSweep3InternalInt var2, long var3);

    public static final native void btAxisSweep3InternalInt_operatorDeleteArray__SWIG_0(long var0, btAxisSweep3InternalInt var2, long var3);

    public static final native long btAxisSweep3InternalInt_operatorNewArray__SWIG_1(long var0, btAxisSweep3InternalInt var2, long var3, long var5);

    public static final native void btAxisSweep3InternalInt_operatorDeleteArray__SWIG_1(long var0, btAxisSweep3InternalInt var2, long var3, long var5);

    public static final native void btAxisSweep3InternalInt_Edge_pos_set(long var0, btAxisSweep3InternalInt.Edge var2, long var3);

    public static final native long btAxisSweep3InternalInt_Edge_pos_get(long var0, btAxisSweep3InternalInt.Edge var2);

    public static final native void btAxisSweep3InternalInt_Edge_handle_set(long var0, btAxisSweep3InternalInt.Edge var2, long var3);

    public static final native long btAxisSweep3InternalInt_Edge_handle_get(long var0, btAxisSweep3InternalInt.Edge var2);

    public static final native long btAxisSweep3InternalInt_Edge_IsMax(long var0, btAxisSweep3InternalInt.Edge var2);

    public static final native long new_btAxisSweep3InternalInt_Edge();

    public static final native void delete_btAxisSweep3InternalInt_Edge(long var0);

    public static final native long btAxisSweep3InternalInt_Handle_operatorNew__SWIG_0(long var0, btAxisSweep3InternalInt.Handle var2, long var3);

    public static final native void btAxisSweep3InternalInt_Handle_operatorDelete__SWIG_0(long var0, btAxisSweep3InternalInt.Handle var2, long var3);

    public static final native long btAxisSweep3InternalInt_Handle_operatorNew__SWIG_1(long var0, btAxisSweep3InternalInt.Handle var2, long var3, long var5);

    public static final native void btAxisSweep3InternalInt_Handle_operatorDelete__SWIG_1(long var0, btAxisSweep3InternalInt.Handle var2, long var3, long var5);

    public static final native long btAxisSweep3InternalInt_Handle_operatorNewArray__SWIG_0(long var0, btAxisSweep3InternalInt.Handle var2, long var3);

    public static final native void btAxisSweep3InternalInt_Handle_operatorDeleteArray__SWIG_0(long var0, btAxisSweep3InternalInt.Handle var2, long var3);

    public static final native long btAxisSweep3InternalInt_Handle_operatorNewArray__SWIG_1(long var0, btAxisSweep3InternalInt.Handle var2, long var3, long var5);

    public static final native void btAxisSweep3InternalInt_Handle_operatorDeleteArray__SWIG_1(long var0, btAxisSweep3InternalInt.Handle var2, long var3, long var5);

    public static final native void btAxisSweep3InternalInt_Handle_minEdges_set(long var0, btAxisSweep3InternalInt.Handle var2, long[] var3);

    public static final native long[] btAxisSweep3InternalInt_Handle_minEdges_get(long var0, btAxisSweep3InternalInt.Handle var2);

    public static final native void btAxisSweep3InternalInt_Handle_maxEdges_set(long var0, btAxisSweep3InternalInt.Handle var2, long[] var3);

    public static final native long[] btAxisSweep3InternalInt_Handle_maxEdges_get(long var0, btAxisSweep3InternalInt.Handle var2);

    public static final native void btAxisSweep3InternalInt_Handle_dbvtProxy_set(long var0, btAxisSweep3InternalInt.Handle var2, long var3, btBroadphaseProxy var5);

    public static final native long btAxisSweep3InternalInt_Handle_dbvtProxy_get(long var0, btAxisSweep3InternalInt.Handle var2);

    public static final native void btAxisSweep3InternalInt_Handle_SetNextFree(long var0, btAxisSweep3InternalInt.Handle var2, long var3);

    public static final native long btAxisSweep3InternalInt_Handle_GetNextFree(long var0, btAxisSweep3InternalInt.Handle var2);

    public static final native long new_btAxisSweep3InternalInt_Handle();

    public static final native void delete_btAxisSweep3InternalInt_Handle(long var0);

    public static final native long new_btAxisSweep3InternalInt__SWIG_0(Vector3 var0, Vector3 var1, long var2, long var4, long var6, long var8, btOverlappingPairCache var10, boolean var11);

    public static final native long new_btAxisSweep3InternalInt__SWIG_1(Vector3 var0, Vector3 var1, long var2, long var4, long var6, long var8, btOverlappingPairCache var10);

    public static final native long new_btAxisSweep3InternalInt__SWIG_2(Vector3 var0, Vector3 var1, long var2, long var4, long var6);

    public static final native long new_btAxisSweep3InternalInt__SWIG_3(Vector3 var0, Vector3 var1, long var2, long var4);

    public static final native void delete_btAxisSweep3InternalInt(long var0);

    public static final native long btAxisSweep3InternalInt_getNumHandles(long var0, btAxisSweep3InternalInt var2);

    public static final native long btAxisSweep3InternalInt_addHandle(long var0, btAxisSweep3InternalInt var2, Vector3 var3, Vector3 var4, long var5, int var7, int var8, long var9, btDispatcher var11);

    public static final native void btAxisSweep3InternalInt_removeHandle(long var0, btAxisSweep3InternalInt var2, long var3, long var5, btDispatcher var7);

    public static final native void btAxisSweep3InternalInt_updateHandle(long var0, btAxisSweep3InternalInt var2, long var3, Vector3 var5, Vector3 var6, long var7, btDispatcher var9);

    public static final native long btAxisSweep3InternalInt_getHandle(long var0, btAxisSweep3InternalInt var2, long var3);

    public static final native void btAxisSweep3InternalInt_rayTest__SWIG_0(long var0, btAxisSweep3InternalInt var2, Vector3 var3, Vector3 var4, long var5, btBroadphaseRayCallback var7, Vector3 var8, Vector3 var9);

    public static final native void btAxisSweep3InternalInt_rayTest__SWIG_1(long var0, btAxisSweep3InternalInt var2, Vector3 var3, Vector3 var4, long var5, btBroadphaseRayCallback var7, Vector3 var8);

    public static final native void btAxisSweep3InternalInt_rayTest__SWIG_2(long var0, btAxisSweep3InternalInt var2, Vector3 var3, Vector3 var4, long var5, btBroadphaseRayCallback var7);

    public static final native void btAxisSweep3InternalInt_quantize(long var0, btAxisSweep3InternalInt var2, LongBuffer var3, Vector3 var4, int var5);

    public static final native void btAxisSweep3InternalInt_unQuantize(long var0, btAxisSweep3InternalInt var2, long var3, btBroadphaseProxy var5, Vector3 var6, Vector3 var7);

    public static final native boolean btAxisSweep3InternalInt_testAabbOverlap(long var0, btAxisSweep3InternalInt var2, long var3, btBroadphaseProxy var5, long var6, btBroadphaseProxy var8);

    public static final native void btAxisSweep3InternalInt_setOverlappingPairUserCallback(long var0, btAxisSweep3InternalInt var2, long var3, btOverlappingPairCallback var5);

    public static final native long btAxisSweep3InternalInt_getOverlappingPairUserCallback(long var0, btAxisSweep3InternalInt var2);

    public static final native long new_btAxisSweep3__SWIG_0(Vector3 var0, Vector3 var1, int var2, long var3, btOverlappingPairCache var5, boolean var6);

    public static final native long new_btAxisSweep3__SWIG_1(Vector3 var0, Vector3 var1, int var2, long var3, btOverlappingPairCache var5);

    public static final native long new_btAxisSweep3__SWIG_2(Vector3 var0, Vector3 var1, int var2);

    public static final native long new_btAxisSweep3__SWIG_3(Vector3 var0, Vector3 var1);

    public static final native void delete_btAxisSweep3(long var0);

    public static final native long new_bt32BitAxisSweep3__SWIG_0(Vector3 var0, Vector3 var1, long var2, long var4, btOverlappingPairCache var6, boolean var7);

    public static final native long new_bt32BitAxisSweep3__SWIG_1(Vector3 var0, Vector3 var1, long var2, long var4, btOverlappingPairCache var6);

    public static final native long new_bt32BitAxisSweep3__SWIG_2(Vector3 var0, Vector3 var1, long var2);

    public static final native long new_bt32BitAxisSweep3__SWIG_3(Vector3 var0, Vector3 var1);

    public static final native void delete_bt32BitAxisSweep3(long var0);

    public static final native long new_btDispatcherInfo();

    public static final native void btDispatcherInfo_timeStep_set(long var0, btDispatcherInfo var2, float var3);

    public static final native float btDispatcherInfo_timeStep_get(long var0, btDispatcherInfo var2);

    public static final native void btDispatcherInfo_stepCount_set(long var0, btDispatcherInfo var2, int var3);

    public static final native int btDispatcherInfo_stepCount_get(long var0, btDispatcherInfo var2);

    public static final native void btDispatcherInfo_dispatchFunc_set(long var0, btDispatcherInfo var2, int var3);

    public static final native int btDispatcherInfo_dispatchFunc_get(long var0, btDispatcherInfo var2);

    public static final native void btDispatcherInfo_timeOfImpact_set(long var0, btDispatcherInfo var2, float var3);

    public static final native float btDispatcherInfo_timeOfImpact_get(long var0, btDispatcherInfo var2);

    public static final native void btDispatcherInfo_useContinuous_set(long var0, btDispatcherInfo var2, boolean var3);

    public static final native boolean btDispatcherInfo_useContinuous_get(long var0, btDispatcherInfo var2);

    public static final native void btDispatcherInfo_debugDraw_set(long var0, btDispatcherInfo var2, long var3, btIDebugDraw var5);

    public static final native long btDispatcherInfo_debugDraw_get(long var0, btDispatcherInfo var2);

    public static final native void btDispatcherInfo_enableSatConvex_set(long var0, btDispatcherInfo var2, boolean var3);

    public static final native boolean btDispatcherInfo_enableSatConvex_get(long var0, btDispatcherInfo var2);

    public static final native void btDispatcherInfo_enableSPU_set(long var0, btDispatcherInfo var2, boolean var3);

    public static final native boolean btDispatcherInfo_enableSPU_get(long var0, btDispatcherInfo var2);

    public static final native void btDispatcherInfo_useEpa_set(long var0, btDispatcherInfo var2, boolean var3);

    public static final native boolean btDispatcherInfo_useEpa_get(long var0, btDispatcherInfo var2);

    public static final native void btDispatcherInfo_allowedCcdPenetration_set(long var0, btDispatcherInfo var2, float var3);

    public static final native float btDispatcherInfo_allowedCcdPenetration_get(long var0, btDispatcherInfo var2);

    public static final native void btDispatcherInfo_useConvexConservativeDistanceUtil_set(long var0, btDispatcherInfo var2, boolean var3);

    public static final native boolean btDispatcherInfo_useConvexConservativeDistanceUtil_get(long var0, btDispatcherInfo var2);

    public static final native void btDispatcherInfo_convexConservativeDistanceThreshold_set(long var0, btDispatcherInfo var2, float var3);

    public static final native float btDispatcherInfo_convexConservativeDistanceThreshold_get(long var0, btDispatcherInfo var2);

    public static final native void delete_btDispatcherInfo(long var0);

    public static final native void delete_btDispatcher(long var0);

    public static final native long btDispatcher_findAlgorithm(long var0, btDispatcher var2, long var3, btCollisionObjectWrapper var5, long var6, btCollisionObjectWrapper var8, long var9, btPersistentManifold var11, int var12);

    public static final native long btDispatcher_getNewManifold(long var0, btDispatcher var2, long var3, btCollisionObject var5, long var6, btCollisionObject var8);

    public static final native void btDispatcher_releaseManifold(long var0, btDispatcher var2, long var3, btPersistentManifold var5);

    public static final native void btDispatcher_clearManifold(long var0, btDispatcher var2, long var3, btPersistentManifold var5);

    public static final native boolean btDispatcher_needsCollision(long var0, btDispatcher var2, long var3, btCollisionObject var5, long var6, btCollisionObject var8);

    public static final native boolean btDispatcher_needsResponse(long var0, btDispatcher var2, long var3, btCollisionObject var5, long var6, btCollisionObject var8);

    public static final native void btDispatcher_dispatchAllCollisionPairs(long var0, btDispatcher var2, long var3, btOverlappingPairCache var5, long var6, btDispatcherInfo var8, long var9, btDispatcher var11);

    public static final native int btDispatcher_getNumManifolds(long var0, btDispatcher var2);

    public static final native long btDispatcher_getManifoldByIndexInternal(long var0, btDispatcher var2, int var3);

    public static final native long btDispatcher_getInternalManifoldPointer(long var0, btDispatcher var2);

    public static final native long btDispatcher_getInternalManifoldPool(long var0, btDispatcher var2);

    public static final native long btDispatcher_getInternalManifoldPoolConst(long var0, btDispatcher var2);

    public static final native long btDispatcher_allocateCollisionAlgorithm(long var0, btDispatcher var2, int var3);

    public static final native void btDispatcher_freeCollisionAlgorithm(long var0, btDispatcher var2, long var3);

    public static final native void delete_btOverlapCallback(long var0);

    public static final native boolean btOverlapCallback_processOverlap(long var0, btOverlapCallback var2, btBroadphasePair var3);

    public static final native long new_btOverlapCallback();

    public static final native void btOverlapCallback_director_connect(btOverlapCallback var0, long var1, boolean var3, boolean var4);

    public static final native void btOverlapCallback_change_ownership(btOverlapCallback var0, long var1, boolean var3);

    public static final native void delete_btOverlapFilterCallback(long var0);

    public static final native boolean btOverlapFilterCallback_needBroadphaseCollision(long var0, btOverlapFilterCallback var2, long var3, btBroadphaseProxy var5, long var6, btBroadphaseProxy var8);

    public static final native long new_btOverlapFilterCallback();

    public static final native void btOverlapFilterCallback_director_connect(btOverlapFilterCallback var0, long var1, boolean var3, boolean var4);

    public static final native void btOverlapFilterCallback_change_ownership(btOverlapFilterCallback var0, long var1, boolean var3);

    public static final native void gRemovePairs_set(int var0);

    public static final native int gRemovePairs_get();

    public static final native void gAddedPairs_set(int var0);

    public static final native int gAddedPairs_get();

    public static final native void gFindPairs_set(int var0);

    public static final native int gFindPairs_get();

    public static final native int BT_NULL_PAIR_get();

    public static final native void delete_btOverlappingPairCache(long var0);

    public static final native long btOverlappingPairCache_getOverlappingPairArrayPtr(long var0, btOverlappingPairCache var2);

    public static final native long btOverlappingPairCache_getOverlappingPairArrayPtrConst(long var0, btOverlappingPairCache var2);

    public static final native long btOverlappingPairCache_getOverlappingPairArray(long var0, btOverlappingPairCache var2);

    public static final native void btOverlappingPairCache_cleanOverlappingPair(long var0, btOverlappingPairCache var2, btBroadphasePair var3, long var4, btDispatcher var6);

    public static final native int btOverlappingPairCache_getNumOverlappingPairs(long var0, btOverlappingPairCache var2);

    public static final native void btOverlappingPairCache_cleanProxyFromPairs(long var0, btOverlappingPairCache var2, long var3, btBroadphaseProxy var5, long var6, btDispatcher var8);

    public static final native void btOverlappingPairCache_setOverlapFilterCallback(long var0, btOverlappingPairCache var2, long var3, btOverlapFilterCallback var5);

    public static final native void btOverlappingPairCache_processAllOverlappingPairs(long var0, btOverlappingPairCache var2, long var3, btOverlapCallback var5, long var6, btDispatcher var8);

    public static final native long btOverlappingPairCache_findPair(long var0, btOverlappingPairCache var2, long var3, btBroadphaseProxy var5, long var6, btBroadphaseProxy var8);

    public static final native boolean btOverlappingPairCache_hasDeferredRemoval(long var0, btOverlappingPairCache var2);

    public static final native void btOverlappingPairCache_setInternalGhostPairCallback(long var0, btOverlappingPairCache var2, long var3, btOverlappingPairCallback var5);

    public static final native void btOverlappingPairCache_sortOverlappingPairs(long var0, btOverlappingPairCache var2, long var3, btDispatcher var5);

    public static final native long btHashedOverlappingPairCache_operatorNew__SWIG_0(long var0, btHashedOverlappingPairCache var2, long var3);

    public static final native void btHashedOverlappingPairCache_operatorDelete__SWIG_0(long var0, btHashedOverlappingPairCache var2, long var3);

    public static final native long btHashedOverlappingPairCache_operatorNew__SWIG_1(long var0, btHashedOverlappingPairCache var2, long var3, long var5);

    public static final native void btHashedOverlappingPairCache_operatorDelete__SWIG_1(long var0, btHashedOverlappingPairCache var2, long var3, long var5);

    public static final native long btHashedOverlappingPairCache_operatorNewArray__SWIG_0(long var0, btHashedOverlappingPairCache var2, long var3);

    public static final native void btHashedOverlappingPairCache_operatorDeleteArray__SWIG_0(long var0, btHashedOverlappingPairCache var2, long var3);

    public static final native long btHashedOverlappingPairCache_operatorNewArray__SWIG_1(long var0, btHashedOverlappingPairCache var2, long var3, long var5);

    public static final native void btHashedOverlappingPairCache_operatorDeleteArray__SWIG_1(long var0, btHashedOverlappingPairCache var2, long var3, long var5);

    public static final native long new_btHashedOverlappingPairCache();

    public static final native void delete_btHashedOverlappingPairCache(long var0);

    public static final native boolean btHashedOverlappingPairCache_needsBroadphaseCollision(long var0, btHashedOverlappingPairCache var2, long var3, btBroadphaseProxy var5, long var6, btBroadphaseProxy var8);

    public static final native long btHashedOverlappingPairCache_getOverlappingPairArrayConst(long var0, btHashedOverlappingPairCache var2);

    public static final native int btHashedOverlappingPairCache_GetCount(long var0, btHashedOverlappingPairCache var2);

    public static final native long btHashedOverlappingPairCache_getOverlapFilterCallback(long var0, btHashedOverlappingPairCache var2);

    public static final native long new_btSortedOverlappingPairCache();

    public static final native void delete_btSortedOverlappingPairCache(long var0);

    public static final native boolean btSortedOverlappingPairCache_needsBroadphaseCollision(long var0, btSortedOverlappingPairCache var2, long var3, btBroadphaseProxy var5, long var6, btBroadphaseProxy var8);

    public static final native long btSortedOverlappingPairCache_getOverlappingPairArrayConst(long var0, btSortedOverlappingPairCache var2);

    public static final native long btSortedOverlappingPairCache_getOverlapFilterCallback(long var0, btSortedOverlappingPairCache var2);

    public static final native long new_btNullPairCache();

    public static final native void delete_btNullPairCache(long var0);

    public static final native long btCollisionShape_operatorNew__SWIG_0(long var0, btCollisionShape var2, long var3);

    public static final native void btCollisionShape_operatorDelete__SWIG_0(long var0, btCollisionShape var2, long var3);

    public static final native long btCollisionShape_operatorNew__SWIG_1(long var0, btCollisionShape var2, long var3, long var5);

    public static final native void btCollisionShape_operatorDelete__SWIG_1(long var0, btCollisionShape var2, long var3, long var5);

    public static final native long btCollisionShape_operatorNewArray__SWIG_0(long var0, btCollisionShape var2, long var3);

    public static final native void btCollisionShape_operatorDeleteArray__SWIG_0(long var0, btCollisionShape var2, long var3);

    public static final native long btCollisionShape_operatorNewArray__SWIG_1(long var0, btCollisionShape var2, long var3, long var5);

    public static final native void btCollisionShape_operatorDeleteArray__SWIG_1(long var0, btCollisionShape var2, long var3, long var5);

    public static final native void delete_btCollisionShape(long var0);

    public static final native void btCollisionShape_getAabb(long var0, btCollisionShape var2, Matrix4 var3, Vector3 var4, Vector3 var5);

    public static final native void btCollisionShape_getBoundingSphere(long var0, btCollisionShape var2, Vector3 var3, long var4);

    public static final native float btCollisionShape_getAngularMotionDisc(long var0, btCollisionShape var2);

    public static final native float btCollisionShape_getContactBreakingThreshold(long var0, btCollisionShape var2, float var3);

    public static final native void btCollisionShape_calculateTemporalAabb(long var0, btCollisionShape var2, Matrix4 var3, Vector3 var4, Vector3 var5, float var6, Vector3 var7, Vector3 var8);

    public static final native boolean btCollisionShape_isPolyhedral(long var0, btCollisionShape var2);

    public static final native boolean btCollisionShape_isConvex2d(long var0, btCollisionShape var2);

    public static final native boolean btCollisionShape_isConvex(long var0, btCollisionShape var2);

    public static final native boolean btCollisionShape_isNonMoving(long var0, btCollisionShape var2);

    public static final native boolean btCollisionShape_isConcave(long var0, btCollisionShape var2);

    public static final native boolean btCollisionShape_isCompound(long var0, btCollisionShape var2);

    public static final native boolean btCollisionShape_isSoftBody(long var0, btCollisionShape var2);

    public static final native boolean btCollisionShape_isInfinite(long var0, btCollisionShape var2);

    public static final native void btCollisionShape_setLocalScaling(long var0, btCollisionShape var2, Vector3 var3);

    public static final native Vector3 btCollisionShape_getLocalScaling(long var0, btCollisionShape var2);

    public static final native void btCollisionShape_calculateLocalInertia(long var0, btCollisionShape var2, float var3, Vector3 var4);

    public static final native String btCollisionShape_getName(long var0, btCollisionShape var2);

    public static final native int btCollisionShape_getShapeType(long var0, btCollisionShape var2);

    public static final native Vector3 btCollisionShape_getAnisotropicRollingFrictionDirection(long var0, btCollisionShape var2);

    public static final native void btCollisionShape_setMargin(long var0, btCollisionShape var2, float var3);

    public static final native float btCollisionShape_getMargin(long var0, btCollisionShape var2);

    public static final native void btCollisionShape_setUserPointer(long var0, btCollisionShape var2, long var3);

    public static final native long btCollisionShape_getUserPointer(long var0, btCollisionShape var2);

    public static final native void btCollisionShape_setUserIndex(long var0, btCollisionShape var2, int var3);

    public static final native int btCollisionShape_getUserIndex(long var0, btCollisionShape var2);

    public static final native int btCollisionShape_calculateSerializeBufferSize(long var0, btCollisionShape var2);

    public static final native String btCollisionShape_serialize(long var0, btCollisionShape var2, long var3, long var5, btSerializer var7);

    public static final native void btCollisionShape_serializeSingleShape(long var0, btCollisionShape var2, long var3, btSerializer var5);

    public static final native void btCollisionShapeData_name_set(long var0, btCollisionShapeData var2, String var3);

    public static final native String btCollisionShapeData_name_get(long var0, btCollisionShapeData var2);

    public static final native void btCollisionShapeData_shapeType_set(long var0, btCollisionShapeData var2, int var3);

    public static final native int btCollisionShapeData_shapeType_get(long var0, btCollisionShapeData var2);

    public static final native void btCollisionShapeData_padding_set(long var0, btCollisionShapeData var2, String var3);

    public static final native String btCollisionShapeData_padding_get(long var0, btCollisionShapeData var2);

    public static final native long new_btCollisionShapeData();

    public static final native void delete_btCollisionShapeData(long var0);

    public static final native long btConvexShape_operatorNew__SWIG_0(long var0, btConvexShape var2, long var3);

    public static final native void btConvexShape_operatorDelete__SWIG_0(long var0, btConvexShape var2, long var3);

    public static final native long btConvexShape_operatorNew__SWIG_1(long var0, btConvexShape var2, long var3, long var5);

    public static final native void btConvexShape_operatorDelete__SWIG_1(long var0, btConvexShape var2, long var3, long var5);

    public static final native long btConvexShape_operatorNewArray__SWIG_0(long var0, btConvexShape var2, long var3);

    public static final native void btConvexShape_operatorDeleteArray__SWIG_0(long var0, btConvexShape var2, long var3);

    public static final native long btConvexShape_operatorNewArray__SWIG_1(long var0, btConvexShape var2, long var3, long var5);

    public static final native void btConvexShape_operatorDeleteArray__SWIG_1(long var0, btConvexShape var2, long var3, long var5);

    public static final native void delete_btConvexShape(long var0);

    public static final native Vector3 btConvexShape_localGetSupportingVertex(long var0, btConvexShape var2, Vector3 var3);

    public static final native Vector3 btConvexShape_localGetSupportingVertexWithoutMargin(long var0, btConvexShape var2, Vector3 var3);

    public static final native Vector3 btConvexShape_localGetSupportVertexWithoutMarginNonVirtual(long var0, btConvexShape var2, Vector3 var3);

    public static final native Vector3 btConvexShape_localGetSupportVertexNonVirtual(long var0, btConvexShape var2, Vector3 var3);

    public static final native float btConvexShape_getMarginNonVirtual(long var0, btConvexShape var2);

    public static final native void btConvexShape_getAabbNonVirtual(long var0, btConvexShape var2, Matrix4 var3, Vector3 var4, Vector3 var5);

    public static final native void btConvexShape_project(long var0, btConvexShape var2, Matrix4 var3, Vector3 var4, long var5, long var7, Vector3 var9, Vector3 var10);

    public static final native void btConvexShape_batchedUnitVectorGetSupportingVertexWithoutMargin(long var0, btConvexShape var2, long var3, btVector3 var5, long var6, btVector3 var8, int var9);

    public static final native void btConvexShape_getAabbSlow(long var0, btConvexShape var2, Matrix4 var3, Vector3 var4, Vector3 var5);

    public static final native int btConvexShape_getNumPreferredPenetrationDirections(long var0, btConvexShape var2);

    public static final native void btConvexShape_getPreferredPenetrationDirection(long var0, btConvexShape var2, int var3, Vector3 var4);

    public static final native long btConvexInternalShape_operatorNew__SWIG_0(long var0, btConvexInternalShape var2, long var3);

    public static final native void btConvexInternalShape_operatorDelete__SWIG_0(long var0, btConvexInternalShape var2, long var3);

    public static final native long btConvexInternalShape_operatorNew__SWIG_1(long var0, btConvexInternalShape var2, long var3, long var5);

    public static final native void btConvexInternalShape_operatorDelete__SWIG_1(long var0, btConvexInternalShape var2, long var3, long var5);

    public static final native long btConvexInternalShape_operatorNewArray__SWIG_0(long var0, btConvexInternalShape var2, long var3);

    public static final native void btConvexInternalShape_operatorDeleteArray__SWIG_0(long var0, btConvexInternalShape var2, long var3);

    public static final native long btConvexInternalShape_operatorNewArray__SWIG_1(long var0, btConvexInternalShape var2, long var3, long var5);

    public static final native void btConvexInternalShape_operatorDeleteArray__SWIG_1(long var0, btConvexInternalShape var2, long var3, long var5);

    public static final native void delete_btConvexInternalShape(long var0);

    public static final native Vector3 btConvexInternalShape_getImplicitShapeDimensions(long var0, btConvexInternalShape var2);

    public static final native void btConvexInternalShape_setImplicitShapeDimensions(long var0, btConvexInternalShape var2, Vector3 var3);

    public static final native void btConvexInternalShape_setSafeMargin__SWIG_0(long var0, btConvexInternalShape var2, float var3, float var4);

    public static final native void btConvexInternalShape_setSafeMargin__SWIG_1(long var0, btConvexInternalShape var2, float var3);

    public static final native void btConvexInternalShape_setSafeMargin__SWIG_2(long var0, btConvexInternalShape var2, Vector3 var3, float var4);

    public static final native void btConvexInternalShape_setSafeMargin__SWIG_3(long var0, btConvexInternalShape var2, Vector3 var3);

    public static final native Vector3 btConvexInternalShape_getLocalScalingNV(long var0, btConvexInternalShape var2);

    public static final native float btConvexInternalShape_getMarginNV(long var0, btConvexInternalShape var2);

    public static final native void btConvexInternalShapeData_collisionShapeData_set(long var0, btConvexInternalShapeData var2, long var3, btCollisionShapeData var5);

    public static final native long btConvexInternalShapeData_collisionShapeData_get(long var0, btConvexInternalShapeData var2);

    public static final native void btConvexInternalShapeData_localScaling_set(long var0, btConvexInternalShapeData var2, long var3, btVector3FloatData var5);

    public static final native long btConvexInternalShapeData_localScaling_get(long var0, btConvexInternalShapeData var2);

    public static final native void btConvexInternalShapeData_implicitShapeDimensions_set(long var0, btConvexInternalShapeData var2, long var3, btVector3FloatData var5);

    public static final native long btConvexInternalShapeData_implicitShapeDimensions_get(long var0, btConvexInternalShapeData var2);

    public static final native void btConvexInternalShapeData_collisionMargin_set(long var0, btConvexInternalShapeData var2, float var3);

    public static final native float btConvexInternalShapeData_collisionMargin_get(long var0, btConvexInternalShapeData var2);

    public static final native void btConvexInternalShapeData_padding_set(long var0, btConvexInternalShapeData var2, int var3);

    public static final native int btConvexInternalShapeData_padding_get(long var0, btConvexInternalShapeData var2);

    public static final native long new_btConvexInternalShapeData();

    public static final native void delete_btConvexInternalShapeData(long var0);

    public static final native void btConvexInternalAabbCachingShape_recalcLocalAabb(long var0, btConvexInternalAabbCachingShape var2);

    public static final native void delete_btConvexInternalAabbCachingShape(long var0);

    public static final native long btPolyhedralConvexShape_operatorNew__SWIG_0(long var0, btPolyhedralConvexShape var2, long var3);

    public static final native void btPolyhedralConvexShape_operatorDelete__SWIG_0(long var0, btPolyhedralConvexShape var2, long var3);

    public static final native long btPolyhedralConvexShape_operatorNew__SWIG_1(long var0, btPolyhedralConvexShape var2, long var3, long var5);

    public static final native void btPolyhedralConvexShape_operatorDelete__SWIG_1(long var0, btPolyhedralConvexShape var2, long var3, long var5);

    public static final native long btPolyhedralConvexShape_operatorNewArray__SWIG_0(long var0, btPolyhedralConvexShape var2, long var3);

    public static final native void btPolyhedralConvexShape_operatorDeleteArray__SWIG_0(long var0, btPolyhedralConvexShape var2, long var3);

    public static final native long btPolyhedralConvexShape_operatorNewArray__SWIG_1(long var0, btPolyhedralConvexShape var2, long var3, long var5);

    public static final native void btPolyhedralConvexShape_operatorDeleteArray__SWIG_1(long var0, btPolyhedralConvexShape var2, long var3, long var5);

    public static final native void delete_btPolyhedralConvexShape(long var0);

    public static final native boolean btPolyhedralConvexShape_initializePolyhedralFeatures__SWIG_0(long var0, btPolyhedralConvexShape var2, int var3);

    public static final native boolean btPolyhedralConvexShape_initializePolyhedralFeatures__SWIG_1(long var0, btPolyhedralConvexShape var2);

    public static final native long btPolyhedralConvexShape_getConvexPolyhedron(long var0, btPolyhedralConvexShape var2);

    public static final native int btPolyhedralConvexShape_getNumVertices(long var0, btPolyhedralConvexShape var2);

    public static final native int btPolyhedralConvexShape_getNumEdges(long var0, btPolyhedralConvexShape var2);

    public static final native void btPolyhedralConvexShape_getEdge(long var0, btPolyhedralConvexShape var2, int var3, Vector3 var4, Vector3 var5);

    public static final native void btPolyhedralConvexShape_getVertex(long var0, btPolyhedralConvexShape var2, int var3, Vector3 var4);

    public static final native int btPolyhedralConvexShape_getNumPlanes(long var0, btPolyhedralConvexShape var2);

    public static final native void btPolyhedralConvexShape_getPlane(long var0, btPolyhedralConvexShape var2, Vector3 var3, Vector3 var4, int var5);

    public static final native boolean btPolyhedralConvexShape_isInside(long var0, btPolyhedralConvexShape var2, Vector3 var3, float var4);

    public static final native void btPolyhedralConvexAabbCachingShape_getNonvirtualAabb(long var0, btPolyhedralConvexAabbCachingShape var2, Matrix4 var3, Vector3 var4, Vector3 var5, float var6);

    public static final native void btPolyhedralConvexAabbCachingShape_recalcLocalAabb(long var0, btPolyhedralConvexAabbCachingShape var2);

    public static final native void delete_btPolyhedralConvexAabbCachingShape(long var0);

    public static final native long btConcaveShape_operatorNew__SWIG_0(long var0, btConcaveShape var2, long var3);

    public static final native void btConcaveShape_operatorDelete__SWIG_0(long var0, btConcaveShape var2, long var3);

    public static final native long btConcaveShape_operatorNew__SWIG_1(long var0, btConcaveShape var2, long var3, long var5);

    public static final native void btConcaveShape_operatorDelete__SWIG_1(long var0, btConcaveShape var2, long var3, long var5);

    public static final native long btConcaveShape_operatorNewArray__SWIG_0(long var0, btConcaveShape var2, long var3);

    public static final native void btConcaveShape_operatorDeleteArray__SWIG_0(long var0, btConcaveShape var2, long var3);

    public static final native long btConcaveShape_operatorNewArray__SWIG_1(long var0, btConcaveShape var2, long var3, long var5);

    public static final native void btConcaveShape_operatorDeleteArray__SWIG_1(long var0, btConcaveShape var2, long var3, long var5);

    public static final native void delete_btConcaveShape(long var0);

    public static final native void btConcaveShape_processAllTriangles(long var0, btConcaveShape var2, long var3, btTriangleCallback var5, Vector3 var6, Vector3 var7);

    public static final native void delete_btTriangleCallback(long var0);

    public static final native void btTriangleCallback_processTriangle(long var0, btTriangleCallback var2, long var3, btVector3 var5, int var6, int var7);

    public static final native long new_btTriangleCallback();

    public static final native void btTriangleCallback_director_connect(btTriangleCallback var0, long var1, boolean var3, boolean var4);

    public static final native void btTriangleCallback_change_ownership(btTriangleCallback var0, long var1, boolean var3);

    public static final native void delete_btInternalTriangleIndexCallback(long var0);

    public static final native void btInternalTriangleIndexCallback_internalProcessTriangleIndex(long var0, btInternalTriangleIndexCallback var2, long var3, btVector3 var5, int var6, int var7);

    public static final native long new_btInternalTriangleIndexCallback();

    public static final native void btInternalTriangleIndexCallback_director_connect(btInternalTriangleIndexCallback var0, long var1, boolean var3, boolean var4);

    public static final native void btInternalTriangleIndexCallback_change_ownership(btInternalTriangleIndexCallback var0, long var1, boolean var3);

    public static final native void btHashMapInternalShortBtHashIntBtTriangleInfo_insert(long var0, btHashMapInternalShortBtHashIntBtTriangleInfo var2, long var3, btHashInt var5, long var6, btTriangleInfo var8);

    public static final native void btHashMapInternalShortBtHashIntBtTriangleInfo_remove(long var0, btHashMapInternalShortBtHashIntBtTriangleInfo var2, long var3, btHashInt var5);

    public static final native int btHashMapInternalShortBtHashIntBtTriangleInfo_size(long var0, btHashMapInternalShortBtHashIntBtTriangleInfo var2);

    public static final native long btHashMapInternalShortBtHashIntBtTriangleInfo_getAtIndexConst(long var0, btHashMapInternalShortBtHashIntBtTriangleInfo var2, int var3);

    public static final native long btHashMapInternalShortBtHashIntBtTriangleInfo_getAtIndex(long var0, btHashMapInternalShortBtHashIntBtTriangleInfo var2, int var3);

    public static final native long btHashMapInternalShortBtHashIntBtTriangleInfo_getKeyAtIndex(long var0, btHashMapInternalShortBtHashIntBtTriangleInfo var2, int var3);

    public static final native long btHashMapInternalShortBtHashIntBtTriangleInfo_getKeyAtIndexConst(long var0, btHashMapInternalShortBtHashIntBtTriangleInfo var2, int var3);

    public static final native long btHashMapInternalShortBtHashIntBtTriangleInfo_operatorSubscript(long var0, btHashMapInternalShortBtHashIntBtTriangleInfo var2, long var3, btHashInt var5);

    public static final native long btHashMapInternalShortBtHashIntBtTriangleInfo_operatorSubscriptConst(long var0, btHashMapInternalShortBtHashIntBtTriangleInfo var2, long var3, btHashInt var5);

    public static final native long btHashMapInternalShortBtHashIntBtTriangleInfo_findConst(long var0, btHashMapInternalShortBtHashIntBtTriangleInfo var2, long var3, btHashInt var5);

    public static final native long btHashMapInternalShortBtHashIntBtTriangleInfo_find(long var0, btHashMapInternalShortBtHashIntBtTriangleInfo var2, long var3, btHashInt var5);

    public static final native int btHashMapInternalShortBtHashIntBtTriangleInfo_findIndex(long var0, btHashMapInternalShortBtHashIntBtTriangleInfo var2, long var3, btHashInt var5);

    public static final native void btHashMapInternalShortBtHashIntBtTriangleInfo_clear(long var0, btHashMapInternalShortBtHashIntBtTriangleInfo var2);

    public static final native long new_btHashMapInternalShortBtHashIntBtTriangleInfo();

    public static final native void delete_btHashMapInternalShortBtHashIntBtTriangleInfo(long var0);

    public static final native long new_btTriangleInfo();

    public static final native void btTriangleInfo_flags_set(long var0, btTriangleInfo var2, int var3);

    public static final native int btTriangleInfo_flags_get(long var0, btTriangleInfo var2);

    public static final native void btTriangleInfo_edgeV0V1Angle_set(long var0, btTriangleInfo var2, float var3);

    public static final native float btTriangleInfo_edgeV0V1Angle_get(long var0, btTriangleInfo var2);

    public static final native void btTriangleInfo_edgeV1V2Angle_set(long var0, btTriangleInfo var2, float var3);

    public static final native float btTriangleInfo_edgeV1V2Angle_get(long var0, btTriangleInfo var2);

    public static final native void btTriangleInfo_edgeV2V0Angle_set(long var0, btTriangleInfo var2, float var3);

    public static final native float btTriangleInfo_edgeV2V0Angle_get(long var0, btTriangleInfo var2);

    public static final native void delete_btTriangleInfo(long var0);

    public static final native void btTriangleInfoMap_convexEpsilon_set(long var0, btTriangleInfoMap var2, float var3);

    public static final native float btTriangleInfoMap_convexEpsilon_get(long var0, btTriangleInfoMap var2);

    public static final native void btTriangleInfoMap_planarEpsilon_set(long var0, btTriangleInfoMap var2, float var3);

    public static final native float btTriangleInfoMap_planarEpsilon_get(long var0, btTriangleInfoMap var2);

    public static final native void btTriangleInfoMap_equalVertexThreshold_set(long var0, btTriangleInfoMap var2, float var3);

    public static final native float btTriangleInfoMap_equalVertexThreshold_get(long var0, btTriangleInfoMap var2);

    public static final native void btTriangleInfoMap_edgeDistanceThreshold_set(long var0, btTriangleInfoMap var2, float var3);

    public static final native float btTriangleInfoMap_edgeDistanceThreshold_get(long var0, btTriangleInfoMap var2);

    public static final native void btTriangleInfoMap_maxEdgeAngleThreshold_set(long var0, btTriangleInfoMap var2, float var3);

    public static final native float btTriangleInfoMap_maxEdgeAngleThreshold_get(long var0, btTriangleInfoMap var2);

    public static final native void btTriangleInfoMap_zeroAreaThreshold_set(long var0, btTriangleInfoMap var2, float var3);

    public static final native float btTriangleInfoMap_zeroAreaThreshold_get(long var0, btTriangleInfoMap var2);

    public static final native long new_btTriangleInfoMap();

    public static final native void delete_btTriangleInfoMap(long var0);

    public static final native int btTriangleInfoMap_calculateSerializeBufferSize(long var0, btTriangleInfoMap var2);

    public static final native String btTriangleInfoMap_serialize(long var0, btTriangleInfoMap var2, long var3, long var5, btSerializer var7);

    public static final native void btTriangleInfoMap_deSerialize(long var0, btTriangleInfoMap var2, long var3, btTriangleInfoMapData var5);

    public static final native void btTriangleInfoData_flags_set(long var0, btTriangleInfoData var2, int var3);

    public static final native int btTriangleInfoData_flags_get(long var0, btTriangleInfoData var2);

    public static final native void btTriangleInfoData_edgeV0V1Angle_set(long var0, btTriangleInfoData var2, float var3);

    public static final native float btTriangleInfoData_edgeV0V1Angle_get(long var0, btTriangleInfoData var2);

    public static final native void btTriangleInfoData_edgeV1V2Angle_set(long var0, btTriangleInfoData var2, float var3);

    public static final native float btTriangleInfoData_edgeV1V2Angle_get(long var0, btTriangleInfoData var2);

    public static final native void btTriangleInfoData_edgeV2V0Angle_set(long var0, btTriangleInfoData var2, float var3);

    public static final native float btTriangleInfoData_edgeV2V0Angle_get(long var0, btTriangleInfoData var2);

    public static final native long new_btTriangleInfoData();

    public static final native void delete_btTriangleInfoData(long var0);

    public static final native void btTriangleInfoMapData_hashTablePtr_set(long var0, btTriangleInfoMapData var2, IntBuffer var3);

    public static final native IntBuffer btTriangleInfoMapData_hashTablePtr_get(long var0, btTriangleInfoMapData var2);

    public static final native void btTriangleInfoMapData_nextPtr_set(long var0, btTriangleInfoMapData var2, IntBuffer var3);

    public static final native IntBuffer btTriangleInfoMapData_nextPtr_get(long var0, btTriangleInfoMapData var2);

    public static final native void btTriangleInfoMapData_valueArrayPtr_set(long var0, btTriangleInfoMapData var2, long var3, btTriangleInfoData var5);

    public static final native long btTriangleInfoMapData_valueArrayPtr_get(long var0, btTriangleInfoMapData var2);

    public static final native void btTriangleInfoMapData_keyArrayPtr_set(long var0, btTriangleInfoMapData var2, IntBuffer var3);

    public static final native IntBuffer btTriangleInfoMapData_keyArrayPtr_get(long var0, btTriangleInfoMapData var2);

    public static final native void btTriangleInfoMapData_convexEpsilon_set(long var0, btTriangleInfoMapData var2, float var3);

    public static final native float btTriangleInfoMapData_convexEpsilon_get(long var0, btTriangleInfoMapData var2);

    public static final native void btTriangleInfoMapData_planarEpsilon_set(long var0, btTriangleInfoMapData var2, float var3);

    public static final native float btTriangleInfoMapData_planarEpsilon_get(long var0, btTriangleInfoMapData var2);

    public static final native void btTriangleInfoMapData_equalVertexThreshold_set(long var0, btTriangleInfoMapData var2, float var3);

    public static final native float btTriangleInfoMapData_equalVertexThreshold_get(long var0, btTriangleInfoMapData var2);

    public static final native void btTriangleInfoMapData_edgeDistanceThreshold_set(long var0, btTriangleInfoMapData var2, float var3);

    public static final native float btTriangleInfoMapData_edgeDistanceThreshold_get(long var0, btTriangleInfoMapData var2);

    public static final native void btTriangleInfoMapData_zeroAreaThreshold_set(long var0, btTriangleInfoMapData var2, float var3);

    public static final native float btTriangleInfoMapData_zeroAreaThreshold_get(long var0, btTriangleInfoMapData var2);

    public static final native void btTriangleInfoMapData_nextSize_set(long var0, btTriangleInfoMapData var2, int var3);

    public static final native int btTriangleInfoMapData_nextSize_get(long var0, btTriangleInfoMapData var2);

    public static final native void btTriangleInfoMapData_hashTableSize_set(long var0, btTriangleInfoMapData var2, int var3);

    public static final native int btTriangleInfoMapData_hashTableSize_get(long var0, btTriangleInfoMapData var2);

    public static final native void btTriangleInfoMapData_numValues_set(long var0, btTriangleInfoMapData var2, int var3);

    public static final native int btTriangleInfoMapData_numValues_get(long var0, btTriangleInfoMapData var2);

    public static final native void btTriangleInfoMapData_numKeys_set(long var0, btTriangleInfoMapData var2, int var3);

    public static final native int btTriangleInfoMapData_numKeys_get(long var0, btTriangleInfoMapData var2);

    public static final native void btTriangleInfoMapData_padding_set(long var0, btTriangleInfoMapData var2, String var3);

    public static final native String btTriangleInfoMapData_padding_get(long var0, btTriangleInfoMapData var2);

    public static final native long new_btTriangleInfoMapData();

    public static final native void delete_btTriangleInfoMapData(long var0);

    public static final native long btStaticPlaneShape_operatorNew__SWIG_0(long var0, btStaticPlaneShape var2, long var3);

    public static final native void btStaticPlaneShape_operatorDelete__SWIG_0(long var0, btStaticPlaneShape var2, long var3);

    public static final native long btStaticPlaneShape_operatorNew__SWIG_1(long var0, btStaticPlaneShape var2, long var3, long var5);

    public static final native void btStaticPlaneShape_operatorDelete__SWIG_1(long var0, btStaticPlaneShape var2, long var3, long var5);

    public static final native long btStaticPlaneShape_operatorNewArray__SWIG_0(long var0, btStaticPlaneShape var2, long var3);

    public static final native void btStaticPlaneShape_operatorDeleteArray__SWIG_0(long var0, btStaticPlaneShape var2, long var3);

    public static final native long btStaticPlaneShape_operatorNewArray__SWIG_1(long var0, btStaticPlaneShape var2, long var3, long var5);

    public static final native void btStaticPlaneShape_operatorDeleteArray__SWIG_1(long var0, btStaticPlaneShape var2, long var3, long var5);

    public static final native long new_btStaticPlaneShape(Vector3 var0, float var1);

    public static final native void delete_btStaticPlaneShape(long var0);

    public static final native Vector3 btStaticPlaneShape_getPlaneNormal(long var0, btStaticPlaneShape var2);

    public static final native float btStaticPlaneShape_getPlaneConstant(long var0, btStaticPlaneShape var2);

    public static final native void btStaticPlaneShapeData_collisionShapeData_set(long var0, btStaticPlaneShapeData var2, long var3, btCollisionShapeData var5);

    public static final native long btStaticPlaneShapeData_collisionShapeData_get(long var0, btStaticPlaneShapeData var2);

    public static final native void btStaticPlaneShapeData_localScaling_set(long var0, btStaticPlaneShapeData var2, long var3, btVector3FloatData var5);

    public static final native long btStaticPlaneShapeData_localScaling_get(long var0, btStaticPlaneShapeData var2);

    public static final native void btStaticPlaneShapeData_planeNormal_set(long var0, btStaticPlaneShapeData var2, long var3, btVector3FloatData var5);

    public static final native long btStaticPlaneShapeData_planeNormal_get(long var0, btStaticPlaneShapeData var2);

    public static final native void btStaticPlaneShapeData_planeConstant_set(long var0, btStaticPlaneShapeData var2, float var3);

    public static final native float btStaticPlaneShapeData_planeConstant_get(long var0, btStaticPlaneShapeData var2);

    public static final native void btStaticPlaneShapeData_pad_set(long var0, btStaticPlaneShapeData var2, String var3);

    public static final native String btStaticPlaneShapeData_pad_get(long var0, btStaticPlaneShapeData var2);

    public static final native long new_btStaticPlaneShapeData();

    public static final native void delete_btStaticPlaneShapeData(long var0);

    public static final native long btHeightfieldTerrainShape_operatorNew__SWIG_0(long var0, btHeightfieldTerrainShape var2, long var3);

    public static final native void btHeightfieldTerrainShape_operatorDelete__SWIG_0(long var0, btHeightfieldTerrainShape var2, long var3);

    public static final native long btHeightfieldTerrainShape_operatorNew__SWIG_1(long var0, btHeightfieldTerrainShape var2, long var3, long var5);

    public static final native void btHeightfieldTerrainShape_operatorDelete__SWIG_1(long var0, btHeightfieldTerrainShape var2, long var3, long var5);

    public static final native long btHeightfieldTerrainShape_operatorNewArray__SWIG_0(long var0, btHeightfieldTerrainShape var2, long var3);

    public static final native void btHeightfieldTerrainShape_operatorDeleteArray__SWIG_0(long var0, btHeightfieldTerrainShape var2, long var3);

    public static final native long btHeightfieldTerrainShape_operatorNewArray__SWIG_1(long var0, btHeightfieldTerrainShape var2, long var3, long var5);

    public static final native void btHeightfieldTerrainShape_operatorDeleteArray__SWIG_1(long var0, btHeightfieldTerrainShape var2, long var3, long var5);

    public static final native void delete_btHeightfieldTerrainShape(long var0);

    public static final native void btHeightfieldTerrainShape_setUseDiamondSubdivision__SWIG_0(long var0, btHeightfieldTerrainShape var2, boolean var3);

    public static final native void btHeightfieldTerrainShape_setUseDiamondSubdivision__SWIG_1(long var0, btHeightfieldTerrainShape var2);

    public static final native void btHeightfieldTerrainShape_setUseZigzagSubdivision__SWIG_0(long var0, btHeightfieldTerrainShape var2, boolean var3);

    public static final native void btHeightfieldTerrainShape_setUseZigzagSubdivision__SWIG_1(long var0, btHeightfieldTerrainShape var2);

    public static final native long new_btHeightfieldTerrainShape__SWIG_0(int var0, int var1, FloatBuffer var2, float var3, float var4, float var5, int var6, boolean var7);

    public static final native long new_btHeightfieldTerrainShape__SWIG_1(int var0, int var1, ShortBuffer var2, float var3, float var4, float var5, int var6, boolean var7);

    public static final native long btTriangleMeshShape_operatorNew__SWIG_0(long var0, btTriangleMeshShape var2, long var3);

    public static final native void btTriangleMeshShape_operatorDelete__SWIG_0(long var0, btTriangleMeshShape var2, long var3);

    public static final native long btTriangleMeshShape_operatorNew__SWIG_1(long var0, btTriangleMeshShape var2, long var3, long var5);

    public static final native void btTriangleMeshShape_operatorDelete__SWIG_1(long var0, btTriangleMeshShape var2, long var3, long var5);

    public static final native long btTriangleMeshShape_operatorNewArray__SWIG_0(long var0, btTriangleMeshShape var2, long var3);

    public static final native void btTriangleMeshShape_operatorDeleteArray__SWIG_0(long var0, btTriangleMeshShape var2, long var3);

    public static final native long btTriangleMeshShape_operatorNewArray__SWIG_1(long var0, btTriangleMeshShape var2, long var3, long var5);

    public static final native void btTriangleMeshShape_operatorDeleteArray__SWIG_1(long var0, btTriangleMeshShape var2, long var3, long var5);

    public static final native void delete_btTriangleMeshShape(long var0);

    public static final native Vector3 btTriangleMeshShape_localGetSupportingVertex(long var0, btTriangleMeshShape var2, Vector3 var3);

    public static final native Vector3 btTriangleMeshShape_localGetSupportingVertexWithoutMargin(long var0, btTriangleMeshShape var2, Vector3 var3);

    public static final native void btTriangleMeshShape_recalcLocalAabb(long var0, btTriangleMeshShape var2);

    public static final native long btTriangleMeshShape_getMeshInterface(long var0, btTriangleMeshShape var2);

    public static final native long btTriangleMeshShape_getMeshInterfaceConst(long var0, btTriangleMeshShape var2);

    public static final native Vector3 btTriangleMeshShape_getLocalAabbMin(long var0, btTriangleMeshShape var2);

    public static final native Vector3 btTriangleMeshShape_getLocalAabbMax(long var0, btTriangleMeshShape var2);

    public static final native long btBvhTriangleMeshShape_operatorNew__SWIG_0(long var0, btBvhTriangleMeshShape var2, long var3);

    public static final native void btBvhTriangleMeshShape_operatorDelete__SWIG_0(long var0, btBvhTriangleMeshShape var2, long var3);

    public static final native long btBvhTriangleMeshShape_operatorNew__SWIG_1(long var0, btBvhTriangleMeshShape var2, long var3, long var5);

    public static final native void btBvhTriangleMeshShape_operatorDelete__SWIG_1(long var0, btBvhTriangleMeshShape var2, long var3, long var5);

    public static final native long btBvhTriangleMeshShape_operatorNewArray__SWIG_0(long var0, btBvhTriangleMeshShape var2, long var3);

    public static final native void btBvhTriangleMeshShape_operatorDeleteArray__SWIG_0(long var0, btBvhTriangleMeshShape var2, long var3);

    public static final native long btBvhTriangleMeshShape_operatorNewArray__SWIG_1(long var0, btBvhTriangleMeshShape var2, long var3, long var5);

    public static final native void btBvhTriangleMeshShape_operatorDeleteArray__SWIG_1(long var0, btBvhTriangleMeshShape var2, long var3, long var5);

    public static final native void delete_btBvhTriangleMeshShape(long var0);

    public static final native boolean btBvhTriangleMeshShape_getOwnsBvh(long var0, btBvhTriangleMeshShape var2);

    public static final native void btBvhTriangleMeshShape_performRaycast(long var0, btBvhTriangleMeshShape var2, long var3, btTriangleCallback var5, Vector3 var6, Vector3 var7);

    public static final native void btBvhTriangleMeshShape_performConvexcast(long var0, btBvhTriangleMeshShape var2, long var3, btTriangleCallback var5, Vector3 var6, Vector3 var7, Vector3 var8, Vector3 var9);

    public static final native void btBvhTriangleMeshShape_refitTree(long var0, btBvhTriangleMeshShape var2, Vector3 var3, Vector3 var4);

    public static final native void btBvhTriangleMeshShape_partialRefitTree(long var0, btBvhTriangleMeshShape var2, Vector3 var3, Vector3 var4);

    public static final native long btBvhTriangleMeshShape_getOptimizedBvh(long var0, btBvhTriangleMeshShape var2);

    public static final native void btBvhTriangleMeshShape_setOptimizedBvh__SWIG_0(long var0, btBvhTriangleMeshShape var2, long var3, btOptimizedBvh var5, Vector3 var6);

    public static final native void btBvhTriangleMeshShape_setOptimizedBvh__SWIG_1(long var0, btBvhTriangleMeshShape var2, long var3, btOptimizedBvh var5);

    public static final native void btBvhTriangleMeshShape_buildOptimizedBvh(long var0, btBvhTriangleMeshShape var2);

    public static final native boolean btBvhTriangleMeshShape_usesQuantizedAabbCompression(long var0, btBvhTriangleMeshShape var2);

    public static final native void btBvhTriangleMeshShape_setTriangleInfoMap(long var0, btBvhTriangleMeshShape var2, long var3, btTriangleInfoMap var5);

    public static final native long btBvhTriangleMeshShape_getTriangleInfoMap__SWIG_0(long var0, btBvhTriangleMeshShape var2);

    public static final native void btBvhTriangleMeshShape_serializeSingleBvh(long var0, btBvhTriangleMeshShape var2, long var3, btSerializer var5);

    public static final native void btBvhTriangleMeshShape_serializeSingleTriangleInfoMap(long var0, btBvhTriangleMeshShape var2, long var3, btSerializer var5);

    public static final native long new_btBvhTriangleMeshShape__SWIG_0(boolean var0, long var1, btStridingMeshInterface var3, boolean var4, boolean var5);

    public static final native long new_btBvhTriangleMeshShape__SWIG_1(boolean var0, long var1, btStridingMeshInterface var3, boolean var4);

    public static final native long new_btBvhTriangleMeshShape__SWIG_2(boolean var0, long var1, btStridingMeshInterface var3, boolean var4, Vector3 var5, Vector3 var6, boolean var7);

    public static final native long new_btBvhTriangleMeshShape__SWIG_3(boolean var0, long var1, btStridingMeshInterface var3, boolean var4, Vector3 var5, Vector3 var6);

    public static final native void btTriangleMeshShapeData_collisionShapeData_set(long var0, btTriangleMeshShapeData var2, long var3, btCollisionShapeData var5);

    public static final native long btTriangleMeshShapeData_collisionShapeData_get(long var0, btTriangleMeshShapeData var2);

    public static final native void btTriangleMeshShapeData_meshInterface_set(long var0, btTriangleMeshShapeData var2, long var3, btStridingMeshInterfaceData var5);

    public static final native long btTriangleMeshShapeData_meshInterface_get(long var0, btTriangleMeshShapeData var2);

    public static final native void btTriangleMeshShapeData_quantizedFloatBvh_set(long var0, btTriangleMeshShapeData var2, long var3, btQuantizedBvhFloatData var5);

    public static final native long btTriangleMeshShapeData_quantizedFloatBvh_get(long var0, btTriangleMeshShapeData var2);

    public static final native void btTriangleMeshShapeData_quantizedDoubleBvh_set(long var0, btTriangleMeshShapeData var2, long var3, btQuantizedBvhDoubleData var5);

    public static final native long btTriangleMeshShapeData_quantizedDoubleBvh_get(long var0, btTriangleMeshShapeData var2);

    public static final native void btTriangleMeshShapeData_triangleInfoMap_set(long var0, btTriangleMeshShapeData var2, long var3, btTriangleInfoMapData var5);

    public static final native long btTriangleMeshShapeData_triangleInfoMap_get(long var0, btTriangleMeshShapeData var2);

    public static final native void btTriangleMeshShapeData_collisionMargin_set(long var0, btTriangleMeshShapeData var2, float var3);

    public static final native float btTriangleMeshShapeData_collisionMargin_get(long var0, btTriangleMeshShapeData var2);

    public static final native void btTriangleMeshShapeData_pad3_set(long var0, btTriangleMeshShapeData var2, String var3);

    public static final native String btTriangleMeshShapeData_pad3_get(long var0, btTriangleMeshShapeData var2);

    public static final native long new_btTriangleMeshShapeData();

    public static final native void delete_btTriangleMeshShapeData(long var0);

    public static final native long btBoxShape_operatorNew__SWIG_0(long var0, btBoxShape var2, long var3);

    public static final native void btBoxShape_operatorDelete__SWIG_0(long var0, btBoxShape var2, long var3);

    public static final native long btBoxShape_operatorNew__SWIG_1(long var0, btBoxShape var2, long var3, long var5);

    public static final native void btBoxShape_operatorDelete__SWIG_1(long var0, btBoxShape var2, long var3, long var5);

    public static final native long btBoxShape_operatorNewArray__SWIG_0(long var0, btBoxShape var2, long var3);

    public static final native void btBoxShape_operatorDeleteArray__SWIG_0(long var0, btBoxShape var2, long var3);

    public static final native long btBoxShape_operatorNewArray__SWIG_1(long var0, btBoxShape var2, long var3, long var5);

    public static final native void btBoxShape_operatorDeleteArray__SWIG_1(long var0, btBoxShape var2, long var3, long var5);

    public static final native Vector3 btBoxShape_getHalfExtentsWithMargin(long var0, btBoxShape var2);

    public static final native Vector3 btBoxShape_getHalfExtentsWithoutMargin(long var0, btBoxShape var2);

    public static final native long new_btBoxShape(Vector3 var0);

    public static final native void btBoxShape_getPlaneEquation(long var0, btBoxShape var2, long var3, btVector4 var5, int var6);

    public static final native void delete_btBoxShape(long var0);

    public static final native long btCapsuleShape_operatorNew__SWIG_0(long var0, btCapsuleShape var2, long var3);

    public static final native void btCapsuleShape_operatorDelete__SWIG_0(long var0, btCapsuleShape var2, long var3);

    public static final native long btCapsuleShape_operatorNew__SWIG_1(long var0, btCapsuleShape var2, long var3, long var5);

    public static final native void btCapsuleShape_operatorDelete__SWIG_1(long var0, btCapsuleShape var2, long var3, long var5);

    public static final native long btCapsuleShape_operatorNewArray__SWIG_0(long var0, btCapsuleShape var2, long var3);

    public static final native void btCapsuleShape_operatorDeleteArray__SWIG_0(long var0, btCapsuleShape var2, long var3);

    public static final native long btCapsuleShape_operatorNewArray__SWIG_1(long var0, btCapsuleShape var2, long var3, long var5);

    public static final native void btCapsuleShape_operatorDeleteArray__SWIG_1(long var0, btCapsuleShape var2, long var3, long var5);

    public static final native long new_btCapsuleShape__SWIG_1(float var0, float var1);

    public static final native int btCapsuleShape_getUpAxis(long var0, btCapsuleShape var2);

    public static final native float btCapsuleShape_getRadius(long var0, btCapsuleShape var2);

    public static final native float btCapsuleShape_getHalfHeight(long var0, btCapsuleShape var2);

    public static final native void btCapsuleShape_deSerializeFloat(long var0, btCapsuleShape var2, long var3, btCapsuleShapeData var5);

    public static final native void delete_btCapsuleShape(long var0);

    public static final native long new_btCapsuleShapeX(float var0, float var1);

    public static final native void delete_btCapsuleShapeX(long var0);

    public static final native long new_btCapsuleShapeZ(float var0, float var1);

    public static final native void delete_btCapsuleShapeZ(long var0);

    public static final native void btCapsuleShapeData_convexInternalShapeData_set(long var0, btCapsuleShapeData var2, long var3, btConvexInternalShapeData var5);

    public static final native long btCapsuleShapeData_convexInternalShapeData_get(long var0, btCapsuleShapeData var2);

    public static final native void btCapsuleShapeData_upAxis_set(long var0, btCapsuleShapeData var2, int var3);

    public static final native int btCapsuleShapeData_upAxis_get(long var0, btCapsuleShapeData var2);

    public static final native void btCapsuleShapeData_padding_set(long var0, btCapsuleShapeData var2, String var3);

    public static final native String btCapsuleShapeData_padding_get(long var0, btCapsuleShapeData var2);

    public static final native long new_btCapsuleShapeData();

    public static final native void delete_btCapsuleShapeData(long var0);

    public static final native long btBox2dShape_operatorNew__SWIG_0(long var0, btBox2dShape var2, long var3);

    public static final native void btBox2dShape_operatorDelete__SWIG_0(long var0, btBox2dShape var2, long var3);

    public static final native long btBox2dShape_operatorNew__SWIG_1(long var0, btBox2dShape var2, long var3, long var5);

    public static final native void btBox2dShape_operatorDelete__SWIG_1(long var0, btBox2dShape var2, long var3, long var5);

    public static final native long btBox2dShape_operatorNewArray__SWIG_0(long var0, btBox2dShape var2, long var3);

    public static final native void btBox2dShape_operatorDeleteArray__SWIG_0(long var0, btBox2dShape var2, long var3);

    public static final native long btBox2dShape_operatorNewArray__SWIG_1(long var0, btBox2dShape var2, long var3, long var5);

    public static final native void btBox2dShape_operatorDeleteArray__SWIG_1(long var0, btBox2dShape var2, long var3, long var5);

    public static final native Vector3 btBox2dShape_getHalfExtentsWithMargin(long var0, btBox2dShape var2);

    public static final native Vector3 btBox2dShape_getHalfExtentsWithoutMargin(long var0, btBox2dShape var2);

    public static final native long new_btBox2dShape(Vector3 var0);

    public static final native int btBox2dShape_getVertexCount(long var0, btBox2dShape var2);

    public static final native long btBox2dShape_getVertices(long var0, btBox2dShape var2);

    public static final native long btBox2dShape_getNormals(long var0, btBox2dShape var2);

    public static final native Vector3 btBox2dShape_getCentroid(long var0, btBox2dShape var2);

    public static final native void btBox2dShape_getPlaneEquation(long var0, btBox2dShape var2, long var3, btVector4 var5, int var6);

    public static final native void delete_btBox2dShape(long var0);

    public static final native long btTriangleShape_operatorNew__SWIG_0(long var0, btTriangleShape var2, long var3);

    public static final native void btTriangleShape_operatorDelete__SWIG_0(long var0, btTriangleShape var2, long var3);

    public static final native long btTriangleShape_operatorNew__SWIG_1(long var0, btTriangleShape var2, long var3, long var5);

    public static final native void btTriangleShape_operatorDelete__SWIG_1(long var0, btTriangleShape var2, long var3, long var5);

    public static final native long btTriangleShape_operatorNewArray__SWIG_0(long var0, btTriangleShape var2, long var3);

    public static final native void btTriangleShape_operatorDeleteArray__SWIG_0(long var0, btTriangleShape var2, long var3);

    public static final native long btTriangleShape_operatorNewArray__SWIG_1(long var0, btTriangleShape var2, long var3, long var5);

    public static final native void btTriangleShape_operatorDeleteArray__SWIG_1(long var0, btTriangleShape var2, long var3, long var5);

    public static final native void btTriangleShape_vertices1_set(long var0, btTriangleShape var2, long var3, btVector3 var5);

    public static final native long btTriangleShape_vertices1_get(long var0, btTriangleShape var2);

    public static final native Vector3 btTriangleShape_getVertexPtr(long var0, btTriangleShape var2, int var3);

    public static final native Vector3 btTriangleShape_getVertexPtrConst(long var0, btTriangleShape var2, int var3);

    public static final native long new_btTriangleShape__SWIG_0();

    public static final native long new_btTriangleShape__SWIG_1(Vector3 var0, Vector3 var1, Vector3 var2);

    public static final native void btTriangleShape_calcNormal(long var0, btTriangleShape var2, Vector3 var3);

    public static final native void btTriangleShape_getPlaneEquation(long var0, btTriangleShape var2, int var3, Vector3 var4, Vector3 var5);

    public static final native void delete_btTriangleShape(long var0);

    public static final native long btSphereShape_operatorNew__SWIG_0(long var0, btSphereShape var2, long var3);

    public static final native void btSphereShape_operatorDelete__SWIG_0(long var0, btSphereShape var2, long var3);

    public static final native long btSphereShape_operatorNew__SWIG_1(long var0, btSphereShape var2, long var3, long var5);

    public static final native void btSphereShape_operatorDelete__SWIG_1(long var0, btSphereShape var2, long var3, long var5);

    public static final native long btSphereShape_operatorNewArray__SWIG_0(long var0, btSphereShape var2, long var3);

    public static final native void btSphereShape_operatorDeleteArray__SWIG_0(long var0, btSphereShape var2, long var3);

    public static final native long btSphereShape_operatorNewArray__SWIG_1(long var0, btSphereShape var2, long var3, long var5);

    public static final native void btSphereShape_operatorDeleteArray__SWIG_1(long var0, btSphereShape var2, long var3, long var5);

    public static final native long new_btSphereShape(float var0);

    public static final native float btSphereShape_getRadius(long var0, btSphereShape var2);

    public static final native void btSphereShape_setUnscaledRadius(long var0, btSphereShape var2, float var3);

    public static final native void delete_btSphereShape(long var0);

    public static final native long btStridingMeshInterface_operatorNew__SWIG_0(long var0, btStridingMeshInterface var2, long var3);

    public static final native void btStridingMeshInterface_operatorDelete__SWIG_0(long var0, btStridingMeshInterface var2, long var3);

    public static final native long btStridingMeshInterface_operatorNew__SWIG_1(long var0, btStridingMeshInterface var2, long var3, long var5);

    public static final native void btStridingMeshInterface_operatorDelete__SWIG_1(long var0, btStridingMeshInterface var2, long var3, long var5);

    public static final native long btStridingMeshInterface_operatorNewArray__SWIG_0(long var0, btStridingMeshInterface var2, long var3);

    public static final native void btStridingMeshInterface_operatorDeleteArray__SWIG_0(long var0, btStridingMeshInterface var2, long var3);

    public static final native long btStridingMeshInterface_operatorNewArray__SWIG_1(long var0, btStridingMeshInterface var2, long var3, long var5);

    public static final native void btStridingMeshInterface_operatorDeleteArray__SWIG_1(long var0, btStridingMeshInterface var2, long var3, long var5);

    public static final native void delete_btStridingMeshInterface(long var0);

    public static final native void btStridingMeshInterface_InternalProcessAllTriangles(long var0, btStridingMeshInterface var2, long var3, btInternalTriangleIndexCallback var5, Vector3 var6, Vector3 var7);

    public static final native void btStridingMeshInterface_calculateAabbBruteForce(long var0, btStridingMeshInterface var2, Vector3 var3, Vector3 var4);

    public static final native void btStridingMeshInterface_getLockedVertexIndexBase__SWIG_0(long var0, btStridingMeshInterface var2, long var3, long var5, long var7, long var9, long var11, long var13, long var15, long var17, int var19);

    public static final native void btStridingMeshInterface_getLockedVertexIndexBase__SWIG_1(long var0, btStridingMeshInterface var2, long var3, long var5, long var7, long var9, long var11, long var13, long var15, long var17);

    public static final native void btStridingMeshInterface_getLockedReadOnlyVertexIndexBase__SWIG_0(long var0, btStridingMeshInterface var2, long var3, long var5, long var7, long var9, long var11, long var13, long var15, long var17, int var19);

    public static final native void btStridingMeshInterface_getLockedReadOnlyVertexIndexBase__SWIG_1(long var0, btStridingMeshInterface var2, long var3, long var5, long var7, long var9, long var11, long var13, long var15, long var17);

    public static final native void btStridingMeshInterface_unLockVertexBase(long var0, btStridingMeshInterface var2, int var3);

    public static final native void btStridingMeshInterface_unLockReadOnlyVertexBase(long var0, btStridingMeshInterface var2, int var3);

    public static final native int btStridingMeshInterface_getNumSubParts(long var0, btStridingMeshInterface var2);

    public static final native void btStridingMeshInterface_preallocateVertices(long var0, btStridingMeshInterface var2, int var3);

    public static final native void btStridingMeshInterface_preallocateIndices(long var0, btStridingMeshInterface var2, int var3);

    public static final native boolean btStridingMeshInterface_hasPremadeAabb(long var0, btStridingMeshInterface var2);

    public static final native void btStridingMeshInterface_setPremadeAabb(long var0, btStridingMeshInterface var2, Vector3 var3, Vector3 var4);

    public static final native void btStridingMeshInterface_getPremadeAabb(long var0, btStridingMeshInterface var2, long var3, btVector3 var5, long var6, btVector3 var8);

    public static final native Vector3 btStridingMeshInterface_getScaling(long var0, btStridingMeshInterface var2);

    public static final native void btStridingMeshInterface_setScaling(long var0, btStridingMeshInterface var2, Vector3 var3);

    public static final native int btStridingMeshInterface_calculateSerializeBufferSize(long var0, btStridingMeshInterface var2);

    public static final native String btStridingMeshInterface_serialize(long var0, btStridingMeshInterface var2, long var3, long var5, btSerializer var7);

    public static final native void btIntIndexData_value_set(long var0, btIntIndexData var2, int var3);

    public static final native int btIntIndexData_value_get(long var0, btIntIndexData var2);

    public static final native long new_btIntIndexData();

    public static final native void delete_btIntIndexData(long var0);

    public static final native void btShortIntIndexData_value_set(long var0, btShortIntIndexData var2, short var3);

    public static final native short btShortIntIndexData_value_get(long var0, btShortIntIndexData var2);

    public static final native void btShortIntIndexData_pad_set(long var0, btShortIntIndexData var2, String var3);

    public static final native String btShortIntIndexData_pad_get(long var0, btShortIntIndexData var2);

    public static final native long new_btShortIntIndexData();

    public static final native void delete_btShortIntIndexData(long var0);

    public static final native void btShortIntIndexTripletData_values_set(long var0, btShortIntIndexTripletData var2, short[] var3);

    public static final native short[] btShortIntIndexTripletData_values_get(long var0, btShortIntIndexTripletData var2);

    public static final native void btShortIntIndexTripletData_pad_set(long var0, btShortIntIndexTripletData var2, String var3);

    public static final native String btShortIntIndexTripletData_pad_get(long var0, btShortIntIndexTripletData var2);

    public static final native long new_btShortIntIndexTripletData();

    public static final native void delete_btShortIntIndexTripletData(long var0);

    public static final native void btCharIndexTripletData_values_set(long var0, btCharIndexTripletData var2, short[] var3);

    public static final native short[] btCharIndexTripletData_values_get(long var0, btCharIndexTripletData var2);

    public static final native void btCharIndexTripletData_pad_set(long var0, btCharIndexTripletData var2, char var3);

    public static final native char btCharIndexTripletData_pad_get(long var0, btCharIndexTripletData var2);

    public static final native long new_btCharIndexTripletData();

    public static final native void delete_btCharIndexTripletData(long var0);

    public static final native void btMeshPartData_vertices3f_set(long var0, btMeshPartData var2, long var3, btVector3FloatData var5);

    public static final native long btMeshPartData_vertices3f_get(long var0, btMeshPartData var2);

    public static final native void btMeshPartData_vertices3d_set(long var0, btMeshPartData var2, long var3, btVector3DoubleData var5);

    public static final native long btMeshPartData_vertices3d_get(long var0, btMeshPartData var2);

    public static final native void btMeshPartData_indices32_set(long var0, btMeshPartData var2, long var3, btIntIndexData var5);

    public static final native long btMeshPartData_indices32_get(long var0, btMeshPartData var2);

    public static final native void btMeshPartData_3indices16_set(long var0, btMeshPartData var2, long var3, btShortIntIndexTripletData var5);

    public static final native long btMeshPartData_3indices16_get(long var0, btMeshPartData var2);

    public static final native void btMeshPartData_3indices8_set(long var0, btMeshPartData var2, long var3, btCharIndexTripletData var5);

    public static final native long btMeshPartData_3indices8_get(long var0, btMeshPartData var2);

    public static final native void btMeshPartData_indices16_set(long var0, btMeshPartData var2, long var3, btShortIntIndexData var5);

    public static final native long btMeshPartData_indices16_get(long var0, btMeshPartData var2);

    public static final native void btMeshPartData_numTriangles_set(long var0, btMeshPartData var2, int var3);

    public static final native int btMeshPartData_numTriangles_get(long var0, btMeshPartData var2);

    public static final native void btMeshPartData_numVertices_set(long var0, btMeshPartData var2, int var3);

    public static final native int btMeshPartData_numVertices_get(long var0, btMeshPartData var2);

    public static final native long new_btMeshPartData();

    public static final native void delete_btMeshPartData(long var0);

    public static final native void btStridingMeshInterfaceData_meshPartsPtr_set(long var0, btStridingMeshInterfaceData var2, long var3, btMeshPartData var5);

    public static final native long btStridingMeshInterfaceData_meshPartsPtr_get(long var0, btStridingMeshInterfaceData var2);

    public static final native void btStridingMeshInterfaceData_scaling_set(long var0, btStridingMeshInterfaceData var2, long var3, btVector3FloatData var5);

    public static final native long btStridingMeshInterfaceData_scaling_get(long var0, btStridingMeshInterfaceData var2);

    public static final native void btStridingMeshInterfaceData_numMeshParts_set(long var0, btStridingMeshInterfaceData var2, int var3);

    public static final native int btStridingMeshInterfaceData_numMeshParts_get(long var0, btStridingMeshInterfaceData var2);

    public static final native void btStridingMeshInterfaceData_padding_set(long var0, btStridingMeshInterfaceData var2, String var3);

    public static final native String btStridingMeshInterfaceData_padding_get(long var0, btStridingMeshInterfaceData var2);

    public static final native long new_btStridingMeshInterfaceData();

    public static final native void delete_btStridingMeshInterfaceData(long var0);

    public static final native long btMinkowskiSumShape_operatorNew__SWIG_0(long var0, btMinkowskiSumShape var2, long var3);

    public static final native void btMinkowskiSumShape_operatorDelete__SWIG_0(long var0, btMinkowskiSumShape var2, long var3);

    public static final native long btMinkowskiSumShape_operatorNew__SWIG_1(long var0, btMinkowskiSumShape var2, long var3, long var5);

    public static final native void btMinkowskiSumShape_operatorDelete__SWIG_1(long var0, btMinkowskiSumShape var2, long var3, long var5);

    public static final native long btMinkowskiSumShape_operatorNewArray__SWIG_0(long var0, btMinkowskiSumShape var2, long var3);

    public static final native void btMinkowskiSumShape_operatorDeleteArray__SWIG_0(long var0, btMinkowskiSumShape var2, long var3);

    public static final native long btMinkowskiSumShape_operatorNewArray__SWIG_1(long var0, btMinkowskiSumShape var2, long var3, long var5);

    public static final native void btMinkowskiSumShape_operatorDeleteArray__SWIG_1(long var0, btMinkowskiSumShape var2, long var3, long var5);

    public static final native long new_btMinkowskiSumShape(long var0, btConvexShape var2, long var3, btConvexShape var5);

    public static final native void btMinkowskiSumShape_setTransformA(long var0, btMinkowskiSumShape var2, Matrix4 var3);

    public static final native void btMinkowskiSumShape_setTransformB(long var0, btMinkowskiSumShape var2, Matrix4 var3);

    public static final native Matrix4 btMinkowskiSumShape_getTransformA(long var0, btMinkowskiSumShape var2);

    public static final native Matrix4 btMinkowskiSumShape_GetTransformB(long var0, btMinkowskiSumShape var2);

    public static final native long btMinkowskiSumShape_getShapeA(long var0, btMinkowskiSumShape var2);

    public static final native long btMinkowskiSumShape_getShapeB(long var0, btMinkowskiSumShape var2);

    public static final native void delete_btMinkowskiSumShape(long var0);

    public static final native void btFace_indices_set(long var0, btFace var2, long var3);

    public static final native long btFace_indices_get(long var0, btFace var2);

    public static final native void btFace_plane_set(long var0, btFace var2, float[] var3);

    public static final native float[] btFace_plane_get(long var0, btFace var2);

    public static final native long new_btFace();

    public static final native void delete_btFace(long var0);

    public static final native long btConvexPolyhedron_operatorNew__SWIG_0(long var0, btConvexPolyhedron var2, long var3);

    public static final native void btConvexPolyhedron_operatorDelete__SWIG_0(long var0, btConvexPolyhedron var2, long var3);

    public static final native long btConvexPolyhedron_operatorNew__SWIG_1(long var0, btConvexPolyhedron var2, long var3, long var5);

    public static final native void btConvexPolyhedron_operatorDelete__SWIG_1(long var0, btConvexPolyhedron var2, long var3, long var5);

    public static final native long btConvexPolyhedron_operatorNewArray__SWIG_0(long var0, btConvexPolyhedron var2, long var3);

    public static final native void btConvexPolyhedron_operatorDeleteArray__SWIG_0(long var0, btConvexPolyhedron var2, long var3);

    public static final native long btConvexPolyhedron_operatorNewArray__SWIG_1(long var0, btConvexPolyhedron var2, long var3, long var5);

    public static final native void btConvexPolyhedron_operatorDeleteArray__SWIG_1(long var0, btConvexPolyhedron var2, long var3, long var5);

    public static final native long new_btConvexPolyhedron();

    public static final native void delete_btConvexPolyhedron(long var0);

    public static final native void btConvexPolyhedron_vertices_set(long var0, btConvexPolyhedron var2, long var3, btVector3Array var5);

    public static final native long btConvexPolyhedron_vertices_get(long var0, btConvexPolyhedron var2);

    public static final native void btConvexPolyhedron_faces_set(long var0, btConvexPolyhedron var2, long var3);

    public static final native long btConvexPolyhedron_faces_get(long var0, btConvexPolyhedron var2);

    public static final native void btConvexPolyhedron_uniqueEdges_set(long var0, btConvexPolyhedron var2, long var3, btVector3Array var5);

    public static final native long btConvexPolyhedron_uniqueEdges_get(long var0, btConvexPolyhedron var2);

    public static final native void btConvexPolyhedron_localCenter_set(long var0, btConvexPolyhedron var2, long var3, btVector3 var5);

    public static final native long btConvexPolyhedron_localCenter_get(long var0, btConvexPolyhedron var2);

    public static final native void btConvexPolyhedron_extents_set(long var0, btConvexPolyhedron var2, long var3, btVector3 var5);

    public static final native long btConvexPolyhedron_extents_get(long var0, btConvexPolyhedron var2);

    public static final native void btConvexPolyhedron_radius_set(long var0, btConvexPolyhedron var2, float var3);

    public static final native float btConvexPolyhedron_radius_get(long var0, btConvexPolyhedron var2);

    public static final native void btConvexPolyhedron_mC_set(long var0, btConvexPolyhedron var2, long var3, btVector3 var5);

    public static final native long btConvexPolyhedron_mC_get(long var0, btConvexPolyhedron var2);

    public static final native void btConvexPolyhedron_mE_set(long var0, btConvexPolyhedron var2, long var3, btVector3 var5);

    public static final native long btConvexPolyhedron_mE_get(long var0, btConvexPolyhedron var2);

    public static final native void btConvexPolyhedron_initialize(long var0, btConvexPolyhedron var2);

    public static final native boolean btConvexPolyhedron_testContainment(long var0, btConvexPolyhedron var2);

    public static final native void btConvexPolyhedron_project(long var0, btConvexPolyhedron var2, Matrix4 var3, Vector3 var4, long var5, long var7, Vector3 var9, Vector3 var10);

    public static final native long btOptimizedBvh_operatorNew__SWIG_0(long var0, btOptimizedBvh var2, long var3);

    public static final native void btOptimizedBvh_operatorDelete__SWIG_0(long var0, btOptimizedBvh var2, long var3);

    public static final native long btOptimizedBvh_operatorNew__SWIG_1(long var0, btOptimizedBvh var2, long var3, long var5);

    public static final native void btOptimizedBvh_operatorDelete__SWIG_1(long var0, btOptimizedBvh var2, long var3, long var5);

    public static final native long btOptimizedBvh_operatorNewArray__SWIG_0(long var0, btOptimizedBvh var2, long var3);

    public static final native void btOptimizedBvh_operatorDeleteArray__SWIG_0(long var0, btOptimizedBvh var2, long var3);

    public static final native long btOptimizedBvh_operatorNewArray__SWIG_1(long var0, btOptimizedBvh var2, long var3, long var5);

    public static final native void btOptimizedBvh_operatorDeleteArray__SWIG_1(long var0, btOptimizedBvh var2, long var3, long var5);

    public static final native long new_btOptimizedBvh();

    public static final native void delete_btOptimizedBvh(long var0);

    public static final native void btOptimizedBvh_build(long var0, btOptimizedBvh var2, long var3, btStridingMeshInterface var5, boolean var6, Vector3 var7, Vector3 var8);

    public static final native void btOptimizedBvh_refit(long var0, btOptimizedBvh var2, long var3, btStridingMeshInterface var5, Vector3 var6, Vector3 var7);

    public static final native void btOptimizedBvh_refitPartial(long var0, btOptimizedBvh var2, long var3, btStridingMeshInterface var5, Vector3 var6, Vector3 var7);

    public static final native void btOptimizedBvh_updateBvhNodes(long var0, btOptimizedBvh var2, long var3, btStridingMeshInterface var5, int var6, int var7, int var8);

    public static final native boolean btOptimizedBvh_serializeInPlace(long var0, btOptimizedBvh var2, long var3, long var5, boolean var7);

    public static final native long btOptimizedBvh_deSerializeInPlace(long var0, long var2, boolean var4);

    public static final native void btTriangle_vertex0_set(long var0, btTriangle var2, long var3, btVector3 var5);

    public static final native long btTriangle_vertex0_get(long var0, btTriangle var2);

    public static final native void btTriangle_vertex1_set(long var0, btTriangle var2, long var3, btVector3 var5);

    public static final native long btTriangle_vertex1_get(long var0, btTriangle var2);

    public static final native void btTriangle_vertex2_set(long var0, btTriangle var2, long var3, btVector3 var5);

    public static final native long btTriangle_vertex2_get(long var0, btTriangle var2);

    public static final native void btTriangle_partId_set(long var0, btTriangle var2, int var3);

    public static final native int btTriangle_partId_get(long var0, btTriangle var2);

    public static final native void btTriangle_triangleIndex_set(long var0, btTriangle var2, int var3);

    public static final native int btTriangle_triangleIndex_get(long var0, btTriangle var2);

    public static final native long new_btTriangle();

    public static final native void delete_btTriangle(long var0);

    public static final native int btTriangleBuffer_getNumTriangles(long var0, btTriangleBuffer var2);

    public static final native long btTriangleBuffer_getTriangle(long var0, btTriangleBuffer var2, int var3);

    public static final native void btTriangleBuffer_clearBuffer(long var0, btTriangleBuffer var2);

    public static final native long new_btTriangleBuffer();

    public static final native void delete_btTriangleBuffer(long var0);

    public static final native long btIndexedMesh_operatorNew__SWIG_0(long var0, btIndexedMesh var2, long var3);

    public static final native void btIndexedMesh_operatorDelete__SWIG_0(long var0, btIndexedMesh var2, long var3);

    public static final native long btIndexedMesh_operatorNew__SWIG_1(long var0, btIndexedMesh var2, long var3, long var5);

    public static final native void btIndexedMesh_operatorDelete__SWIG_1(long var0, btIndexedMesh var2, long var3, long var5);

    public static final native long btIndexedMesh_operatorNewArray__SWIG_0(long var0, btIndexedMesh var2, long var3);

    public static final native void btIndexedMesh_operatorDeleteArray__SWIG_0(long var0, btIndexedMesh var2, long var3);

    public static final native long btIndexedMesh_operatorNewArray__SWIG_1(long var0, btIndexedMesh var2, long var3, long var5);

    public static final native void btIndexedMesh_operatorDeleteArray__SWIG_1(long var0, btIndexedMesh var2, long var3, long var5);

    public static final native void btIndexedMesh_numTriangles_set(long var0, btIndexedMesh var2, int var3);

    public static final native int btIndexedMesh_numTriangles_get(long var0, btIndexedMesh var2);

    public static final native void btIndexedMesh_triangleIndexBase_set(long var0, btIndexedMesh var2, ByteBuffer var3);

    public static final native ByteBuffer btIndexedMesh_triangleIndexBase_get(long var0, btIndexedMesh var2);

    public static final native void btIndexedMesh_triangleIndexStride_set(long var0, btIndexedMesh var2, int var3);

    public static final native int btIndexedMesh_triangleIndexStride_get(long var0, btIndexedMesh var2);

    public static final native void btIndexedMesh_numVertices_set(long var0, btIndexedMesh var2, int var3);

    public static final native int btIndexedMesh_numVertices_get(long var0, btIndexedMesh var2);

    public static final native void btIndexedMesh_vertexBase_set(long var0, btIndexedMesh var2, ByteBuffer var3);

    public static final native ByteBuffer btIndexedMesh_vertexBase_get(long var0, btIndexedMesh var2);

    public static final native void btIndexedMesh_vertexStride_set(long var0, btIndexedMesh var2, int var3);

    public static final native int btIndexedMesh_vertexStride_get(long var0, btIndexedMesh var2);

    public static final native void btIndexedMesh_indexType_set(long var0, btIndexedMesh var2, int var3);

    public static final native int btIndexedMesh_indexType_get(long var0, btIndexedMesh var2);

    public static final native void btIndexedMesh_vertexType_set(long var0, btIndexedMesh var2, int var3);

    public static final native int btIndexedMesh_vertexType_get(long var0, btIndexedMesh var2);

    public static final native long new_btIndexedMesh();

    public static final native void btIndexedMesh_setTriangleIndexBase(long var0, btIndexedMesh var2, ShortBuffer var3);

    public static final native void btIndexedMesh_setVertexBase(long var0, btIndexedMesh var2, FloatBuffer var3);

    public static final native void btIndexedMesh_setVertices(long var0, btIndexedMesh var2, FloatBuffer var3, int var4, int var5, int var6);

    public static final native void btIndexedMesh_setIndices(long var0, btIndexedMesh var2, ShortBuffer var3, int var4, int var5);

    public static final native void delete_btIndexedMesh(long var0);

    public static final native long btTriangleIndexVertexArray_operatorNew__SWIG_0(long var0, btTriangleIndexVertexArray var2, long var3);

    public static final native void btTriangleIndexVertexArray_operatorDelete__SWIG_0(long var0, btTriangleIndexVertexArray var2, long var3);

    public static final native long btTriangleIndexVertexArray_operatorNew__SWIG_1(long var0, btTriangleIndexVertexArray var2, long var3, long var5);

    public static final native void btTriangleIndexVertexArray_operatorDelete__SWIG_1(long var0, btTriangleIndexVertexArray var2, long var3, long var5);

    public static final native long btTriangleIndexVertexArray_operatorNewArray__SWIG_0(long var0, btTriangleIndexVertexArray var2, long var3);

    public static final native void btTriangleIndexVertexArray_operatorDeleteArray__SWIG_0(long var0, btTriangleIndexVertexArray var2, long var3);

    public static final native long btTriangleIndexVertexArray_operatorNewArray__SWIG_1(long var0, btTriangleIndexVertexArray var2, long var3, long var5);

    public static final native void btTriangleIndexVertexArray_operatorDeleteArray__SWIG_1(long var0, btTriangleIndexVertexArray var2, long var3, long var5);

    public static final native long new_btTriangleIndexVertexArray();

    public static final native void delete_btTriangleIndexVertexArray(long var0);

    public static final native void btTriangleIndexVertexArray_internalAddIndexedMesh__SWIG_0(long var0, btTriangleIndexVertexArray var2, long var3, btIndexedMesh var5, int var6);

    public static final native void btTriangleIndexVertexArray_internalAddIndexedMesh__SWIG_1(long var0, btTriangleIndexVertexArray var2, long var3, btIndexedMesh var5);

    public static final native void btTriangleIndexVertexArray_getLockedVertexIndexBase__SWIG_0(long var0, btTriangleIndexVertexArray var2, long var3, long var5, long var7, long var9, long var11, long var13, long var15, long var17, int var19);

    public static final native void btTriangleIndexVertexArray_getLockedVertexIndexBase__SWIG_1(long var0, btTriangleIndexVertexArray var2, long var3, long var5, long var7, long var9, long var11, long var13, long var15, long var17);

    public static final native void btTriangleIndexVertexArray_getLockedReadOnlyVertexIndexBase__SWIG_0(long var0, btTriangleIndexVertexArray var2, long var3, long var5, long var7, long var9, long var11, long var13, long var15, long var17, int var19);

    public static final native void btTriangleIndexVertexArray_getLockedReadOnlyVertexIndexBase__SWIG_1(long var0, btTriangleIndexVertexArray var2, long var3, long var5, long var7, long var9, long var11, long var13, long var15, long var17);

    public static final native long btTriangleIndexVertexArray_getIndexedMeshArray(long var0, btTriangleIndexVertexArray var2);

    public static final native void btMaterial_friction_set(long var0, btMaterial var2, float var3);

    public static final native float btMaterial_friction_get(long var0, btMaterial var2);

    public static final native void btMaterial_restitution_set(long var0, btMaterial var2, float var3);

    public static final native float btMaterial_restitution_get(long var0, btMaterial var2);

    public static final native void btMaterial_pad_set(long var0, btMaterial var2, int[] var3);

    public static final native int[] btMaterial_pad_get(long var0, btMaterial var2);

    public static final native long new_btMaterial__SWIG_0();

    public static final native long new_btMaterial__SWIG_1(float var0, float var1);

    public static final native void delete_btMaterial(long var0);

    public static final native long btScaledBvhTriangleMeshShape_operatorNew__SWIG_0(long var0, btScaledBvhTriangleMeshShape var2, long var3);

    public static final native void btScaledBvhTriangleMeshShape_operatorDelete__SWIG_0(long var0, btScaledBvhTriangleMeshShape var2, long var3);

    public static final native long btScaledBvhTriangleMeshShape_operatorNew__SWIG_1(long var0, btScaledBvhTriangleMeshShape var2, long var3, long var5);

    public static final native void btScaledBvhTriangleMeshShape_operatorDelete__SWIG_1(long var0, btScaledBvhTriangleMeshShape var2, long var3, long var5);

    public static final native long btScaledBvhTriangleMeshShape_operatorNewArray__SWIG_0(long var0, btScaledBvhTriangleMeshShape var2, long var3);

    public static final native void btScaledBvhTriangleMeshShape_operatorDeleteArray__SWIG_0(long var0, btScaledBvhTriangleMeshShape var2, long var3);

    public static final native long btScaledBvhTriangleMeshShape_operatorNewArray__SWIG_1(long var0, btScaledBvhTriangleMeshShape var2, long var3, long var5);

    public static final native void btScaledBvhTriangleMeshShape_operatorDeleteArray__SWIG_1(long var0, btScaledBvhTriangleMeshShape var2, long var3, long var5);

    public static final native long new_btScaledBvhTriangleMeshShape(long var0, btBvhTriangleMeshShape var2, Vector3 var3);

    public static final native void delete_btScaledBvhTriangleMeshShape(long var0);

    public static final native long btScaledBvhTriangleMeshShape_getChildShape(long var0, btScaledBvhTriangleMeshShape var2);

    public static final native long btScaledBvhTriangleMeshShape_getChildShapeConst(long var0, btScaledBvhTriangleMeshShape var2);

    public static final native void btScaledTriangleMeshShapeData_trimeshShapeData_set(long var0, btScaledTriangleMeshShapeData var2, long var3, btTriangleMeshShapeData var5);

    public static final native long btScaledTriangleMeshShapeData_trimeshShapeData_get(long var0, btScaledTriangleMeshShapeData var2);

    public static final native void btScaledTriangleMeshShapeData_localScaling_set(long var0, btScaledTriangleMeshShapeData var2, long var3, btVector3FloatData var5);

    public static final native long btScaledTriangleMeshShapeData_localScaling_get(long var0, btScaledTriangleMeshShapeData var2);

    public static final native long new_btScaledTriangleMeshShapeData();

    public static final native void delete_btScaledTriangleMeshShapeData(long var0);

    public static final native long btShapeHull_operatorNew__SWIG_0(long var0, btShapeHull var2, long var3);

    public static final native void btShapeHull_operatorDelete__SWIG_0(long var0, btShapeHull var2, long var3);

    public static final native long btShapeHull_operatorNew__SWIG_1(long var0, btShapeHull var2, long var3, long var5);

    public static final native void btShapeHull_operatorDelete__SWIG_1(long var0, btShapeHull var2, long var3, long var5);

    public static final native long btShapeHull_operatorNewArray__SWIG_0(long var0, btShapeHull var2, long var3);

    public static final native void btShapeHull_operatorDeleteArray__SWIG_0(long var0, btShapeHull var2, long var3);

    public static final native long btShapeHull_operatorNewArray__SWIG_1(long var0, btShapeHull var2, long var3, long var5);

    public static final native void btShapeHull_operatorDeleteArray__SWIG_1(long var0, btShapeHull var2, long var3, long var5);

    public static final native long new_btShapeHull(long var0, btConvexShape var2);

    public static final native void delete_btShapeHull(long var0);

    public static final native boolean btShapeHull_buildHull(long var0, btShapeHull var2, float var3);

    public static final native int btShapeHull_numTriangles(long var0, btShapeHull var2);

    public static final native int btShapeHull_numVertices(long var0, btShapeHull var2);

    public static final native int btShapeHull_numIndices(long var0, btShapeHull var2);

    public static final native Vector3 btShapeHull_getVertex(long var0, btShapeHull var2, int var3);

    public static final native int btShapeHull_getIndex(long var0, btShapeHull var2, int var3);

    public static final native long btConvexHullShape_operatorNew__SWIG_0(long var0, btConvexHullShape var2, long var3);

    public static final native void btConvexHullShape_operatorDelete__SWIG_0(long var0, btConvexHullShape var2, long var3);

    public static final native long btConvexHullShape_operatorNew__SWIG_1(long var0, btConvexHullShape var2, long var3, long var5);

    public static final native void btConvexHullShape_operatorDelete__SWIG_1(long var0, btConvexHullShape var2, long var3, long var5);

    public static final native long btConvexHullShape_operatorNewArray__SWIG_0(long var0, btConvexHullShape var2, long var3);

    public static final native void btConvexHullShape_operatorDeleteArray__SWIG_0(long var0, btConvexHullShape var2, long var3);

    public static final native long btConvexHullShape_operatorNewArray__SWIG_1(long var0, btConvexHullShape var2, long var3, long var5);

    public static final native void btConvexHullShape_operatorDeleteArray__SWIG_1(long var0, btConvexHullShape var2, long var3, long var5);

    public static final native long new_btConvexHullShape__SWIG_0(FloatBuffer var0, int var1, int var2);

    public static final native long new_btConvexHullShape__SWIG_1(FloatBuffer var0, int var1);

    public static final native long new_btConvexHullShape__SWIG_2(FloatBuffer var0);

    public static final native long new_btConvexHullShape__SWIG_3();

    public static final native void btConvexHullShape_addPoint__SWIG_0(long var0, btConvexHullShape var2, Vector3 var3, boolean var4);

    public static final native void btConvexHullShape_addPoint__SWIG_1(long var0, btConvexHullShape var2, Vector3 var3);

    public static final native long btConvexHullShape_getUnscaledPoints(long var0, btConvexHullShape var2);

    public static final native long btConvexHullShape_getUnscaledPointsConst(long var0, btConvexHullShape var2);

    public static final native long btConvexHullShape_getPoints(long var0, btConvexHullShape var2);

    public static final native void btConvexHullShape_optimizeConvexHull(long var0, btConvexHullShape var2);

    public static final native Vector3 btConvexHullShape_getScaledPoint(long var0, btConvexHullShape var2, int var3);

    public static final native int btConvexHullShape_getNumPoints(long var0, btConvexHullShape var2);

    public static final native long new_btConvexHullShape__SWIG_4(long var0, btShapeHull var2);

    public static final native void delete_btConvexHullShape(long var0);

    public static final native void btConvexHullShapeData_convexInternalShapeData_set(long var0, btConvexHullShapeData var2, long var3, btConvexInternalShapeData var5);

    public static final native long btConvexHullShapeData_convexInternalShapeData_get(long var0, btConvexHullShapeData var2);

    public static final native void btConvexHullShapeData_unscaledPointsFloatPtr_set(long var0, btConvexHullShapeData var2, long var3, btVector3FloatData var5);

    public static final native long btConvexHullShapeData_unscaledPointsFloatPtr_get(long var0, btConvexHullShapeData var2);

    public static final native void btConvexHullShapeData_unscaledPointsDoublePtr_set(long var0, btConvexHullShapeData var2, long var3, btVector3DoubleData var5);

    public static final native long btConvexHullShapeData_unscaledPointsDoublePtr_get(long var0, btConvexHullShapeData var2);

    public static final native void btConvexHullShapeData_numUnscaledPoints_set(long var0, btConvexHullShapeData var2, int var3);

    public static final native int btConvexHullShapeData_numUnscaledPoints_get(long var0, btConvexHullShapeData var2);

    public static final native void btConvexHullShapeData_padding3_set(long var0, btConvexHullShapeData var2, String var3);

    public static final native String btConvexHullShapeData_padding3_get(long var0, btConvexHullShapeData var2);

    public static final native long new_btConvexHullShapeData();

    public static final native void delete_btConvexHullShapeData(long var0);

    public static final native void btMaterialProperties_numMaterials_set(long var0, btMaterialProperties var2, int var3);

    public static final native int btMaterialProperties_numMaterials_get(long var0, btMaterialProperties var2);

    public static final native void btMaterialProperties_materialBase_set(long var0, btMaterialProperties var2, ByteBuffer var3);

    public static final native ByteBuffer btMaterialProperties_materialBase_get(long var0, btMaterialProperties var2);

    public static final native void btMaterialProperties_materialStride_set(long var0, btMaterialProperties var2, int var3);

    public static final native int btMaterialProperties_materialStride_get(long var0, btMaterialProperties var2);

    public static final native void btMaterialProperties_materialType_set(long var0, btMaterialProperties var2, int var3);

    public static final native int btMaterialProperties_materialType_get(long var0, btMaterialProperties var2);

    public static final native void btMaterialProperties_numTriangles_set(long var0, btMaterialProperties var2, int var3);

    public static final native int btMaterialProperties_numTriangles_get(long var0, btMaterialProperties var2);

    public static final native void btMaterialProperties_triangleMaterialsBase_set(long var0, btMaterialProperties var2, ByteBuffer var3);

    public static final native ByteBuffer btMaterialProperties_triangleMaterialsBase_get(long var0, btMaterialProperties var2);

    public static final native void btMaterialProperties_triangleMaterialStride_set(long var0, btMaterialProperties var2, int var3);

    public static final native int btMaterialProperties_triangleMaterialStride_get(long var0, btMaterialProperties var2);

    public static final native void btMaterialProperties_triangleType_set(long var0, btMaterialProperties var2, int var3);

    public static final native int btMaterialProperties_triangleType_get(long var0, btMaterialProperties var2);

    public static final native long new_btMaterialProperties();

    public static final native void delete_btMaterialProperties(long var0);

    public static final native long btTriangleIndexVertexMaterialArray_operatorNew__SWIG_0(long var0, btTriangleIndexVertexMaterialArray var2, long var3);

    public static final native void btTriangleIndexVertexMaterialArray_operatorDelete__SWIG_0(long var0, btTriangleIndexVertexMaterialArray var2, long var3);

    public static final native long btTriangleIndexVertexMaterialArray_operatorNew__SWIG_1(long var0, btTriangleIndexVertexMaterialArray var2, long var3, long var5);

    public static final native void btTriangleIndexVertexMaterialArray_operatorDelete__SWIG_1(long var0, btTriangleIndexVertexMaterialArray var2, long var3, long var5);

    public static final native long btTriangleIndexVertexMaterialArray_operatorNewArray__SWIG_0(long var0, btTriangleIndexVertexMaterialArray var2, long var3);

    public static final native void btTriangleIndexVertexMaterialArray_operatorDeleteArray__SWIG_0(long var0, btTriangleIndexVertexMaterialArray var2, long var3);

    public static final native long btTriangleIndexVertexMaterialArray_operatorNewArray__SWIG_1(long var0, btTriangleIndexVertexMaterialArray var2, long var3, long var5);

    public static final native void btTriangleIndexVertexMaterialArray_operatorDeleteArray__SWIG_1(long var0, btTriangleIndexVertexMaterialArray var2, long var3, long var5);

    public static final native long new_btTriangleIndexVertexMaterialArray__SWIG_0();

    public static final native long new_btTriangleIndexVertexMaterialArray__SWIG_1(int var0, IntBuffer var1, int var2, int var3, FloatBuffer var4, int var5, int var6, ByteBuffer var7, int var8, IntBuffer var9, int var10);

    public static final native void delete_btTriangleIndexVertexMaterialArray(long var0);

    public static final native void btTriangleIndexVertexMaterialArray_addMaterialProperties__SWIG_0(long var0, btTriangleIndexVertexMaterialArray var2, long var3, btMaterialProperties var5, int var6);

    public static final native void btTriangleIndexVertexMaterialArray_addMaterialProperties__SWIG_1(long var0, btTriangleIndexVertexMaterialArray var2, long var3, btMaterialProperties var5);

    public static final native void btTriangleIndexVertexMaterialArray_getLockedMaterialBase__SWIG_0(long var0, btTriangleIndexVertexMaterialArray var2, long var3, long var5, long var7, long var9, long var11, long var13, long var15, long var17, int var19);

    public static final native void btTriangleIndexVertexMaterialArray_getLockedMaterialBase__SWIG_1(long var0, btTriangleIndexVertexMaterialArray var2, long var3, long var5, long var7, long var9, long var11, long var13, long var15, long var17);

    public static final native void btTriangleIndexVertexMaterialArray_getLockedReadOnlyMaterialBase__SWIG_0(long var0, btTriangleIndexVertexMaterialArray var2, long var3, long var5, long var7, long var9, long var11, long var13, long var15, long var17, int var19);

    public static final native void btTriangleIndexVertexMaterialArray_getLockedReadOnlyMaterialBase__SWIG_1(long var0, btTriangleIndexVertexMaterialArray var2, long var3, long var5, long var7, long var9, long var11, long var13, long var15, long var17);

    public static final native long btCylinderShape_operatorNew__SWIG_0(long var0, btCylinderShape var2, long var3);

    public static final native void btCylinderShape_operatorDelete__SWIG_0(long var0, btCylinderShape var2, long var3);

    public static final native long btCylinderShape_operatorNew__SWIG_1(long var0, btCylinderShape var2, long var3, long var5);

    public static final native void btCylinderShape_operatorDelete__SWIG_1(long var0, btCylinderShape var2, long var3, long var5);

    public static final native long btCylinderShape_operatorNewArray__SWIG_0(long var0, btCylinderShape var2, long var3);

    public static final native void btCylinderShape_operatorDeleteArray__SWIG_0(long var0, btCylinderShape var2, long var3);

    public static final native long btCylinderShape_operatorNewArray__SWIG_1(long var0, btCylinderShape var2, long var3, long var5);

    public static final native void btCylinderShape_operatorDeleteArray__SWIG_1(long var0, btCylinderShape var2, long var3, long var5);

    public static final native Vector3 btCylinderShape_getHalfExtentsWithMargin(long var0, btCylinderShape var2);

    public static final native Vector3 btCylinderShape_getHalfExtentsWithoutMargin(long var0, btCylinderShape var2);

    public static final native long new_btCylinderShape(Vector3 var0);

    public static final native int btCylinderShape_getUpAxis(long var0, btCylinderShape var2);

    public static final native float btCylinderShape_getRadius(long var0, btCylinderShape var2);

    public static final native void delete_btCylinderShape(long var0);

    public static final native long btCylinderShapeX_operatorNew__SWIG_0(long var0, btCylinderShapeX var2, long var3);

    public static final native void btCylinderShapeX_operatorDelete__SWIG_0(long var0, btCylinderShapeX var2, long var3);

    public static final native long btCylinderShapeX_operatorNew__SWIG_1(long var0, btCylinderShapeX var2, long var3, long var5);

    public static final native void btCylinderShapeX_operatorDelete__SWIG_1(long var0, btCylinderShapeX var2, long var3, long var5);

    public static final native long btCylinderShapeX_operatorNewArray__SWIG_0(long var0, btCylinderShapeX var2, long var3);

    public static final native void btCylinderShapeX_operatorDeleteArray__SWIG_0(long var0, btCylinderShapeX var2, long var3);

    public static final native long btCylinderShapeX_operatorNewArray__SWIG_1(long var0, btCylinderShapeX var2, long var3, long var5);

    public static final native void btCylinderShapeX_operatorDeleteArray__SWIG_1(long var0, btCylinderShapeX var2, long var3, long var5);

    public static final native long new_btCylinderShapeX(Vector3 var0);

    public static final native void delete_btCylinderShapeX(long var0);

    public static final native long btCylinderShapeZ_operatorNew__SWIG_0(long var0, btCylinderShapeZ var2, long var3);

    public static final native void btCylinderShapeZ_operatorDelete__SWIG_0(long var0, btCylinderShapeZ var2, long var3);

    public static final native long btCylinderShapeZ_operatorNew__SWIG_1(long var0, btCylinderShapeZ var2, long var3, long var5);

    public static final native void btCylinderShapeZ_operatorDelete__SWIG_1(long var0, btCylinderShapeZ var2, long var3, long var5);

    public static final native long btCylinderShapeZ_operatorNewArray__SWIG_0(long var0, btCylinderShapeZ var2, long var3);

    public static final native void btCylinderShapeZ_operatorDeleteArray__SWIG_0(long var0, btCylinderShapeZ var2, long var3);

    public static final native long btCylinderShapeZ_operatorNewArray__SWIG_1(long var0, btCylinderShapeZ var2, long var3, long var5);

    public static final native void btCylinderShapeZ_operatorDeleteArray__SWIG_1(long var0, btCylinderShapeZ var2, long var3, long var5);

    public static final native long new_btCylinderShapeZ(Vector3 var0);

    public static final native void delete_btCylinderShapeZ(long var0);

    public static final native void btCylinderShapeData_convexInternalShapeData_set(long var0, btCylinderShapeData var2, long var3, btConvexInternalShapeData var5);

    public static final native long btCylinderShapeData_convexInternalShapeData_get(long var0, btCylinderShapeData var2);

    public static final native void btCylinderShapeData_upAxis_set(long var0, btCylinderShapeData var2, int var3);

    public static final native int btCylinderShapeData_upAxis_get(long var0, btCylinderShapeData var2);

    public static final native void btCylinderShapeData_padding_set(long var0, btCylinderShapeData var2, String var3);

    public static final native String btCylinderShapeData_padding_get(long var0, btCylinderShapeData var2);

    public static final native long new_btCylinderShapeData();

    public static final native void delete_btCylinderShapeData(long var0);

    public static final native void btTriangleMesh_weldingThreshold_set(long var0, btTriangleMesh var2, float var3);

    public static final native float btTriangleMesh_weldingThreshold_get(long var0, btTriangleMesh var2);

    public static final native long new_btTriangleMesh__SWIG_0(boolean var0, boolean var1);

    public static final native long new_btTriangleMesh__SWIG_1(boolean var0);

    public static final native long new_btTriangleMesh__SWIG_2();

    public static final native boolean btTriangleMesh_getUse32bitIndices(long var0, btTriangleMesh var2);

    public static final native boolean btTriangleMesh_getUse4componentVertices(long var0, btTriangleMesh var2);

    public static final native void btTriangleMesh_addTriangle__SWIG_0(long var0, btTriangleMesh var2, Vector3 var3, Vector3 var4, Vector3 var5, boolean var6);

    public static final native void btTriangleMesh_addTriangle__SWIG_1(long var0, btTriangleMesh var2, Vector3 var3, Vector3 var4, Vector3 var5);

    public static final native void btTriangleMesh_addTriangleIndices(long var0, btTriangleMesh var2, int var3, int var4, int var5);

    public static final native int btTriangleMesh_getNumTriangles(long var0, btTriangleMesh var2);

    public static final native int btTriangleMesh_findOrAddVertex(long var0, btTriangleMesh var2, Vector3 var3, boolean var4);

    public static final native void btTriangleMesh_addIndex(long var0, btTriangleMesh var2, int var3);

    public static final native void delete_btTriangleMesh(long var0);

    public static final native long btConeShape_operatorNew__SWIG_0(long var0, btConeShape var2, long var3);

    public static final native void btConeShape_operatorDelete__SWIG_0(long var0, btConeShape var2, long var3);

    public static final native long btConeShape_operatorNew__SWIG_1(long var0, btConeShape var2, long var3, long var5);

    public static final native void btConeShape_operatorDelete__SWIG_1(long var0, btConeShape var2, long var3, long var5);

    public static final native long btConeShape_operatorNewArray__SWIG_0(long var0, btConeShape var2, long var3);

    public static final native void btConeShape_operatorDeleteArray__SWIG_0(long var0, btConeShape var2, long var3);

    public static final native long btConeShape_operatorNewArray__SWIG_1(long var0, btConeShape var2, long var3, long var5);

    public static final native void btConeShape_operatorDeleteArray__SWIG_1(long var0, btConeShape var2, long var3, long var5);

    public static final native long new_btConeShape(float var0, float var1);

    public static final native float btConeShape_getRadius(long var0, btConeShape var2);

    public static final native float btConeShape_getHeight(long var0, btConeShape var2);

    public static final native void btConeShape_setRadius(long var0, btConeShape var2, float var3);

    public static final native void btConeShape_setHeight(long var0, btConeShape var2, float var3);

    public static final native void btConeShape_setConeUpIndex(long var0, btConeShape var2, int var3);

    public static final native int btConeShape_getConeUpIndex(long var0, btConeShape var2);

    public static final native void delete_btConeShape(long var0);

    public static final native long new_btConeShapeX(float var0, float var1);

    public static final native void delete_btConeShapeX(long var0);

    public static final native long new_btConeShapeZ(float var0, float var1);

    public static final native void delete_btConeShapeZ(long var0);

    public static final native void btConeShapeData_convexInternalShapeData_set(long var0, btConeShapeData var2, long var3, btConvexInternalShapeData var5);

    public static final native long btConeShapeData_convexInternalShapeData_get(long var0, btConeShapeData var2);

    public static final native void btConeShapeData_upIndex_set(long var0, btConeShapeData var2, int var3);

    public static final native int btConeShapeData_upIndex_get(long var0, btConeShapeData var2);

    public static final native void btConeShapeData_padding_set(long var0, btConeShapeData var2, String var3);

    public static final native String btConeShapeData_padding_get(long var0, btConeShapeData var2);

    public static final native long new_btConeShapeData();

    public static final native void delete_btConeShapeData(long var0);

    public static final native long btConvexTriangleMeshShape_operatorNew__SWIG_0(long var0, btConvexTriangleMeshShape var2, long var3);

    public static final native void btConvexTriangleMeshShape_operatorDelete__SWIG_0(long var0, btConvexTriangleMeshShape var2, long var3);

    public static final native long btConvexTriangleMeshShape_operatorNew__SWIG_1(long var0, btConvexTriangleMeshShape var2, long var3, long var5);

    public static final native void btConvexTriangleMeshShape_operatorDelete__SWIG_1(long var0, btConvexTriangleMeshShape var2, long var3, long var5);

    public static final native long btConvexTriangleMeshShape_operatorNewArray__SWIG_0(long var0, btConvexTriangleMeshShape var2, long var3);

    public static final native void btConvexTriangleMeshShape_operatorDeleteArray__SWIG_0(long var0, btConvexTriangleMeshShape var2, long var3);

    public static final native long btConvexTriangleMeshShape_operatorNewArray__SWIG_1(long var0, btConvexTriangleMeshShape var2, long var3, long var5);

    public static final native void btConvexTriangleMeshShape_operatorDeleteArray__SWIG_1(long var0, btConvexTriangleMeshShape var2, long var3, long var5);

    public static final native long new_btConvexTriangleMeshShape__SWIG_0(long var0, btStridingMeshInterface var2, boolean var3);

    public static final native long new_btConvexTriangleMeshShape__SWIG_1(long var0, btStridingMeshInterface var2);

    public static final native long btConvexTriangleMeshShape_getMeshInterface(long var0, btConvexTriangleMeshShape var2);

    public static final native long btConvexTriangleMeshShape_getMeshInterfaceConst(long var0, btConvexTriangleMeshShape var2);

    public static final native void btConvexTriangleMeshShape_calculatePrincipalAxisTransform(long var0, btConvexTriangleMeshShape var2, Matrix4 var3, Vector3 var4, long var5);

    public static final native void delete_btConvexTriangleMeshShape(long var0);

    public static final native long btEmptyShape_operatorNew__SWIG_0(long var0, btEmptyShape var2, long var3);

    public static final native void btEmptyShape_operatorDelete__SWIG_0(long var0, btEmptyShape var2, long var3);

    public static final native long btEmptyShape_operatorNew__SWIG_1(long var0, btEmptyShape var2, long var3, long var5);

    public static final native void btEmptyShape_operatorDelete__SWIG_1(long var0, btEmptyShape var2, long var3, long var5);

    public static final native long btEmptyShape_operatorNewArray__SWIG_0(long var0, btEmptyShape var2, long var3);

    public static final native void btEmptyShape_operatorDeleteArray__SWIG_0(long var0, btEmptyShape var2, long var3);

    public static final native long btEmptyShape_operatorNewArray__SWIG_1(long var0, btEmptyShape var2, long var3, long var5);

    public static final native void btEmptyShape_operatorDeleteArray__SWIG_1(long var0, btEmptyShape var2, long var3, long var5);

    public static final native long new_btEmptyShape();

    public static final native void delete_btEmptyShape(long var0);

    public static final native long btMultimaterialTriangleMeshShape_operatorNew__SWIG_0(long var0, btMultimaterialTriangleMeshShape var2, long var3);

    public static final native void btMultimaterialTriangleMeshShape_operatorDelete__SWIG_0(long var0, btMultimaterialTriangleMeshShape var2, long var3);

    public static final native long btMultimaterialTriangleMeshShape_operatorNew__SWIG_1(long var0, btMultimaterialTriangleMeshShape var2, long var3, long var5);

    public static final native void btMultimaterialTriangleMeshShape_operatorDelete__SWIG_1(long var0, btMultimaterialTriangleMeshShape var2, long var3, long var5);

    public static final native long btMultimaterialTriangleMeshShape_operatorNewArray__SWIG_0(long var0, btMultimaterialTriangleMeshShape var2, long var3);

    public static final native void btMultimaterialTriangleMeshShape_operatorDeleteArray__SWIG_0(long var0, btMultimaterialTriangleMeshShape var2, long var3);

    public static final native long btMultimaterialTriangleMeshShape_operatorNewArray__SWIG_1(long var0, btMultimaterialTriangleMeshShape var2, long var3, long var5);

    public static final native void btMultimaterialTriangleMeshShape_operatorDeleteArray__SWIG_1(long var0, btMultimaterialTriangleMeshShape var2, long var3, long var5);

    public static final native long new_btMultimaterialTriangleMeshShape__SWIG_0(long var0, btStridingMeshInterface var2, boolean var3, boolean var4);

    public static final native long new_btMultimaterialTriangleMeshShape__SWIG_1(long var0, btStridingMeshInterface var2, boolean var3);

    public static final native long new_btMultimaterialTriangleMeshShape__SWIG_2(long var0, btStridingMeshInterface var2, boolean var3, Vector3 var4, Vector3 var5, boolean var6);

    public static final native long new_btMultimaterialTriangleMeshShape__SWIG_3(long var0, btStridingMeshInterface var2, boolean var3, Vector3 var4, Vector3 var5);

    public static final native void delete_btMultimaterialTriangleMeshShape(long var0);

    public static final native long btMultimaterialTriangleMeshShape_getMaterialProperties(long var0, btMultimaterialTriangleMeshShape var2, int var3, int var4);

    public static final native long btBU_Simplex1to4_operatorNew__SWIG_0(long var0, btBU_Simplex1to4 var2, long var3);

    public static final native void btBU_Simplex1to4_operatorDelete__SWIG_0(long var0, btBU_Simplex1to4 var2, long var3);

    public static final native long btBU_Simplex1to4_operatorNew__SWIG_1(long var0, btBU_Simplex1to4 var2, long var3, long var5);

    public static final native void btBU_Simplex1to4_operatorDelete__SWIG_1(long var0, btBU_Simplex1to4 var2, long var3, long var5);

    public static final native long btBU_Simplex1to4_operatorNewArray__SWIG_0(long var0, btBU_Simplex1to4 var2, long var3);

    public static final native void btBU_Simplex1to4_operatorDeleteArray__SWIG_0(long var0, btBU_Simplex1to4 var2, long var3);

    public static final native long btBU_Simplex1to4_operatorNewArray__SWIG_1(long var0, btBU_Simplex1to4 var2, long var3, long var5);

    public static final native void btBU_Simplex1to4_operatorDeleteArray__SWIG_1(long var0, btBU_Simplex1to4 var2, long var3, long var5);

    public static final native long new_btBU_Simplex1to4__SWIG_0();

    public static final native long new_btBU_Simplex1to4__SWIG_1(Vector3 var0);

    public static final native long new_btBU_Simplex1to4__SWIG_2(Vector3 var0, Vector3 var1);

    public static final native long new_btBU_Simplex1to4__SWIG_3(Vector3 var0, Vector3 var1, Vector3 var2);

    public static final native long new_btBU_Simplex1to4__SWIG_4(Vector3 var0, Vector3 var1, Vector3 var2, Vector3 var3);

    public static final native void btBU_Simplex1to4_reset(long var0, btBU_Simplex1to4 var2);

    public static final native void btBU_Simplex1to4_addVertex(long var0, btBU_Simplex1to4 var2, Vector3 var3);

    public static final native int btBU_Simplex1to4_getIndex(long var0, btBU_Simplex1to4 var2, int var3);

    public static final native void delete_btBU_Simplex1to4(long var0);

    public static final native long btUniformScalingShape_operatorNew__SWIG_0(long var0, btUniformScalingShape var2, long var3);

    public static final native void btUniformScalingShape_operatorDelete__SWIG_0(long var0, btUniformScalingShape var2, long var3);

    public static final native long btUniformScalingShape_operatorNew__SWIG_1(long var0, btUniformScalingShape var2, long var3, long var5);

    public static final native void btUniformScalingShape_operatorDelete__SWIG_1(long var0, btUniformScalingShape var2, long var3, long var5);

    public static final native long btUniformScalingShape_operatorNewArray__SWIG_0(long var0, btUniformScalingShape var2, long var3);

    public static final native void btUniformScalingShape_operatorDeleteArray__SWIG_0(long var0, btUniformScalingShape var2, long var3);

    public static final native long btUniformScalingShape_operatorNewArray__SWIG_1(long var0, btUniformScalingShape var2, long var3, long var5);

    public static final native void btUniformScalingShape_operatorDeleteArray__SWIG_1(long var0, btUniformScalingShape var2, long var3, long var5);

    public static final native long new_btUniformScalingShape(long var0, btConvexShape var2, float var3);

    public static final native void delete_btUniformScalingShape(long var0);

    public static final native float btUniformScalingShape_getUniformScalingFactor(long var0, btUniformScalingShape var2);

    public static final native long btUniformScalingShape_getChildShape(long var0, btUniformScalingShape var2);

    public static final native long btUniformScalingShape_getChildShapeConst(long var0, btUniformScalingShape var2);

    public static final native long btConvexPointCloudShape_operatorNew__SWIG_0(long var0, btConvexPointCloudShape var2, long var3);

    public static final native void btConvexPointCloudShape_operatorDelete__SWIG_0(long var0, btConvexPointCloudShape var2, long var3);

    public static final native long btConvexPointCloudShape_operatorNew__SWIG_1(long var0, btConvexPointCloudShape var2, long var3, long var5);

    public static final native void btConvexPointCloudShape_operatorDelete__SWIG_1(long var0, btConvexPointCloudShape var2, long var3, long var5);

    public static final native long btConvexPointCloudShape_operatorNewArray__SWIG_0(long var0, btConvexPointCloudShape var2, long var3);

    public static final native void btConvexPointCloudShape_operatorDeleteArray__SWIG_0(long var0, btConvexPointCloudShape var2, long var3);

    public static final native long btConvexPointCloudShape_operatorNewArray__SWIG_1(long var0, btConvexPointCloudShape var2, long var3, long var5);

    public static final native void btConvexPointCloudShape_operatorDeleteArray__SWIG_1(long var0, btConvexPointCloudShape var2, long var3, long var5);

    public static final native long new_btConvexPointCloudShape__SWIG_0();

    public static final native long new_btConvexPointCloudShape__SWIG_1(long var0, btVector3 var2, int var3, Vector3 var4, boolean var5);

    public static final native long new_btConvexPointCloudShape__SWIG_2(long var0, btVector3 var2, int var3, Vector3 var4);

    public static final native void btConvexPointCloudShape_setPoints__SWIG_0(long var0, btConvexPointCloudShape var2, long var3, btVector3 var5, int var6, boolean var7, Vector3 var8);

    public static final native void btConvexPointCloudShape_setPoints__SWIG_1(long var0, btConvexPointCloudShape var2, long var3, btVector3 var5, int var6, boolean var7);

    public static final native void btConvexPointCloudShape_setPoints__SWIG_2(long var0, btConvexPointCloudShape var2, long var3, btVector3 var5, int var6);

    public static final native long btConvexPointCloudShape_getUnscaledPoints(long var0, btConvexPointCloudShape var2);

    public static final native long btConvexPointCloudShape_getUnscaledPointsConst(long var0, btConvexPointCloudShape var2);

    public static final native int btConvexPointCloudShape_getNumPoints(long var0, btConvexPointCloudShape var2);

    public static final native Vector3 btConvexPointCloudShape_getScaledPoint(long var0, btConvexPointCloudShape var2, int var3);

    public static final native void delete_btConvexPointCloudShape(long var0);

    public static final native long btConvex2dShape_operatorNew__SWIG_0(long var0, btConvex2dShape var2, long var3);

    public static final native void btConvex2dShape_operatorDelete__SWIG_0(long var0, btConvex2dShape var2, long var3);

    public static final native long btConvex2dShape_operatorNew__SWIG_1(long var0, btConvex2dShape var2, long var3, long var5);

    public static final native void btConvex2dShape_operatorDelete__SWIG_1(long var0, btConvex2dShape var2, long var3, long var5);

    public static final native long btConvex2dShape_operatorNewArray__SWIG_0(long var0, btConvex2dShape var2, long var3);

    public static final native void btConvex2dShape_operatorDeleteArray__SWIG_0(long var0, btConvex2dShape var2, long var3);

    public static final native long btConvex2dShape_operatorNewArray__SWIG_1(long var0, btConvex2dShape var2, long var3, long var5);

    public static final native void btConvex2dShape_operatorDeleteArray__SWIG_1(long var0, btConvex2dShape var2, long var3, long var5);

    public static final native long new_btConvex2dShape(long var0, btConvexShape var2);

    public static final native void delete_btConvex2dShape(long var0);

    public static final native long btConvex2dShape_getChildShape(long var0, btConvex2dShape var2);

    public static final native long btConvex2dShape_getChildShapeConst(long var0, btConvex2dShape var2);

    public static final native long btCollisionObject_operatorNew__SWIG_0(long var0, btCollisionObject var2, long var3);

    public static final native void btCollisionObject_operatorDelete__SWIG_0(long var0, btCollisionObject var2, long var3);

    public static final native long btCollisionObject_operatorNew__SWIG_1(long var0, btCollisionObject var2, long var3, long var5);

    public static final native void btCollisionObject_operatorDelete__SWIG_1(long var0, btCollisionObject var2, long var3, long var5);

    public static final native long btCollisionObject_operatorNewArray__SWIG_0(long var0, btCollisionObject var2, long var3);

    public static final native void btCollisionObject_operatorDeleteArray__SWIG_0(long var0, btCollisionObject var2, long var3);

    public static final native long btCollisionObject_operatorNewArray__SWIG_1(long var0, btCollisionObject var2, long var3, long var5);

    public static final native void btCollisionObject_operatorDeleteArray__SWIG_1(long var0, btCollisionObject var2, long var3, long var5);

    public static final native boolean btCollisionObject_mergesSimulationIslands(long var0, btCollisionObject var2);

    public static final native Vector3 btCollisionObject_getAnisotropicFriction__SWIG_0(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setAnisotropicFriction__SWIG_0(long var0, btCollisionObject var2, Vector3 var3, int var4);

    public static final native void btCollisionObject_setAnisotropicFriction__SWIG_1(long var0, btCollisionObject var2, Vector3 var3);

    public static final native boolean btCollisionObject_hasAnisotropicFriction__SWIG_0(long var0, btCollisionObject var2, int var3);

    public static final native boolean btCollisionObject_hasAnisotropicFriction__SWIG_1(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setContactProcessingThreshold(long var0, btCollisionObject var2, float var3);

    public static final native float btCollisionObject_getContactProcessingThreshold(long var0, btCollisionObject var2);

    public static final native boolean btCollisionObject_isStaticObject(long var0, btCollisionObject var2);

    public static final native boolean btCollisionObject_isKinematicObject(long var0, btCollisionObject var2);

    public static final native boolean btCollisionObject_isStaticOrKinematicObject(long var0, btCollisionObject var2);

    public static final native boolean btCollisionObject_hasContactResponse(long var0, btCollisionObject var2);

    public static final native long new_btCollisionObject();

    public static final native void delete_btCollisionObject(long var0);

    public static final native void btCollisionObject_internalSetCollisionShape(long var0, btCollisionObject var2, long var3, btCollisionShape var5);

    public static final native long btCollisionObject_internalGetCollisionShape__SWIG_0(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setIgnoreCollisionCheck(long var0, btCollisionObject var2, long var3, btCollisionObject var5, boolean var6);

    public static final native boolean btCollisionObject_checkCollideWithOverride(long var0, btCollisionObject var2, long var3, btCollisionObject var5);

    public static final native long btCollisionObject_internalGetExtensionPointer(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_internalSetExtensionPointer(long var0, btCollisionObject var2, long var3);

    public static final native int btCollisionObject_getActivationState(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setActivationState(long var0, btCollisionObject var2, int var3);

    public static final native void btCollisionObject_setDeactivationTime(long var0, btCollisionObject var2, float var3);

    public static final native float btCollisionObject_getDeactivationTime(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_forceActivationState(long var0, btCollisionObject var2, int var3);

    public static final native void btCollisionObject_activate__SWIG_0(long var0, btCollisionObject var2, boolean var3);

    public static final native void btCollisionObject_activate__SWIG_1(long var0, btCollisionObject var2);

    public static final native boolean btCollisionObject_isActive(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setRestitution(long var0, btCollisionObject var2, float var3);

    public static final native float btCollisionObject_getRestitution(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setFriction(long var0, btCollisionObject var2, float var3);

    public static final native float btCollisionObject_getFriction(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setRollingFriction(long var0, btCollisionObject var2, float var3);

    public static final native float btCollisionObject_getRollingFriction(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setSpinningFriction(long var0, btCollisionObject var2, float var3);

    public static final native float btCollisionObject_getSpinningFriction(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setContactStiffnessAndDamping(long var0, btCollisionObject var2, float var3, float var4);

    public static final native float btCollisionObject_getContactStiffness(long var0, btCollisionObject var2);

    public static final native float btCollisionObject_getContactDamping(long var0, btCollisionObject var2);

    public static final native int btCollisionObject_getInternalType(long var0, btCollisionObject var2);

    public static final native Matrix4 btCollisionObject_getWorldTransform__SWIG_0(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setWorldTransform(long var0, btCollisionObject var2, Matrix4 var3);

    public static final native long btCollisionObject_getBroadphaseHandle__SWIG_0(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setBroadphaseHandle(long var0, btCollisionObject var2, long var3, btBroadphaseProxy var5);

    public static final native Matrix4 btCollisionObject_getInterpolationWorldTransform__SWIG_0(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setInterpolationWorldTransform(long var0, btCollisionObject var2, Matrix4 var3);

    public static final native void btCollisionObject_setInterpolationLinearVelocity(long var0, btCollisionObject var2, Vector3 var3);

    public static final native void btCollisionObject_setInterpolationAngularVelocity(long var0, btCollisionObject var2, Vector3 var3);

    public static final native Vector3 btCollisionObject_getInterpolationLinearVelocity__SWIG_0(long var0, btCollisionObject var2);

    public static final native Vector3 btCollisionObject_getInterpolationAngularVelocity__SWIG_0(long var0, btCollisionObject var2);

    public static final native int btCollisionObject_getIslandTag(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setIslandTag(long var0, btCollisionObject var2, int var3);

    public static final native int btCollisionObject_getCompanionId(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setCompanionId(long var0, btCollisionObject var2, int var3);

    public static final native int btCollisionObject_getWorldArrayIndex(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setWorldArrayIndex(long var0, btCollisionObject var2, int var3);

    public static final native float btCollisionObject_getHitFraction(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setHitFraction(long var0, btCollisionObject var2, float var3);

    public static final native int btCollisionObject_getCollisionFlags(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setCollisionFlags(long var0, btCollisionObject var2, int var3);

    public static final native float btCollisionObject_getCcdSweptSphereRadius(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setCcdSweptSphereRadius(long var0, btCollisionObject var2, float var3);

    public static final native float btCollisionObject_getCcdMotionThreshold(long var0, btCollisionObject var2);

    public static final native float btCollisionObject_getCcdSquareMotionThreshold(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setCcdMotionThreshold(long var0, btCollisionObject var2, float var3);

    public static final native long btCollisionObject_getUserPointer(long var0, btCollisionObject var2);

    public static final native int btCollisionObject_getUserIndex(long var0, btCollisionObject var2);

    public static final native int btCollisionObject_getUserIndex2(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setUserPointer(long var0, btCollisionObject var2, long var3);

    public static final native void btCollisionObject_setUserIndex(long var0, btCollisionObject var2, int var3);

    public static final native void btCollisionObject_setUserIndex2(long var0, btCollisionObject var2, int var3);

    public static final native int btCollisionObject_getUpdateRevisionInternal(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_setCustomDebugColor(long var0, btCollisionObject var2, Vector3 var3);

    public static final native void btCollisionObject_removeCustomDebugColor(long var0, btCollisionObject var2);

    public static final native boolean btCollisionObject_getCustomDebugColor(long var0, btCollisionObject var2, Vector3 var3);

    public static final native boolean btCollisionObject_checkCollideWith(long var0, btCollisionObject var2, long var3, btCollisionObject var5);

    public static final native int btCollisionObject_calculateSerializeBufferSize(long var0, btCollisionObject var2);

    public static final native String btCollisionObject_serialize(long var0, btCollisionObject var2, long var3, long var5, btSerializer var7);

    public static final native void btCollisionObject_serializeSingleObject(long var0, btCollisionObject var2, long var3, btSerializer var5);

    public static final native void btCollisionObject_internalSetGdxBridge(long var0, btCollisionObject var2, long var3, GdxCollisionObjectBridge var5);

    public static final native long btCollisionObject_internalGetGdxBridge(long var0, btCollisionObject var2);

    public static final native void btCollisionObject_getAnisotropicFriction__SWIG_1(long var0, btCollisionObject var2, Vector3 var3);

    public static final native void btCollisionObject_getWorldTransform__SWIG_2(long var0, btCollisionObject var2, Matrix4 var3);

    public static final native void btCollisionObject_getInterpolationWorldTransform__SWIG_2(long var0, btCollisionObject var2, Matrix4 var3);

    public static final native void btCollisionObject_getInterpolationLinearVelocity__SWIG_1(long var0, btCollisionObject var2, Vector3 var3);

    public static final native void btCollisionObject_getInterpolationAngularVelocity__SWIG_1(long var0, btCollisionObject var2, Vector3 var3);

    public static final native void btCollisionObjectDoubleData_broadphaseHandle_set(long var0, btCollisionObjectDoubleData var2, long var3);

    public static final native long btCollisionObjectDoubleData_broadphaseHandle_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_collisionShape_set(long var0, btCollisionObjectDoubleData var2, long var3);

    public static final native long btCollisionObjectDoubleData_collisionShape_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_rootCollisionShape_set(long var0, btCollisionObjectDoubleData var2, long var3, btCollisionShapeData var5);

    public static final native long btCollisionObjectDoubleData_rootCollisionShape_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_name_set(long var0, btCollisionObjectDoubleData var2, String var3);

    public static final native String btCollisionObjectDoubleData_name_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_worldTransform_set(long var0, btCollisionObjectDoubleData var2, long var3, btTransformDoubleData var5);

    public static final native long btCollisionObjectDoubleData_worldTransform_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_interpolationWorldTransform_set(long var0, btCollisionObjectDoubleData var2, long var3, btTransformDoubleData var5);

    public static final native long btCollisionObjectDoubleData_interpolationWorldTransform_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_interpolationLinearVelocity_set(long var0, btCollisionObjectDoubleData var2, long var3, btVector3DoubleData var5);

    public static final native long btCollisionObjectDoubleData_interpolationLinearVelocity_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_interpolationAngularVelocity_set(long var0, btCollisionObjectDoubleData var2, long var3, btVector3DoubleData var5);

    public static final native long btCollisionObjectDoubleData_interpolationAngularVelocity_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_anisotropicFriction_set(long var0, btCollisionObjectDoubleData var2, long var3, btVector3DoubleData var5);

    public static final native long btCollisionObjectDoubleData_anisotropicFriction_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_contactProcessingThreshold_set(long var0, btCollisionObjectDoubleData var2, double var3);

    public static final native double btCollisionObjectDoubleData_contactProcessingThreshold_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_deactivationTime_set(long var0, btCollisionObjectDoubleData var2, double var3);

    public static final native double btCollisionObjectDoubleData_deactivationTime_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_friction_set(long var0, btCollisionObjectDoubleData var2, double var3);

    public static final native double btCollisionObjectDoubleData_friction_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_rollingFriction_set(long var0, btCollisionObjectDoubleData var2, double var3);

    public static final native double btCollisionObjectDoubleData_rollingFriction_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_contactDamping_set(long var0, btCollisionObjectDoubleData var2, double var3);

    public static final native double btCollisionObjectDoubleData_contactDamping_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_contactStiffness_set(long var0, btCollisionObjectDoubleData var2, double var3);

    public static final native double btCollisionObjectDoubleData_contactStiffness_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_restitution_set(long var0, btCollisionObjectDoubleData var2, double var3);

    public static final native double btCollisionObjectDoubleData_restitution_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_hitFraction_set(long var0, btCollisionObjectDoubleData var2, double var3);

    public static final native double btCollisionObjectDoubleData_hitFraction_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_ccdSweptSphereRadius_set(long var0, btCollisionObjectDoubleData var2, double var3);

    public static final native double btCollisionObjectDoubleData_ccdSweptSphereRadius_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_ccdMotionThreshold_set(long var0, btCollisionObjectDoubleData var2, double var3);

    public static final native double btCollisionObjectDoubleData_ccdMotionThreshold_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_hasAnisotropicFriction_set(long var0, btCollisionObjectDoubleData var2, int var3);

    public static final native int btCollisionObjectDoubleData_hasAnisotropicFriction_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_collisionFlags_set(long var0, btCollisionObjectDoubleData var2, int var3);

    public static final native int btCollisionObjectDoubleData_collisionFlags_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_islandTag1_set(long var0, btCollisionObjectDoubleData var2, int var3);

    public static final native int btCollisionObjectDoubleData_islandTag1_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_companionId_set(long var0, btCollisionObjectDoubleData var2, int var3);

    public static final native int btCollisionObjectDoubleData_companionId_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_activationState1_set(long var0, btCollisionObjectDoubleData var2, int var3);

    public static final native int btCollisionObjectDoubleData_activationState1_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_internalType_set(long var0, btCollisionObjectDoubleData var2, int var3);

    public static final native int btCollisionObjectDoubleData_internalType_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_checkCollideWith_set(long var0, btCollisionObjectDoubleData var2, int var3);

    public static final native int btCollisionObjectDoubleData_checkCollideWith_get(long var0, btCollisionObjectDoubleData var2);

    public static final native void btCollisionObjectDoubleData_padding_set(long var0, btCollisionObjectDoubleData var2, String var3);

    public static final native String btCollisionObjectDoubleData_padding_get(long var0, btCollisionObjectDoubleData var2);

    public static final native long new_btCollisionObjectDoubleData();

    public static final native void delete_btCollisionObjectDoubleData(long var0);

    public static final native void btCollisionObjectFloatData_broadphaseHandle_set(long var0, btCollisionObjectFloatData var2, long var3);

    public static final native long btCollisionObjectFloatData_broadphaseHandle_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_collisionShape_set(long var0, btCollisionObjectFloatData var2, long var3);

    public static final native long btCollisionObjectFloatData_collisionShape_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_rootCollisionShape_set(long var0, btCollisionObjectFloatData var2, long var3, btCollisionShapeData var5);

    public static final native long btCollisionObjectFloatData_rootCollisionShape_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_name_set(long var0, btCollisionObjectFloatData var2, String var3);

    public static final native String btCollisionObjectFloatData_name_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_worldTransform_set(long var0, btCollisionObjectFloatData var2, long var3, btTransformFloatData var5);

    public static final native long btCollisionObjectFloatData_worldTransform_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_interpolationWorldTransform_set(long var0, btCollisionObjectFloatData var2, long var3, btTransformFloatData var5);

    public static final native long btCollisionObjectFloatData_interpolationWorldTransform_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_interpolationLinearVelocity_set(long var0, btCollisionObjectFloatData var2, long var3, btVector3FloatData var5);

    public static final native long btCollisionObjectFloatData_interpolationLinearVelocity_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_interpolationAngularVelocity_set(long var0, btCollisionObjectFloatData var2, long var3, btVector3FloatData var5);

    public static final native long btCollisionObjectFloatData_interpolationAngularVelocity_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_anisotropicFriction_set(long var0, btCollisionObjectFloatData var2, long var3, btVector3FloatData var5);

    public static final native long btCollisionObjectFloatData_anisotropicFriction_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_contactProcessingThreshold_set(long var0, btCollisionObjectFloatData var2, float var3);

    public static final native float btCollisionObjectFloatData_contactProcessingThreshold_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_deactivationTime_set(long var0, btCollisionObjectFloatData var2, float var3);

    public static final native float btCollisionObjectFloatData_deactivationTime_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_friction_set(long var0, btCollisionObjectFloatData var2, float var3);

    public static final native float btCollisionObjectFloatData_friction_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_rollingFriction_set(long var0, btCollisionObjectFloatData var2, float var3);

    public static final native float btCollisionObjectFloatData_rollingFriction_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_contactDamping_set(long var0, btCollisionObjectFloatData var2, float var3);

    public static final native float btCollisionObjectFloatData_contactDamping_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_contactStiffness_set(long var0, btCollisionObjectFloatData var2, float var3);

    public static final native float btCollisionObjectFloatData_contactStiffness_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_restitution_set(long var0, btCollisionObjectFloatData var2, float var3);

    public static final native float btCollisionObjectFloatData_restitution_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_hitFraction_set(long var0, btCollisionObjectFloatData var2, float var3);

    public static final native float btCollisionObjectFloatData_hitFraction_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_ccdSweptSphereRadius_set(long var0, btCollisionObjectFloatData var2, float var3);

    public static final native float btCollisionObjectFloatData_ccdSweptSphereRadius_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_ccdMotionThreshold_set(long var0, btCollisionObjectFloatData var2, float var3);

    public static final native float btCollisionObjectFloatData_ccdMotionThreshold_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_hasAnisotropicFriction_set(long var0, btCollisionObjectFloatData var2, int var3);

    public static final native int btCollisionObjectFloatData_hasAnisotropicFriction_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_collisionFlags_set(long var0, btCollisionObjectFloatData var2, int var3);

    public static final native int btCollisionObjectFloatData_collisionFlags_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_islandTag1_set(long var0, btCollisionObjectFloatData var2, int var3);

    public static final native int btCollisionObjectFloatData_islandTag1_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_companionId_set(long var0, btCollisionObjectFloatData var2, int var3);

    public static final native int btCollisionObjectFloatData_companionId_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_activationState1_set(long var0, btCollisionObjectFloatData var2, int var3);

    public static final native int btCollisionObjectFloatData_activationState1_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_internalType_set(long var0, btCollisionObjectFloatData var2, int var3);

    public static final native int btCollisionObjectFloatData_internalType_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_checkCollideWith_set(long var0, btCollisionObjectFloatData var2, int var3);

    public static final native int btCollisionObjectFloatData_checkCollideWith_get(long var0, btCollisionObjectFloatData var2);

    public static final native void btCollisionObjectFloatData_padding_set(long var0, btCollisionObjectFloatData var2, String var3);

    public static final native String btCollisionObjectFloatData_padding_get(long var0, btCollisionObjectFloatData var2);

    public static final native long new_btCollisionObjectFloatData();

    public static final native void delete_btCollisionObjectFloatData(long var0);

    public static final native void GdxCollisionObjectBridge_userValue_set(long var0, GdxCollisionObjectBridge var2, int var3);

    public static final native int GdxCollisionObjectBridge_userValue_get(long var0, GdxCollisionObjectBridge var2);

    public static final native void GdxCollisionObjectBridge_contactCallbackFlag_set(long var0, GdxCollisionObjectBridge var2, int var3);

    public static final native int GdxCollisionObjectBridge_contactCallbackFlag_get(long var0, GdxCollisionObjectBridge var2);

    public static final native void GdxCollisionObjectBridge_contactCallbackFilter_set(long var0, GdxCollisionObjectBridge var2, int var3);

    public static final native int GdxCollisionObjectBridge_contactCallbackFilter_get(long var0, GdxCollisionObjectBridge var2);

    public static final native long new_GdxCollisionObjectBridge();

    public static final native void delete_GdxCollisionObjectBridge(long var0);

    public static final native boolean gdxCheckFilter__SWIG_0(int var0, int var1);

    public static final native boolean gdxCheckFilter__SWIG_1(long var0, btCollisionObject var2, long var3, btCollisionObject var5);

    public static final native Vector3 btDbvtAabbMm_Center(long var0, btDbvtAabbMm var2);

    public static final native Vector3 btDbvtAabbMm_Lengths(long var0, btDbvtAabbMm var2);

    public static final native Vector3 btDbvtAabbMm_Extents(long var0, btDbvtAabbMm var2);

    public static final native Vector3 btDbvtAabbMm_Mins(long var0, btDbvtAabbMm var2);

    public static final native Vector3 btDbvtAabbMm_Maxs(long var0, btDbvtAabbMm var2);

    public static final native long btDbvtAabbMm_FromCE(Vector3 var0, Vector3 var1);

    public static final native long btDbvtAabbMm_FromCR(Vector3 var0, float var1);

    public static final native long btDbvtAabbMm_FromMM(Vector3 var0, Vector3 var1);

    public static final native long btDbvtAabbMm_FromPoints__SWIG_0(long var0, btVector3 var2, int var3);

    public static final native long btDbvtAabbMm_FromPoints__SWIG_1(long var0, int var2);

    public static final native void btDbvtAabbMm_Expand(long var0, btDbvtAabbMm var2, Vector3 var3);

    public static final native void btDbvtAabbMm_SignedExpand(long var0, btDbvtAabbMm var2, Vector3 var3);

    public static final native boolean btDbvtAabbMm_Contain(long var0, btDbvtAabbMm var2, long var3, btDbvtAabbMm var5);

    public static final native int btDbvtAabbMm_Classify(long var0, btDbvtAabbMm var2, Vector3 var3, float var4, int var5);

    public static final native float btDbvtAabbMm_ProjectMinimum(long var0, btDbvtAabbMm var2, Vector3 var3, long var4);

    public static final native boolean Intersect__SWIG_0(long var0, btDbvtAabbMm var2, long var3, btDbvtAabbMm var5);

    public static final native boolean Intersect__SWIG_1(long var0, btDbvtAabbMm var2, Vector3 var3);

    public static final native float Proximity(long var0, btDbvtAabbMm var2, long var3, btDbvtAabbMm var5);

    public static final native int Select(long var0, btDbvtAabbMm var2, long var3, btDbvtAabbMm var5, long var6, btDbvtAabbMm var8);

    public static final native void Merge(long var0, btDbvtAabbMm var2, long var3, btDbvtAabbMm var5, long var6, btDbvtAabbMm var8);

    public static final native boolean NotEqual(long var0, btDbvtAabbMm var2, long var3, btDbvtAabbMm var5);

    public static final native Vector3 btDbvtAabbMm_tMins(long var0, btDbvtAabbMm var2);

    public static final native Vector3 btDbvtAabbMm_tMaxs(long var0, btDbvtAabbMm var2);

    public static final native long new_btDbvtAabbMm();

    public static final native void delete_btDbvtAabbMm(long var0);

    public static final native void btDbvtNode_volume_set(long var0, btDbvtNode var2, long var3, btDbvtAabbMm var5);

    public static final native long btDbvtNode_volume_get(long var0, btDbvtNode var2);

    public static final native void btDbvtNode_parent_set(long var0, btDbvtNode var2, long var3, btDbvtNode var5);

    public static final native long btDbvtNode_parent_get(long var0, btDbvtNode var2);

    public static final native boolean btDbvtNode_isleaf(long var0, btDbvtNode var2);

    public static final native boolean btDbvtNode_isinternal(long var0, btDbvtNode var2);

    public static final native void btDbvtNode_childs_set(long var0, btDbvtNode var2, long var3);

    public static final native long btDbvtNode_childs_get(long var0, btDbvtNode var2);

    public static final native void btDbvtNode_data_set(long var0, btDbvtNode var2, long var3);

    public static final native long btDbvtNode_data_get(long var0, btDbvtNode var2);

    public static final native void btDbvtNode_dataAsInt_set(long var0, btDbvtNode var2, int var3);

    public static final native int btDbvtNode_dataAsInt_get(long var0, btDbvtNode var2);

    public static final native long btDbvtNode_getChild(long var0, btDbvtNode var2, int var3);

    public static final native long btDbvtNode_getChild0(long var0, btDbvtNode var2);

    public static final native long btDbvtNode_getChild1(long var0, btDbvtNode var2);

    public static final native long btDbvtNode_getDataAsProxy(long var0, btDbvtNode var2);

    public static final native long btDbvtNode_getDataAsProxyClientObject(long var0, btDbvtNode var2);

    public static final native long new_btDbvtNode();

    public static final native void delete_btDbvtNode(long var0);

    public static final native void btDbvt_sStkNN_a_set(long var0, btDbvt.sStkNN var2, long var3, btDbvtNode var5);

    public static final native long btDbvt_sStkNN_a_get(long var0, btDbvt.sStkNN var2);

    public static final native void btDbvt_sStkNN_b_set(long var0, btDbvt.sStkNN var2, long var3, btDbvtNode var5);

    public static final native long btDbvt_sStkNN_b_get(long var0, btDbvt.sStkNN var2);

    public static final native long new_btDbvt_sStkNN__SWIG_0();

    public static final native long new_btDbvt_sStkNN__SWIG_1(long var0, btDbvtNode var2, long var3, btDbvtNode var5);

    public static final native void delete_btDbvt_sStkNN(long var0);

    public static final native void btDbvt_sStkNP_node_set(long var0, btDbvt.sStkNP var2, long var3, btDbvtNode var5);

    public static final native long btDbvt_sStkNP_node_get(long var0, btDbvt.sStkNP var2);

    public static final native void btDbvt_sStkNP_mask_set(long var0, btDbvt.sStkNP var2, int var3);

    public static final native int btDbvt_sStkNP_mask_get(long var0, btDbvt.sStkNP var2);

    public static final native long new_btDbvt_sStkNP(long var0, btDbvtNode var2, long var3);

    public static final native void delete_btDbvt_sStkNP(long var0);

    public static final native void btDbvt_sStkNPS_node_set(long var0, btDbvt.sStkNPS var2, long var3, btDbvtNode var5);

    public static final native long btDbvt_sStkNPS_node_get(long var0, btDbvt.sStkNPS var2);

    public static final native void btDbvt_sStkNPS_mask_set(long var0, btDbvt.sStkNPS var2, int var3);

    public static final native int btDbvt_sStkNPS_mask_get(long var0, btDbvt.sStkNPS var2);

    public static final native void btDbvt_sStkNPS_value_set(long var0, btDbvt.sStkNPS var2, float var3);

    public static final native float btDbvt_sStkNPS_value_get(long var0, btDbvt.sStkNPS var2);

    public static final native long new_btDbvt_sStkNPS__SWIG_0();

    public static final native long new_btDbvt_sStkNPS__SWIG_1(long var0, btDbvtNode var2, long var3, float var5);

    public static final native void delete_btDbvt_sStkNPS(long var0);

    public static final native void btDbvt_sStkCLN_node_set(long var0, btDbvt.sStkCLN var2, long var3, btDbvtNode var5);

    public static final native long btDbvt_sStkCLN_node_get(long var0, btDbvt.sStkCLN var2);

    public static final native void btDbvt_sStkCLN_parent_set(long var0, btDbvt.sStkCLN var2, long var3, btDbvtNode var5);

    public static final native long btDbvt_sStkCLN_parent_get(long var0, btDbvt.sStkCLN var2);

    public static final native long new_btDbvt_sStkCLN(long var0, btDbvtNode var2, long var3, btDbvtNode var5);

    public static final native void delete_btDbvt_sStkCLN(long var0);

    public static final native void delete_btDbvt_IWriter(long var0);

    public static final native void btDbvt_IWriter_Prepare(long var0, btDbvt.IWriter var2, long var3, btDbvtNode var5, int var6);

    public static final native void btDbvt_IWriter_WriteNode(long var0, btDbvt.IWriter var2, long var3, btDbvtNode var5, int var6, int var7, int var8, int var9);

    public static final native void btDbvt_IWriter_WriteLeaf(long var0, btDbvt.IWriter var2, long var3, btDbvtNode var5, int var6, int var7);

    public static final native void delete_btDbvt_IClone(long var0);

    public static final native void btDbvt_IClone_CloneLeaf(long var0, btDbvt.IClone var2, long var3, btDbvtNode var5);

    public static final native long new_btDbvt_IClone();

    public static final native void btDbvt_root_set(long var0, btDbvt var2, long var3, btDbvtNode var5);

    public static final native long btDbvt_root_get(long var0, btDbvt var2);

    public static final native void btDbvt_free_set(long var0, btDbvt var2, long var3, btDbvtNode var5);

    public static final native long btDbvt_free_get(long var0, btDbvt var2);

    public static final native void btDbvt_lkhd_set(long var0, btDbvt var2, int var3);

    public static final native int btDbvt_lkhd_get(long var0, btDbvt var2);

    public static final native void btDbvt_leaves_set(long var0, btDbvt var2, int var3);

    public static final native int btDbvt_leaves_get(long var0, btDbvt var2);

    public static final native void btDbvt_opath_set(long var0, btDbvt var2, long var3);

    public static final native long btDbvt_opath_get(long var0, btDbvt var2);

    public static final native void btDbvt_stkStack_set(long var0, btDbvt var2, long var3);

    public static final native long btDbvt_stkStack_get(long var0, btDbvt var2);

    public static final native long new_btDbvt();

    public static final native void delete_btDbvt(long var0);

    public static final native void btDbvt_clear(long var0, btDbvt var2);

    public static final native boolean btDbvt_empty(long var0, btDbvt var2);

    public static final native void btDbvt_optimizeBottomUp(long var0, btDbvt var2);

    public static final native void btDbvt_optimizeTopDown__SWIG_0(long var0, btDbvt var2, int var3);

    public static final native void btDbvt_optimizeTopDown__SWIG_1(long var0, btDbvt var2);

    public static final native void btDbvt_optimizeIncremental(long var0, btDbvt var2, int var3);

    public static final native long btDbvt_insert(long var0, btDbvt var2, long var3, btDbvtAabbMm var5, long var6);

    public static final native void btDbvt_update__SWIG_0(long var0, btDbvt var2, long var3, btDbvtNode var5, int var6);

    public static final native void btDbvt_update__SWIG_1(long var0, btDbvt var2, long var3, btDbvtNode var5);

    public static final native void btDbvt_update__SWIG_2(long var0, btDbvt var2, long var3, btDbvtNode var5, long var6, btDbvtAabbMm var8);

    public static final native boolean btDbvt_update__SWIG_3(long var0, btDbvt var2, long var3, btDbvtNode var5, long var6, btDbvtAabbMm var8, Vector3 var9, float var10);

    public static final native boolean btDbvt_update__SWIG_4(long var0, btDbvt var2, long var3, btDbvtNode var5, long var6, btDbvtAabbMm var8, Vector3 var9);

    public static final native boolean btDbvt_update__SWIG_5(long var0, btDbvt var2, long var3, btDbvtNode var5, long var6, btDbvtAabbMm var8, float var9);

    public static final native void btDbvt_remove(long var0, btDbvt var2, long var3, btDbvtNode var5);

    public static final native void btDbvt_write(long var0, btDbvt var2, long var3, btDbvt.IWriter var5);

    public static final native void btDbvt_clone__SWIG_0(long var0, btDbvt var2, long var3, btDbvt var5, long var6, btDbvt.IClone var8);

    public static final native void btDbvt_clone__SWIG_1(long var0, btDbvt var2, long var3, btDbvt var5);

    public static final native int btDbvt_maxdepth(long var0, btDbvtNode var2);

    public static final native int btDbvt_countLeaves(long var0, btDbvtNode var2);

    public static final native void btDbvt_extractLeaves(long var0, btDbvtNode var2, long var3);

    public static final native void btDbvt_benchmark();

    public static final native void btDbvt_enumNodes(long var0, btDbvtNode var2, long var3, ICollide var5);

    public static final native void btDbvt_enumLeaves(long var0, btDbvtNode var2, long var3, ICollide var5);

    public static final native void btDbvt_collideTT(long var0, btDbvt var2, long var3, btDbvtNode var5, long var6, btDbvtNode var8, long var9, ICollide var11);

    public static final native void btDbvt_collideTTpersistentStack(long var0, btDbvt var2, long var3, btDbvtNode var5, long var6, btDbvtNode var8, long var9, ICollide var11);

    public static final native void btDbvt_collideTV(long var0, btDbvt var2, long var3, btDbvtNode var5, long var6, btDbvtAabbMm var8, long var9, ICollide var11);

    public static final native void btDbvt_collideTVNoStackAlloc(long var0, btDbvt var2, long var3, btDbvtNode var5, long var6, btDbvtAabbMm var8, long var9, long var11, ICollide var13);

    public static final native void btDbvt_rayTest(long var0, btDbvtNode var2, Vector3 var3, Vector3 var4, long var5, ICollide var7);

    public static final native void btDbvt_rayTestInternal(long var0, btDbvt var2, long var3, btDbvtNode var5, Vector3 var6, Vector3 var7, Vector3 var8, long[] var9, float var10, Vector3 var11, Vector3 var12, long var13, long var15, ICollide var17);

    public static final native void btDbvt_collideKDOP__SWIG_0(long var0, btDbvtNode var2, long var3, btVector3 var5, FloatBuffer var6, int var7, long var8, ICollide var10);

    public static final native void btDbvt_collideOCL__SWIG_0(long var0, btDbvtNode var2, long var3, btVector3 var5, FloatBuffer var6, Vector3 var7, int var8, long var9, ICollide var11, boolean var12);

    public static final native void btDbvt_collideOCL__SWIG_1(long var0, btDbvtNode var2, long var3, btVector3 var5, FloatBuffer var6, Vector3 var7, int var8, long var9, ICollide var11);

    public static final native void btDbvt_collideTU(long var0, btDbvtNode var2, long var3, ICollide var5);

    public static final native int btDbvt_nearest(IntBuffer var0, long var1, btDbvt.sStkNPS var3, float var4, int var5, int var6);

    public static final native int btDbvt_allocate(long var0, long var2, long var4, btDbvt.sStkNPS var6);

    public static final native void btDbvt_collideKDOP__SWIG_1(long var0, btDbvtNode var2, FloatBuffer var3, FloatBuffer var4, int var5, long var6, ICollide var8);

    public static final native void btDbvt_collideOCL__SWIG_2(long var0, btDbvtNode var2, FloatBuffer var3, FloatBuffer var4, Vector3 var5, int var6, long var7, ICollide var9, boolean var10);

    public static final native void btDbvt_collideOCL__SWIG_3(long var0, btDbvtNode var2, FloatBuffer var3, FloatBuffer var4, Vector3 var5, int var6, long var7, ICollide var9);

    public static final native void delete_ICollide(long var0);

    public static final native void ICollide_Process__SWIG_0(long var0, ICollide var2, long var3, btDbvtNode var5, long var6, btDbvtNode var8);

    public static final native void ICollide_ProcessSwigExplicitICollide__SWIG_0(long var0, ICollide var2, long var3, btDbvtNode var5, long var6, btDbvtNode var8);

    public static final native void ICollide_Process__SWIG_1(long var0, ICollide var2, long var3, btDbvtNode var5);

    public static final native void ICollide_ProcessSwigExplicitICollide__SWIG_1(long var0, ICollide var2, long var3, btDbvtNode var5);

    public static final native void ICollide_Process__SWIG_2(long var0, ICollide var2, long var3, btDbvtNode var5, float var6);

    public static final native void ICollide_ProcessSwigExplicitICollide__SWIG_2(long var0, ICollide var2, long var3, btDbvtNode var5, float var6);

    public static final native boolean ICollide_Descent(long var0, ICollide var2, long var3, btDbvtNode var5);

    public static final native boolean ICollide_DescentSwigExplicitICollide(long var0, ICollide var2, long var3, btDbvtNode var5);

    public static final native boolean ICollide_AllLeaves(long var0, ICollide var2, long var3, btDbvtNode var5);

    public static final native boolean ICollide_AllLeavesSwigExplicitICollide(long var0, ICollide var2, long var3, btDbvtNode var5);

    public static final native long new_ICollide();

    public static final native void ICollide_director_connect(ICollide var0, long var1, boolean var3, boolean var4);

    public static final native void ICollide_change_ownership(ICollide var0, long var1, boolean var3);

    public static final native void btDbvtProxy_leaf_set(long var0, btDbvtProxy var2, long var3, btDbvtNode var5);

    public static final native long btDbvtProxy_leaf_get(long var0, btDbvtProxy var2);

    public static final native void btDbvtProxy_links_set(long var0, btDbvtProxy var2, long var3);

    public static final native long btDbvtProxy_links_get(long var0, btDbvtProxy var2);

    public static final native void btDbvtProxy_stage_set(long var0, btDbvtProxy var2, int var3);

    public static final native int btDbvtProxy_stage_get(long var0, btDbvtProxy var2);

    public static final native long new_btDbvtProxy(Vector3 var0, Vector3 var1, long var2, int var4, int var5);

    public static final native void delete_btDbvtProxy(long var0);

    public static final native void btDbvtBroadphase_sets_set(long var0, btDbvtBroadphase var2, long var3, btDbvt var5);

    public static final native long btDbvtBroadphase_sets_get(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_stageRoots_set(long var0, btDbvtBroadphase var2, long var3);

    public static final native long btDbvtBroadphase_stageRoots_get(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_paircache_set(long var0, btDbvtBroadphase var2, long var3, btOverlappingPairCache var5);

    public static final native long btDbvtBroadphase_paircache_get(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_prediction_set(long var0, btDbvtBroadphase var2, float var3);

    public static final native float btDbvtBroadphase_prediction_get(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_stageCurrent_set(long var0, btDbvtBroadphase var2, int var3);

    public static final native int btDbvtBroadphase_stageCurrent_get(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_fupdates_set(long var0, btDbvtBroadphase var2, int var3);

    public static final native int btDbvtBroadphase_fupdates_get(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_dupdates_set(long var0, btDbvtBroadphase var2, int var3);

    public static final native int btDbvtBroadphase_dupdates_get(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_cupdates_set(long var0, btDbvtBroadphase var2, int var3);

    public static final native int btDbvtBroadphase_cupdates_get(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_newpairs_set(long var0, btDbvtBroadphase var2, int var3);

    public static final native int btDbvtBroadphase_newpairs_get(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_fixedleft_set(long var0, btDbvtBroadphase var2, int var3);

    public static final native int btDbvtBroadphase_fixedleft_get(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_updates_call_set(long var0, btDbvtBroadphase var2, long var3);

    public static final native long btDbvtBroadphase_updates_call_get(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_updates_done_set(long var0, btDbvtBroadphase var2, long var3);

    public static final native long btDbvtBroadphase_updates_done_get(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_updates_ratio_set(long var0, btDbvtBroadphase var2, float var3);

    public static final native float btDbvtBroadphase_updates_ratio_get(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_pid_set(long var0, btDbvtBroadphase var2, int var3);

    public static final native int btDbvtBroadphase_pid_get(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_cid_set(long var0, btDbvtBroadphase var2, int var3);

    public static final native int btDbvtBroadphase_cid_get(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_gid_set(long var0, btDbvtBroadphase var2, int var3);

    public static final native int btDbvtBroadphase_gid_get(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_releasepaircache_set(long var0, btDbvtBroadphase var2, boolean var3);

    public static final native boolean btDbvtBroadphase_releasepaircache_get(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_deferedcollide_set(long var0, btDbvtBroadphase var2, boolean var3);

    public static final native boolean btDbvtBroadphase_deferedcollide_get(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_needcleanup_set(long var0, btDbvtBroadphase var2, boolean var3);

    public static final native boolean btDbvtBroadphase_needcleanup_get(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_rayTestStacks_set(long var0, btDbvtBroadphase var2, long var3);

    public static final native long btDbvtBroadphase_rayTestStacks_get(long var0, btDbvtBroadphase var2);

    public static final native long new_btDbvtBroadphase__SWIG_0(long var0, btOverlappingPairCache var2);

    public static final native long new_btDbvtBroadphase__SWIG_1();

    public static final native void delete_btDbvtBroadphase(long var0);

    public static final native void btDbvtBroadphase_collide(long var0, btDbvtBroadphase var2, long var3, btDispatcher var5);

    public static final native void btDbvtBroadphase_optimize(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_rayTest__SWIG_0(long var0, btDbvtBroadphase var2, Vector3 var3, Vector3 var4, long var5, btBroadphaseRayCallback var7, Vector3 var8, Vector3 var9);

    public static final native void btDbvtBroadphase_rayTest__SWIG_1(long var0, btDbvtBroadphase var2, Vector3 var3, Vector3 var4, long var5, btBroadphaseRayCallback var7, Vector3 var8);

    public static final native void btDbvtBroadphase_rayTest__SWIG_2(long var0, btDbvtBroadphase var2, Vector3 var3, Vector3 var4, long var5, btBroadphaseRayCallback var7);

    public static final native void btDbvtBroadphase_performDeferredRemoval(long var0, btDbvtBroadphase var2, long var3, btDispatcher var5);

    public static final native void btDbvtBroadphase_setVelocityPrediction(long var0, btDbvtBroadphase var2, float var3);

    public static final native float btDbvtBroadphase_getVelocityPrediction(long var0, btDbvtBroadphase var2);

    public static final native void btDbvtBroadphase_setAabbForceUpdate(long var0, btDbvtBroadphase var2, long var3, btBroadphaseProxy var5, Vector3 var6, Vector3 var7, long var8, btDispatcher var10);

    public static final native void btDbvtBroadphase_benchmark(long var0, btBroadphaseInterface var2);

    public static final native long btDbvtBroadphase_getSet(long var0, btDbvtBroadphase var2, int var3);

    public static final native long btDbvtBroadphase_getSet0(long var0, btDbvtBroadphase var2);

    public static final native long btDbvtBroadphase_getSet1(long var0, btDbvtBroadphase var2);

    public static final native long btCompoundShapeChild_operatorNew__SWIG_0(long var0, btCompoundShapeChild var2, long var3);

    public static final native void btCompoundShapeChild_operatorDelete__SWIG_0(long var0, btCompoundShapeChild var2, long var3);

    public static final native long btCompoundShapeChild_operatorNew__SWIG_1(long var0, btCompoundShapeChild var2, long var3, long var5);

    public static final native void btCompoundShapeChild_operatorDelete__SWIG_1(long var0, btCompoundShapeChild var2, long var3, long var5);

    public static final native long btCompoundShapeChild_operatorNewArray__SWIG_0(long var0, btCompoundShapeChild var2, long var3);

    public static final native void btCompoundShapeChild_operatorDeleteArray__SWIG_0(long var0, btCompoundShapeChild var2, long var3);

    public static final native long btCompoundShapeChild_operatorNewArray__SWIG_1(long var0, btCompoundShapeChild var2, long var3, long var5);

    public static final native void btCompoundShapeChild_operatorDeleteArray__SWIG_1(long var0, btCompoundShapeChild var2, long var3, long var5);

    public static final native void btCompoundShapeChild_transform_set(long var0, btCompoundShapeChild var2, long var3, btTransform var5);

    public static final native long btCompoundShapeChild_transform_get(long var0, btCompoundShapeChild var2);

    public static final native void btCompoundShapeChild_childShape_set(long var0, btCompoundShapeChild var2, long var3, btCollisionShape var5);

    public static final native long btCompoundShapeChild_childShape_get(long var0, btCompoundShapeChild var2);

    public static final native void btCompoundShapeChild_childShapeType_set(long var0, btCompoundShapeChild var2, int var3);

    public static final native int btCompoundShapeChild_childShapeType_get(long var0, btCompoundShapeChild var2);

    public static final native void btCompoundShapeChild_childMargin_set(long var0, btCompoundShapeChild var2, float var3);

    public static final native float btCompoundShapeChild_childMargin_get(long var0, btCompoundShapeChild var2);

    public static final native void btCompoundShapeChild_node_set(long var0, btCompoundShapeChild var2, long var3, btDbvtNode var5);

    public static final native long btCompoundShapeChild_node_get(long var0, btCompoundShapeChild var2);

    public static final native long new_btCompoundShapeChild();

    public static final native void delete_btCompoundShapeChild(long var0);

    public static final native boolean operatorEqualTo__SWIG_4(long var0, btCompoundShapeChild var2, long var3, btCompoundShapeChild var5);

    public static final native long btCompoundShape_operatorNew__SWIG_0(long var0, btCompoundShape var2, long var3);

    public static final native void btCompoundShape_operatorDelete__SWIG_0(long var0, btCompoundShape var2, long var3);

    public static final native long btCompoundShape_operatorNew__SWIG_1(long var0, btCompoundShape var2, long var3, long var5);

    public static final native void btCompoundShape_operatorDelete__SWIG_1(long var0, btCompoundShape var2, long var3, long var5);

    public static final native long btCompoundShape_operatorNewArray__SWIG_0(long var0, btCompoundShape var2, long var3);

    public static final native void btCompoundShape_operatorDeleteArray__SWIG_0(long var0, btCompoundShape var2, long var3);

    public static final native long btCompoundShape_operatorNewArray__SWIG_1(long var0, btCompoundShape var2, long var3, long var5);

    public static final native void btCompoundShape_operatorDeleteArray__SWIG_1(long var0, btCompoundShape var2, long var3, long var5);

    public static final native long new_btCompoundShape__SWIG_0(boolean var0, int var1);

    public static final native long new_btCompoundShape__SWIG_1(boolean var0);

    public static final native long new_btCompoundShape__SWIG_2();

    public static final native void delete_btCompoundShape(long var0);

    public static final native void btCompoundShape_internalAddChildShape(long var0, btCompoundShape var2, Matrix4 var3, long var4, btCollisionShape var6);

    public static final native void btCompoundShape_internalRemoveChildShape(long var0, btCompoundShape var2, long var3, btCollisionShape var5);

    public static final native void btCompoundShape_internalRemoveChildShapeByIndex(long var0, btCompoundShape var2, int var3);

    public static final native int btCompoundShape_getNumChildShapes(long var0, btCompoundShape var2);

    public static final native Matrix4 btCompoundShape_getChildTransform(long var0, btCompoundShape var2, int var3);

    public static final native Matrix4 btCompoundShape_getChildTransformConst(long var0, btCompoundShape var2, int var3);

    public static final native void btCompoundShape_updateChildTransform__SWIG_0(long var0, btCompoundShape var2, int var3, Matrix4 var4, boolean var5);

    public static final native void btCompoundShape_updateChildTransform__SWIG_1(long var0, btCompoundShape var2, int var3, Matrix4 var4);

    public static final native long btCompoundShape_getChildList(long var0, btCompoundShape var2);

    public static final native void btCompoundShape_recalculateLocalAabb(long var0, btCompoundShape var2);

    public static final native long btCompoundShape_getDynamicAabbTreeConst(long var0, btCompoundShape var2);

    public static final native long btCompoundShape_getDynamicAabbTree(long var0, btCompoundShape var2);

    public static final native void btCompoundShape_createAabbTreeFromChildren(long var0, btCompoundShape var2);

    public static final native void btCompoundShape_calculatePrincipalAxisTransform(long var0, btCompoundShape var2, FloatBuffer var3, Matrix4 var4, Vector3 var5);

    public static final native int btCompoundShape_getUpdateRevision(long var0, btCompoundShape var2);

    public static final native void btCompoundShapeChildData_transform_set(long var0, btCompoundShapeChildData var2, long var3, btTransformFloatData var5);

    public static final native long btCompoundShapeChildData_transform_get(long var0, btCompoundShapeChildData var2);

    public static final native void btCompoundShapeChildData_childShape_set(long var0, btCompoundShapeChildData var2, long var3, btCollisionShapeData var5);

    public static final native long btCompoundShapeChildData_childShape_get(long var0, btCompoundShapeChildData var2);

    public static final native void btCompoundShapeChildData_childShapeType_set(long var0, btCompoundShapeChildData var2, int var3);

    public static final native int btCompoundShapeChildData_childShapeType_get(long var0, btCompoundShapeChildData var2);

    public static final native void btCompoundShapeChildData_childMargin_set(long var0, btCompoundShapeChildData var2, float var3);

    public static final native float btCompoundShapeChildData_childMargin_get(long var0, btCompoundShapeChildData var2);

    public static final native long new_btCompoundShapeChildData();

    public static final native void delete_btCompoundShapeChildData(long var0);

    public static final native void btCompoundShapeData_collisionShapeData_set(long var0, btCompoundShapeData var2, long var3, btCollisionShapeData var5);

    public static final native long btCompoundShapeData_collisionShapeData_get(long var0, btCompoundShapeData var2);

    public static final native void btCompoundShapeData_childShapePtr_set(long var0, btCompoundShapeData var2, long var3, btCompoundShapeChildData var5);

    public static final native long btCompoundShapeData_childShapePtr_get(long var0, btCompoundShapeData var2);

    public static final native void btCompoundShapeData_numChildShapes_set(long var0, btCompoundShapeData var2, int var3);

    public static final native int btCompoundShapeData_numChildShapes_get(long var0, btCompoundShapeData var2);

    public static final native void btCompoundShapeData_collisionMargin_set(long var0, btCompoundShapeData var2, float var3);

    public static final native float btCompoundShapeData_collisionMargin_get(long var0, btCompoundShapeData var2);

    public static final native long new_btCompoundShapeData();

    public static final native void delete_btCompoundShapeData(long var0);

    public static final native long btCollisionObjectArray_operatorAssignment(long var0, btCollisionObjectArray var2, long var3, btCollisionObjectArray var5);

    public static final native long new_btCollisionObjectArray__SWIG_0();

    public static final native void delete_btCollisionObjectArray(long var0);

    public static final native long new_btCollisionObjectArray__SWIG_1(long var0, btCollisionObjectArray var2);

    public static final native int btCollisionObjectArray_size(long var0, btCollisionObjectArray var2);

    public static final native long btCollisionObjectArray_atConst(long var0, btCollisionObjectArray var2, int var3);

    public static final native long btCollisionObjectArray_at(long var0, btCollisionObjectArray var2, int var3);

    public static final native long btCollisionObjectArray_operatorSubscriptConst(long var0, btCollisionObjectArray var2, int var3);

    public static final native long btCollisionObjectArray_operatorSubscript(long var0, btCollisionObjectArray var2, int var3);

    public static final native void btCollisionObjectArray_clear(long var0, btCollisionObjectArray var2);

    public static final native void btCollisionObjectArray_pop_back(long var0, btCollisionObjectArray var2);

    public static final native void btCollisionObjectArray_resizeNoInitialize(long var0, btCollisionObjectArray var2, int var3);

    public static final native void btCollisionObjectArray_resize__SWIG_0(long var0, btCollisionObjectArray var2, int var3, long var4, btCollisionObject var6);

    public static final native void btCollisionObjectArray_resize__SWIG_1(long var0, btCollisionObjectArray var2, int var3);

    public static final native long btCollisionObjectArray_expandNonInitializing(long var0, btCollisionObjectArray var2);

    public static final native long btCollisionObjectArray_expand__SWIG_0(long var0, btCollisionObjectArray var2, long var3, btCollisionObject var5);

    public static final native long btCollisionObjectArray_expand__SWIG_1(long var0, btCollisionObjectArray var2);

    public static final native void btCollisionObjectArray_push_back(long var0, btCollisionObjectArray var2, long var3, btCollisionObject var5);

    public static final native int btCollisionObjectArray_capacity(long var0, btCollisionObjectArray var2);

    public static final native void btCollisionObjectArray_reserve(long var0, btCollisionObjectArray var2, int var3);

    public static final native boolean btCollisionObjectArray_less_operatorFunctionCall(long var0, btCollisionObjectArray.less var2, long var3, btCollisionObject var5, long var6, btCollisionObject var8);

    public static final native long new_btCollisionObjectArray_less();

    public static final native void delete_btCollisionObjectArray_less(long var0);

    public static final native void btCollisionObjectArray_swap(long var0, btCollisionObjectArray var2, int var3, int var4);

    public static final native int btCollisionObjectArray_findBinarySearch(long var0, btCollisionObjectArray var2, long var3, btCollisionObject var5);

    public static final native int btCollisionObjectArray_findLinearSearch(long var0, btCollisionObjectArray var2, long var3, btCollisionObject var5);

    public static final native int btCollisionObjectArray_findLinearSearch2(long var0, btCollisionObjectArray var2, long var3, btCollisionObject var5);

    public static final native void btCollisionObjectArray_removeAtIndex(long var0, btCollisionObjectArray var2, int var3);

    public static final native void btCollisionObjectArray_remove(long var0, btCollisionObjectArray var2, long var3, btCollisionObject var5);

    public static final native void btCollisionObjectArray_initializeFromBuffer(long var0, btCollisionObjectArray var2, long var3, int var5, int var6);

    public static final native void btCollisionObjectArray_copyFromArray(long var0, btCollisionObjectArray var2, long var3, btCollisionObjectArray var5);

    public static final native long btCollisionObjectConstArray_operatorAssignment(long var0, btCollisionObjectConstArray var2, long var3, btCollisionObjectConstArray var5);

    public static final native long new_btCollisionObjectConstArray__SWIG_0();

    public static final native void delete_btCollisionObjectConstArray(long var0);

    public static final native long new_btCollisionObjectConstArray__SWIG_1(long var0, btCollisionObjectConstArray var2);

    public static final native int btCollisionObjectConstArray_size(long var0, btCollisionObjectConstArray var2);

    public static final native long btCollisionObjectConstArray_atConst(long var0, btCollisionObjectConstArray var2, int var3);

    public static final native long btCollisionObjectConstArray_at(long var0, btCollisionObjectConstArray var2, int var3);

    public static final native long btCollisionObjectConstArray_operatorSubscriptConst(long var0, btCollisionObjectConstArray var2, int var3);

    public static final native long btCollisionObjectConstArray_operatorSubscript(long var0, btCollisionObjectConstArray var2, int var3);

    public static final native void btCollisionObjectConstArray_clear(long var0, btCollisionObjectConstArray var2);

    public static final native void btCollisionObjectConstArray_pop_back(long var0, btCollisionObjectConstArray var2);

    public static final native void btCollisionObjectConstArray_resizeNoInitialize(long var0, btCollisionObjectConstArray var2, int var3);

    public static final native void btCollisionObjectConstArray_resize__SWIG_0(long var0, btCollisionObjectConstArray var2, int var3, long var4, btCollisionObject var6);

    public static final native void btCollisionObjectConstArray_resize__SWIG_1(long var0, btCollisionObjectConstArray var2, int var3);

    public static final native long btCollisionObjectConstArray_expandNonInitializing(long var0, btCollisionObjectConstArray var2);

    public static final native long btCollisionObjectConstArray_expand__SWIG_0(long var0, btCollisionObjectConstArray var2, long var3, btCollisionObject var5);

    public static final native long btCollisionObjectConstArray_expand__SWIG_1(long var0, btCollisionObjectConstArray var2);

    public static final native void btCollisionObjectConstArray_push_back(long var0, btCollisionObjectConstArray var2, long var3, btCollisionObject var5);

    public static final native int btCollisionObjectConstArray_capacity(long var0, btCollisionObjectConstArray var2);

    public static final native void btCollisionObjectConstArray_reserve(long var0, btCollisionObjectConstArray var2, int var3);

    public static final native boolean btCollisionObjectConstArray_less_operatorFunctionCall(long var0, btCollisionObjectConstArray.less var2, long var3, btCollisionObject var5, long var6, btCollisionObject var8);

    public static final native long new_btCollisionObjectConstArray_less();

    public static final native void delete_btCollisionObjectConstArray_less(long var0);

    public static final native void btCollisionObjectConstArray_swap(long var0, btCollisionObjectConstArray var2, int var3, int var4);

    public static final native int btCollisionObjectConstArray_findBinarySearch(long var0, btCollisionObjectConstArray var2, long var3, btCollisionObject var5);

    public static final native int btCollisionObjectConstArray_findLinearSearch(long var0, btCollisionObjectConstArray var2, long var3, btCollisionObject var5);

    public static final native int btCollisionObjectConstArray_findLinearSearch2(long var0, btCollisionObjectConstArray var2, long var3, btCollisionObject var5);

    public static final native void btCollisionObjectConstArray_removeAtIndex(long var0, btCollisionObjectConstArray var2, int var3);

    public static final native void btCollisionObjectConstArray_remove(long var0, btCollisionObjectConstArray var2, long var3, btCollisionObject var5);

    public static final native void btCollisionObjectConstArray_initializeFromBuffer(long var0, btCollisionObjectConstArray var2, long var3, int var5, int var6);

    public static final native void btCollisionObjectConstArray_copyFromArray(long var0, btCollisionObjectConstArray var2, long var3, btCollisionObjectConstArray var5);

    public static final native void btCollisionObjectWrapper_parent_set(long var0, btCollisionObjectWrapper var2, long var3, btCollisionObjectWrapper var5);

    public static final native long btCollisionObjectWrapper_parent_get(long var0, btCollisionObjectWrapper var2);

    public static final native void btCollisionObjectWrapper_shape_set(long var0, btCollisionObjectWrapper var2, long var3, btCollisionShape var5);

    public static final native long btCollisionObjectWrapper_shape_get(long var0, btCollisionObjectWrapper var2);

    public static final native void btCollisionObjectWrapper_collisionObject_set(long var0, btCollisionObjectWrapper var2, long var3, btCollisionObject var5);

    public static final native long btCollisionObjectWrapper_collisionObject_get(long var0, btCollisionObjectWrapper var2);

    public static final native Matrix4 btCollisionObjectWrapper_worldTransform_get(long var0, btCollisionObjectWrapper var2);

    public static final native void btCollisionObjectWrapper_partId_set(long var0, btCollisionObjectWrapper var2, int var3);

    public static final native int btCollisionObjectWrapper_partId_get(long var0, btCollisionObjectWrapper var2);

    public static final native void btCollisionObjectWrapper_index_set(long var0, btCollisionObjectWrapper var2, int var3);

    public static final native int btCollisionObjectWrapper_index_get(long var0, btCollisionObjectWrapper var2);

    public static final native long btCollisionObjectWrapper_getCollisionShape(long var0, btCollisionObjectWrapper var2);

    public static final native long new_CollisionObjectWrapper__SWIG_0(long var0, btCollisionObjectWrapper var2, long var3, btCollisionShape var5, long var6, btCollisionObject var8, Matrix4 var9, int var10, int var11);

    public static final native long new_CollisionObjectWrapper__SWIG_1(long var0, btCollisionObjectWrapper var2, long var3, btCollisionShape var5, long var6, btCollisionObject var8, Matrix4 var9, int var10);

    public static final native long new_CollisionObjectWrapper__SWIG_2(long var0, btCollisionObjectWrapper var2, long var3, btCollisionShape var5, long var6, btCollisionObject var8, Matrix4 var9);

    public static final native long new_CollisionObjectWrapper__SWIG_3(long var0, btCollisionShape var2, long var3, btCollisionObject var5, Matrix4 var6, int var7, int var8);

    public static final native long new_CollisionObjectWrapper__SWIG_4(long var0, btCollisionShape var2, long var3, btCollisionObject var5, Matrix4 var6, int var7);

    public static final native long new_CollisionObjectWrapper__SWIG_5(long var0, btCollisionShape var2, long var3, btCollisionObject var5, Matrix4 var6);

    public static final native long new_CollisionObjectWrapper__SWIG_6(long var0, btCollisionObjectWrapper var2, long var3, btCollisionObject var5, int var6, int var7);

    public static final native long new_CollisionObjectWrapper__SWIG_7(long var0, btCollisionObjectWrapper var2, long var3, btCollisionObject var5, int var6);

    public static final native long new_CollisionObjectWrapper__SWIG_8(long var0, btCollisionObjectWrapper var2, long var3, btCollisionObject var5);

    public static final native long new_CollisionObjectWrapper__SWIG_9(long var0, btCollisionObject var2, int var3, int var4);

    public static final native long new_CollisionObjectWrapper__SWIG_10(long var0, btCollisionObject var2, int var3);

    public static final native long new_CollisionObjectWrapper__SWIG_11(long var0, btCollisionObject var2);

    public static final native long CollisionObjectWrapper_getWrapper(long var0, CollisionObjectWrapper var2);

    public static final native void delete_CollisionObjectWrapper(long var0);

    public static final native void btCollisionAlgorithmCreateFunc_swapped_set(long var0, btCollisionAlgorithmCreateFunc var2, boolean var3);

    public static final native boolean btCollisionAlgorithmCreateFunc_swapped_get(long var0, btCollisionAlgorithmCreateFunc var2);

    public static final native long new_btCollisionAlgorithmCreateFunc();

    public static final native void delete_btCollisionAlgorithmCreateFunc(long var0);

    public static final native long btCollisionAlgorithmCreateFunc_CreateCollisionAlgorithm(long var0, btCollisionAlgorithmCreateFunc var2, long var3, btCollisionAlgorithmConstructionInfo var5, long var6, btCollisionObjectWrapper var8, long var9, btCollisionObjectWrapper var11);

    public static final native long new_btEmptyAlgorithm(long var0, btCollisionAlgorithmConstructionInfo var2);

    public static final native long new_btEmptyAlgorithm_CreateFunc();

    public static final native void delete_btEmptyAlgorithm_CreateFunc(long var0);

    public static final native void delete_btEmptyAlgorithm(long var0);

    public static final native void delete_btActivatingCollisionAlgorithm(long var0);

    public static final native long btConvexTriangleCallback_operatorNew__SWIG_0(long var0, btConvexTriangleCallback var2, long var3);

    public static final native void btConvexTriangleCallback_operatorDelete__SWIG_0(long var0, btConvexTriangleCallback var2, long var3);

    public static final native long btConvexTriangleCallback_operatorNew__SWIG_1(long var0, btConvexTriangleCallback var2, long var3, long var5);

    public static final native void btConvexTriangleCallback_operatorDelete__SWIG_1(long var0, btConvexTriangleCallback var2, long var3, long var5);

    public static final native long btConvexTriangleCallback_operatorNewArray__SWIG_0(long var0, btConvexTriangleCallback var2, long var3);

    public static final native void btConvexTriangleCallback_operatorDeleteArray__SWIG_0(long var0, btConvexTriangleCallback var2, long var3);

    public static final native long btConvexTriangleCallback_operatorNewArray__SWIG_1(long var0, btConvexTriangleCallback var2, long var3, long var5);

    public static final native void btConvexTriangleCallback_operatorDeleteArray__SWIG_1(long var0, btConvexTriangleCallback var2, long var3, long var5);

    public static final native void btConvexTriangleCallback_triangleCount_set(long var0, btConvexTriangleCallback var2, int var3);

    public static final native int btConvexTriangleCallback_triangleCount_get(long var0, btConvexTriangleCallback var2);

    public static final native void btConvexTriangleCallback_manifoldPtr_set(long var0, btConvexTriangleCallback var2, long var3, btPersistentManifold var5);

    public static final native long btConvexTriangleCallback_manifoldPtr_get(long var0, btConvexTriangleCallback var2);

    public static final native long new_btConvexTriangleCallback(long var0, btDispatcher var2, long var3, btCollisionObjectWrapper var5, long var6, btCollisionObjectWrapper var8, boolean var9);

    public static final native void btConvexTriangleCallback_setTimeStepAndCounters(long var0, btConvexTriangleCallback var2, float var3, long var4, btDispatcherInfo var6, long var7, btCollisionObjectWrapper var9, long var10, btCollisionObjectWrapper var12, long var13, btManifoldResult var15);

    public static final native void btConvexTriangleCallback_clearWrapperData(long var0, btConvexTriangleCallback var2);

    public static final native void delete_btConvexTriangleCallback(long var0);

    public static final native void btConvexTriangleCallback_processTriangle(long var0, btConvexTriangleCallback var2, long var3, btVector3 var5, int var6, int var7);

    public static final native void btConvexTriangleCallback_processTriangleSwigExplicitbtConvexTriangleCallback(long var0, btConvexTriangleCallback var2, long var3, btVector3 var5, int var6, int var7);

    public static final native void btConvexTriangleCallback_clearCache(long var0, btConvexTriangleCallback var2);

    public static final native Vector3 btConvexTriangleCallback_getAabbMin(long var0, btConvexTriangleCallback var2);

    public static final native Vector3 btConvexTriangleCallback_getAabbMax(long var0, btConvexTriangleCallback var2);

    public static final native void btConvexTriangleCallback_director_connect(btConvexTriangleCallback var0, long var1, boolean var3, boolean var4);

    public static final native void btConvexTriangleCallback_change_ownership(btConvexTriangleCallback var0, long var1, boolean var3);

    public static final native long btConvexConcaveCollisionAlgorithm_operatorNew__SWIG_0(long var0, btConvexConcaveCollisionAlgorithm var2, long var3);

    public static final native void btConvexConcaveCollisionAlgorithm_operatorDelete__SWIG_0(long var0, btConvexConcaveCollisionAlgorithm var2, long var3);

    public static final native long btConvexConcaveCollisionAlgorithm_operatorNew__SWIG_1(long var0, btConvexConcaveCollisionAlgorithm var2, long var3, long var5);

    public static final native void btConvexConcaveCollisionAlgorithm_operatorDelete__SWIG_1(long var0, btConvexConcaveCollisionAlgorithm var2, long var3, long var5);

    public static final native long btConvexConcaveCollisionAlgorithm_operatorNewArray__SWIG_0(long var0, btConvexConcaveCollisionAlgorithm var2, long var3);

    public static final native void btConvexConcaveCollisionAlgorithm_operatorDeleteArray__SWIG_0(long var0, btConvexConcaveCollisionAlgorithm var2, long var3);

    public static final native long btConvexConcaveCollisionAlgorithm_operatorNewArray__SWIG_1(long var0, btConvexConcaveCollisionAlgorithm var2, long var3, long var5);

    public static final native void btConvexConcaveCollisionAlgorithm_operatorDeleteArray__SWIG_1(long var0, btConvexConcaveCollisionAlgorithm var2, long var3, long var5);

    public static final native long new_btConvexConcaveCollisionAlgorithm(long var0, btCollisionAlgorithmConstructionInfo var2, long var3, btCollisionObjectWrapper var5, long var6, btCollisionObjectWrapper var8, boolean var9);

    public static final native void delete_btConvexConcaveCollisionAlgorithm(long var0);

    public static final native void btConvexConcaveCollisionAlgorithm_clearCache(long var0, btConvexConcaveCollisionAlgorithm var2);

    public static final native long new_btConvexConcaveCollisionAlgorithm_CreateFunc();

    public static final native void delete_btConvexConcaveCollisionAlgorithm_CreateFunc(long var0);

    public static final native long new_btConvexConcaveCollisionAlgorithm_SwappedCreateFunc();

    public static final native void delete_btConvexConcaveCollisionAlgorithm_SwappedCreateFunc(long var0);

    public static final native long new_btConvexPlaneCollisionAlgorithm(long var0, btPersistentManifold var2, long var3, btCollisionAlgorithmConstructionInfo var5, long var6, btCollisionObjectWrapper var8, long var9, btCollisionObjectWrapper var11, boolean var12, int var13, int var14);

    public static final native void delete_btConvexPlaneCollisionAlgorithm(long var0);

    public static final native void btConvexPlaneCollisionAlgorithm_collideSingleContact(long var0, btConvexPlaneCollisionAlgorithm var2, Quaternion var3, long var4, btCollisionObjectWrapper var6, long var7, btCollisionObjectWrapper var9, long var10, btDispatcherInfo var12, long var13, btManifoldResult var15);

    public static final native void btConvexPlaneCollisionAlgorithm_CreateFunc_numPerturbationIterations_set(long var0, btConvexPlaneCollisionAlgorithm.CreateFunc var2, int var3);

    public static final native int btConvexPlaneCollisionAlgorithm_CreateFunc_numPerturbationIterations_get(long var0, btConvexPlaneCollisionAlgorithm.CreateFunc var2);

    public static final native void btConvexPlaneCollisionAlgorithm_CreateFunc_minimumPointsPerturbationThreshold_set(long var0, btConvexPlaneCollisionAlgorithm.CreateFunc var2, int var3);

    public static final native int btConvexPlaneCollisionAlgorithm_CreateFunc_minimumPointsPerturbationThreshold_get(long var0, btConvexPlaneCollisionAlgorithm.CreateFunc var2);

    public static final native long new_btConvexPlaneCollisionAlgorithm_CreateFunc();

    public static final native void delete_btConvexPlaneCollisionAlgorithm_CreateFunc(long var0);

    public static final native void gCompoundChildShapePairCallback_set(long var0);

    public static final native long gCompoundChildShapePairCallback_get();

    public static final native long new_btCompoundCollisionAlgorithm(long var0, btCollisionAlgorithmConstructionInfo var2, long var3, btCollisionObjectWrapper var5, long var6, btCollisionObjectWrapper var8, boolean var9);

    public static final native void delete_btCompoundCollisionAlgorithm(long var0);

    public static final native long btCompoundCollisionAlgorithm_getChildAlgorithm(long var0, btCompoundCollisionAlgorithm var2, int var3);

    public static final native long new_btCompoundCollisionAlgorithm_CreateFunc();

    public static final native void delete_btCompoundCollisionAlgorithm_CreateFunc(long var0);

    public static final native long new_btCompoundCollisionAlgorithm_SwappedCreateFunc();

    public static final native void delete_btCompoundCollisionAlgorithm_SwappedCreateFunc(long var0);

    public static final native long new_btCompoundCompoundCollisionAlgorithm(long var0, btCollisionAlgorithmConstructionInfo var2, long var3, btCollisionObjectWrapper var5, long var6, btCollisionObjectWrapper var8, boolean var9);

    public static final native void delete_btCompoundCompoundCollisionAlgorithm(long var0);

    public static final native long new_btCompoundCompoundCollisionAlgorithm_CreateFunc();

    public static final native void delete_btCompoundCompoundCollisionAlgorithm_CreateFunc(long var0);

    public static final native long new_btCompoundCompoundCollisionAlgorithm_SwappedCreateFunc();

    public static final native void delete_btCompoundCompoundCollisionAlgorithm_SwappedCreateFunc(long var0);

    public static final native void delete_btCollisionConfiguration(long var0);

    public static final native long btCollisionConfiguration_getPersistentManifoldPool(long var0, btCollisionConfiguration var2);

    public static final native long btCollisionConfiguration_getCollisionAlgorithmPool(long var0, btCollisionConfiguration var2);

    public static final native long btCollisionConfiguration_getCollisionAlgorithmCreateFunc(long var0, btCollisionConfiguration var2, int var3, int var4);

    public static final native long btCollisionConfiguration_getClosestPointsAlgorithmCreateFunc(long var0, btCollisionConfiguration var2, int var3, int var4);

    public static final native void btDefaultCollisionConstructionInfo_persistentManifoldPool_set(long var0, btDefaultCollisionConstructionInfo var2, long var3, btPoolAllocator var5);

    public static final native long btDefaultCollisionConstructionInfo_persistentManifoldPool_get(long var0, btDefaultCollisionConstructionInfo var2);

    public static final native void btDefaultCollisionConstructionInfo_collisionAlgorithmPool_set(long var0, btDefaultCollisionConstructionInfo var2, long var3, btPoolAllocator var5);

    public static final native long btDefaultCollisionConstructionInfo_collisionAlgorithmPool_get(long var0, btDefaultCollisionConstructionInfo var2);

    public static final native void btDefaultCollisionConstructionInfo_defaultMaxPersistentManifoldPoolSize_set(long var0, btDefaultCollisionConstructionInfo var2, int var3);

    public static final native int btDefaultCollisionConstructionInfo_defaultMaxPersistentManifoldPoolSize_get(long var0, btDefaultCollisionConstructionInfo var2);

    public static final native void btDefaultCollisionConstructionInfo_defaultMaxCollisionAlgorithmPoolSize_set(long var0, btDefaultCollisionConstructionInfo var2, int var3);

    public static final native int btDefaultCollisionConstructionInfo_defaultMaxCollisionAlgorithmPoolSize_get(long var0, btDefaultCollisionConstructionInfo var2);

    public static final native void btDefaultCollisionConstructionInfo_customCollisionAlgorithmMaxElementSize_set(long var0, btDefaultCollisionConstructionInfo var2, int var3);

    public static final native int btDefaultCollisionConstructionInfo_customCollisionAlgorithmMaxElementSize_get(long var0, btDefaultCollisionConstructionInfo var2);

    public static final native void btDefaultCollisionConstructionInfo_useEpaPenetrationAlgorithm_set(long var0, btDefaultCollisionConstructionInfo var2, int var3);

    public static final native int btDefaultCollisionConstructionInfo_useEpaPenetrationAlgorithm_get(long var0, btDefaultCollisionConstructionInfo var2);

    public static final native long new_btDefaultCollisionConstructionInfo();

    public static final native void delete_btDefaultCollisionConstructionInfo(long var0);

    public static final native long new_btDefaultCollisionConfiguration__SWIG_0(long var0, btDefaultCollisionConstructionInfo var2);

    public static final native long new_btDefaultCollisionConfiguration__SWIG_1();

    public static final native void delete_btDefaultCollisionConfiguration(long var0);

    public static final native void btDefaultCollisionConfiguration_setConvexConvexMultipointIterations__SWIG_0(long var0, btDefaultCollisionConfiguration var2, int var3, int var4);

    public static final native void btDefaultCollisionConfiguration_setConvexConvexMultipointIterations__SWIG_1(long var0, btDefaultCollisionConfiguration var2, int var3);

    public static final native void btDefaultCollisionConfiguration_setConvexConvexMultipointIterations__SWIG_2(long var0, btDefaultCollisionConfiguration var2);

    public static final native void btDefaultCollisionConfiguration_setPlaneConvexMultipointIterations__SWIG_0(long var0, btDefaultCollisionConfiguration var2, int var3, int var4);

    public static final native void btDefaultCollisionConfiguration_setPlaneConvexMultipointIterations__SWIG_1(long var0, btDefaultCollisionConfiguration var2, int var3);

    public static final native void btDefaultCollisionConfiguration_setPlaneConvexMultipointIterations__SWIG_2(long var0, btDefaultCollisionConfiguration var2);

    public static final native void gContactAddedCallback_set(long var0);

    public static final native long gContactAddedCallback_get();

    public static final native long new_btManifoldResult__SWIG_0();

    public static final native long new_btManifoldResult__SWIG_1(long var0, btCollisionObjectWrapper var2, long var3, btCollisionObjectWrapper var5);

    public static final native void delete_btManifoldResult(long var0);

    public static final native void btManifoldResult_setPersistentManifold(long var0, btManifoldResult var2, long var3, btPersistentManifold var5);

    public static final native long btManifoldResult_getPersistentManifoldConst(long var0, btManifoldResult var2);

    public static final native long btManifoldResult_getPersistentManifold(long var0, btManifoldResult var2);

    public static final native void btManifoldResult_refreshContactPoints(long var0, btManifoldResult var2);

    public static final native long btManifoldResult_getBody0Wrap(long var0, btManifoldResult var2);

    public static final native long btManifoldResult_getBody1Wrap(long var0, btManifoldResult var2);

    public static final native void btManifoldResult_setBody0Wrap(long var0, btManifoldResult var2, long var3, btCollisionObjectWrapper var5);

    public static final native void btManifoldResult_setBody1Wrap(long var0, btManifoldResult var2, long var3, btCollisionObjectWrapper var5);

    public static final native long btManifoldResult_getBody0Internal(long var0, btManifoldResult var2);

    public static final native long btManifoldResult_getBody1Internal(long var0, btManifoldResult var2);

    public static final native void btManifoldResult_closestPointDistanceThreshold_set(long var0, btManifoldResult var2, float var3);

    public static final native float btManifoldResult_closestPointDistanceThreshold_get(long var0, btManifoldResult var2);

    public static final native float btManifoldResult_calculateCombinedRestitution(long var0, btCollisionObject var2, long var3, btCollisionObject var5);

    public static final native float btManifoldResult_calculateCombinedFriction(long var0, btCollisionObject var2, long var3, btCollisionObject var5);

    public static final native float btManifoldResult_calculateCombinedRollingFriction(long var0, btCollisionObject var2, long var3, btCollisionObject var5);

    public static final native float btManifoldResult_calculateCombinedSpinningFriction(long var0, btCollisionObject var2, long var3, btCollisionObject var5);

    public static final native float btManifoldResult_calculateCombinedContactDamping(long var0, btCollisionObject var2, long var3, btCollisionObject var5);

    public static final native float btManifoldResult_calculateCombinedContactStiffness(long var0, btCollisionObject var2, long var3, btCollisionObject var5);

    public static final native int BT_SIMPLE_NULL_PAIR_get();

    public static final native long new_btSimplePair(int var0, int var1);

    public static final native void btSimplePair_indexA_set(long var0, btSimplePair var2, int var3);

    public static final native int btSimplePair_indexA_get(long var0, btSimplePair var2);

    public static final native void btSimplePair_indexB_set(long var0, btSimplePair var2, int var3);

    public static final native int btSimplePair_indexB_get(long var0, btSimplePair var2);

    public static final native void btSimplePair_userPointer_set(long var0, btSimplePair var2, long var3);

    public static final native long btSimplePair_userPointer_get(long var0, btSimplePair var2);

    public static final native void btSimplePair_userValue_set(long var0, btSimplePair var2, int var3);

    public static final native int btSimplePair_userValue_get(long var0, btSimplePair var2);

    public static final native void delete_btSimplePair(long var0);

    public static final native void gOverlappingSimplePairs_set(int var0);

    public static final native int gOverlappingSimplePairs_get();

    public static final native void gRemoveSimplePairs_set(int var0);

    public static final native int gRemoveSimplePairs_get();

    public static final native void gAddedSimplePairs_set(int var0);

    public static final native int gAddedSimplePairs_get();

    public static final native void gFindSimplePairs_set(int var0);

    public static final native int gFindSimplePairs_get();

    public static final native long new_btHashedSimplePairCache();

    public static final native void delete_btHashedSimplePairCache(long var0);

    public static final native void btHashedSimplePairCache_removeAllPairs(long var0, btHashedSimplePairCache var2);

    public static final native long btHashedSimplePairCache_removeOverlappingPair(long var0, btHashedSimplePairCache var2, int var3, int var4);

    public static final native long btHashedSimplePairCache_addOverlappingPair(long var0, btHashedSimplePairCache var2, int var3, int var4);

    public static final native long btHashedSimplePairCache_getOverlappingPairArrayPtr(long var0, btHashedSimplePairCache var2);

    public static final native long btHashedSimplePairCache_getOverlappingPairArrayPtrConst(long var0, btHashedSimplePairCache var2);

    public static final native long btHashedSimplePairCache_getOverlappingPairArray(long var0, btHashedSimplePairCache var2);

    public static final native long btHashedSimplePairCache_getOverlappingPairArrayConst(long var0, btHashedSimplePairCache var2);

    public static final native long btHashedSimplePairCache_findPair(long var0, btHashedSimplePairCache var2, int var3, int var4);

    public static final native int btHashedSimplePairCache_GetCount(long var0, btHashedSimplePairCache var2);

    public static final native int btHashedSimplePairCache_getNumOverlappingPairs(long var0, btHashedSimplePairCache var2);

    public static final native long new_btSphereSphereCollisionAlgorithm__SWIG_0(long var0, btPersistentManifold var2, long var3, btCollisionAlgorithmConstructionInfo var5, long var6, btCollisionObjectWrapper var8, long var9, btCollisionObjectWrapper var11);

    public static final native long new_btSphereSphereCollisionAlgorithm__SWIG_1(long var0, btCollisionAlgorithmConstructionInfo var2);

    public static final native void delete_btSphereSphereCollisionAlgorithm(long var0);

    public static final native long new_btSphereSphereCollisionAlgorithm_CreateFunc();

    public static final native void delete_btSphereSphereCollisionAlgorithm_CreateFunc(long var0);

    public static final native long new_btBoxBoxCollisionAlgorithm__SWIG_0(long var0, btCollisionAlgorithmConstructionInfo var2);

    public static final native long new_btBoxBoxCollisionAlgorithm__SWIG_1(long var0, btPersistentManifold var2, long var3, btCollisionAlgorithmConstructionInfo var5, long var6, btCollisionObjectWrapper var8, long var9, btCollisionObjectWrapper var11);

    public static final native void delete_btBoxBoxCollisionAlgorithm(long var0);

    public static final native long new_btBoxBoxCollisionAlgorithm_CreateFunc();

    public static final native void delete_btBoxBoxCollisionAlgorithm_CreateFunc(long var0);

    public static final native long new_btBox2dBox2dCollisionAlgorithm__SWIG_0(long var0, btCollisionAlgorithmConstructionInfo var2);

    public static final native long new_btBox2dBox2dCollisionAlgorithm__SWIG_1(long var0, btPersistentManifold var2, long var3, btCollisionAlgorithmConstructionInfo var5, long var6, btCollisionObjectWrapper var8, long var9, btCollisionObjectWrapper var11);

    public static final native void delete_btBox2dBox2dCollisionAlgorithm(long var0);

    public static final native long new_btBox2dBox2dCollisionAlgorithm_CreateFunc();

    public static final native void delete_btBox2dBox2dCollisionAlgorithm_CreateFunc(long var0);

    public static final native void btElement_id_set(long var0, btElement var2, int var3);

    public static final native int btElement_id_get(long var0, btElement var2);

    public static final native void btElement_sz_set(long var0, btElement var2, int var3);

    public static final native int btElement_sz_get(long var0, btElement var2);

    public static final native long new_btElement();

    public static final native void delete_btElement(long var0);

    public static final native long new_btUnionFind();

    public static final native void delete_btUnionFind(long var0);

    public static final native void btUnionFind_sortIslands(long var0, btUnionFind var2);

    public static final native void btUnionFind_reset(long var0, btUnionFind var2, int var3);

    public static final native int btUnionFind_getNumElements(long var0, btUnionFind var2);

    public static final native boolean btUnionFind_isRoot(long var0, btUnionFind var2, int var3);

    public static final native long btUnionFind_getElement(long var0, btUnionFind var2, int var3);

    public static final native long btUnionFind_getElementConst(long var0, btUnionFind var2, int var3);

    public static final native void btUnionFind_allocate(long var0, btUnionFind var2, int var3);

    public static final native void btUnionFind_Free(long var0, btUnionFind var2);

    public static final native int btUnionFind_find__SWIG_0(long var0, btUnionFind var2, int var3, int var4);

    public static final native void btUnionFind_unite(long var0, btUnionFind var2, int var3, int var4);

    public static final native int btUnionFind_find__SWIG_1(long var0, btUnionFind var2, int var3);

    public static final native long new_btSphereTriangleCollisionAlgorithm__SWIG_0(long var0, btPersistentManifold var2, long var3, btCollisionAlgorithmConstructionInfo var5, long var6, btCollisionObjectWrapper var8, long var9, btCollisionObjectWrapper var11, boolean var12);

    public static final native long new_btSphereTriangleCollisionAlgorithm__SWIG_1(long var0, btCollisionAlgorithmConstructionInfo var2);

    public static final native void delete_btSphereTriangleCollisionAlgorithm(long var0);

    public static final native long new_btSphereTriangleCollisionAlgorithm_CreateFunc();

    public static final native void delete_btSphereTriangleCollisionAlgorithm_CreateFunc(long var0);

    public static final native long new_btSimulationIslandManager();

    public static final native void delete_btSimulationIslandManager(long var0);

    public static final native void btSimulationIslandManager_initUnionFind(long var0, btSimulationIslandManager var2, int var3);

    public static final native long btSimulationIslandManager_getUnionFind(long var0, btSimulationIslandManager var2);

    public static final native void btSimulationIslandManager_updateActivationState(long var0, btSimulationIslandManager var2, long var3, btCollisionWorld var5, long var6, btDispatcher var8);

    public static final native void btSimulationIslandManager_storeIslandActivationState(long var0, btSimulationIslandManager var2, long var3, btCollisionWorld var5);

    public static final native void btSimulationIslandManager_findUnions(long var0, btSimulationIslandManager var2, long var3, btDispatcher var5, long var6, btCollisionWorld var8);

    public static final native void delete_btSimulationIslandManager_IslandCallback(long var0);

    public static final native void btSimulationIslandManager_IslandCallback_processIsland(long var0, btSimulationIslandManager.IslandCallback var2, long var3, int var5, long var6, int var8, int var9);

    public static final native void btSimulationIslandManager_buildAndProcessIslands(long var0, btSimulationIslandManager var2, long var3, btDispatcher var5, long var6, btCollisionWorld var8, long var9, btSimulationIslandManager.IslandCallback var11);

    public static final native void btSimulationIslandManager_buildIslands(long var0, btSimulationIslandManager var2, long var3, btDispatcher var5, long var6, btCollisionWorld var8);

    public static final native boolean btSimulationIslandManager_getSplitIslands(long var0, btSimulationIslandManager var2);

    public static final native void btSimulationIslandManager_setSplitIslands(long var0, btSimulationIslandManager var2, boolean var3);

    public static final native long new_btGhostObject();

    public static final native void delete_btGhostObject(long var0);

    public static final native void btGhostObject_convexSweepTest__SWIG_0(long var0, btGhostObject var2, long var3, btConvexShape var5, Matrix4 var6, Matrix4 var7, long var8, ConvexResultCallback var10, float var11);

    public static final native void btGhostObject_convexSweepTest__SWIG_1(long var0, btGhostObject var2, long var3, btConvexShape var5, Matrix4 var6, Matrix4 var7, long var8, ConvexResultCallback var10);

    public static final native void btGhostObject_rayTest(long var0, btGhostObject var2, Vector3 var3, Vector3 var4, long var5, RayResultCallback var7);

    public static final native void btGhostObject_addOverlappingObjectInternal__SWIG_0(long var0, btGhostObject var2, long var3, btBroadphaseProxy var5, long var6, btBroadphaseProxy var8);

    public static final native void btGhostObject_addOverlappingObjectInternal__SWIG_1(long var0, btGhostObject var2, long var3, btBroadphaseProxy var5);

    public static final native void btGhostObject_removeOverlappingObjectInternal__SWIG_0(long var0, btGhostObject var2, long var3, btBroadphaseProxy var5, long var6, btDispatcher var8, long var9, btBroadphaseProxy var11);

    public static final native void btGhostObject_removeOverlappingObjectInternal__SWIG_1(long var0, btGhostObject var2, long var3, btBroadphaseProxy var5, long var6, btDispatcher var8);

    public static final native int btGhostObject_getNumOverlappingObjects(long var0, btGhostObject var2);

    public static final native long btGhostObject_getOverlappingObject(long var0, btGhostObject var2, int var3);

    public static final native long btGhostObject_getOverlappingObjectConst(long var0, btGhostObject var2, int var3);

    public static final native long btGhostObject_getOverlappingPairs(long var0, btGhostObject var2);

    public static final native long btGhostObject_getOverlappingPairsConst(long var0, btGhostObject var2);

    public static final native long btGhostObject_upcastConstBtCollisionObject(long var0, btCollisionObject var2);

    public static final native long btGhostObject_upcast(long var0, btCollisionObject var2);

    public static final native long new_btPairCachingGhostObject();

    public static final native void delete_btPairCachingGhostObject(long var0);

    public static final native void btPairCachingGhostObject_addOverlappingObjectInternal__SWIG_0(long var0, btPairCachingGhostObject var2, long var3, btBroadphaseProxy var5, long var6, btBroadphaseProxy var8);

    public static final native void btPairCachingGhostObject_addOverlappingObjectInternal__SWIG_1(long var0, btPairCachingGhostObject var2, long var3, btBroadphaseProxy var5);

    public static final native void btPairCachingGhostObject_removeOverlappingObjectInternal__SWIG_0(long var0, btPairCachingGhostObject var2, long var3, btBroadphaseProxy var5, long var6, btDispatcher var8, long var9, btBroadphaseProxy var11);

    public static final native void btPairCachingGhostObject_removeOverlappingObjectInternal__SWIG_1(long var0, btPairCachingGhostObject var2, long var3, btBroadphaseProxy var5, long var6, btDispatcher var8);

    public static final native long btPairCachingGhostObject_getOverlappingPairCache(long var0, btPairCachingGhostObject var2);

    public static final native long new_btGhostPairCallback();

    public static final native void delete_btGhostPairCallback(long var0);

    public static final native long btGhostPairCallback_removeOverlappingPair(long var0, btGhostPairCallback var2, long var3, btBroadphaseProxy var5, long var6, btBroadphaseProxy var8, long var9, btDispatcher var11);

    public static final native long btGhostPairCallback_removeOverlappingPairSwigExplicitbtGhostPairCallback(long var0, btGhostPairCallback var2, long var3, btBroadphaseProxy var5, long var6, btBroadphaseProxy var8, long var9, btDispatcher var11);

    public static final native void btGhostPairCallback_removeOverlappingPairsContainingProxy(long var0, btGhostPairCallback var2, long var3, btBroadphaseProxy var5, long var6, btDispatcher var8);

    public static final native void btGhostPairCallback_removeOverlappingPairsContainingProxySwigExplicitbtGhostPairCallback(long var0, btGhostPairCallback var2, long var3, btBroadphaseProxy var5, long var6, btDispatcher var8);

    public static final native void btGhostPairCallback_director_connect(btGhostPairCallback var0, long var1, boolean var3, boolean var4);

    public static final native void btGhostPairCallback_change_ownership(btGhostPairCallback var0, long var1, boolean var3);

    public static final native long new_btCollisionWorld(long var0, btDispatcher var2, long var3, btBroadphaseInterface var5, long var6, btCollisionConfiguration var8);

    public static final native void delete_btCollisionWorld(long var0);

    public static final native void btCollisionWorld_setBroadphase(long var0, btCollisionWorld var2, long var3, btBroadphaseInterface var5);

    public static final native long btCollisionWorld_getBroadphaseConst(long var0, btCollisionWorld var2);

    public static final native long btCollisionWorld_getBroadphase(long var0, btCollisionWorld var2);

    public static final native long btCollisionWorld_getPairCache(long var0, btCollisionWorld var2);

    public static final native long btCollisionWorld_getDispatcher(long var0, btCollisionWorld var2);

    public static final native long btCollisionWorld_getDispatcherConst(long var0, btCollisionWorld var2);

    public static final native void btCollisionWorld_updateSingleAabb(long var0, btCollisionWorld var2, long var3, btCollisionObject var5);

    public static final native void btCollisionWorld_updateAabbs(long var0, btCollisionWorld var2);

    public static final native void btCollisionWorld_computeOverlappingPairs(long var0, btCollisionWorld var2);

    public static final native void btCollisionWorld_setDebugDrawer(long var0, btCollisionWorld var2, long var3, btIDebugDraw var5);

    public static final native long btCollisionWorld_getDebugDrawer(long var0, btCollisionWorld var2);

    public static final native void btCollisionWorld_debugDrawWorld(long var0, btCollisionWorld var2);

    public static final native void btCollisionWorld_debugDrawObject(long var0, btCollisionWorld var2, Matrix4 var3, long var4, btCollisionShape var6, Vector3 var7);

    public static final native int btCollisionWorld_getNumCollisionObjects(long var0, btCollisionWorld var2);

    public static final native void btCollisionWorld_rayTest(long var0, btCollisionWorld var2, Vector3 var3, Vector3 var4, long var5, RayResultCallback var7);

    public static final native void btCollisionWorld_convexSweepTest__SWIG_0(long var0, btCollisionWorld var2, long var3, btConvexShape var5, Matrix4 var6, Matrix4 var7, long var8, ConvexResultCallback var10, float var11);

    public static final native void btCollisionWorld_convexSweepTest__SWIG_1(long var0, btCollisionWorld var2, long var3, btConvexShape var5, Matrix4 var6, Matrix4 var7, long var8, ConvexResultCallback var10);

    public static final native void btCollisionWorld_contactTest(long var0, btCollisionWorld var2, long var3, btCollisionObject var5, long var6, ContactResultCallback var8);

    public static final native void btCollisionWorld_contactPairTest(long var0, btCollisionWorld var2, long var3, btCollisionObject var5, long var6, btCollisionObject var8, long var9, ContactResultCallback var11);

    public static final native void btCollisionWorld_rayTestSingle(Matrix4 var0, Matrix4 var1, long var2, btCollisionObject var4, long var5, btCollisionShape var7, Matrix4 var8, long var9, RayResultCallback var11);

    public static final native void btCollisionWorld_rayTestSingleInternal(Matrix4 var0, Matrix4 var1, long var2, btCollisionObjectWrapper var4, long var5, RayResultCallback var7);

    public static final native void btCollisionWorld_objectQuerySingle(long var0, btConvexShape var2, Matrix4 var3, Matrix4 var4, long var5, btCollisionObject var7, long var8, btCollisionShape var10, Matrix4 var11, long var12, ConvexResultCallback var14, float var15);

    public static final native void btCollisionWorld_objectQuerySingleInternal(long var0, btConvexShape var2, Matrix4 var3, Matrix4 var4, long var5, btCollisionObjectWrapper var7, long var8, ConvexResultCallback var10, float var11);

    public static final native void btCollisionWorld_addCollisionObject__SWIG_0(long var0, btCollisionWorld var2, long var3, btCollisionObject var5, int var6, int var7);

    public static final native void btCollisionWorld_addCollisionObject__SWIG_1(long var0, btCollisionWorld var2, long var3, btCollisionObject var5, int var6);

    public static final native void btCollisionWorld_addCollisionObject__SWIG_2(long var0, btCollisionWorld var2, long var3, btCollisionObject var5);

    public static final native long btCollisionWorld_getCollisionObjectArray(long var0, btCollisionWorld var2);

    public static final native long btCollisionWorld_getCollisionObjectArrayConst(long var0, btCollisionWorld var2);

    public static final native void btCollisionWorld_removeCollisionObject(long var0, btCollisionWorld var2, long var3, btCollisionObject var5);

    public static final native void btCollisionWorld_performDiscreteCollisionDetection(long var0, btCollisionWorld var2);

    public static final native long btCollisionWorld_getDispatchInfo(long var0, btCollisionWorld var2);

    public static final native long btCollisionWorld_getDispatchInfoConst(long var0, btCollisionWorld var2);

    public static final native boolean btCollisionWorld_getForceUpdateAllAabbs(long var0, btCollisionWorld var2);

    public static final native void btCollisionWorld_setForceUpdateAllAabbs(long var0, btCollisionWorld var2, boolean var3);

    public static final native void btCollisionWorld_serialize(long var0, btCollisionWorld var2, long var3, btSerializer var5);

    public static final native void LocalShapeInfo_shapePart_set(long var0, LocalShapeInfo var2, int var3);

    public static final native int LocalShapeInfo_shapePart_get(long var0, LocalShapeInfo var2);

    public static final native void LocalShapeInfo_triangleIndex_set(long var0, LocalShapeInfo var2, int var3);

    public static final native int LocalShapeInfo_triangleIndex_get(long var0, LocalShapeInfo var2);

    public static final native long new_LocalShapeInfo();

    public static final native void delete_LocalShapeInfo(long var0);

    public static final native long new_LocalRayResult(long var0, btCollisionObject var2, long var3, LocalShapeInfo var5, Vector3 var6, float var7);

    public static final native void LocalRayResult_collisionObject_set(long var0, LocalRayResult var2, long var3, btCollisionObject var5);

    public static final native long LocalRayResult_collisionObject_get(long var0, LocalRayResult var2);

    public static final native void LocalRayResult_localShapeInfo_set(long var0, LocalRayResult var2, long var3, LocalShapeInfo var5);

    public static final native long LocalRayResult_localShapeInfo_get(long var0, LocalRayResult var2);

    public static final native void LocalRayResult_hitNormalLocal_set(long var0, LocalRayResult var2, long var3, btVector3 var5);

    public static final native long LocalRayResult_hitNormalLocal_get(long var0, LocalRayResult var2);

    public static final native void LocalRayResult_hitFraction_set(long var0, LocalRayResult var2, float var3);

    public static final native float LocalRayResult_hitFraction_get(long var0, LocalRayResult var2);

    public static final native void delete_LocalRayResult(long var0);

    public static final native void RayResultCallback_closestHitFraction_set(long var0, RayResultCallback var2, float var3);

    public static final native float RayResultCallback_closestHitFraction_get(long var0, RayResultCallback var2);

    public static final native void RayResultCallback_collisionObject_set(long var0, RayResultCallback var2, long var3, btCollisionObject var5);

    public static final native long RayResultCallback_collisionObject_get(long var0, RayResultCallback var2);

    public static final native void RayResultCallback_collisionFilterGroup_set(long var0, RayResultCallback var2, int var3);

    public static final native int RayResultCallback_collisionFilterGroup_get(long var0, RayResultCallback var2);

    public static final native void RayResultCallback_collisionFilterMask_set(long var0, RayResultCallback var2, int var3);

    public static final native int RayResultCallback_collisionFilterMask_get(long var0, RayResultCallback var2);

    public static final native void RayResultCallback_flags_set(long var0, RayResultCallback var2, long var3);

    public static final native long RayResultCallback_flags_get(long var0, RayResultCallback var2);

    public static final native void delete_RayResultCallback(long var0);

    public static final native boolean RayResultCallback_hasHit(long var0, RayResultCallback var2);

    public static final native long new_RayResultCallback();

    public static final native boolean RayResultCallback_needsCollision(long var0, RayResultCallback var2, long var3, btBroadphaseProxy var5);

    public static final native boolean RayResultCallback_needsCollisionSwigExplicitRayResultCallback(long var0, RayResultCallback var2, long var3, btBroadphaseProxy var5);

    public static final native float RayResultCallback_addSingleResult(long var0, RayResultCallback var2, long var3, LocalRayResult var5, boolean var6);

    public static final native void RayResultCallback_director_connect(RayResultCallback var0, long var1, boolean var3, boolean var4);

    public static final native void RayResultCallback_change_ownership(RayResultCallback var0, long var1, boolean var3);

    public static final native long new_ClosestRayResultCallback(Vector3 var0, Vector3 var1);

    public static final native float ClosestRayResultCallback_addSingleResult(long var0, ClosestRayResultCallback var2, long var3, LocalRayResult var5, boolean var6);

    public static final native float ClosestRayResultCallback_addSingleResultSwigExplicitClosestRayResultCallback(long var0, ClosestRayResultCallback var2, long var3, LocalRayResult var5, boolean var6);

    public static final native void ClosestRayResultCallback_getRayFromWorld(long var0, ClosestRayResultCallback var2, Vector3 var3);

    public static final native void ClosestRayResultCallback_setRayFromWorld(long var0, ClosestRayResultCallback var2, Vector3 var3);

    public static final native void ClosestRayResultCallback_getRayToWorld(long var0, ClosestRayResultCallback var2, Vector3 var3);

    public static final native void ClosestRayResultCallback_setRayToWorld(long var0, ClosestRayResultCallback var2, Vector3 var3);

    public static final native void ClosestRayResultCallback_getHitNormalWorld(long var0, ClosestRayResultCallback var2, Vector3 var3);

    public static final native void ClosestRayResultCallback_setHitNormalWorld(long var0, ClosestRayResultCallback var2, Vector3 var3);

    public static final native void ClosestRayResultCallback_getHitPointWorld(long var0, ClosestRayResultCallback var2, Vector3 var3);

    public static final native void ClosestRayResultCallback_setHitPointWorld(long var0, ClosestRayResultCallback var2, Vector3 var3);

    public static final native void delete_ClosestRayResultCallback(long var0);

    public static final native void ClosestRayResultCallback_director_connect(ClosestRayResultCallback var0, long var1, boolean var3, boolean var4);

    public static final native void ClosestRayResultCallback_change_ownership(ClosestRayResultCallback var0, long var1, boolean var3);

    public static final native long new_AllHitsRayResultCallback(Vector3 var0, Vector3 var1);

    public static final native void AllHitsRayResultCallback_collisionObjects_set(long var0, AllHitsRayResultCallback var2, long var3, btCollisionObjectConstArray var5);

    public static final native long AllHitsRayResultCallback_collisionObjects_get(long var0, AllHitsRayResultCallback var2);

    public static final native void AllHitsRayResultCallback_hitNormalWorld_set(long var0, AllHitsRayResultCallback var2, long var3, btVector3Array var5);

    public static final native long AllHitsRayResultCallback_hitNormalWorld_get(long var0, AllHitsRayResultCallback var2);

    public static final native void AllHitsRayResultCallback_hitPointWorld_set(long var0, AllHitsRayResultCallback var2, long var3, btVector3Array var5);

    public static final native long AllHitsRayResultCallback_hitPointWorld_get(long var0, AllHitsRayResultCallback var2);

    public static final native void AllHitsRayResultCallback_hitFractions_set(long var0, AllHitsRayResultCallback var2, long var3, btScalarArray var5);

    public static final native long AllHitsRayResultCallback_hitFractions_get(long var0, AllHitsRayResultCallback var2);

    public static final native float AllHitsRayResultCallback_addSingleResult(long var0, AllHitsRayResultCallback var2, long var3, LocalRayResult var5, boolean var6);

    public static final native float AllHitsRayResultCallback_addSingleResultSwigExplicitAllHitsRayResultCallback(long var0, AllHitsRayResultCallback var2, long var3, LocalRayResult var5, boolean var6);

    public static final native void AllHitsRayResultCallback_getRayFromWorld(long var0, AllHitsRayResultCallback var2, Vector3 var3);

    public static final native void AllHitsRayResultCallback_setRayFromWorld(long var0, AllHitsRayResultCallback var2, Vector3 var3);

    public static final native void AllHitsRayResultCallback_getRayToWorld(long var0, AllHitsRayResultCallback var2, Vector3 var3);

    public static final native void AllHitsRayResultCallback_setRayToWorld(long var0, AllHitsRayResultCallback var2, Vector3 var3);

    public static final native void delete_AllHitsRayResultCallback(long var0);

    public static final native void AllHitsRayResultCallback_director_connect(AllHitsRayResultCallback var0, long var1, boolean var3, boolean var4);

    public static final native void AllHitsRayResultCallback_change_ownership(AllHitsRayResultCallback var0, long var1, boolean var3);

    public static final native long new_LocalConvexResult(long var0, btCollisionObject var2, long var3, LocalShapeInfo var5, Vector3 var6, Vector3 var7, float var8);

    public static final native void LocalConvexResult_hitCollisionObject_set(long var0, LocalConvexResult var2, long var3, btCollisionObject var5);

    public static final native long LocalConvexResult_hitCollisionObject_get(long var0, LocalConvexResult var2);

    public static final native void LocalConvexResult_localShapeInfo_set(long var0, LocalConvexResult var2, long var3, LocalShapeInfo var5);

    public static final native long LocalConvexResult_localShapeInfo_get(long var0, LocalConvexResult var2);

    public static final native void LocalConvexResult_hitFraction_set(long var0, LocalConvexResult var2, float var3);

    public static final native float LocalConvexResult_hitFraction_get(long var0, LocalConvexResult var2);

    public static final native void LocalConvexResult_getHitNormalLocal(long var0, LocalConvexResult var2, Vector3 var3);

    public static final native void LocalConvexResult_setHitNormalLocal(long var0, LocalConvexResult var2, Vector3 var3);

    public static final native void LocalConvexResult_getHitPointLocal(long var0, LocalConvexResult var2, Vector3 var3);

    public static final native void LocalConvexResult_setHitPointLocal(long var0, LocalConvexResult var2, Vector3 var3);

    public static final native void delete_LocalConvexResult(long var0);

    public static final native void ConvexResultCallback_closestHitFraction_set(long var0, ConvexResultCallback var2, float var3);

    public static final native float ConvexResultCallback_closestHitFraction_get(long var0, ConvexResultCallback var2);

    public static final native void ConvexResultCallback_collisionFilterGroup_set(long var0, ConvexResultCallback var2, int var3);

    public static final native int ConvexResultCallback_collisionFilterGroup_get(long var0, ConvexResultCallback var2);

    public static final native void ConvexResultCallback_collisionFilterMask_set(long var0, ConvexResultCallback var2, int var3);

    public static final native int ConvexResultCallback_collisionFilterMask_get(long var0, ConvexResultCallback var2);

    public static final native long new_ConvexResultCallback();

    public static final native void delete_ConvexResultCallback(long var0);

    public static final native boolean ConvexResultCallback_hasHit(long var0, ConvexResultCallback var2);

    public static final native boolean ConvexResultCallback_needsCollision(long var0, ConvexResultCallback var2, long var3, btBroadphaseProxy var5);

    public static final native boolean ConvexResultCallback_needsCollisionSwigExplicitConvexResultCallback(long var0, ConvexResultCallback var2, long var3, btBroadphaseProxy var5);

    public static final native float ConvexResultCallback_addSingleResult(long var0, ConvexResultCallback var2, long var3, LocalConvexResult var5, boolean var6);

    public static final native void ConvexResultCallback_director_connect(ConvexResultCallback var0, long var1, boolean var3, boolean var4);

    public static final native void ConvexResultCallback_change_ownership(ConvexResultCallback var0, long var1, boolean var3);

    public static final native long new_ClosestConvexResultCallback(Vector3 var0, Vector3 var1);

    public static final native void ClosestConvexResultCallback_convexFromWorld_set(long var0, ClosestConvexResultCallback var2, long var3, btVector3 var5);

    public static final native long ClosestConvexResultCallback_convexFromWorld_get(long var0, ClosestConvexResultCallback var2);

    public static final native void ClosestConvexResultCallback_convexToWorld_set(long var0, ClosestConvexResultCallback var2, long var3, btVector3 var5);

    public static final native long ClosestConvexResultCallback_convexToWorld_get(long var0, ClosestConvexResultCallback var2);

    public static final native void ClosestConvexResultCallback_hitCollisionObject_set(long var0, ClosestConvexResultCallback var2, long var3, btCollisionObject var5);

    public static final native long ClosestConvexResultCallback_hitCollisionObject_get(long var0, ClosestConvexResultCallback var2);

    public static final native float ClosestConvexResultCallback_addSingleResult(long var0, ClosestConvexResultCallback var2, long var3, LocalConvexResult var5, boolean var6);

    public static final native float ClosestConvexResultCallback_addSingleResultSwigExplicitClosestConvexResultCallback(long var0, ClosestConvexResultCallback var2, long var3, LocalConvexResult var5, boolean var6);

    public static final native void ClosestConvexResultCallback_getConvexFromWorld(long var0, ClosestConvexResultCallback var2, Vector3 var3);

    public static final native void ClosestConvexResultCallback_setRayFromWorld(long var0, ClosestConvexResultCallback var2, Vector3 var3);

    public static final native void ClosestConvexResultCallback_getConvexToWorld(long var0, ClosestConvexResultCallback var2, Vector3 var3);

    public static final native void ClosestConvexResultCallback_setConvexToWorld(long var0, ClosestConvexResultCallback var2, Vector3 var3);

    public static final native void ClosestConvexResultCallback_getHitNormalWorld(long var0, ClosestConvexResultCallback var2, Vector3 var3);

    public static final native void ClosestConvexResultCallback_setHitNormalWorld(long var0, ClosestConvexResultCallback var2, Vector3 var3);

    public static final native void ClosestConvexResultCallback_getHitPointWorld(long var0, ClosestConvexResultCallback var2, Vector3 var3);

    public static final native void ClosestConvexResultCallback_setHitPointWorld(long var0, ClosestConvexResultCallback var2, Vector3 var3);

    public static final native void delete_ClosestConvexResultCallback(long var0);

    public static final native void ClosestConvexResultCallback_director_connect(ClosestConvexResultCallback var0, long var1, boolean var3, boolean var4);

    public static final native void ClosestConvexResultCallback_change_ownership(ClosestConvexResultCallback var0, long var1, boolean var3);

    public static final native void ContactResultCallback_collisionFilterGroup_set(long var0, ContactResultCallback var2, int var3);

    public static final native int ContactResultCallback_collisionFilterGroup_get(long var0, ContactResultCallback var2);

    public static final native void ContactResultCallback_collisionFilterMask_set(long var0, ContactResultCallback var2, int var3);

    public static final native int ContactResultCallback_collisionFilterMask_get(long var0, ContactResultCallback var2);

    public static final native void ContactResultCallback_closestDistanceThreshold_set(long var0, ContactResultCallback var2, float var3);

    public static final native float ContactResultCallback_closestDistanceThreshold_get(long var0, ContactResultCallback var2);

    public static final native long new_ContactResultCallback();

    public static final native void delete_ContactResultCallback(long var0);

    public static final native boolean ContactResultCallback_needsCollision(long var0, ContactResultCallback var2, long var3, btBroadphaseProxy var5);

    public static final native boolean ContactResultCallback_needsCollisionSwigExplicitContactResultCallback(long var0, ContactResultCallback var2, long var3, btBroadphaseProxy var5);

    public static final native float ContactResultCallback_addSingleResult(long var0, ContactResultCallback var2, long var3, btManifoldPoint var5, long var6, btCollisionObjectWrapper var8, int var9, int var10, long var11, btCollisionObjectWrapper var13, int var14, int var15);

    public static final native void ContactResultCallback_director_connect(ContactResultCallback var0, long var1, boolean var3, boolean var4);

    public static final native void ContactResultCallback_change_ownership(ContactResultCallback var0, long var1, boolean var3);

    public static final native void ClosestNotMeConvexResultCallback_me_set(long var0, ClosestNotMeConvexResultCallback var2, long var3, btCollisionObject var5);

    public static final native long ClosestNotMeConvexResultCallback_me_get(long var0, ClosestNotMeConvexResultCallback var2);

    public static final native void ClosestNotMeConvexResultCallback_allowedPenetration_set(long var0, ClosestNotMeConvexResultCallback var2, float var3);

    public static final native float ClosestNotMeConvexResultCallback_allowedPenetration_get(long var0, ClosestNotMeConvexResultCallback var2);

    public static final native long new_ClosestNotMeConvexResultCallback(long var0, btCollisionObject var2, Vector3 var3, Vector3 var4);

    public static final native boolean ClosestNotMeConvexResultCallback_needsCollision(long var0, ClosestNotMeConvexResultCallback var2, long var3, btBroadphaseProxy var5);

    public static final native void delete_ClosestNotMeConvexResultCallback(long var0);

    public static final native long new_ClosestNotMeRayResultCallback(long var0, btCollisionObject var2);

    public static final native void delete_ClosestNotMeRayResultCallback(long var0);

    public static final native long new_btConvex2dConvex2dAlgorithm(long var0, btPersistentManifold var2, long var3, btCollisionAlgorithmConstructionInfo var5, long var6, btCollisionObjectWrapper var8, long var9, btCollisionObjectWrapper var11, long var12, btVoronoiSimplexSolver var14, long var15, btConvexPenetrationDepthSolver var17, int var18, int var19);

    public static final native void delete_btConvex2dConvex2dAlgorithm(long var0);

    public static final native void btConvex2dConvex2dAlgorithm_setLowLevelOfDetail(long var0, btConvex2dConvex2dAlgorithm var2, boolean var3);

    public static final native long btConvex2dConvex2dAlgorithm_getManifold(long var0, btConvex2dConvex2dAlgorithm var2);

    public static final native void btConvex2dConvex2dAlgorithm_CreateFunc_pdSolver_set(long var0, btConvex2dConvex2dAlgorithm.CreateFunc var2, long var3, btConvexPenetrationDepthSolver var5);

    public static final native long btConvex2dConvex2dAlgorithm_CreateFunc_pdSolver_get(long var0, btConvex2dConvex2dAlgorithm.CreateFunc var2);

    public static final native void btConvex2dConvex2dAlgorithm_CreateFunc_simplexSolver_set(long var0, btConvex2dConvex2dAlgorithm.CreateFunc var2, long var3, btVoronoiSimplexSolver var5);

    public static final native long btConvex2dConvex2dAlgorithm_CreateFunc_simplexSolver_get(long var0, btConvex2dConvex2dAlgorithm.CreateFunc var2);

    public static final native void btConvex2dConvex2dAlgorithm_CreateFunc_numPerturbationIterations_set(long var0, btConvex2dConvex2dAlgorithm.CreateFunc var2, int var3);

    public static final native int btConvex2dConvex2dAlgorithm_CreateFunc_numPerturbationIterations_get(long var0, btConvex2dConvex2dAlgorithm.CreateFunc var2);

    public static final native void btConvex2dConvex2dAlgorithm_CreateFunc_minimumPointsPerturbationThreshold_set(long var0, btConvex2dConvex2dAlgorithm.CreateFunc var2, int var3);

    public static final native int btConvex2dConvex2dAlgorithm_CreateFunc_minimumPointsPerturbationThreshold_get(long var0, btConvex2dConvex2dAlgorithm.CreateFunc var2);

    public static final native long new_btConvex2dConvex2dAlgorithm_CreateFunc(long var0, btVoronoiSimplexSolver var2, long var3, btConvexPenetrationDepthSolver var5);

    public static final native void delete_btConvex2dConvex2dAlgorithm_CreateFunc(long var0);

    public static final native void btBoxBoxDetector_box1_set(long var0, btBoxBoxDetector var2, long var3, btBoxShape var5);

    public static final native long btBoxBoxDetector_box1_get(long var0, btBoxBoxDetector var2);

    public static final native void btBoxBoxDetector_box2_set(long var0, btBoxBoxDetector var2, long var3, btBoxShape var5);

    public static final native long btBoxBoxDetector_box2_get(long var0, btBoxBoxDetector var2);

    public static final native long new_btBoxBoxDetector(long var0, btBoxShape var2, long var3, btBoxShape var5);

    public static final native void delete_btBoxBoxDetector(long var0);

    public static final native void btBoxBoxDetector_getClosestPoints__SWIG_0(long var0, btBoxBoxDetector var2, long var3, btDiscreteCollisionDetectorInterface.ClosestPointInput var5, long var6, btDiscreteCollisionDetectorInterface.Result var8, long var9, btIDebugDraw var11, boolean var12);

    public static final native void btBoxBoxDetector_getClosestPoints__SWIG_1(long var0, btBoxBoxDetector var2, long var3, btDiscreteCollisionDetectorInterface.ClosestPointInput var5, long var6, btDiscreteCollisionDetectorInterface.Result var8, long var9, btIDebugDraw var11);

    public static final native long new_btSphereBoxCollisionAlgorithm(long var0, btPersistentManifold var2, long var3, btCollisionAlgorithmConstructionInfo var5, long var6, btCollisionObjectWrapper var8, long var9, btCollisionObjectWrapper var11, boolean var12);

    public static final native void delete_btSphereBoxCollisionAlgorithm(long var0);

    public static final native boolean btSphereBoxCollisionAlgorithm_getSphereDistance(long var0, btSphereBoxCollisionAlgorithm var2, long var3, btCollisionObjectWrapper var5, Vector3 var6, Vector3 var7, long var8, Vector3 var10, float var11, float var12);

    public static final native float btSphereBoxCollisionAlgorithm_getSpherePenetration(long var0, btSphereBoxCollisionAlgorithm var2, Vector3 var3, Vector3 var4, Vector3 var5, Vector3 var6);

    public static final native long new_btSphereBoxCollisionAlgorithm_CreateFunc();

    public static final native void delete_btSphereBoxCollisionAlgorithm_CreateFunc(long var0);

    public static final native int btCollisionDispatcher_getDispatcherFlags(long var0, btCollisionDispatcher var2);

    public static final native void btCollisionDispatcher_setDispatcherFlags(long var0, btCollisionDispatcher var2, int var3);

    public static final native void btCollisionDispatcher_registerCollisionCreateFunc(long var0, btCollisionDispatcher var2, int var3, int var4, long var5, btCollisionAlgorithmCreateFunc var7);

    public static final native void btCollisionDispatcher_registerClosestPointsCreateFunc(long var0, btCollisionDispatcher var2, int var3, int var4, long var5, btCollisionAlgorithmCreateFunc var7);

    public static final native long btCollisionDispatcher_getManifoldByIndexInternalConst(long var0, btCollisionDispatcher var2, int var3);

    public static final native long new_btCollisionDispatcher(long var0, btCollisionConfiguration var2);

    public static final native void delete_btCollisionDispatcher(long var0);

    public static final native void btCollisionDispatcher_setNearCallback(long var0, btCollisionDispatcher var2, long var3);

    public static final native long btCollisionDispatcher_getNearCallback(long var0, btCollisionDispatcher var2);

    public static final native void btCollisionDispatcher_defaultNearCallback(btBroadphasePair var0, long var1, btCollisionDispatcher var3, long var4, btDispatcherInfo var6);

    public static final native long btCollisionDispatcher_getCollisionConfiguration(long var0, btCollisionDispatcher var2);

    public static final native long btCollisionDispatcher_getCollisionConfigurationConst(long var0, btCollisionDispatcher var2);

    public static final native void btCollisionDispatcher_setCollisionConfiguration(long var0, btCollisionDispatcher var2, long var3, btCollisionConfiguration var5);

    public static final native long new_btCollisionDispatcherMt__SWIG_0(long var0, btCollisionConfiguration var2, int var3);

    public static final native long new_btCollisionDispatcherMt__SWIG_1(long var0, btCollisionConfiguration var2);

    public static final native void delete_btCollisionDispatcherMt(long var0);

    public static final native long new_btConvexConvexAlgorithm(long var0, btPersistentManifold var2, long var3, btCollisionAlgorithmConstructionInfo var5, long var6, btCollisionObjectWrapper var8, long var9, btCollisionObjectWrapper var11, long var12, btConvexPenetrationDepthSolver var14, int var15, int var16);

    public static final native void delete_btConvexConvexAlgorithm(long var0);

    public static final native void btConvexConvexAlgorithm_setLowLevelOfDetail(long var0, btConvexConvexAlgorithm var2, boolean var3);

    public static final native long btConvexConvexAlgorithm_getManifold(long var0, btConvexConvexAlgorithm var2);

    public static final native void btConvexConvexAlgorithm_CreateFunc_pdSolver_set(long var0, btConvexConvexAlgorithm.CreateFunc var2, long var3, btConvexPenetrationDepthSolver var5);

    public static final native long btConvexConvexAlgorithm_CreateFunc_pdSolver_get(long var0, btConvexConvexAlgorithm.CreateFunc var2);

    public static final native void btConvexConvexAlgorithm_CreateFunc_numPerturbationIterations_set(long var0, btConvexConvexAlgorithm.CreateFunc var2, int var3);

    public static final native int btConvexConvexAlgorithm_CreateFunc_numPerturbationIterations_get(long var0, btConvexConvexAlgorithm.CreateFunc var2);

    public static final native void btConvexConvexAlgorithm_CreateFunc_minimumPointsPerturbationThreshold_set(long var0, btConvexConvexAlgorithm.CreateFunc var2, int var3);

    public static final native int btConvexConvexAlgorithm_CreateFunc_minimumPointsPerturbationThreshold_get(long var0, btConvexConvexAlgorithm.CreateFunc var2);

    public static final native long new_btConvexConvexAlgorithm_CreateFunc(long var0, btConvexPenetrationDepthSolver var2);

    public static final native void delete_btConvexConvexAlgorithm_CreateFunc(long var0);

    public static final native void SphereTriangleDetector_getClosestPoints__SWIG_0(long var0, SphereTriangleDetector var2, long var3, btDiscreteCollisionDetectorInterface.ClosestPointInput var5, long var6, btDiscreteCollisionDetectorInterface.Result var8, long var9, btIDebugDraw var11, boolean var12);

    public static final native void SphereTriangleDetector_getClosestPoints__SWIG_1(long var0, SphereTriangleDetector var2, long var3, btDiscreteCollisionDetectorInterface.ClosestPointInput var5, long var6, btDiscreteCollisionDetectorInterface.Result var8, long var9, btIDebugDraw var11);

    public static final native long new_SphereTriangleDetector(long var0, btSphereShape var2, long var3, btTriangleShape var5, float var6);

    public static final native void delete_SphereTriangleDetector(long var0);

    public static final native boolean SphereTriangleDetector_collide(long var0, SphereTriangleDetector var2, Vector3 var3, Vector3 var4, Vector3 var5, long var6, long var8, float var10);

    public static final native void btGenerateInternalEdgeInfo(long var0, btBvhTriangleMeshShape var2, long var3, btTriangleInfoMap var5);

    public static final native void btAdjustInternalEdgeContacts__SWIG_0(long var0, btManifoldPoint var2, long var3, btCollisionObjectWrapper var5, long var6, btCollisionObjectWrapper var8, int var9, int var10, int var11);

    public static final native void btAdjustInternalEdgeContacts__SWIG_1(long var0, btManifoldPoint var2, long var3, btCollisionObjectWrapper var5, long var6, btCollisionObjectWrapper var8, int var9, int var10);

    public static final native void delete_btConvexCast(long var0);

    public static final native void btConvexCast_CastResult_DebugDraw(long var0, btConvexCast.CastResult var2, float var3);

    public static final native void btConvexCast_CastResult_drawCoordSystem(long var0, btConvexCast.CastResult var2, Matrix4 var3);

    public static final native void btConvexCast_CastResult_reportFailure(long var0, btConvexCast.CastResult var2, int var3, int var4);

    public static final native long new_btConvexCast_CastResult();

    public static final native void delete_btConvexCast_CastResult(long var0);

    public static final native void btConvexCast_CastResult_hitTransformA_set(long var0, btConvexCast.CastResult var2, long var3, btTransform var5);

    public static final native long btConvexCast_CastResult_hitTransformA_get(long var0, btConvexCast.CastResult var2);

    public static final native void btConvexCast_CastResult_hitTransformB_set(long var0, btConvexCast.CastResult var2, long var3, btTransform var5);

    public static final native long btConvexCast_CastResult_hitTransformB_get(long var0, btConvexCast.CastResult var2);

    public static final native void btConvexCast_CastResult_normal_set(long var0, btConvexCast.CastResult var2, long var3, btVector3 var5);

    public static final native long btConvexCast_CastResult_normal_get(long var0, btConvexCast.CastResult var2);

    public static final native void btConvexCast_CastResult_hitPoint_set(long var0, btConvexCast.CastResult var2, long var3, btVector3 var5);

    public static final native long btConvexCast_CastResult_hitPoint_get(long var0, btConvexCast.CastResult var2);

    public static final native void btConvexCast_CastResult_fraction_set(long var0, btConvexCast.CastResult var2, float var3);

    public static final native float btConvexCast_CastResult_fraction_get(long var0, btConvexCast.CastResult var2);

    public static final native void btConvexCast_CastResult_debugDrawer_set(long var0, btConvexCast.CastResult var2, long var3, btIDebugDraw var5);

    public static final native long btConvexCast_CastResult_debugDrawer_get(long var0, btConvexCast.CastResult var2);

    public static final native void btConvexCast_CastResult_allowedPenetration_set(long var0, btConvexCast.CastResult var2, float var3);

    public static final native float btConvexCast_CastResult_allowedPenetration_get(long var0, btConvexCast.CastResult var2);

    public static final native boolean btConvexCast_calcTimeOfImpact(long var0, btConvexCast var2, Matrix4 var3, Matrix4 var4, Matrix4 var5, Matrix4 var6, long var7, btConvexCast.CastResult var9);

    public static final native long new_btSubsimplexConvexCast(long var0, btConvexShape var2, long var3, btConvexShape var5, long var6, btVoronoiSimplexSolver var8);

    public static final native void delete_btSubsimplexConvexCast(long var0);

    public static final native void btPolyhedralContactClipping_clipHullAgainstHull(Vector3 var0, long var1, btConvexPolyhedron var3, long var4, btConvexPolyhedron var6, Matrix4 var7, Matrix4 var8, float var9, float var10, long var11, btVector3Array var13, long var14, btVector3Array var16, long var17, btDiscreteCollisionDetectorInterface.Result var19);

    public static final native void btPolyhedralContactClipping_clipFaceAgainstHull(Vector3 var0, long var1, btConvexPolyhedron var3, Matrix4 var4, long var5, btVector3Array var7, long var8, btVector3Array var10, float var11, float var12, long var13, btDiscreteCollisionDetectorInterface.Result var15);

    public static final native boolean btPolyhedralContactClipping_findSeparatingAxis(long var0, btConvexPolyhedron var2, long var3, btConvexPolyhedron var5, Matrix4 var6, Matrix4 var7, Vector3 var8, long var9, btDiscreteCollisionDetectorInterface.Result var11);

    public static final native void btPolyhedralContactClipping_clipFace(long var0, btVector3Array var2, long var3, btVector3Array var5, Vector3 var6, float var7);

    public static final native long new_btPolyhedralContactClipping();

    public static final native void delete_btPolyhedralContactClipping(long var0);

    public static final native void gContactBreakingThreshold_set(float var0);

    public static final native float gContactBreakingThreshold_get();

    public static final native long btPersistentManifold_operatorNew__SWIG_0(long var0, btPersistentManifold var2, long var3);

    public static final native void btPersistentManifold_operatorDelete__SWIG_0(long var0, btPersistentManifold var2, long var3);

    public static final native long btPersistentManifold_operatorNew__SWIG_1(long var0, btPersistentManifold var2, long var3, long var5);

    public static final native void btPersistentManifold_operatorDelete__SWIG_1(long var0, btPersistentManifold var2, long var3, long var5);

    public static final native long btPersistentManifold_operatorNewArray__SWIG_0(long var0, btPersistentManifold var2, long var3);

    public static final native void btPersistentManifold_operatorDeleteArray__SWIG_0(long var0, btPersistentManifold var2, long var3);

    public static final native long btPersistentManifold_operatorNewArray__SWIG_1(long var0, btPersistentManifold var2, long var3, long var5);

    public static final native void btPersistentManifold_operatorDeleteArray__SWIG_1(long var0, btPersistentManifold var2, long var3, long var5);

    public static final native void btPersistentManifold_companionIdA_set(long var0, btPersistentManifold var2, int var3);

    public static final native int btPersistentManifold_companionIdA_get(long var0, btPersistentManifold var2);

    public static final native void btPersistentManifold_companionIdB_set(long var0, btPersistentManifold var2, int var3);

    public static final native int btPersistentManifold_companionIdB_get(long var0, btPersistentManifold var2);

    public static final native void btPersistentManifold_index1a_set(long var0, btPersistentManifold var2, int var3);

    public static final native int btPersistentManifold_index1a_get(long var0, btPersistentManifold var2);

    public static final native long new_btPersistentManifold__SWIG_0();

    public static final native long new_btPersistentManifold__SWIG_1(long var0, btCollisionObject var2, long var3, btCollisionObject var5, int var6, float var7, float var8);

    public static final native long btPersistentManifold_getBody0(long var0, btPersistentManifold var2);

    public static final native long btPersistentManifold_getBody1(long var0, btPersistentManifold var2);

    public static final native void btPersistentManifold_setBodies(long var0, btPersistentManifold var2, long var3, btCollisionObject var5, long var6, btCollisionObject var8);

    public static final native void btPersistentManifold_clearUserCache(long var0, btPersistentManifold var2, long var3, btManifoldPoint var5);

    public static final native int btPersistentManifold_getNumContacts(long var0, btPersistentManifold var2);

    public static final native void btPersistentManifold_setNumContacts(long var0, btPersistentManifold var2, int var3);

    public static final native long btPersistentManifold_getContactPointConst(long var0, btPersistentManifold var2, int var3);

    public static final native long btPersistentManifold_getContactPoint(long var0, btPersistentManifold var2, int var3);

    public static final native float btPersistentManifold_getContactBreakingThreshold(long var0, btPersistentManifold var2);

    public static final native float btPersistentManifold_getContactProcessingThreshold(long var0, btPersistentManifold var2);

    public static final native void btPersistentManifold_setContactBreakingThreshold(long var0, btPersistentManifold var2, float var3);

    public static final native void btPersistentManifold_setContactProcessingThreshold(long var0, btPersistentManifold var2, float var3);

    public static final native int btPersistentManifold_getCacheEntry(long var0, btPersistentManifold var2, long var3, btManifoldPoint var5);

    public static final native int btPersistentManifold_addManifoldPoint__SWIG_0(long var0, btPersistentManifold var2, long var3, btManifoldPoint var5, boolean var6);

    public static final native int btPersistentManifold_addManifoldPoint__SWIG_1(long var0, btPersistentManifold var2, long var3, btManifoldPoint var5);

    public static final native void btPersistentManifold_removeContactPoint(long var0, btPersistentManifold var2, int var3);

    public static final native void btPersistentManifold_replaceContactPoint(long var0, btPersistentManifold var2, long var3, btManifoldPoint var5, int var6);

    public static final native boolean btPersistentManifold_validContactDistance(long var0, btPersistentManifold var2, long var3, btManifoldPoint var5);

    public static final native void btPersistentManifold_refreshContactPoints(long var0, btPersistentManifold var2, Matrix4 var3, Matrix4 var4);

    public static final native void btPersistentManifold_clearManifold(long var0, btPersistentManifold var2);

    public static final native void delete_btPersistentManifold(long var0);

    public static final native long btPersistentManifoldArray_operatorAssignment(long var0, btPersistentManifoldArray var2, long var3, btPersistentManifoldArray var5);

    public static final native long new_btPersistentManifoldArray__SWIG_0();

    public static final native void delete_btPersistentManifoldArray(long var0);

    public static final native long new_btPersistentManifoldArray__SWIG_1(long var0, btPersistentManifoldArray var2);

    public static final native int btPersistentManifoldArray_size(long var0, btPersistentManifoldArray var2);

    public static final native long btPersistentManifoldArray_atConst(long var0, btPersistentManifoldArray var2, int var3);

    public static final native long btPersistentManifoldArray_at(long var0, btPersistentManifoldArray var2, int var3);

    public static final native long btPersistentManifoldArray_operatorSubscriptConst(long var0, btPersistentManifoldArray var2, int var3);

    public static final native long btPersistentManifoldArray_operatorSubscript(long var0, btPersistentManifoldArray var2, int var3);

    public static final native void btPersistentManifoldArray_clear(long var0, btPersistentManifoldArray var2);

    public static final native void btPersistentManifoldArray_pop_back(long var0, btPersistentManifoldArray var2);

    public static final native void btPersistentManifoldArray_resizeNoInitialize(long var0, btPersistentManifoldArray var2, int var3);

    public static final native void btPersistentManifoldArray_resize__SWIG_0(long var0, btPersistentManifoldArray var2, int var3, long var4, btPersistentManifold var6);

    public static final native void btPersistentManifoldArray_resize__SWIG_1(long var0, btPersistentManifoldArray var2, int var3);

    public static final native long btPersistentManifoldArray_expandNonInitializing(long var0, btPersistentManifoldArray var2);

    public static final native long btPersistentManifoldArray_expand__SWIG_0(long var0, btPersistentManifoldArray var2, long var3, btPersistentManifold var5);

    public static final native long btPersistentManifoldArray_expand__SWIG_1(long var0, btPersistentManifoldArray var2);

    public static final native void btPersistentManifoldArray_push_back(long var0, btPersistentManifoldArray var2, long var3, btPersistentManifold var5);

    public static final native int btPersistentManifoldArray_capacity(long var0, btPersistentManifoldArray var2);

    public static final native void btPersistentManifoldArray_reserve(long var0, btPersistentManifoldArray var2, int var3);

    public static final native boolean btPersistentManifoldArray_less_operatorFunctionCall(long var0, btPersistentManifoldArray.less var2, long var3, btPersistentManifold var5, long var6, btPersistentManifold var8);

    public static final native long new_btPersistentManifoldArray_less();

    public static final native void delete_btPersistentManifoldArray_less(long var0);

    public static final native void btPersistentManifoldArray_swap(long var0, btPersistentManifoldArray var2, int var3, int var4);

    public static final native int btPersistentManifoldArray_findBinarySearch(long var0, btPersistentManifoldArray var2, long var3, btPersistentManifold var5);

    public static final native int btPersistentManifoldArray_findLinearSearch(long var0, btPersistentManifoldArray var2, long var3, btPersistentManifold var5);

    public static final native int btPersistentManifoldArray_findLinearSearch2(long var0, btPersistentManifoldArray var2, long var3, btPersistentManifold var5);

    public static final native void btPersistentManifoldArray_removeAtIndex(long var0, btPersistentManifoldArray var2, int var3);

    public static final native void btPersistentManifoldArray_remove(long var0, btPersistentManifoldArray var2, long var3, btPersistentManifold var5);

    public static final native void btPersistentManifoldArray_initializeFromBuffer(long var0, btPersistentManifoldArray var2, long var3, int var5, int var6);

    public static final native void btPersistentManifoldArray_copyFromArray(long var0, btPersistentManifoldArray var2, long var3, btPersistentManifoldArray var5);

    public static final native void btGjkPairDetector_lastUsedMethod_set(long var0, btGjkPairDetector var2, int var3);

    public static final native int btGjkPairDetector_lastUsedMethod_get(long var0, btGjkPairDetector var2);

    public static final native void btGjkPairDetector_curIter_set(long var0, btGjkPairDetector var2, int var3);

    public static final native int btGjkPairDetector_curIter_get(long var0, btGjkPairDetector var2);

    public static final native void btGjkPairDetector_degenerateSimplex_set(long var0, btGjkPairDetector var2, int var3);

    public static final native int btGjkPairDetector_degenerateSimplex_get(long var0, btGjkPairDetector var2);

    public static final native void btGjkPairDetector_catchDegeneracies_set(long var0, btGjkPairDetector var2, int var3);

    public static final native int btGjkPairDetector_catchDegeneracies_get(long var0, btGjkPairDetector var2);

    public static final native void btGjkPairDetector_fixContactNormalDirection_set(long var0, btGjkPairDetector var2, int var3);

    public static final native int btGjkPairDetector_fixContactNormalDirection_get(long var0, btGjkPairDetector var2);

    public static final native long new_btGjkPairDetector__SWIG_0(long var0, btConvexShape var2, long var3, btConvexShape var5, long var6, btVoronoiSimplexSolver var8, long var9, btConvexPenetrationDepthSolver var11);

    public static final native long new_btGjkPairDetector__SWIG_1(long var0, btConvexShape var2, long var3, btConvexShape var5, int var6, int var7, float var8, float var9, long var10, btVoronoiSimplexSolver var12, long var13, btConvexPenetrationDepthSolver var15);

    public static final native void delete_btGjkPairDetector(long var0);

    public static final native void btGjkPairDetector_getClosestPoints__SWIG_0(long var0, btGjkPairDetector var2, long var3, btDiscreteCollisionDetectorInterface.ClosestPointInput var5, long var6, btDiscreteCollisionDetectorInterface.Result var8, long var9, btIDebugDraw var11, boolean var12);

    public static final native void btGjkPairDetector_getClosestPoints__SWIG_1(long var0, btGjkPairDetector var2, long var3, btDiscreteCollisionDetectorInterface.ClosestPointInput var5, long var6, btDiscreteCollisionDetectorInterface.Result var8, long var9, btIDebugDraw var11);

    public static final native void btGjkPairDetector_getClosestPointsNonVirtual(long var0, btGjkPairDetector var2, long var3, btDiscreteCollisionDetectorInterface.ClosestPointInput var5, long var6, btDiscreteCollisionDetectorInterface.Result var8, long var9, btIDebugDraw var11);

    public static final native void btGjkPairDetector_setMinkowskiA(long var0, btGjkPairDetector var2, long var3, btConvexShape var5);

    public static final native void btGjkPairDetector_setMinkowskiB(long var0, btGjkPairDetector var2, long var3, btConvexShape var5);

    public static final native void btGjkPairDetector_setCachedSeperatingAxis(long var0, btGjkPairDetector var2, Vector3 var3);

    public static final native Vector3 btGjkPairDetector_getCachedSeparatingAxis(long var0, btGjkPairDetector var2);

    public static final native float btGjkPairDetector_getCachedSeparatingDistance(long var0, btGjkPairDetector var2);

    public static final native void btGjkPairDetector_setPenetrationDepthSolver(long var0, btGjkPairDetector var2, long var3, btConvexPenetrationDepthSolver var5);

    public static final native void btGjkPairDetector_setIgnoreMargin(long var0, btGjkPairDetector var2, boolean var3);

    public static final native void delete_btConvexPenetrationDepthSolver(long var0);

    public static final native boolean btConvexPenetrationDepthSolver_calcPenDepth(long var0, btConvexPenetrationDepthSolver var2, long var3, btVoronoiSimplexSolver var5, long var6, btConvexShape var8, long var9, btConvexShape var11, Matrix4 var12, Matrix4 var13, Vector3 var14, Vector3 var15, Vector3 var16, long var17, btIDebugDraw var19);

    public static final native long new_btMinkowskiPenetrationDepthSolver();

    public static final native void delete_btMinkowskiPenetrationDepthSolver(long var0);

    public static final native long new_btGjkConvexCast(long var0, btConvexShape var2, long var3, btConvexShape var5, long var6, btVoronoiSimplexSolver var8);

    public static final native void delete_btGjkConvexCast(long var0);

    public static final native void btConstraintRow_normal_set(long var0, btConstraintRow var2, float[] var3);

    public static final native float[] btConstraintRow_normal_get(long var0, btConstraintRow var2);

    public static final native void btConstraintRow_rhs_set(long var0, btConstraintRow var2, float var3);

    public static final native float btConstraintRow_rhs_get(long var0, btConstraintRow var2);

    public static final native void btConstraintRow_jacDiagInv_set(long var0, btConstraintRow var2, float var3);

    public static final native float btConstraintRow_jacDiagInv_get(long var0, btConstraintRow var2);

    public static final native void btConstraintRow_lowerLimit_set(long var0, btConstraintRow var2, float var3);

    public static final native float btConstraintRow_lowerLimit_get(long var0, btConstraintRow var2);

    public static final native void btConstraintRow_upperLimit_set(long var0, btConstraintRow var2, float var3);

    public static final native float btConstraintRow_upperLimit_get(long var0, btConstraintRow var2);

    public static final native void btConstraintRow_accumImpulse_set(long var0, btConstraintRow var2, float var3);

    public static final native float btConstraintRow_accumImpulse_get(long var0, btConstraintRow var2);

    public static final native long new_btConstraintRow();

    public static final native void delete_btConstraintRow(long var0);

    public static final native long new_btManifoldPoint__SWIG_0();

    public static final native long new_btManifoldPoint__SWIG_1(Vector3 var0, Vector3 var1, Vector3 var2, float var3);

    public static final native void btManifoldPoint_distance1_set(long var0, btManifoldPoint var2, float var3);

    public static final native float btManifoldPoint_distance1_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_combinedFriction_set(long var0, btManifoldPoint var2, float var3);

    public static final native float btManifoldPoint_combinedFriction_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_combinedRollingFriction_set(long var0, btManifoldPoint var2, float var3);

    public static final native float btManifoldPoint_combinedRollingFriction_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_combinedSpinningFriction_set(long var0, btManifoldPoint var2, float var3);

    public static final native float btManifoldPoint_combinedSpinningFriction_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_combinedRestitution_set(long var0, btManifoldPoint var2, float var3);

    public static final native float btManifoldPoint_combinedRestitution_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_partId0_set(long var0, btManifoldPoint var2, int var3);

    public static final native int btManifoldPoint_partId0_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_partId1_set(long var0, btManifoldPoint var2, int var3);

    public static final native int btManifoldPoint_partId1_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_index0_set(long var0, btManifoldPoint var2, int var3);

    public static final native int btManifoldPoint_index0_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_index1_set(long var0, btManifoldPoint var2, int var3);

    public static final native int btManifoldPoint_index1_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_userPersistentData_set(long var0, btManifoldPoint var2, long var3);

    public static final native long btManifoldPoint_userPersistentData_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_contactPointFlags_set(long var0, btManifoldPoint var2, int var3);

    public static final native int btManifoldPoint_contactPointFlags_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_appliedImpulse_set(long var0, btManifoldPoint var2, float var3);

    public static final native float btManifoldPoint_appliedImpulse_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_appliedImpulseLateral1_set(long var0, btManifoldPoint var2, float var3);

    public static final native float btManifoldPoint_appliedImpulseLateral1_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_appliedImpulseLateral2_set(long var0, btManifoldPoint var2, float var3);

    public static final native float btManifoldPoint_appliedImpulseLateral2_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_contactMotion1_set(long var0, btManifoldPoint var2, float var3);

    public static final native float btManifoldPoint_contactMotion1_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_contactMotion2_set(long var0, btManifoldPoint var2, float var3);

    public static final native float btManifoldPoint_contactMotion2_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_contactCFM_set(long var0, btManifoldPoint var2, float var3);

    public static final native float btManifoldPoint_contactCFM_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_combinedContactStiffness1_set(long var0, btManifoldPoint var2, float var3);

    public static final native float btManifoldPoint_combinedContactStiffness1_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_contactERP_set(long var0, btManifoldPoint var2, float var3);

    public static final native float btManifoldPoint_contactERP_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_combinedContactDamping1_set(long var0, btManifoldPoint var2, float var3);

    public static final native float btManifoldPoint_combinedContactDamping1_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_frictionCFM_set(long var0, btManifoldPoint var2, float var3);

    public static final native float btManifoldPoint_frictionCFM_get(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_lifeTime_set(long var0, btManifoldPoint var2, int var3);

    public static final native int btManifoldPoint_lifeTime_get(long var0, btManifoldPoint var2);

    public static final native float btManifoldPoint_getDistance(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_setDistance(long var0, btManifoldPoint var2, float var3);

    public static final native int btManifoldPoint_getUserValue(long var0, btManifoldPoint var2);

    public static final native void btManifoldPoint_setUserValue(long var0, btManifoldPoint var2, int var3);

    public static final native void btManifoldPoint_getLocalPointA(long var0, btManifoldPoint var2, Vector3 var3);

    public static final native void btManifoldPoint_setLocalPointA(long var0, btManifoldPoint var2, Vector3 var3);

    public static final native void btManifoldPoint_getLocalPointB(long var0, btManifoldPoint var2, Vector3 var3);

    public static final native void btManifoldPoint_setLocalPointB(long var0, btManifoldPoint var2, Vector3 var3);

    public static final native void btManifoldPoint_getPositionWorldOnA(long var0, btManifoldPoint var2, Vector3 var3);

    public static final native void btManifoldPoint_setPositionWorldOnA(long var0, btManifoldPoint var2, Vector3 var3);

    public static final native void btManifoldPoint_getPositionWorldOnB(long var0, btManifoldPoint var2, Vector3 var3);

    public static final native void btManifoldPoint_setPositionWorldOnB(long var0, btManifoldPoint var2, Vector3 var3);

    public static final native void btManifoldPoint_getNormalWorldOnB(long var0, btManifoldPoint var2, Vector3 var3);

    public static final native void btManifoldPoint_setNormalWorldOnB(long var0, btManifoldPoint var2, Vector3 var3);

    public static final native void btManifoldPoint_getLateralFrictionDir1(long var0, btManifoldPoint var2, Vector3 var3);

    public static final native void btManifoldPoint_setLateralFrictionDir1(long var0, btManifoldPoint var2, Vector3 var3);

    public static final native void btManifoldPoint_getLateralFrictionDir2(long var0, btManifoldPoint var2, Vector3 var3);

    public static final native void btManifoldPoint_setLateralFrictionDir2(long var0, btManifoldPoint var2, Vector3 var3);

    public static final native void delete_btManifoldPoint(long var0);

    public static final native long new_btContinuousConvexCollision__SWIG_0(long var0, btConvexShape var2, long var3, btConvexShape var5, long var6, btVoronoiSimplexSolver var8, long var9, btConvexPenetrationDepthSolver var11);

    public static final native long new_btContinuousConvexCollision__SWIG_1(long var0, btConvexShape var2, long var3, btStaticPlaneShape var5);

    public static final native void delete_btContinuousConvexCollision(long var0);

    public static final native void btTriangleRaycastCallback_from_set(long var0, btTriangleRaycastCallback var2, long var3, btVector3 var5);

    public static final native long btTriangleRaycastCallback_from_get(long var0, btTriangleRaycastCallback var2);

    public static final native void btTriangleRaycastCallback_to_set(long var0, btTriangleRaycastCallback var2, long var3, btVector3 var5);

    public static final native long btTriangleRaycastCallback_to_get(long var0, btTriangleRaycastCallback var2);

    public static final native void btTriangleRaycastCallback_flags_set(long var0, btTriangleRaycastCallback var2, long var3);

    public static final native long btTriangleRaycastCallback_flags_get(long var0, btTriangleRaycastCallback var2);

    public static final native void btTriangleRaycastCallback_hitFraction_set(long var0, btTriangleRaycastCallback var2, float var3);

    public static final native float btTriangleRaycastCallback_hitFraction_get(long var0, btTriangleRaycastCallback var2);

    public static final native long new_btTriangleRaycastCallback__SWIG_0(Vector3 var0, Vector3 var1, long var2);

    public static final native long new_btTriangleRaycastCallback__SWIG_1(Vector3 var0, Vector3 var1);

    public static final native void btTriangleRaycastCallback_processTriangle(long var0, btTriangleRaycastCallback var2, long var3, btVector3 var5, int var6, int var7);

    public static final native void btTriangleRaycastCallback_processTriangleSwigExplicitbtTriangleRaycastCallback(long var0, btTriangleRaycastCallback var2, long var3, btVector3 var5, int var6, int var7);

    public static final native float btTriangleRaycastCallback_reportHit(long var0, btTriangleRaycastCallback var2, Vector3 var3, float var4, int var5, int var6);

    public static final native void delete_btTriangleRaycastCallback(long var0);

    public static final native void btTriangleRaycastCallback_director_connect(btTriangleRaycastCallback var0, long var1, boolean var3, boolean var4);

    public static final native void btTriangleRaycastCallback_change_ownership(btTriangleRaycastCallback var0, long var1, boolean var3);

    public static final native void btTriangleConvexcastCallback_convexShape_set(long var0, btTriangleConvexcastCallback var2, long var3, btConvexShape var5);

    public static final native long btTriangleConvexcastCallback_convexShape_get(long var0, btTriangleConvexcastCallback var2);

    public static final native void btTriangleConvexcastCallback_convexShapeFrom_set(long var0, btTriangleConvexcastCallback var2, long var3, btTransform var5);

    public static final native long btTriangleConvexcastCallback_convexShapeFrom_get(long var0, btTriangleConvexcastCallback var2);

    public static final native void btTriangleConvexcastCallback_convexShapeTo_set(long var0, btTriangleConvexcastCallback var2, long var3, btTransform var5);

    public static final native long btTriangleConvexcastCallback_convexShapeTo_get(long var0, btTriangleConvexcastCallback var2);

    public static final native void btTriangleConvexcastCallback_triangleToWorld_set(long var0, btTriangleConvexcastCallback var2, long var3, btTransform var5);

    public static final native long btTriangleConvexcastCallback_triangleToWorld_get(long var0, btTriangleConvexcastCallback var2);

    public static final native void btTriangleConvexcastCallback_hitFraction_set(long var0, btTriangleConvexcastCallback var2, float var3);

    public static final native float btTriangleConvexcastCallback_hitFraction_get(long var0, btTriangleConvexcastCallback var2);

    public static final native void btTriangleConvexcastCallback_triangleCollisionMargin_set(long var0, btTriangleConvexcastCallback var2, float var3);

    public static final native float btTriangleConvexcastCallback_triangleCollisionMargin_get(long var0, btTriangleConvexcastCallback var2);

    public static final native void btTriangleConvexcastCallback_allowedPenetration_set(long var0, btTriangleConvexcastCallback var2, float var3);

    public static final native float btTriangleConvexcastCallback_allowedPenetration_get(long var0, btTriangleConvexcastCallback var2);

    public static final native long new_btTriangleConvexcastCallback(long var0, btConvexShape var2, Matrix4 var3, Matrix4 var4, Matrix4 var5, float var6);

    public static final native void btTriangleConvexcastCallback_processTriangle(long var0, btTriangleConvexcastCallback var2, long var3, btVector3 var5, int var6, int var7);

    public static final native void btTriangleConvexcastCallback_processTriangleSwigExplicitbtTriangleConvexcastCallback(long var0, btTriangleConvexcastCallback var2, long var3, btVector3 var5, int var6, int var7);

    public static final native float btTriangleConvexcastCallback_reportHit(long var0, btTriangleConvexcastCallback var2, Vector3 var3, Vector3 var4, float var5, int var6, int var7);

    public static final native void delete_btTriangleConvexcastCallback(long var0);

    public static final native void btTriangleConvexcastCallback_director_connect(btTriangleConvexcastCallback var0, long var1, boolean var3, boolean var4);

    public static final native void btTriangleConvexcastCallback_change_ownership(btTriangleConvexcastCallback var0, long var1, boolean var3);

    public static final native void btGjkEpaSolver2_sResults_status_set(long var0, btGjkEpaSolver2.sResults var2, int var3);

    public static final native int btGjkEpaSolver2_sResults_status_get(long var0, btGjkEpaSolver2.sResults var2);

    public static final native void btGjkEpaSolver2_sResults_witnesses_set(long var0, btGjkEpaSolver2.sResults var2, long var3, btVector3 var5);

    public static final native long btGjkEpaSolver2_sResults_witnesses_get(long var0, btGjkEpaSolver2.sResults var2);

    public static final native void btGjkEpaSolver2_sResults_normal_set(long var0, btGjkEpaSolver2.sResults var2, long var3, btVector3 var5);

    public static final native long btGjkEpaSolver2_sResults_normal_get(long var0, btGjkEpaSolver2.sResults var2);

    public static final native void btGjkEpaSolver2_sResults_distance_set(long var0, btGjkEpaSolver2.sResults var2, float var3);

    public static final native float btGjkEpaSolver2_sResults_distance_get(long var0, btGjkEpaSolver2.sResults var2);

    public static final native long new_btGjkEpaSolver2_sResults();

    public static final native void delete_btGjkEpaSolver2_sResults(long var0);

    public static final native int btGjkEpaSolver2_StackSizeRequirement();

    public static final native boolean btGjkEpaSolver2_Distance(long var0, btConvexShape var2, Matrix4 var3, long var4, btConvexShape var6, Matrix4 var7, Vector3 var8, long var9, btGjkEpaSolver2.sResults var11);

    public static final native boolean btGjkEpaSolver2_Penetration__SWIG_0(long var0, btConvexShape var2, Matrix4 var3, long var4, btConvexShape var6, Matrix4 var7, Vector3 var8, long var9, btGjkEpaSolver2.sResults var11, boolean var12);

    public static final native boolean btGjkEpaSolver2_Penetration__SWIG_1(long var0, btConvexShape var2, Matrix4 var3, long var4, btConvexShape var6, Matrix4 var7, Vector3 var8, long var9, btGjkEpaSolver2.sResults var11);

    public static final native float btGjkEpaSolver2_SignedDistance__SWIG_0(Vector3 var0, float var1, long var2, btConvexShape var4, Matrix4 var5, long var6, btGjkEpaSolver2.sResults var8);

    public static final native boolean btGjkEpaSolver2_SignedDistance__SWIG_1(long var0, btConvexShape var2, Matrix4 var3, long var4, btConvexShape var6, Matrix4 var7, Vector3 var8, long var9, btGjkEpaSolver2.sResults var11);

    public static final native long new_btGjkEpaSolver2();

    public static final native void delete_btGjkEpaSolver2(long var0);

    public static final native long new_btGjkEpaPenetrationDepthSolver();

    public static final native void delete_btGjkEpaPenetrationDepthSolver(long var0);

    public static final native void btPointCollector_normalOnBInWorld_set(long var0, btPointCollector var2, long var3, btVector3 var5);

    public static final native long btPointCollector_normalOnBInWorld_get(long var0, btPointCollector var2);

    public static final native void btPointCollector_pointInWorld_set(long var0, btPointCollector var2, long var3, btVector3 var5);

    public static final native long btPointCollector_pointInWorld_get(long var0, btPointCollector var2);

    public static final native void btPointCollector_distance_set(long var0, btPointCollector var2, float var3);

    public static final native float btPointCollector_distance_get(long var0, btPointCollector var2);

    public static final native void btPointCollector_hasResult_set(long var0, btPointCollector var2, boolean var3);

    public static final native boolean btPointCollector_hasResult_get(long var0, btPointCollector var2);

    public static final native long new_btPointCollector();

    public static final native void delete_btPointCollector(long var0);

    public static final native long new_btUsageBitfield();

    public static final native void btUsageBitfield_reset(long var0, btUsageBitfield var2);

    public static final native void btUsageBitfield_usedVertexA_set(long var0, btUsageBitfield var2, int var3);

    public static final native int btUsageBitfield_usedVertexA_get(long var0, btUsageBitfield var2);

    public static final native void btUsageBitfield_usedVertexB_set(long var0, btUsageBitfield var2, int var3);

    public static final native int btUsageBitfield_usedVertexB_get(long var0, btUsageBitfield var2);

    public static final native void btUsageBitfield_usedVertexC_set(long var0, btUsageBitfield var2, int var3);

    public static final native int btUsageBitfield_usedVertexC_get(long var0, btUsageBitfield var2);

    public static final native void btUsageBitfield_usedVertexD_set(long var0, btUsageBitfield var2, int var3);

    public static final native int btUsageBitfield_usedVertexD_get(long var0, btUsageBitfield var2);

    public static final native void btUsageBitfield_unused1_set(long var0, btUsageBitfield var2, int var3);

    public static final native int btUsageBitfield_unused1_get(long var0, btUsageBitfield var2);

    public static final native void btUsageBitfield_unused2_set(long var0, btUsageBitfield var2, int var3);

    public static final native int btUsageBitfield_unused2_get(long var0, btUsageBitfield var2);

    public static final native void btUsageBitfield_unused3_set(long var0, btUsageBitfield var2, int var3);

    public static final native int btUsageBitfield_unused3_get(long var0, btUsageBitfield var2);

    public static final native void btUsageBitfield_unused4_set(long var0, btUsageBitfield var2, int var3);

    public static final native int btUsageBitfield_unused4_get(long var0, btUsageBitfield var2);

    public static final native void delete_btUsageBitfield(long var0);

    public static final native void btSubSimplexClosestResult_closestPointOnSimplex_set(long var0, btSubSimplexClosestResult var2, long var3, btVector3 var5);

    public static final native long btSubSimplexClosestResult_closestPointOnSimplex_get(long var0, btSubSimplexClosestResult var2);

    public static final native void btSubSimplexClosestResult_usedVertices_set(long var0, btSubSimplexClosestResult var2, long var3, btUsageBitfield var5);

    public static final native long btSubSimplexClosestResult_usedVertices_get(long var0, btSubSimplexClosestResult var2);

    public static final native void btSubSimplexClosestResult_barycentricCoords_set(long var0, btSubSimplexClosestResult var2, float[] var3);

    public static final native float[] btSubSimplexClosestResult_barycentricCoords_get(long var0, btSubSimplexClosestResult var2);

    public static final native void btSubSimplexClosestResult_degenerate_set(long var0, btSubSimplexClosestResult var2, boolean var3);

    public static final native boolean btSubSimplexClosestResult_degenerate_get(long var0, btSubSimplexClosestResult var2);

    public static final native void btSubSimplexClosestResult_reset(long var0, btSubSimplexClosestResult var2);

    public static final native boolean btSubSimplexClosestResult_isValid(long var0, btSubSimplexClosestResult var2);

    public static final native void btSubSimplexClosestResult_setBarycentricCoordinates__SWIG_0(long var0, btSubSimplexClosestResult var2, float var3, float var4, float var5, float var6);

    public static final native void btSubSimplexClosestResult_setBarycentricCoordinates__SWIG_1(long var0, btSubSimplexClosestResult var2, float var3, float var4, float var5);

    public static final native void btSubSimplexClosestResult_setBarycentricCoordinates__SWIG_2(long var0, btSubSimplexClosestResult var2, float var3, float var4);

    public static final native void btSubSimplexClosestResult_setBarycentricCoordinates__SWIG_3(long var0, btSubSimplexClosestResult var2, float var3);

    public static final native void btSubSimplexClosestResult_setBarycentricCoordinates__SWIG_4(long var0, btSubSimplexClosestResult var2);

    public static final native long new_btSubSimplexClosestResult();

    public static final native void delete_btSubSimplexClosestResult(long var0);

    public static final native long btVoronoiSimplexSolver_operatorNew__SWIG_0(long var0, btVoronoiSimplexSolver var2, long var3);

    public static final native void btVoronoiSimplexSolver_operatorDelete__SWIG_0(long var0, btVoronoiSimplexSolver var2, long var3);

    public static final native long btVoronoiSimplexSolver_operatorNew__SWIG_1(long var0, btVoronoiSimplexSolver var2, long var3, long var5);

    public static final native void btVoronoiSimplexSolver_operatorDelete__SWIG_1(long var0, btVoronoiSimplexSolver var2, long var3, long var5);

    public static final native long btVoronoiSimplexSolver_operatorNewArray__SWIG_0(long var0, btVoronoiSimplexSolver var2, long var3);

    public static final native void btVoronoiSimplexSolver_operatorDeleteArray__SWIG_0(long var0, btVoronoiSimplexSolver var2, long var3);

    public static final native long btVoronoiSimplexSolver_operatorNewArray__SWIG_1(long var0, btVoronoiSimplexSolver var2, long var3, long var5);

    public static final native void btVoronoiSimplexSolver_operatorDeleteArray__SWIG_1(long var0, btVoronoiSimplexSolver var2, long var3, long var5);

    public static final native void btVoronoiSimplexSolver_numVertices_set(long var0, btVoronoiSimplexSolver var2, int var3);

    public static final native int btVoronoiSimplexSolver_numVertices_get(long var0, btVoronoiSimplexSolver var2);

    public static final native void btVoronoiSimplexSolver_simplexVectorW_set(long var0, btVoronoiSimplexSolver var2, long var3, btVector3 var5);

    public static final native long btVoronoiSimplexSolver_simplexVectorW_get(long var0, btVoronoiSimplexSolver var2);

    public static final native void btVoronoiSimplexSolver_simplexPointsP_set(long var0, btVoronoiSimplexSolver var2, long var3, btVector3 var5);

    public static final native long btVoronoiSimplexSolver_simplexPointsP_get(long var0, btVoronoiSimplexSolver var2);

    public static final native void btVoronoiSimplexSolver_simplexPointsQ_set(long var0, btVoronoiSimplexSolver var2, long var3, btVector3 var5);

    public static final native long btVoronoiSimplexSolver_simplexPointsQ_get(long var0, btVoronoiSimplexSolver var2);

    public static final native void btVoronoiSimplexSolver_cachedP1_set(long var0, btVoronoiSimplexSolver var2, long var3, btVector3 var5);

    public static final native long btVoronoiSimplexSolver_cachedP1_get(long var0, btVoronoiSimplexSolver var2);

    public static final native void btVoronoiSimplexSolver_cachedP2_set(long var0, btVoronoiSimplexSolver var2, long var3, btVector3 var5);

    public static final native long btVoronoiSimplexSolver_cachedP2_get(long var0, btVoronoiSimplexSolver var2);

    public static final native void btVoronoiSimplexSolver_cachedV_set(long var0, btVoronoiSimplexSolver var2, long var3, btVector3 var5);

    public static final native long btVoronoiSimplexSolver_cachedV_get(long var0, btVoronoiSimplexSolver var2);

    public static final native void btVoronoiSimplexSolver_lastW_set(long var0, btVoronoiSimplexSolver var2, long var3, btVector3 var5);

    public static final native long btVoronoiSimplexSolver_lastW_get(long var0, btVoronoiSimplexSolver var2);

    public static final native void btVoronoiSimplexSolver_equalVertexThreshold_set(long var0, btVoronoiSimplexSolver var2, float var3);

    public static final native float btVoronoiSimplexSolver_equalVertexThreshold_get(long var0, btVoronoiSimplexSolver var2);

    public static final native void btVoronoiSimplexSolver_cachedValidClosest_set(long var0, btVoronoiSimplexSolver var2, boolean var3);

    public static final native boolean btVoronoiSimplexSolver_cachedValidClosest_get(long var0, btVoronoiSimplexSolver var2);

    public static final native void btVoronoiSimplexSolver_cachedBC_set(long var0, btVoronoiSimplexSolver var2, long var3, btSubSimplexClosestResult var5);

    public static final native long btVoronoiSimplexSolver_cachedBC_get(long var0, btVoronoiSimplexSolver var2);

    public static final native void btVoronoiSimplexSolver_needsUpdate_set(long var0, btVoronoiSimplexSolver var2, boolean var3);

    public static final native boolean btVoronoiSimplexSolver_needsUpdate_get(long var0, btVoronoiSimplexSolver var2);

    public static final native void btVoronoiSimplexSolver_removeVertex(long var0, btVoronoiSimplexSolver var2, int var3);

    public static final native void btVoronoiSimplexSolver_reduceVertices(long var0, btVoronoiSimplexSolver var2, long var3, btUsageBitfield var5);

    public static final native boolean btVoronoiSimplexSolver_updateClosestVectorAndPoints(long var0, btVoronoiSimplexSolver var2);

    public static final native boolean btVoronoiSimplexSolver_closestPtPointTetrahedron(long var0, btVoronoiSimplexSolver var2, Vector3 var3, Vector3 var4, Vector3 var5, Vector3 var6, Vector3 var7, long var8, btSubSimplexClosestResult var10);

    public static final native int btVoronoiSimplexSolver_pointOutsideOfPlane(long var0, btVoronoiSimplexSolver var2, Vector3 var3, Vector3 var4, Vector3 var5, Vector3 var6, Vector3 var7);

    public static final native boolean btVoronoiSimplexSolver_closestPtPointTriangle(long var0, btVoronoiSimplexSolver var2, Vector3 var3, Vector3 var4, Vector3 var5, Vector3 var6, long var7, btSubSimplexClosestResult var9);

    public static final native long new_btVoronoiSimplexSolver();

    public static final native void btVoronoiSimplexSolver_reset(long var0, btVoronoiSimplexSolver var2);

    public static final native void btVoronoiSimplexSolver_addVertex(long var0, btVoronoiSimplexSolver var2, Vector3 var3, Vector3 var4, Vector3 var5);

    public static final native boolean btVoronoiSimplexSolver_closest(long var0, btVoronoiSimplexSolver var2, Vector3 var3);

    public static final native float btVoronoiSimplexSolver_maxVertex(long var0, btVoronoiSimplexSolver var2);

    public static final native boolean btVoronoiSimplexSolver_fullSimplex(long var0, btVoronoiSimplexSolver var2);

    public static final native int btVoronoiSimplexSolver_getSimplex(long var0, btVoronoiSimplexSolver var2, long var3, btVector3 var5, long var6, btVector3 var8, long var9, btVector3 var11);

    public static final native boolean btVoronoiSimplexSolver_inSimplex(long var0, btVoronoiSimplexSolver var2, Vector3 var3);

    public static final native void btVoronoiSimplexSolver_backup_closest(long var0, btVoronoiSimplexSolver var2, Vector3 var3);

    public static final native boolean btVoronoiSimplexSolver_emptySimplex(long var0, btVoronoiSimplexSolver var2);

    public static final native void btVoronoiSimplexSolver_compute_points(long var0, btVoronoiSimplexSolver var2, Vector3 var3, Vector3 var4);

    public static final native int btVoronoiSimplexSolver_m_numVerticesVar(long var0, btVoronoiSimplexSolver var2);

    public static final native void delete_btVoronoiSimplexSolver(long var0);

    public static final native long btMultiSphereShape_operatorNew__SWIG_0(long var0, btMultiSphereShape var2, long var3);

    public static final native void btMultiSphereShape_operatorDelete__SWIG_0(long var0, btMultiSphereShape var2, long var3);

    public static final native long btMultiSphereShape_operatorNew__SWIG_1(long var0, btMultiSphereShape var2, long var3, long var5);

    public static final native void btMultiSphereShape_operatorDelete__SWIG_1(long var0, btMultiSphereShape var2, long var3, long var5);

    public static final native long btMultiSphereShape_operatorNewArray__SWIG_0(long var0, btMultiSphereShape var2, long var3);

    public static final native void btMultiSphereShape_operatorDeleteArray__SWIG_0(long var0, btMultiSphereShape var2, long var3);

    public static final native long btMultiSphereShape_operatorNewArray__SWIG_1(long var0, btMultiSphereShape var2, long var3, long var5);

    public static final native void btMultiSphereShape_operatorDeleteArray__SWIG_1(long var0, btMultiSphereShape var2, long var3, long var5);

    public static final native long new_btMultiSphereShape(Vector3[] var0, float[] var1, int var2);

    public static final native int btMultiSphereShape_getSphereCount(long var0, btMultiSphereShape var2);

    public static final native Vector3 btMultiSphereShape_getSpherePosition(long var0, btMultiSphereShape var2, int var3);

    public static final native float btMultiSphereShape_getSphereRadius(long var0, btMultiSphereShape var2, int var3);

    public static final native void delete_btMultiSphereShape(long var0);

    public static final native void btPositionAndRadius_pos_set(long var0, btPositionAndRadius var2, long var3, btVector3FloatData var5);

    public static final native long btPositionAndRadius_pos_get(long var0, btPositionAndRadius var2);

    public static final native void btPositionAndRadius_radius_set(long var0, btPositionAndRadius var2, float var3);

    public static final native float btPositionAndRadius_radius_get(long var0, btPositionAndRadius var2);

    public static final native long new_btPositionAndRadius();

    public static final native void delete_btPositionAndRadius(long var0);

    public static final native void btMultiSphereShapeData_convexInternalShapeData_set(long var0, btMultiSphereShapeData var2, long var3, btConvexInternalShapeData var5);

    public static final native long btMultiSphereShapeData_convexInternalShapeData_get(long var0, btMultiSphereShapeData var2);

    public static final native void btMultiSphereShapeData_localPositionArrayPtr_set(long var0, btMultiSphereShapeData var2, long var3, btPositionAndRadius var5);

    public static final native long btMultiSphereShapeData_localPositionArrayPtr_get(long var0, btMultiSphereShapeData var2);

    public static final native void btMultiSphereShapeData_localPositionArraySize_set(long var0, btMultiSphereShapeData var2, int var3);

    public static final native int btMultiSphereShapeData_localPositionArraySize_get(long var0, btMultiSphereShapeData var2);

    public static final native void btMultiSphereShapeData_padding_set(long var0, btMultiSphereShapeData var2, String var3);

    public static final native String btMultiSphereShapeData_padding_get(long var0, btMultiSphereShapeData var2);

    public static final native long new_btMultiSphereShapeData();

    public static final native void delete_btMultiSphereShapeData(long var0);

    public static final native long new_CustomCollisionDispatcher(long var0, btCollisionConfiguration var2);

    public static final native boolean CustomCollisionDispatcher_needsCollision(long var0, CustomCollisionDispatcher var2, long var3, btCollisionObject var5, long var6, btCollisionObject var8);

    public static final native boolean CustomCollisionDispatcher_needsCollisionSwigExplicitCustomCollisionDispatcher(long var0, CustomCollisionDispatcher var2, long var3, btCollisionObject var5, long var6, btCollisionObject var8);

    public static final native boolean CustomCollisionDispatcher_needsResponse(long var0, CustomCollisionDispatcher var2, long var3, btCollisionObject var5, long var6, btCollisionObject var8);

    public static final native boolean CustomCollisionDispatcher_needsResponseSwigExplicitCustomCollisionDispatcher(long var0, CustomCollisionDispatcher var2, long var3, btCollisionObject var5, long var6, btCollisionObject var8);

    public static final native void delete_CustomCollisionDispatcher(long var0);

    public static final native void CustomCollisionDispatcher_director_connect(CustomCollisionDispatcher var0, long var1, boolean var3, boolean var4);

    public static final native void CustomCollisionDispatcher_change_ownership(CustomCollisionDispatcher var0, long var1, boolean var3);

    public static final native long new_ContactListener(boolean var0);

    public static final native void delete_ContactListener(long var0);

    public static final native void ContactListener_enable(long var0, ContactListener var2);

    public static final native void ContactListener_disable(long var0, ContactListener var2);

    public static final native void ContactListener_enableOnAdded(long var0, ContactListener var2);

    public static final native void ContactListener_disableOnAdded(long var0, ContactListener var2);

    public static final native boolean ContactListener_isOnAddedEnabled(long var0, ContactListener var2);

    public static final native boolean ContactListener_onContactAdded__SWIG_0(long var0, ContactListener var2, long var3, btManifoldPoint var5, long var6, btCollisionObjectWrapper var8, int var9, int var10, long var11, btCollisionObjectWrapper var13, int var14, int var15);

    public static final native boolean ContactListener_onContactAdded__SWIG_1(long var0, ContactListener var2, long var3, btManifoldPoint var5, long var6, btCollisionObject var8, int var9, int var10, long var11, btCollisionObject var13, int var14, int var15);

    public static final native boolean ContactListener_onContactAdded__SWIG_2(long var0, ContactListener var2, long var3, btManifoldPoint var5, int var6, int var7, int var8, int var9, int var10, int var11);

    public static final native boolean ContactListener_onContactAdded__SWIG_3(long var0, ContactListener var2, long var3, btManifoldPoint var5, long var6, btCollisionObjectWrapper var8, int var9, int var10, boolean var11, long var12, btCollisionObjectWrapper var14, int var15, int var16, boolean var17);

    public static final native boolean ContactListener_onContactAdded__SWIG_4(long var0, ContactListener var2, long var3, btManifoldPoint var5, long var6, btCollisionObject var8, int var9, int var10, boolean var11, long var12, btCollisionObject var14, int var15, int var16, boolean var17);

    public static final native boolean ContactListener_onContactAdded__SWIG_5(long var0, ContactListener var2, long var3, btManifoldPoint var5, int var6, int var7, int var8, boolean var9, int var10, int var11, int var12, boolean var13);

    public static final native boolean ContactListener_onContactAdded__SWIG_6(long var0, ContactListener var2, long var3, btCollisionObjectWrapper var5, int var6, int var7, long var8, btCollisionObjectWrapper var10, int var11, int var12);

    public static final native boolean ContactListener_onContactAdded__SWIG_7(long var0, ContactListener var2, long var3, btCollisionObject var5, int var6, int var7, long var8, btCollisionObject var10, int var11, int var12);

    public static final native boolean ContactListener_onContactAdded__SWIG_8(long var0, ContactListener var2, int var3, int var4, int var5, int var6, int var7, int var8);

    public static final native boolean ContactListener_onContactAdded__SWIG_9(long var0, ContactListener var2, long var3, btCollisionObjectWrapper var5, int var6, int var7, boolean var8, long var9, btCollisionObjectWrapper var11, int var12, int var13, boolean var14);

    public static final native boolean ContactListener_onContactAdded__SWIG_10(long var0, ContactListener var2, long var3, btCollisionObject var5, int var6, int var7, boolean var8, long var9, btCollisionObject var11, int var12, int var13, boolean var14);

    public static final native boolean ContactListener_onContactAdded__SWIG_11(long var0, ContactListener var2, int var3, int var4, int var5, boolean var6, int var7, int var8, int var9, boolean var10);

    public static final native void ContactListener_enableOnProcessed(long var0, ContactListener var2);

    public static final native void ContactListener_disableOnProcessed(long var0, ContactListener var2);

    public static final native boolean ContactListener_isOnProcessedEnabled(long var0, ContactListener var2);

    public static final native void ContactListener_onContactProcessed__SWIG_0(long var0, ContactListener var2, long var3, btManifoldPoint var5, long var6, btCollisionObject var8, long var9, btCollisionObject var11);

    public static final native void ContactListener_onContactProcessed__SWIG_1(long var0, ContactListener var2, long var3, btManifoldPoint var5, int var6, int var7);

    public static final native void ContactListener_onContactProcessed__SWIG_2(long var0, ContactListener var2, long var3, btManifoldPoint var5, long var6, btCollisionObject var8, boolean var9, long var10, btCollisionObject var12, boolean var13);

    public static final native void ContactListener_onContactProcessed__SWIG_3(long var0, ContactListener var2, long var3, btManifoldPoint var5, int var6, boolean var7, int var8, boolean var9);

    public static final native void ContactListener_onContactProcessed__SWIG_4(long var0, ContactListener var2, long var3, btCollisionObject var5, long var6, btCollisionObject var8);

    public static final native void ContactListener_onContactProcessed__SWIG_5(long var0, ContactListener var2, int var3, int var4);

    public static final native void ContactListener_onContactProcessed__SWIG_6(long var0, ContactListener var2, long var3, btCollisionObject var5, boolean var6, long var7, btCollisionObject var9, boolean var10);

    public static final native void ContactListener_onContactProcessed__SWIG_7(long var0, ContactListener var2, int var3, boolean var4, int var5, boolean var6);

    public static final native void ContactListener_enableOnDestroyed(long var0, ContactListener var2);

    public static final native void ContactListener_disableOnDestroyed(long var0, ContactListener var2);

    public static final native boolean ContactListener_isOnDestroyedEnabled(long var0, ContactListener var2);

    public static final native void ContactListener_onContactDestroyed(long var0, ContactListener var2, int var3);

    public static final native void ContactListener_enableOnStarted(long var0, ContactListener var2);

    public static final native void ContactListener_disableOnStarted(long var0, ContactListener var2);

    public static final native boolean ContactListener_isOnStartedEnabled(long var0, ContactListener var2);

    public static final native void ContactListener_onContactStarted__SWIG_0(long var0, ContactListener var2, long var3, btPersistentManifold var5);

    public static final native void ContactListener_onContactStarted__SWIG_1(long var0, ContactListener var2, long var3, btCollisionObject var5, long var6, btCollisionObject var8);

    public static final native void ContactListener_onContactStarted__SWIG_2(long var0, ContactListener var2, int var3, int var4);

    public static final native void ContactListener_onContactStarted__SWIG_3(long var0, ContactListener var2, long var3, btPersistentManifold var5, boolean var6, boolean var7);

    public static final native void ContactListener_onContactStarted__SWIG_4(long var0, ContactListener var2, long var3, btCollisionObject var5, boolean var6, long var7, btCollisionObject var9, boolean var10);

    public static final native void ContactListener_onContactStarted__SWIG_5(long var0, ContactListener var2, int var3, boolean var4, int var5, boolean var6);

    public static final native void ContactListener_enableOnEnded(long var0, ContactListener var2);

    public static final native void ContactListener_disableOnEnded(long var0, ContactListener var2);

    public static final native boolean ContactListener_isOnEndedEnabled(long var0, ContactListener var2);

    public static final native void ContactListener_onContactEnded__SWIG_0(long var0, ContactListener var2, long var3, btPersistentManifold var5);

    public static final native void ContactListener_onContactEnded__SWIG_1(long var0, ContactListener var2, long var3, btCollisionObject var5, long var6, btCollisionObject var8);

    public static final native void ContactListener_onContactEnded__SWIG_2(long var0, ContactListener var2, int var3, int var4);

    public static final native void ContactListener_onContactEnded__SWIG_3(long var0, ContactListener var2, long var3, btPersistentManifold var5, boolean var6, boolean var7);

    public static final native void ContactListener_onContactEnded__SWIG_4(long var0, ContactListener var2, long var3, btCollisionObject var5, boolean var6, long var7, btCollisionObject var9, boolean var10);

    public static final native void ContactListener_onContactEnded__SWIG_5(long var0, ContactListener var2, int var3, boolean var4, int var5, boolean var6);

    public static final native boolean ContactListener_setEvents(long var0, ContactListener var2);

    public static final native void ContactListener_director_connect(ContactListener var0, long var1, boolean var3, boolean var4);

    public static final native void ContactListener_change_ownership(ContactListener var0, long var1, boolean var3);

    public static final native void ContactCache_cacheTime_set(long var0, ContactCache var2, float var3);

    public static final native float ContactCache_cacheTime_get(long var0, ContactCache var2);

    public static final native long new_ContactCache(boolean var0);

    public static final native void delete_ContactCache(long var0);

    public static final native void ContactCache_enable(long var0, ContactCache var2);

    public static final native void ContactCache_disable(long var0, ContactCache var2);

    public static final native boolean ContactCache_isEnabled(long var0, ContactCache var2);

    public static final native void ContactCache_onContactStarted(long var0, ContactCache var2, long var3, btPersistentManifold var5, boolean var6, boolean var7);

    public static final native void ContactCache_onContactEnded(long var0, ContactCache var2, long var3, btCollisionObject var5, boolean var6, long var7, btCollisionObject var9, boolean var10);

    public static final native void ContactCache_clear(long var0, ContactCache var2);

    public static final native void ContactCache_update(long var0, ContactCache var2, float var3);

    public static final native void ContactCache_director_connect(ContactCache var0, long var1, boolean var3, boolean var4);

    public static final native void ContactCache_change_ownership(ContactCache var0, long var1, boolean var3);

    public static final native int btBroadphasePairArray_size(long var0, btBroadphasePairArray var2);

    public static final native long btBroadphasePairArray_at(long var0, btBroadphasePairArray var2, int var3);

    public static final native int btBroadphasePairArray_getCollisionObjects(long var0, btBroadphasePairArray var2, int[] var3, int var4, int var5);

    public static final native int btBroadphasePairArray_getCollisionObjectsValue(long var0, btBroadphasePairArray var2, int[] var3, int var4, int var5);

    public static final native long new_btBroadphasePairArray();

    public static final native void delete_btBroadphasePairArray(long var0);

    public static final native void bt_calc_quantization_parameters(Vector3 var0, Vector3 var1, Vector3 var2, Vector3 var3, Vector3 var4, float var5);

    public static final native void bt_quantize_clamp(IntBuffer var0, Vector3 var1, Vector3 var2, Vector3 var3, Vector3 var4);

    public static final native Vector3 bt_unquantize(IntBuffer var0, Vector3 var1, Vector3 var2);

    public static final native float bt_mat3_dot_col(Matrix3 var0, Vector3 var1, int var2);

    public static final native void BT_BOX_BOX_TRANSFORM_CACHE_T1to0_set(long var0, BT_BOX_BOX_TRANSFORM_CACHE var2, long var3, btVector3 var5);

    public static final native long BT_BOX_BOX_TRANSFORM_CACHE_T1to0_get(long var0, BT_BOX_BOX_TRANSFORM_CACHE var2);

    public static final native void BT_BOX_BOX_TRANSFORM_CACHE_R1to0_set(long var0, BT_BOX_BOX_TRANSFORM_CACHE var2, long var3, btMatrix3x3 var5);

    public static final native long BT_BOX_BOX_TRANSFORM_CACHE_R1to0_get(long var0, BT_BOX_BOX_TRANSFORM_CACHE var2);

    public static final native void BT_BOX_BOX_TRANSFORM_CACHE_AR_set(long var0, BT_BOX_BOX_TRANSFORM_CACHE var2, long var3, btMatrix3x3 var5);

    public static final native long BT_BOX_BOX_TRANSFORM_CACHE_AR_get(long var0, BT_BOX_BOX_TRANSFORM_CACHE var2);

    public static final native void BT_BOX_BOX_TRANSFORM_CACHE_calc_absolute_matrix(long var0, BT_BOX_BOX_TRANSFORM_CACHE var2);

    public static final native long new_BT_BOX_BOX_TRANSFORM_CACHE();

    public static final native void BT_BOX_BOX_TRANSFORM_CACHE_calc_from_homogenic(long var0, BT_BOX_BOX_TRANSFORM_CACHE var2, Matrix4 var3, Matrix4 var4);

    public static final native void BT_BOX_BOX_TRANSFORM_CACHE_calc_from_full_invert(long var0, BT_BOX_BOX_TRANSFORM_CACHE var2, Matrix4 var3, Matrix4 var4);

    public static final native Vector3 BT_BOX_BOX_TRANSFORM_CACHE_transform(long var0, BT_BOX_BOX_TRANSFORM_CACHE var2, Vector3 var3);

    public static final native void delete_BT_BOX_BOX_TRANSFORM_CACHE(long var0);

    public static final native void btAABB_min_set(long var0, btAABB var2, long var3, btVector3 var5);

    public static final native long btAABB_min_get(long var0, btAABB var2);

    public static final native void btAABB_max_set(long var0, btAABB var2, long var3, btVector3 var5);

    public static final native long btAABB_max_get(long var0, btAABB var2);

    public static final native long new_btAABB__SWIG_0();

    public static final native long new_btAABB__SWIG_1(Vector3 var0, Vector3 var1, Vector3 var2);

    public static final native long new_btAABB__SWIG_2(Vector3 var0, Vector3 var1, Vector3 var2, float var3);

    public static final native long new_btAABB__SWIG_3(long var0, btAABB var2);

    public static final native long new_btAABB__SWIG_4(long var0, btAABB var2, float var3);

    public static final native void btAABB_invalidate(long var0, btAABB var2);

    public static final native void btAABB_increment_margin(long var0, btAABB var2, float var3);

    public static final native void btAABB_copy_with_margin(long var0, btAABB var2, long var3, btAABB var5, float var6);

    public static final native void btAABB_appy_transform(long var0, btAABB var2, Matrix4 var3);

    public static final native void btAABB_appy_transform_trans_cache(long var0, btAABB var2, long var3, BT_BOX_BOX_TRANSFORM_CACHE var5);

    public static final native void btAABB_merge(long var0, btAABB var2, long var3, btAABB var5);

    public static final native void btAABB_get_center_extend(long var0, btAABB var2, Vector3 var3, Vector3 var4);

    public static final native void btAABB_find_intersection(long var0, btAABB var2, long var3, btAABB var5, long var6, btAABB var8);

    public static final native boolean btAABB_has_collision(long var0, btAABB var2, long var3, btAABB var5);

    public static final native boolean btAABB_collide_ray(long var0, btAABB var2, Vector3 var3, Vector3 var4);

    public static final native void btAABB_projection_interval(long var0, btAABB var2, Vector3 var3, long var4, long var6);

    public static final native int btAABB_plane_classify(long var0, btAABB var2, long var3, btVector4 var5);

    public static final native boolean btAABB_overlapping_trans_conservative(long var0, btAABB var2, long var3, btAABB var5, Matrix4 var6);

    public static final native boolean btAABB_overlapping_trans_conservative2(long var0, btAABB var2, long var3, btAABB var5, long var6, BT_BOX_BOX_TRANSFORM_CACHE var8);

    public static final native boolean btAABB_overlapping_trans_cache(long var0, btAABB var2, long var3, btAABB var5, long var6, BT_BOX_BOX_TRANSFORM_CACHE var8, boolean var9);

    public static final native boolean btAABB_collide_plane(long var0, btAABB var2, long var3, btVector4 var5);

    public static final native boolean btAABB_collide_triangle_exact(long var0, btAABB var2, Vector3 var3, Vector3 var4, Vector3 var5, long var6, btVector4 var8);

    public static final native void delete_btAABB(long var0);

    public static final native boolean btCompareTransformsEqual(Matrix4 var0, Matrix4 var1);

    public static final native float bt_distance_point_plane(long var0, btVector4 var2, Vector3 var3);

    public static final native void bt_vec_blend(Vector3 var0, Vector3 var1, Vector3 var2, float var3);

    public static final native void bt_plane_clip_polygon_collect(Vector3 var0, Vector3 var1, float var2, float var3, long var4, btVector3 var6, long var7);

    public static final native int bt_plane_clip_polygon(long var0, btVector4 var2, long var3, btVector3 var5, int var6, long var7, btVector3 var9);

    public static final native int bt_plane_clip_triangle(long var0, btVector4 var2, Vector3 var3, Vector3 var4, Vector3 var5, long var6, btVector3 var8);

    public static final native void bt_edge_plane(Vector3 var0, Vector3 var1, Vector3 var2, long var3, btVector4 var5);

    public static final native void bt_closest_point_on_segment(Vector3 var0, Vector3 var1, Vector3 var2, Vector3 var3);

    public static final native int bt_line_plane_collision(long var0, btVector4 var2, Vector3 var3, Vector3 var4, Vector3 var5, long var6, float var8, float var9);

    public static final native void bt_segment_collision(Vector3 var0, Vector3 var1, Vector3 var2, Vector3 var3, Vector3 var4, Vector3 var5);

    public static final native void GIM_TRIANGLE_CONTACT_penetration_depth_set(long var0, GIM_TRIANGLE_CONTACT var2, float var3);

    public static final native float GIM_TRIANGLE_CONTACT_penetration_depth_get(long var0, GIM_TRIANGLE_CONTACT var2);

    public static final native void GIM_TRIANGLE_CONTACT_point_count_set(long var0, GIM_TRIANGLE_CONTACT var2, int var3);

    public static final native int GIM_TRIANGLE_CONTACT_point_count_get(long var0, GIM_TRIANGLE_CONTACT var2);

    public static final native void GIM_TRIANGLE_CONTACT_separating_normal_set(long var0, GIM_TRIANGLE_CONTACT var2, long var3, btVector4 var5);

    public static final native long GIM_TRIANGLE_CONTACT_separating_normal_get(long var0, GIM_TRIANGLE_CONTACT var2);

    public static final native void GIM_TRIANGLE_CONTACT_points_set(long var0, GIM_TRIANGLE_CONTACT var2, long var3, btVector3 var5);

    public static final native long GIM_TRIANGLE_CONTACT_points_get(long var0, GIM_TRIANGLE_CONTACT var2);

    public static final native void GIM_TRIANGLE_CONTACT_copy_from(long var0, GIM_TRIANGLE_CONTACT var2, long var3, GIM_TRIANGLE_CONTACT var5);

    public static final native long new_GIM_TRIANGLE_CONTACT__SWIG_0();

    public static final native long new_GIM_TRIANGLE_CONTACT__SWIG_1(long var0, GIM_TRIANGLE_CONTACT var2);

    public static final native void GIM_TRIANGLE_CONTACT_merge_points(long var0, GIM_TRIANGLE_CONTACT var2, long var3, btVector4 var5, float var6, long var7, btVector3 var9, int var10);

    public static final native void delete_GIM_TRIANGLE_CONTACT(long var0);

    public static final native void btPrimitiveTriangle_vertices_set(long var0, btPrimitiveTriangle var2, long var3, btVector3 var5);

    public static final native long btPrimitiveTriangle_vertices_get(long var0, btPrimitiveTriangle var2);

    public static final native void btPrimitiveTriangle_plane_set(long var0, btPrimitiveTriangle var2, long var3, btVector4 var5);

    public static final native long btPrimitiveTriangle_plane_get(long var0, btPrimitiveTriangle var2);

    public static final native void btPrimitiveTriangle_margin_set(long var0, btPrimitiveTriangle var2, float var3);

    public static final native float btPrimitiveTriangle_margin_get(long var0, btPrimitiveTriangle var2);

    public static final native void btPrimitiveTriangle_dummy_set(long var0, btPrimitiveTriangle var2, float var3);

    public static final native float btPrimitiveTriangle_dummy_get(long var0, btPrimitiveTriangle var2);

    public static final native long new_btPrimitiveTriangle();

    public static final native void btPrimitiveTriangle_buildTriPlane(long var0, btPrimitiveTriangle var2);

    public static final native boolean btPrimitiveTriangle_overlap_test_conservative(long var0, btPrimitiveTriangle var2, long var3, btPrimitiveTriangle var5);

    public static final native void btPrimitiveTriangle_get_edge_plane(long var0, btPrimitiveTriangle var2, int var3, long var4, btVector4 var6);

    public static final native void btPrimitiveTriangle_applyTransform(long var0, btPrimitiveTriangle var2, Matrix4 var3);

    public static final native int btPrimitiveTriangle_clip_triangle(long var0, btPrimitiveTriangle var2, long var3, btPrimitiveTriangle var5, long var6, btVector3 var8);

    public static final native boolean btPrimitiveTriangle_find_triangle_collision_clip_method(long var0, btPrimitiveTriangle var2, long var3, btPrimitiveTriangle var5, long var6, GIM_TRIANGLE_CONTACT var8);

    public static final native void delete_btPrimitiveTriangle(long var0);

    public static final native long new_btTriangleShapeEx__SWIG_0();

    public static final native long new_btTriangleShapeEx__SWIG_1(Vector3 var0, Vector3 var1, Vector3 var2);

    public static final native long new_btTriangleShapeEx__SWIG_2(long var0, btTriangleShapeEx var2);

    public static final native void btTriangleShapeEx_applyTransform(long var0, btTriangleShapeEx var2, Matrix4 var3);

    public static final native void btTriangleShapeEx_buildTriPlane(long var0, btTriangleShapeEx var2, long var3, btVector4 var5);

    public static final native boolean btTriangleShapeEx_overlap_test_conservative(long var0, btTriangleShapeEx var2, long var3, btTriangleShapeEx var5);

    public static final native void delete_btTriangleShapeEx(long var0);

    public static final native void GIM_PAIR_index1_set(long var0, GIM_PAIR var2, int var3);

    public static final native int GIM_PAIR_index1_get(long var0, GIM_PAIR var2);

    public static final native void GIM_PAIR_index2_set(long var0, GIM_PAIR var2, int var3);

    public static final native int GIM_PAIR_index2_get(long var0, GIM_PAIR var2);

    public static final native long new_GIM_PAIR__SWIG_0();

    public static final native long new_GIM_PAIR__SWIG_1(long var0, GIM_PAIR var2);

    public static final native long new_GIM_PAIR__SWIG_2(int var0, int var1);

    public static final native void delete_GIM_PAIR(long var0);

    public static final native void GIM_BVH_DATA_bound_set(long var0, GIM_BVH_DATA var2, long var3, btAABB var5);

    public static final native long GIM_BVH_DATA_bound_get(long var0, GIM_BVH_DATA var2);

    public static final native void GIM_BVH_DATA_data_set(long var0, GIM_BVH_DATA var2, int var3);

    public static final native int GIM_BVH_DATA_data_get(long var0, GIM_BVH_DATA var2);

    public static final native long new_GIM_BVH_DATA();

    public static final native void delete_GIM_BVH_DATA(long var0);

    public static final native void GIM_BVH_TREE_NODE_bound_set(long var0, GIM_BVH_TREE_NODE var2, long var3, btAABB var5);

    public static final native long GIM_BVH_TREE_NODE_bound_get(long var0, GIM_BVH_TREE_NODE var2);

    public static final native long new_GIM_BVH_TREE_NODE();

    public static final native boolean GIM_BVH_TREE_NODE_isLeafNode(long var0, GIM_BVH_TREE_NODE var2);

    public static final native int GIM_BVH_TREE_NODE_getEscapeIndex(long var0, GIM_BVH_TREE_NODE var2);

    public static final native void GIM_BVH_TREE_NODE_setEscapeIndex(long var0, GIM_BVH_TREE_NODE var2, int var3);

    public static final native int GIM_BVH_TREE_NODE_getDataIndex(long var0, GIM_BVH_TREE_NODE var2);

    public static final native void GIM_BVH_TREE_NODE_setDataIndex(long var0, GIM_BVH_TREE_NODE var2, int var3);

    public static final native void delete_GIM_BVH_TREE_NODE(long var0);

    public static final native long btGimPairArray_operatorAssignment(long var0, btGimPairArray var2, long var3, btGimPairArray var5);

    public static final native long new_btGimPairArray__SWIG_0();

    public static final native void delete_btGimPairArray(long var0);

    public static final native long new_btGimPairArray__SWIG_1(long var0, btGimPairArray var2);

    public static final native int btGimPairArray_size(long var0, btGimPairArray var2);

    public static final native long btGimPairArray_atConst(long var0, btGimPairArray var2, int var3);

    public static final native long btGimPairArray_at(long var0, btGimPairArray var2, int var3);

    public static final native long btGimPairArray_operatorSubscriptConst(long var0, btGimPairArray var2, int var3);

    public static final native long btGimPairArray_operatorSubscript(long var0, btGimPairArray var2, int var3);

    public static final native void btGimPairArray_clear(long var0, btGimPairArray var2);

    public static final native void btGimPairArray_pop_back(long var0, btGimPairArray var2);

    public static final native void btGimPairArray_resizeNoInitialize(long var0, btGimPairArray var2, int var3);

    public static final native void btGimPairArray_resize__SWIG_0(long var0, btGimPairArray var2, int var3, long var4, GIM_PAIR var6);

    public static final native void btGimPairArray_resize__SWIG_1(long var0, btGimPairArray var2, int var3);

    public static final native long btGimPairArray_expandNonInitializing(long var0, btGimPairArray var2);

    public static final native long btGimPairArray_expand__SWIG_0(long var0, btGimPairArray var2, long var3, GIM_PAIR var5);

    public static final native long btGimPairArray_expand__SWIG_1(long var0, btGimPairArray var2);

    public static final native void btGimPairArray_push_back(long var0, btGimPairArray var2, long var3, GIM_PAIR var5);

    public static final native int btGimPairArray_capacity(long var0, btGimPairArray var2);

    public static final native void btGimPairArray_reserve(long var0, btGimPairArray var2, int var3);

    public static final native long new_btGimPairArray_less();

    public static final native void delete_btGimPairArray_less(long var0);

    public static final native void btGimPairArray_swap(long var0, btGimPairArray var2, int var3, int var4);

    public static final native void btGimPairArray_removeAtIndex(long var0, btGimPairArray var2, int var3);

    public static final native void btGimPairArray_initializeFromBuffer(long var0, btGimPairArray var2, long var3, int var5, int var6);

    public static final native void btGimPairArray_copyFromArray(long var0, btGimPairArray var2, long var3, btGimPairArray var5);

    public static final native long btGimBvhDataArray_operatorAssignment(long var0, btGimBvhDataArray var2, long var3, btGimBvhDataArray var5);

    public static final native long new_btGimBvhDataArray__SWIG_0();

    public static final native void delete_btGimBvhDataArray(long var0);

    public static final native long new_btGimBvhDataArray__SWIG_1(long var0, btGimBvhDataArray var2);

    public static final native int btGimBvhDataArray_size(long var0, btGimBvhDataArray var2);

    public static final native long btGimBvhDataArray_atConst(long var0, btGimBvhDataArray var2, int var3);

    public static final native long btGimBvhDataArray_at(long var0, btGimBvhDataArray var2, int var3);

    public static final native long btGimBvhDataArray_operatorSubscriptConst(long var0, btGimBvhDataArray var2, int var3);

    public static final native long btGimBvhDataArray_operatorSubscript(long var0, btGimBvhDataArray var2, int var3);

    public static final native void btGimBvhDataArray_clear(long var0, btGimBvhDataArray var2);

    public static final native void btGimBvhDataArray_pop_back(long var0, btGimBvhDataArray var2);

    public static final native void btGimBvhDataArray_resizeNoInitialize(long var0, btGimBvhDataArray var2, int var3);

    public static final native void btGimBvhDataArray_resize__SWIG_0(long var0, btGimBvhDataArray var2, int var3, long var4, GIM_BVH_DATA var6);

    public static final native void btGimBvhDataArray_resize__SWIG_1(long var0, btGimBvhDataArray var2, int var3);

    public static final native long btGimBvhDataArray_expandNonInitializing(long var0, btGimBvhDataArray var2);

    public static final native long btGimBvhDataArray_expand__SWIG_0(long var0, btGimBvhDataArray var2, long var3, GIM_BVH_DATA var5);

    public static final native long btGimBvhDataArray_expand__SWIG_1(long var0, btGimBvhDataArray var2);

    public static final native void btGimBvhDataArray_push_back(long var0, btGimBvhDataArray var2, long var3, GIM_BVH_DATA var5);

    public static final native int btGimBvhDataArray_capacity(long var0, btGimBvhDataArray var2);

    public static final native void btGimBvhDataArray_reserve(long var0, btGimBvhDataArray var2, int var3);

    public static final native long new_btGimBvhDataArray_less();

    public static final native void delete_btGimBvhDataArray_less(long var0);

    public static final native void btGimBvhDataArray_swap(long var0, btGimBvhDataArray var2, int var3, int var4);

    public static final native void btGimBvhDataArray_removeAtIndex(long var0, btGimBvhDataArray var2, int var3);

    public static final native void btGimBvhDataArray_initializeFromBuffer(long var0, btGimBvhDataArray var2, long var3, int var5, int var6);

    public static final native void btGimBvhDataArray_copyFromArray(long var0, btGimBvhDataArray var2, long var3, btGimBvhDataArray var5);

    public static final native long btGimBvhTreeNodeArray_operatorAssignment(long var0, btGimBvhTreeNodeArray var2, long var3, btGimBvhTreeNodeArray var5);

    public static final native long new_btGimBvhTreeNodeArray__SWIG_0();

    public static final native void delete_btGimBvhTreeNodeArray(long var0);

    public static final native long new_btGimBvhTreeNodeArray__SWIG_1(long var0, btGimBvhTreeNodeArray var2);

    public static final native int btGimBvhTreeNodeArray_size(long var0, btGimBvhTreeNodeArray var2);

    public static final native long btGimBvhTreeNodeArray_atConst(long var0, btGimBvhTreeNodeArray var2, int var3);

    public static final native long btGimBvhTreeNodeArray_at(long var0, btGimBvhTreeNodeArray var2, int var3);

    public static final native long btGimBvhTreeNodeArray_operatorSubscriptConst(long var0, btGimBvhTreeNodeArray var2, int var3);

    public static final native long btGimBvhTreeNodeArray_operatorSubscript(long var0, btGimBvhTreeNodeArray var2, int var3);

    public static final native void btGimBvhTreeNodeArray_clear(long var0, btGimBvhTreeNodeArray var2);

    public static final native void btGimBvhTreeNodeArray_pop_back(long var0, btGimBvhTreeNodeArray var2);

    public static final native void btGimBvhTreeNodeArray_resizeNoInitialize(long var0, btGimBvhTreeNodeArray var2, int var3);

    public static final native void btGimBvhTreeNodeArray_resize__SWIG_0(long var0, btGimBvhTreeNodeArray var2, int var3, long var4, GIM_BVH_TREE_NODE var6);

    public static final native void btGimBvhTreeNodeArray_resize__SWIG_1(long var0, btGimBvhTreeNodeArray var2, int var3);

    public static final native long btGimBvhTreeNodeArray_expandNonInitializing(long var0, btGimBvhTreeNodeArray var2);

    public static final native long btGimBvhTreeNodeArray_expand__SWIG_0(long var0, btGimBvhTreeNodeArray var2, long var3, GIM_BVH_TREE_NODE var5);

    public static final native long btGimBvhTreeNodeArray_expand__SWIG_1(long var0, btGimBvhTreeNodeArray var2);

    public static final native void btGimBvhTreeNodeArray_push_back(long var0, btGimBvhTreeNodeArray var2, long var3, GIM_BVH_TREE_NODE var5);

    public static final native int btGimBvhTreeNodeArray_capacity(long var0, btGimBvhTreeNodeArray var2);

    public static final native void btGimBvhTreeNodeArray_reserve(long var0, btGimBvhTreeNodeArray var2, int var3);

    public static final native long new_btGimBvhTreeNodeArray_less();

    public static final native void delete_btGimBvhTreeNodeArray_less(long var0);

    public static final native void btGimBvhTreeNodeArray_swap(long var0, btGimBvhTreeNodeArray var2, int var3, int var4);

    public static final native void btGimBvhTreeNodeArray_removeAtIndex(long var0, btGimBvhTreeNodeArray var2, int var3);

    public static final native void btGimBvhTreeNodeArray_initializeFromBuffer(long var0, btGimBvhTreeNodeArray var2, long var3, int var5, int var6);

    public static final native void btGimBvhTreeNodeArray_copyFromArray(long var0, btGimBvhTreeNodeArray var2, long var3, btGimBvhTreeNodeArray var5);

    public static final native long new_btPairSet();

    public static final native void btPairSet_push_pair(long var0, btPairSet var2, int var3, int var4);

    public static final native void btPairSet_push_pair_inv(long var0, btPairSet var2, int var3, int var4);

    public static final native void delete_btPairSet(long var0);

    public static final native long new_GIM_BVH_DATA_ARRAY();

    public static final native void delete_GIM_BVH_DATA_ARRAY(long var0);

    public static final native long new_GIM_BVH_TREE_NODE_ARRAY();

    public static final native void delete_GIM_BVH_TREE_NODE_ARRAY(long var0);

    public static final native long new_btBvhTree();

    public static final native void btBvhTree_build_tree(long var0, btBvhTree var2, long var3, GIM_BVH_DATA_ARRAY var5);

    public static final native void btBvhTree_clearNodes(long var0, btBvhTree var2);

    public static final native int btBvhTree_getNodeCount(long var0, btBvhTree var2);

    public static final native boolean btBvhTree_isLeafNode(long var0, btBvhTree var2, int var3);

    public static final native int btBvhTree_getNodeData(long var0, btBvhTree var2, int var3);

    public static final native void btBvhTree_getNodeBound(long var0, btBvhTree var2, int var3, long var4, btAABB var6);

    public static final native void btBvhTree_setNodeBound(long var0, btBvhTree var2, int var3, long var4, btAABB var6);

    public static final native int btBvhTree_getLeftNode(long var0, btBvhTree var2, int var3);

    public static final native int btBvhTree_getRightNode(long var0, btBvhTree var2, int var3);

    public static final native int btBvhTree_getEscapeNodeIndex(long var0, btBvhTree var2, int var3);

    public static final native long btBvhTree_get_node_pointer__SWIG_0(long var0, btBvhTree var2, int var3);

    public static final native long btBvhTree_get_node_pointer__SWIG_1(long var0, btBvhTree var2);

    public static final native void delete_btBvhTree(long var0);

    public static final native void delete_btPrimitiveManagerBase(long var0);

    public static final native boolean btPrimitiveManagerBase_is_trimesh(long var0, btPrimitiveManagerBase var2);

    public static final native int btPrimitiveManagerBase_get_primitive_count(long var0, btPrimitiveManagerBase var2);

    public static final native void btPrimitiveManagerBase_get_primitive_box(long var0, btPrimitiveManagerBase var2, int var3, long var4, btAABB var6);

    public static final native void btPrimitiveManagerBase_get_primitive_triangle(long var0, btPrimitiveManagerBase var2, int var3, long var4, btPrimitiveTriangle var6);

    public static final native long new_btGImpactBvh__SWIG_0();

    public static final native long new_btGImpactBvh__SWIG_1(long var0, btPrimitiveManagerBase var2);

    public static final native long btGImpactBvh_getGlobalBox(long var0, btGImpactBvh var2);

    public static final native void btGImpactBvh_setPrimitiveManager(long var0, btGImpactBvh var2, long var3, btPrimitiveManagerBase var5);

    public static final native long btGImpactBvh_getPrimitiveManager(long var0, btGImpactBvh var2);

    public static final native void btGImpactBvh_update(long var0, btGImpactBvh var2);

    public static final native void btGImpactBvh_buildSet(long var0, btGImpactBvh var2);

    public static final native boolean btGImpactBvh_boxQuery(long var0, btGImpactBvh var2, long var3, btAABB var5, long var6);

    public static final native boolean btGImpactBvh_boxQueryTrans(long var0, btGImpactBvh var2, long var3, btAABB var5, Matrix4 var6, long var7);

    public static final native boolean btGImpactBvh_rayQuery(long var0, btGImpactBvh var2, Vector3 var3, Vector3 var4, long var5);

    public static final native boolean btGImpactBvh_hasHierarchy(long var0, btGImpactBvh var2);

    public static final native boolean btGImpactBvh_isTrimesh(long var0, btGImpactBvh var2);

    public static final native int btGImpactBvh_getNodeCount(long var0, btGImpactBvh var2);

    public static final native boolean btGImpactBvh_isLeafNode(long var0, btGImpactBvh var2, int var3);

    public static final native int btGImpactBvh_getNodeData(long var0, btGImpactBvh var2, int var3);

    public static final native void btGImpactBvh_getNodeBound(long var0, btGImpactBvh var2, int var3, long var4, btAABB var6);

    public static final native void btGImpactBvh_setNodeBound(long var0, btGImpactBvh var2, int var3, long var4, btAABB var6);

    public static final native int btGImpactBvh_getLeftNode(long var0, btGImpactBvh var2, int var3);

    public static final native int btGImpactBvh_getRightNode(long var0, btGImpactBvh var2, int var3);

    public static final native int btGImpactBvh_getEscapeNodeIndex(long var0, btGImpactBvh var2, int var3);

    public static final native void btGImpactBvh_getNodeTriangle(long var0, btGImpactBvh var2, int var3, long var4, btPrimitiveTriangle var6);

    public static final native long btGImpactBvh_get_node_pointer__SWIG_0(long var0, btGImpactBvh var2, int var3);

    public static final native long btGImpactBvh_get_node_pointer__SWIG_1(long var0, btGImpactBvh var2);

    public static final native void btGImpactBvh_find_collision(long var0, btGImpactBvh var2, Matrix4 var3, long var4, btGImpactBvh var6, Matrix4 var7, long var8, btPairSet var10);

    public static final native void delete_btGImpactBvh(long var0);

    public static final native void BT_QUANTIZED_BVH_NODE_quantizedAabbMin_set(long var0, BT_QUANTIZED_BVH_NODE var2, int[] var3);

    public static final native int[] BT_QUANTIZED_BVH_NODE_quantizedAabbMin_get(long var0, BT_QUANTIZED_BVH_NODE var2);

    public static final native void BT_QUANTIZED_BVH_NODE_quantizedAabbMax_set(long var0, BT_QUANTIZED_BVH_NODE var2, int[] var3);

    public static final native int[] BT_QUANTIZED_BVH_NODE_quantizedAabbMax_get(long var0, BT_QUANTIZED_BVH_NODE var2);

    public static final native void BT_QUANTIZED_BVH_NODE_escapeIndexOrDataIndex_set(long var0, BT_QUANTIZED_BVH_NODE var2, int var3);

    public static final native int BT_QUANTIZED_BVH_NODE_escapeIndexOrDataIndex_get(long var0, BT_QUANTIZED_BVH_NODE var2);

    public static final native long new_BT_QUANTIZED_BVH_NODE();

    public static final native boolean BT_QUANTIZED_BVH_NODE_isLeafNode(long var0, BT_QUANTIZED_BVH_NODE var2);

    public static final native int BT_QUANTIZED_BVH_NODE_getEscapeIndex(long var0, BT_QUANTIZED_BVH_NODE var2);

    public static final native void BT_QUANTIZED_BVH_NODE_setEscapeIndex(long var0, BT_QUANTIZED_BVH_NODE var2, int var3);

    public static final native int BT_QUANTIZED_BVH_NODE_getDataIndex(long var0, BT_QUANTIZED_BVH_NODE var2);

    public static final native void BT_QUANTIZED_BVH_NODE_setDataIndex(long var0, BT_QUANTIZED_BVH_NODE var2, int var3);

    public static final native boolean BT_QUANTIZED_BVH_NODE_testQuantizedBoxOverlapp(long var0, BT_QUANTIZED_BVH_NODE var2, IntBuffer var3, IntBuffer var4);

    public static final native void delete_BT_QUANTIZED_BVH_NODE(long var0);

    public static final native long btGimQuantizedBvhNodeArray_operatorAssignment(long var0, btGimQuantizedBvhNodeArray var2, long var3, btGimQuantizedBvhNodeArray var5);

    public static final native long new_btGimQuantizedBvhNodeArray__SWIG_0();

    public static final native void delete_btGimQuantizedBvhNodeArray(long var0);

    public static final native long new_btGimQuantizedBvhNodeArray__SWIG_1(long var0, btGimQuantizedBvhNodeArray var2);

    public static final native int btGimQuantizedBvhNodeArray_size(long var0, btGimQuantizedBvhNodeArray var2);

    public static final native long btGimQuantizedBvhNodeArray_atConst(long var0, btGimQuantizedBvhNodeArray var2, int var3);

    public static final native long btGimQuantizedBvhNodeArray_at(long var0, btGimQuantizedBvhNodeArray var2, int var3);

    public static final native long btGimQuantizedBvhNodeArray_operatorSubscriptConst(long var0, btGimQuantizedBvhNodeArray var2, int var3);

    public static final native long btGimQuantizedBvhNodeArray_operatorSubscript(long var0, btGimQuantizedBvhNodeArray var2, int var3);

    public static final native void btGimQuantizedBvhNodeArray_clear(long var0, btGimQuantizedBvhNodeArray var2);

    public static final native void btGimQuantizedBvhNodeArray_pop_back(long var0, btGimQuantizedBvhNodeArray var2);

    public static final native void btGimQuantizedBvhNodeArray_resizeNoInitialize(long var0, btGimQuantizedBvhNodeArray var2, int var3);

    public static final native void btGimQuantizedBvhNodeArray_resize__SWIG_0(long var0, btGimQuantizedBvhNodeArray var2, int var3, long var4, BT_QUANTIZED_BVH_NODE var6);

    public static final native void btGimQuantizedBvhNodeArray_resize__SWIG_1(long var0, btGimQuantizedBvhNodeArray var2, int var3);

    public static final native long btGimQuantizedBvhNodeArray_expandNonInitializing(long var0, btGimQuantizedBvhNodeArray var2);

    public static final native long btGimQuantizedBvhNodeArray_expand__SWIG_0(long var0, btGimQuantizedBvhNodeArray var2, long var3, BT_QUANTIZED_BVH_NODE var5);

    public static final native long btGimQuantizedBvhNodeArray_expand__SWIG_1(long var0, btGimQuantizedBvhNodeArray var2);

    public static final native void btGimQuantizedBvhNodeArray_push_back(long var0, btGimQuantizedBvhNodeArray var2, long var3, BT_QUANTIZED_BVH_NODE var5);

    public static final native int btGimQuantizedBvhNodeArray_capacity(long var0, btGimQuantizedBvhNodeArray var2);

    public static final native void btGimQuantizedBvhNodeArray_reserve(long var0, btGimQuantizedBvhNodeArray var2, int var3);

    public static final native long new_btGimQuantizedBvhNodeArray_less();

    public static final native void delete_btGimQuantizedBvhNodeArray_less(long var0);

    public static final native void btGimQuantizedBvhNodeArray_swap(long var0, btGimQuantizedBvhNodeArray var2, int var3, int var4);

    public static final native void btGimQuantizedBvhNodeArray_removeAtIndex(long var0, btGimQuantizedBvhNodeArray var2, int var3);

    public static final native void btGimQuantizedBvhNodeArray_initializeFromBuffer(long var0, btGimQuantizedBvhNodeArray var2, long var3, int var5, int var6);

    public static final native void btGimQuantizedBvhNodeArray_copyFromArray(long var0, btGimQuantizedBvhNodeArray var2, long var3, btGimQuantizedBvhNodeArray var5);

    public static final native long new_GIM_QUANTIZED_BVH_NODE_ARRAY();

    public static final native void delete_GIM_QUANTIZED_BVH_NODE_ARRAY(long var0);

    public static final native long new_btQuantizedBvhTree();

    public static final native void btQuantizedBvhTree_build_tree(long var0, btQuantizedBvhTree var2, long var3, GIM_BVH_DATA_ARRAY var5);

    public static final native void btQuantizedBvhTree_quantizePoint(long var0, btQuantizedBvhTree var2, IntBuffer var3, Vector3 var4);

    public static final native boolean btQuantizedBvhTree_testQuantizedBoxOverlapp(long var0, btQuantizedBvhTree var2, int var3, IntBuffer var4, IntBuffer var5);

    public static final native void btQuantizedBvhTree_clearNodes(long var0, btQuantizedBvhTree var2);

    public static final native int btQuantizedBvhTree_getNodeCount(long var0, btQuantizedBvhTree var2);

    public static final native boolean btQuantizedBvhTree_isLeafNode(long var0, btQuantizedBvhTree var2, int var3);

    public static final native int btQuantizedBvhTree_getNodeData(long var0, btQuantizedBvhTree var2, int var3);

    public static final native void btQuantizedBvhTree_getNodeBound(long var0, btQuantizedBvhTree var2, int var3, long var4, btAABB var6);

    public static final native void btQuantizedBvhTree_setNodeBound(long var0, btQuantizedBvhTree var2, int var3, long var4, btAABB var6);

    public static final native int btQuantizedBvhTree_getLeftNode(long var0, btQuantizedBvhTree var2, int var3);

    public static final native int btQuantizedBvhTree_getRightNode(long var0, btQuantizedBvhTree var2, int var3);

    public static final native int btQuantizedBvhTree_getEscapeNodeIndex(long var0, btQuantizedBvhTree var2, int var3);

    public static final native long btQuantizedBvhTree_get_node_pointer__SWIG_0(long var0, btQuantizedBvhTree var2, int var3);

    public static final native long btQuantizedBvhTree_get_node_pointer__SWIG_1(long var0, btQuantizedBvhTree var2);

    public static final native void delete_btQuantizedBvhTree(long var0);

    public static final native long new_btGImpactQuantizedBvh__SWIG_0();

    public static final native long new_btGImpactQuantizedBvh__SWIG_1(long var0, btPrimitiveManagerBase var2);

    public static final native long btGImpactQuantizedBvh_getGlobalBox(long var0, btGImpactQuantizedBvh var2);

    public static final native void btGImpactQuantizedBvh_setPrimitiveManager(long var0, btGImpactQuantizedBvh var2, long var3, btPrimitiveManagerBase var5);

    public static final native long btGImpactQuantizedBvh_getPrimitiveManager(long var0, btGImpactQuantizedBvh var2);

    public static final native void btGImpactQuantizedBvh_update(long var0, btGImpactQuantizedBvh var2);

    public static final native void btGImpactQuantizedBvh_buildSet(long var0, btGImpactQuantizedBvh var2);

    public static final native boolean btGImpactQuantizedBvh_boxQuery(long var0, btGImpactQuantizedBvh var2, long var3, btAABB var5, long var6);

    public static final native boolean btGImpactQuantizedBvh_boxQueryTrans(long var0, btGImpactQuantizedBvh var2, long var3, btAABB var5, Matrix4 var6, long var7);

    public static final native boolean btGImpactQuantizedBvh_rayQuery(long var0, btGImpactQuantizedBvh var2, Vector3 var3, Vector3 var4, long var5);

    public static final native boolean btGImpactQuantizedBvh_hasHierarchy(long var0, btGImpactQuantizedBvh var2);

    public static final native boolean btGImpactQuantizedBvh_isTrimesh(long var0, btGImpactQuantizedBvh var2);

    public static final native int btGImpactQuantizedBvh_getNodeCount(long var0, btGImpactQuantizedBvh var2);

    public static final native boolean btGImpactQuantizedBvh_isLeafNode(long var0, btGImpactQuantizedBvh var2, int var3);

    public static final native int btGImpactQuantizedBvh_getNodeData(long var0, btGImpactQuantizedBvh var2, int var3);

    public static final native void btGImpactQuantizedBvh_getNodeBound(long var0, btGImpactQuantizedBvh var2, int var3, long var4, btAABB var6);

    public static final native void btGImpactQuantizedBvh_setNodeBound(long var0, btGImpactQuantizedBvh var2, int var3, long var4, btAABB var6);

    public static final native int btGImpactQuantizedBvh_getLeftNode(long var0, btGImpactQuantizedBvh var2, int var3);

    public static final native int btGImpactQuantizedBvh_getRightNode(long var0, btGImpactQuantizedBvh var2, int var3);

    public static final native int btGImpactQuantizedBvh_getEscapeNodeIndex(long var0, btGImpactQuantizedBvh var2, int var3);

    public static final native void btGImpactQuantizedBvh_getNodeTriangle(long var0, btGImpactQuantizedBvh var2, int var3, long var4, btPrimitiveTriangle var6);

    public static final native long btGImpactQuantizedBvh_get_node_pointer__SWIG_0(long var0, btGImpactQuantizedBvh var2, int var3);

    public static final native long btGImpactQuantizedBvh_get_node_pointer__SWIG_1(long var0, btGImpactQuantizedBvh var2);

    public static final native void btGImpactQuantizedBvh_find_collision(long var0, btGImpactQuantizedBvh var2, Matrix4 var3, long var4, btGImpactQuantizedBvh var6, Matrix4 var7, long var8, btPairSet var10);

    public static final native void delete_btGImpactQuantizedBvh(long var0);

    public static final native long new_btTetrahedronShapeEx();

    public static final native void btTetrahedronShapeEx_setVertices(long var0, btTetrahedronShapeEx var2, Vector3 var3, Vector3 var4, Vector3 var5, Vector3 var6);

    public static final native void delete_btTetrahedronShapeEx(long var0);

    public static final native void btGImpactShapeInterface_updateBound(long var0, btGImpactShapeInterface var2);

    public static final native void btGImpactShapeInterface_postUpdate(long var0, btGImpactShapeInterface var2);

    public static final native long btGImpactShapeInterface_getLocalBox(long var0, btGImpactShapeInterface var2);

    public static final native int btGImpactShapeInterface_getShapeType(long var0, btGImpactShapeInterface var2);

    public static final native int btGImpactShapeInterface_getGImpactShapeType(long var0, btGImpactShapeInterface var2);

    public static final native long btGImpactShapeInterface_getBoxSet(long var0, btGImpactShapeInterface var2);

    public static final native boolean btGImpactShapeInterface_hasBoxSet(long var0, btGImpactShapeInterface var2);

    public static final native long btGImpactShapeInterface_getPrimitiveManager(long var0, btGImpactShapeInterface var2);

    public static final native int btGImpactShapeInterface_getNumChildShapes(long var0, btGImpactShapeInterface var2);

    public static final native boolean btGImpactShapeInterface_childrenHasTransform(long var0, btGImpactShapeInterface var2);

    public static final native boolean btGImpactShapeInterface_needsRetrieveTriangles(long var0, btGImpactShapeInterface var2);

    public static final native boolean btGImpactShapeInterface_needsRetrieveTetrahedrons(long var0, btGImpactShapeInterface var2);

    public static final native void btGImpactShapeInterface_getBulletTriangle(long var0, btGImpactShapeInterface var2, int var3, long var4, btTriangleShapeEx var6);

    public static final native void btGImpactShapeInterface_getBulletTetrahedron(long var0, btGImpactShapeInterface var2, int var3, long var4, btTetrahedronShapeEx var6);

    public static final native void btGImpactShapeInterface_lockChildShapes(long var0, btGImpactShapeInterface var2);

    public static final native void btGImpactShapeInterface_unlockChildShapes(long var0, btGImpactShapeInterface var2);

    public static final native void btGImpactShapeInterface_getPrimitiveTriangle(long var0, btGImpactShapeInterface var2, int var3, long var4, btPrimitiveTriangle var6);

    public static final native void btGImpactShapeInterface_getChildAabb(long var0, btGImpactShapeInterface var2, int var3, Matrix4 var4, Vector3 var5, Vector3 var6);

    public static final native long btGImpactShapeInterface_getChildShape(long var0, btGImpactShapeInterface var2, int var3);

    public static final native long btGImpactShapeInterface_getChildShapeConst(long var0, btGImpactShapeInterface var2, int var3);

    public static final native Matrix4 btGImpactShapeInterface_getChildTransform(long var0, btGImpactShapeInterface var2, int var3);

    public static final native void btGImpactShapeInterface_setChildTransform(long var0, btGImpactShapeInterface var2, int var3, Matrix4 var4);

    public static final native void btGImpactShapeInterface_rayTest(long var0, btGImpactShapeInterface var2, Vector3 var3, Vector3 var4, long var5, RayResultCallback var7);

    public static final native void btGImpactShapeInterface_processAllTrianglesRay(long var0, btGImpactShapeInterface var2, long var3, btTriangleCallback var5, Vector3 var6, Vector3 var7);

    public static final native void delete_btGImpactShapeInterface(long var0);

    public static final native void delete_btGImpactCompoundShape_CompoundPrimitiveManager(long var0);

    public static final native void btGImpactCompoundShape_CompoundPrimitiveManager_compoundShape_set(long var0, btGImpactCompoundShape.CompoundPrimitiveManager var2, long var3, btGImpactCompoundShape var5);

    public static final native long btGImpactCompoundShape_CompoundPrimitiveManager_compoundShape_get(long var0, btGImpactCompoundShape.CompoundPrimitiveManager var2);

    public static final native long new_btGImpactCompoundShape_CompoundPrimitiveManager__SWIG_0(long var0, btGImpactCompoundShape.CompoundPrimitiveManager var2);

    public static final native long new_btGImpactCompoundShape_CompoundPrimitiveManager__SWIG_1(long var0, btGImpactCompoundShape var2);

    public static final native long new_btGImpactCompoundShape_CompoundPrimitiveManager__SWIG_2();

    public static final native long new_btGImpactCompoundShape__SWIG_0(boolean var0);

    public static final native long new_btGImpactCompoundShape__SWIG_1();

    public static final native void delete_btGImpactCompoundShape(long var0);

    public static final native long btGImpactCompoundShape_getCompoundPrimitiveManager(long var0, btGImpactCompoundShape var2);

    public static final native void btGImpactCompoundShape_addChildShape__SWIG_0(long var0, btGImpactCompoundShape var2, Matrix4 var3, long var4, btCollisionShape var6);

    public static final native void btGImpactCompoundShape_addChildShape__SWIG_1(long var0, btGImpactCompoundShape var2, long var3, btCollisionShape var5);

    public static final native void btGImpactMeshShapePart_TrimeshPrimitiveManager_margin_set(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2, float var3);

    public static final native float btGImpactMeshShapePart_TrimeshPrimitiveManager_margin_get(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2);

    public static final native void btGImpactMeshShapePart_TrimeshPrimitiveManager_meshInterface_set(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2, long var3, btStridingMeshInterface var5);

    public static final native long btGImpactMeshShapePart_TrimeshPrimitiveManager_meshInterface_get(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2);

    public static final native void btGImpactMeshShapePart_TrimeshPrimitiveManager_scale_set(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2, long var3, btVector3 var5);

    public static final native long btGImpactMeshShapePart_TrimeshPrimitiveManager_scale_get(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2);

    public static final native void btGImpactMeshShapePart_TrimeshPrimitiveManager_part_set(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2, int var3);

    public static final native int btGImpactMeshShapePart_TrimeshPrimitiveManager_part_get(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2);

    public static final native void btGImpactMeshShapePart_TrimeshPrimitiveManager_lock_count_set(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2, int var3);

    public static final native int btGImpactMeshShapePart_TrimeshPrimitiveManager_lock_count_get(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2);

    public static final native void btGImpactMeshShapePart_TrimeshPrimitiveManager_vertexbase_set(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2, ByteBuffer var3);

    public static final native ByteBuffer btGImpactMeshShapePart_TrimeshPrimitiveManager_vertexbase_get(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2);

    public static final native void btGImpactMeshShapePart_TrimeshPrimitiveManager_numverts_set(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2, int var3);

    public static final native int btGImpactMeshShapePart_TrimeshPrimitiveManager_numverts_get(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2);

    public static final native void btGImpactMeshShapePart_TrimeshPrimitiveManager_type_set(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2, int var3);

    public static final native int btGImpactMeshShapePart_TrimeshPrimitiveManager_type_get(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2);

    public static final native void btGImpactMeshShapePart_TrimeshPrimitiveManager_stride_set(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2, int var3);

    public static final native int btGImpactMeshShapePart_TrimeshPrimitiveManager_stride_get(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2);

    public static final native void btGImpactMeshShapePart_TrimeshPrimitiveManager_indexbase_set(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2, ByteBuffer var3);

    public static final native ByteBuffer btGImpactMeshShapePart_TrimeshPrimitiveManager_indexbase_get(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2);

    public static final native void btGImpactMeshShapePart_TrimeshPrimitiveManager_indexstride_set(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2, int var3);

    public static final native int btGImpactMeshShapePart_TrimeshPrimitiveManager_indexstride_get(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2);

    public static final native void btGImpactMeshShapePart_TrimeshPrimitiveManager_numfaces_set(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2, int var3);

    public static final native int btGImpactMeshShapePart_TrimeshPrimitiveManager_numfaces_get(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2);

    public static final native void btGImpactMeshShapePart_TrimeshPrimitiveManager_indicestype_set(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2, int var3);

    public static final native int btGImpactMeshShapePart_TrimeshPrimitiveManager_indicestype_get(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2);

    public static final native long new_btGImpactMeshShapePart_TrimeshPrimitiveManager__SWIG_0();

    public static final native long new_btGImpactMeshShapePart_TrimeshPrimitiveManager__SWIG_1(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2);

    public static final native long new_btGImpactMeshShapePart_TrimeshPrimitiveManager__SWIG_2(long var0, btStridingMeshInterface var2, int var3);

    public static final native void delete_btGImpactMeshShapePart_TrimeshPrimitiveManager(long var0);

    public static final native void btGImpactMeshShapePart_TrimeshPrimitiveManager_lock(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2);

    public static final native void btGImpactMeshShapePart_TrimeshPrimitiveManager_unlock(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2);

    public static final native int btGImpactMeshShapePart_TrimeshPrimitiveManager_get_vertex_count(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2);

    public static final native void btGImpactMeshShapePart_TrimeshPrimitiveManager_get_indices(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2, int var3, long var4, long var6, long var8);

    public static final native void btGImpactMeshShapePart_TrimeshPrimitiveManager_get_vertex(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2, long var3, Vector3 var5);

    public static final native void btGImpactMeshShapePart_TrimeshPrimitiveManager_get_bullet_triangle(long var0, btGImpactMeshShapePart.TrimeshPrimitiveManager var2, int var3, long var4, btTriangleShapeEx var6);

    public static final native long new_btGImpactMeshShapePart__SWIG_0();

    public static final native long new_btGImpactMeshShapePart__SWIG_1(long var0, btStridingMeshInterface var2, int var3);

    public static final native void delete_btGImpactMeshShapePart(long var0);

    public static final native long btGImpactMeshShapePart_getTrimeshPrimitiveManager(long var0, btGImpactMeshShapePart var2);

    public static final native int btGImpactMeshShapePart_getVertexCount(long var0, btGImpactMeshShapePart var2);

    public static final native void btGImpactMeshShapePart_getVertex(long var0, btGImpactMeshShapePart var2, int var3, Vector3 var4);

    public static final native int btGImpactMeshShapePart_getPart(long var0, btGImpactMeshShapePart var2);

    public static final native long new_btGImpactMeshShape(long var0, btStridingMeshInterface var2);

    public static final native void delete_btGImpactMeshShape(long var0);

    public static final native long btGImpactMeshShape_getMeshInterface(long var0, btGImpactMeshShape var2);

    public static final native long btGImpactMeshShape_getMeshInterfaceConst(long var0, btGImpactMeshShape var2);

    public static final native int btGImpactMeshShape_getMeshPartCount(long var0, btGImpactMeshShape var2);

    public static final native long btGImpactMeshShape_getMeshPart(long var0, btGImpactMeshShape var2, int var3);

    public static final native long btGImpactMeshShape_getMeshPartConst(long var0, btGImpactMeshShape var2, int var3);

    public static final native void btGImpactMeshShapeData_collisionShapeData_set(long var0, btGImpactMeshShapeData var2, long var3, btCollisionShapeData var5);

    public static final native long btGImpactMeshShapeData_collisionShapeData_get(long var0, btGImpactMeshShapeData var2);

    public static final native void btGImpactMeshShapeData_meshInterface_set(long var0, btGImpactMeshShapeData var2, long var3, btStridingMeshInterfaceData var5);

    public static final native long btGImpactMeshShapeData_meshInterface_get(long var0, btGImpactMeshShapeData var2);

    public static final native void btGImpactMeshShapeData_localScaling_set(long var0, btGImpactMeshShapeData var2, long var3, btVector3FloatData var5);

    public static final native long btGImpactMeshShapeData_localScaling_get(long var0, btGImpactMeshShapeData var2);

    public static final native void btGImpactMeshShapeData_collisionMargin_set(long var0, btGImpactMeshShapeData var2, float var3);

    public static final native float btGImpactMeshShapeData_collisionMargin_get(long var0, btGImpactMeshShapeData var2);

    public static final native void btGImpactMeshShapeData_gimpactSubType_set(long var0, btGImpactMeshShapeData var2, int var3);

    public static final native int btGImpactMeshShapeData_gimpactSubType_get(long var0, btGImpactMeshShapeData var2);

    public static final native long new_btGImpactMeshShapeData();

    public static final native void delete_btGImpactMeshShapeData(long var0);

    public static final native void GIM_CONTACT_point_set(long var0, GIM_CONTACT var2, long var3, btVector3 var5);

    public static final native long GIM_CONTACT_point_get(long var0, GIM_CONTACT var2);

    public static final native void GIM_CONTACT_normal_set(long var0, GIM_CONTACT var2, long var3, btVector3 var5);

    public static final native long GIM_CONTACT_normal_get(long var0, GIM_CONTACT var2);

    public static final native void GIM_CONTACT_depth_set(long var0, GIM_CONTACT var2, float var3);

    public static final native float GIM_CONTACT_depth_get(long var0, GIM_CONTACT var2);

    public static final native void GIM_CONTACT_distance_set(long var0, GIM_CONTACT var2, float var3);

    public static final native float GIM_CONTACT_distance_get(long var0, GIM_CONTACT var2);

    public static final native void GIM_CONTACT_feature1_set(long var0, GIM_CONTACT var2, int var3);

    public static final native int GIM_CONTACT_feature1_get(long var0, GIM_CONTACT var2);

    public static final native void GIM_CONTACT_feature2_set(long var0, GIM_CONTACT var2, int var3);

    public static final native int GIM_CONTACT_feature2_get(long var0, GIM_CONTACT var2);

    public static final native long new_GIM_CONTACT__SWIG_0();

    public static final native long new_GIM_CONTACT__SWIG_1(long var0, GIM_CONTACT var2);

    public static final native long new_GIM_CONTACT__SWIG_2(Vector3 var0, Vector3 var1, float var2, int var3, int var4);

    public static final native long GIM_CONTACT_calc_key_contact(long var0, GIM_CONTACT var2);

    public static final native void GIM_CONTACT_interpolate_normals(long var0, GIM_CONTACT var2, long var3, btVector3 var5, int var6);

    public static final native void delete_GIM_CONTACT(long var0);

    public static final native long btGimContactArray_operatorAssignment(long var0, btGimContactArray var2, long var3, btGimContactArray var5);

    public static final native long new_btGimContactArray__SWIG_0();

    public static final native void delete_btGimContactArray(long var0);

    public static final native long new_btGimContactArray__SWIG_1(long var0, btGimContactArray var2);

    public static final native int btGimContactArray_size(long var0, btGimContactArray var2);

    public static final native long btGimContactArray_atConst(long var0, btGimContactArray var2, int var3);

    public static final native long btGimContactArray_at(long var0, btGimContactArray var2, int var3);

    public static final native long btGimContactArray_operatorSubscriptConst(long var0, btGimContactArray var2, int var3);

    public static final native long btGimContactArray_operatorSubscript(long var0, btGimContactArray var2, int var3);

    public static final native void btGimContactArray_clear(long var0, btGimContactArray var2);

    public static final native void btGimContactArray_pop_back(long var0, btGimContactArray var2);

    public static final native void btGimContactArray_resizeNoInitialize(long var0, btGimContactArray var2, int var3);

    public static final native void btGimContactArray_resize__SWIG_0(long var0, btGimContactArray var2, int var3, long var4, GIM_CONTACT var6);

    public static final native void btGimContactArray_resize__SWIG_1(long var0, btGimContactArray var2, int var3);

    public static final native long btGimContactArray_expandNonInitializing(long var0, btGimContactArray var2);

    public static final native long btGimContactArray_expand__SWIG_0(long var0, btGimContactArray var2, long var3, GIM_CONTACT var5);

    public static final native long btGimContactArray_expand__SWIG_1(long var0, btGimContactArray var2);

    public static final native void btGimContactArray_push_back(long var0, btGimContactArray var2, long var3, GIM_CONTACT var5);

    public static final native int btGimContactArray_capacity(long var0, btGimContactArray var2);

    public static final native void btGimContactArray_reserve(long var0, btGimContactArray var2, int var3);

    public static final native long new_btGimContactArray_less();

    public static final native void delete_btGimContactArray_less(long var0);

    public static final native void btGimContactArray_swap(long var0, btGimContactArray var2, int var3, int var4);

    public static final native void btGimContactArray_removeAtIndex(long var0, btGimContactArray var2, int var3);

    public static final native void btGimContactArray_initializeFromBuffer(long var0, btGimContactArray var2, long var3, int var5, int var6);

    public static final native void btGimContactArray_copyFromArray(long var0, btGimContactArray var2, long var3, btGimContactArray var5);

    public static final native long new_btContactArray();

    public static final native void btContactArray_push_contact(long var0, btContactArray var2, Vector3 var3, Vector3 var4, float var5, int var6, int var7);

    public static final native void btContactArray_push_triangle_contacts(long var0, btContactArray var2, long var3, GIM_TRIANGLE_CONTACT var5, int var6, int var7);

    public static final native void btContactArray_merge_contacts__SWIG_0(long var0, btContactArray var2, long var3, btContactArray var5, boolean var6);

    public static final native void btContactArray_merge_contacts__SWIG_1(long var0, btContactArray var2, long var3, btContactArray var5);

    public static final native void btContactArray_merge_contacts_unique(long var0, btContactArray var2, long var3, btContactArray var5);

    public static final native void delete_btContactArray(long var0);

    public static final native long btCompoundFromGimpactShape_operatorNew__SWIG_0(long var0, btCompoundFromGimpactShape var2, long var3);

    public static final native void btCompoundFromGimpactShape_operatorDelete__SWIG_0(long var0, btCompoundFromGimpactShape var2, long var3);

    public static final native long btCompoundFromGimpactShape_operatorNew__SWIG_1(long var0, btCompoundFromGimpactShape var2, long var3, long var5);

    public static final native void btCompoundFromGimpactShape_operatorDelete__SWIG_1(long var0, btCompoundFromGimpactShape var2, long var3, long var5);

    public static final native long btCompoundFromGimpactShape_operatorNewArray__SWIG_0(long var0, btCompoundFromGimpactShape var2, long var3);

    public static final native void btCompoundFromGimpactShape_operatorDeleteArray__SWIG_0(long var0, btCompoundFromGimpactShape var2, long var3);

    public static final native long btCompoundFromGimpactShape_operatorNewArray__SWIG_1(long var0, btCompoundFromGimpactShape var2, long var3, long var5);

    public static final native void btCompoundFromGimpactShape_operatorDeleteArray__SWIG_1(long var0, btCompoundFromGimpactShape var2, long var3, long var5);

    public static final native void delete_btCompoundFromGimpactShape(long var0);

    public static final native long new_btCompoundFromGimpactShape();

    public static final native void MyCallback_ignorePart_set(long var0, MyCallback var2, int var3);

    public static final native int MyCallback_ignorePart_get(long var0, MyCallback var2);

    public static final native void MyCallback_ignoreTriangleIndex_set(long var0, MyCallback var2, int var3);

    public static final native int MyCallback_ignoreTriangleIndex_get(long var0, MyCallback var2);

    public static final native long new_MyCallback(Vector3 var0, Vector3 var1, int var2, int var3);

    public static final native void delete_MyCallback(long var0);

    public static final native void MyInternalTriangleIndexCallback_gimpactShape_set(long var0, MyInternalTriangleIndexCallback var2, long var3, btGImpactMeshShape var5);

    public static final native long MyInternalTriangleIndexCallback_gimpactShape_get(long var0, MyInternalTriangleIndexCallback var2);

    public static final native void MyInternalTriangleIndexCallback_colShape_set(long var0, MyInternalTriangleIndexCallback var2, long var3, btCompoundShape var5);

    public static final native long MyInternalTriangleIndexCallback_colShape_get(long var0, MyInternalTriangleIndexCallback var2);

    public static final native void MyInternalTriangleIndexCallback_depth_set(long var0, MyInternalTriangleIndexCallback var2, float var3);

    public static final native float MyInternalTriangleIndexCallback_depth_get(long var0, MyInternalTriangleIndexCallback var2);

    public static final native long new_MyInternalTriangleIndexCallback(long var0, btCompoundShape var2, long var3, btGImpactMeshShape var5, float var6);

    public static final native void delete_MyInternalTriangleIndexCallback(long var0);

    public static final native long btCreateCompoundFromGimpactShape(long var0, btGImpactMeshShape var2, float var3);

    public static final native void btGenericMemoryPool_pool_set(long var0, btGenericMemoryPool var2, ByteBuffer var3);

    public static final native ByteBuffer btGenericMemoryPool_pool_get(long var0, btGenericMemoryPool var2);

    public static final native void btGenericMemoryPool_free_nodes_set(long var0, btGenericMemoryPool var2, long var3);

    public static final native long btGenericMemoryPool_free_nodes_get(long var0, btGenericMemoryPool var2);

    public static final native void btGenericMemoryPool_allocated_sizes_set(long var0, btGenericMemoryPool var2, long var3);

    public static final native long btGenericMemoryPool_allocated_sizes_get(long var0, btGenericMemoryPool var2);

    public static final native void btGenericMemoryPool_allocated_count_set(long var0, btGenericMemoryPool var2, long var3);

    public static final native long btGenericMemoryPool_allocated_count_get(long var0, btGenericMemoryPool var2);

    public static final native void btGenericMemoryPool_free_nodes_count_set(long var0, btGenericMemoryPool var2, long var3);

    public static final native long btGenericMemoryPool_free_nodes_count_get(long var0, btGenericMemoryPool var2);

    public static final native void btGenericMemoryPool_init_pool(long var0, btGenericMemoryPool var2, long var3, long var5);

    public static final native void btGenericMemoryPool_end_pool(long var0, btGenericMemoryPool var2);

    public static final native long new_btGenericMemoryPool(long var0, long var2);

    public static final native void delete_btGenericMemoryPool(long var0);

    public static final native long btGenericMemoryPool_get_pool_capacity(long var0, btGenericMemoryPool var2);

    public static final native long btGenericMemoryPool_gem_element_size(long var0, btGenericMemoryPool var2);

    public static final native long btGenericMemoryPool_get_max_element_count(long var0, btGenericMemoryPool var2);

    public static final native long btGenericMemoryPool_get_allocated_count(long var0, btGenericMemoryPool var2);

    public static final native long btGenericMemoryPool_get_free_positions_count(long var0, btGenericMemoryPool var2);

    public static final native long btGenericMemoryPool_get_element_data(long var0, btGenericMemoryPool var2, long var3);

    public static final native long btGenericMemoryPool_allocate(long var0, btGenericMemoryPool var2, long var3);

    public static final native boolean btGenericMemoryPool_freeMemory(long var0, btGenericMemoryPool var2, long var3);

    public static final native void btGenericPoolAllocator_pools_set(long var0, btGenericPoolAllocator var2, long var3);

    public static final native long btGenericPoolAllocator_pools_get(long var0, btGenericPoolAllocator var2);

    public static final native void btGenericPoolAllocator_pool_count_set(long var0, btGenericPoolAllocator var2, long var3);

    public static final native long btGenericPoolAllocator_pool_count_get(long var0, btGenericPoolAllocator var2);

    public static final native long btGenericPoolAllocator_get_pool_capacity(long var0, btGenericPoolAllocator var2);

    public static final native long new_btGenericPoolAllocator(long var0, long var2);

    public static final native void delete_btGenericPoolAllocator(long var0);

    public static final native long btGenericPoolAllocator_allocate(long var0, btGenericPoolAllocator var2, long var3);

    public static final native boolean btGenericPoolAllocator_freeMemory(long var0, btGenericPoolAllocator var2, long var3);

    public static final native long btPoolAlloc(long var0);

    public static final native long btPoolRealloc(long var0, long var2, long var4);

    public static final native void btPoolFree(long var0);

    public static final native long new_btGImpactCollisionAlgorithm(long var0, btCollisionAlgorithmConstructionInfo var2, long var3, btCollisionObjectWrapper var5, long var6, btCollisionObjectWrapper var8);

    public static final native void delete_btGImpactCollisionAlgorithm(long var0);

    public static final native long btGImpactCollisionAlgorithm_internalGetResultOut(long var0, btGImpactCollisionAlgorithm var2);

    public static final native long new_btGImpactCollisionAlgorithm_CreateFunc();

    public static final native void delete_btGImpactCollisionAlgorithm_CreateFunc(long var0);

    public static final native void btGImpactCollisionAlgorithm_registerAlgorithm(long var0, btCollisionDispatcher var2);

    public static final native void btGImpactCollisionAlgorithm_gimpact_vs_gimpact(long var0, btGImpactCollisionAlgorithm var2, long var3, btCollisionObjectWrapper var5, long var6, btCollisionObjectWrapper var8, long var9, btGImpactShapeInterface var11, long var12, btGImpactShapeInterface var14);

    public static final native void btGImpactCollisionAlgorithm_gimpact_vs_shape(long var0, btGImpactCollisionAlgorithm var2, long var3, btCollisionObjectWrapper var5, long var6, btCollisionObjectWrapper var8, long var9, btGImpactShapeInterface var11, long var12, btCollisionShape var14, boolean var15);

    public static final native void btGImpactCollisionAlgorithm_gimpact_vs_compoundshape(long var0, btGImpactCollisionAlgorithm var2, long var3, btCollisionObjectWrapper var5, long var6, btCollisionObjectWrapper var8, long var9, btGImpactShapeInterface var11, long var12, btCompoundShape var14, boolean var15);

    public static final native void btGImpactCollisionAlgorithm_gimpact_vs_concave(long var0, btGImpactCollisionAlgorithm var2, long var3, btCollisionObjectWrapper var5, long var6, btCollisionObjectWrapper var8, long var9, btGImpactShapeInterface var11, long var12, btConcaveShape var14, boolean var15);

    public static final native void btGImpactCollisionAlgorithm_setFace0(long var0, btGImpactCollisionAlgorithm var2, int var3);

    public static final native int btGImpactCollisionAlgorithm_getFace0(long var0, btGImpactCollisionAlgorithm var2);

    public static final native void btGImpactCollisionAlgorithm_setFace1(long var0, btGImpactCollisionAlgorithm var2, int var3);

    public static final native int btGImpactCollisionAlgorithm_getFace1(long var0, btGImpactCollisionAlgorithm var2);

    public static final native void btGImpactCollisionAlgorithm_setPart0(long var0, btGImpactCollisionAlgorithm var2, int var3);

    public static final native int btGImpactCollisionAlgorithm_getPart0(long var0, btGImpactCollisionAlgorithm var2);

    public static final native void btGImpactCollisionAlgorithm_setPart1(long var0, btGImpactCollisionAlgorithm var2, int var3);

    public static final native int btGImpactCollisionAlgorithm_getPart1(long var0, btGImpactCollisionAlgorithm var2);

    public static final native Vector3 gim_inertia_add_transformed(Vector3 var0, Vector3 var1, Matrix4 var2);

    public static final native Vector3 gim_get_point_inertia(Vector3 var0, float var1);

    public static final native void gim_set_alloc_handler(long var0);

    public static final native void gim_set_alloca_handler(long var0);

    public static final native void gim_set_realloc_handler(long var0);

    public static final native void gim_set_free_handler(long var0);

    public static final native long gim_get_alloc_handler();

    public static final native long gim_get_alloca_handler();

    public static final native long gim_get_realloc_handler();

    public static final native long gim_get_free_handler();

    public static final native long gim_alloc(long var0);

    public static final native long gim_alloca(long var0);

    public static final native long gim_realloc(long var0, long var2, long var4);

    public static final native void gim_free(long var0);

    public static final native void gim_simd_memcpy(long var0, long var2, long var4);

    public static final native void gim_bitset_container_set(long var0, gim_bitset var2, long var3);

    public static final native long gim_bitset_container_get(long var0, gim_bitset var2);

    public static final native long new_gim_bitset__SWIG_0();

    public static final native long new_gim_bitset__SWIG_1(long var0);

    public static final native void delete_gim_bitset(long var0);

    public static final native boolean gim_bitset_resize(long var0, gim_bitset var2, long var3);

    public static final native long gim_bitset_size(long var0, gim_bitset var2);

    public static final native void gim_bitset_set_all(long var0, gim_bitset var2);

    public static final native void gim_bitset_clear_all(long var0, gim_bitset var2);

    public static final native void gim_bitset_set(long var0, gim_bitset var2, long var3);

    public static final native char gim_bitset_get(long var0, gim_bitset var2, long var3);

    public static final native void gim_bitset_clear(long var0, gim_bitset var2, long var3);

    public static final native void GIM_BOX_BOX_TRANSFORM_CACHE_T1to0_set(long var0, GIM_BOX_BOX_TRANSFORM_CACHE var2, long var3, btVector3 var5);

    public static final native long GIM_BOX_BOX_TRANSFORM_CACHE_T1to0_get(long var0, GIM_BOX_BOX_TRANSFORM_CACHE var2);

    public static final native void GIM_BOX_BOX_TRANSFORM_CACHE_R1to0_set(long var0, GIM_BOX_BOX_TRANSFORM_CACHE var2, long var3, btMatrix3x3 var5);

    public static final native long GIM_BOX_BOX_TRANSFORM_CACHE_R1to0_get(long var0, GIM_BOX_BOX_TRANSFORM_CACHE var2);

    public static final native void GIM_BOX_BOX_TRANSFORM_CACHE_AR_set(long var0, GIM_BOX_BOX_TRANSFORM_CACHE var2, long var3, btMatrix3x3 var5);

    public static final native long GIM_BOX_BOX_TRANSFORM_CACHE_AR_get(long var0, GIM_BOX_BOX_TRANSFORM_CACHE var2);

    public static final native void GIM_BOX_BOX_TRANSFORM_CACHE_calc_absolute_matrix(long var0, GIM_BOX_BOX_TRANSFORM_CACHE var2);

    public static final native long new_GIM_BOX_BOX_TRANSFORM_CACHE__SWIG_0();

    public static final native long new_GIM_BOX_BOX_TRANSFORM_CACHE__SWIG_1(long var0);

    public static final native void GIM_BOX_BOX_TRANSFORM_CACHE_calc_from_homogenic(long var0, GIM_BOX_BOX_TRANSFORM_CACHE var2, Matrix4 var3, Matrix4 var4);

    public static final native void GIM_BOX_BOX_TRANSFORM_CACHE_calc_from_full_invert(long var0, GIM_BOX_BOX_TRANSFORM_CACHE var2, Matrix4 var3, Matrix4 var4);

    public static final native Vector3 GIM_BOX_BOX_TRANSFORM_CACHE_transform(long var0, GIM_BOX_BOX_TRANSFORM_CACHE var2, Vector3 var3);

    public static final native void delete_GIM_BOX_BOX_TRANSFORM_CACHE(long var0);

    public static final native void GIM_AABB_min_set(long var0, GIM_AABB var2, long var3, btVector3 var5);

    public static final native long GIM_AABB_min_get(long var0, GIM_AABB var2);

    public static final native void GIM_AABB_max_set(long var0, GIM_AABB var2, long var3, btVector3 var5);

    public static final native long GIM_AABB_max_get(long var0, GIM_AABB var2);

    public static final native long new_GIM_AABB__SWIG_0();

    public static final native long new_GIM_AABB__SWIG_1(Vector3 var0, Vector3 var1, Vector3 var2);

    public static final native long new_GIM_AABB__SWIG_2(Vector3 var0, Vector3 var1, Vector3 var2, long var3);

    public static final native long new_GIM_AABB__SWIG_3(long var0, GIM_AABB var2);

    public static final native long new_GIM_AABB__SWIG_4(long var0, GIM_AABB var2, float var3);

    public static final native void GIM_AABB_invalidate(long var0, GIM_AABB var2);

    public static final native void GIM_AABB_increment_margin(long var0, GIM_AABB var2, float var3);

    public static final native void GIM_AABB_copy_with_margin(long var0, GIM_AABB var2, long var3, GIM_AABB var5, float var6);

    public static final native void GIM_AABB_appy_transform(long var0, GIM_AABB var2, Matrix4 var3);

    public static final native void GIM_AABB_merge(long var0, GIM_AABB var2, long var3, GIM_AABB var5);

    public static final native void GIM_AABB_get_center_extend(long var0, GIM_AABB var2, Vector3 var3, Vector3 var4);

    public static final native void GIM_AABB_find_intersection(long var0, GIM_AABB var2, long var3, GIM_AABB var5, long var6, GIM_AABB var8);

    public static final native boolean GIM_AABB_has_collision(long var0, GIM_AABB var2, long var3, GIM_AABB var5);

    public static final native boolean GIM_AABB_collide_ray(long var0, GIM_AABB var2, Vector3 var3, Vector3 var4);

    public static final native void GIM_AABB_projection_interval(long var0, GIM_AABB var2, Vector3 var3, long var4, long var6);

    public static final native int GIM_AABB_plane_classify(long var0, GIM_AABB var2, long var3, btVector4 var5);

    public static final native boolean GIM_AABB_overlapping_trans_conservative(long var0, GIM_AABB var2, long var3, GIM_AABB var5, Matrix4 var6);

    public static final native boolean GIM_AABB_overlapping_trans_cache(long var0, GIM_AABB var2, long var3, GIM_AABB var5, long var6, GIM_BOX_BOX_TRANSFORM_CACHE var8, boolean var9);

    public static final native boolean GIM_AABB_collide_plane(long var0, GIM_AABB var2, long var3, btVector4 var5);

    public static final native boolean GIM_AABB_collide_triangle_exact(long var0, GIM_AABB var2, Vector3 var3, Vector3 var4, Vector3 var5, long var6, btVector4 var8);

    public static final native void delete_GIM_AABB(long var0);

    public static final native long new_DISTANCE_PLANE_3D_FUNC();

    public static final native void delete_DISTANCE_PLANE_3D_FUNC(long var0);

    public static final native void gim_contact_array_internal_data_set(long var0, gim_contact_array_internal var2, long var3, GIM_CONTACT var5);

    public static final native long gim_contact_array_internal_data_get(long var0, gim_contact_array_internal var2);

    public static final native void gim_contact_array_internal_size_set(long var0, gim_contact_array_internal var2, long var3);

    public static final native long gim_contact_array_internal_size_get(long var0, gim_contact_array_internal var2);

    public static final native void gim_contact_array_internal_allocated_size_set(long var0, gim_contact_array_internal var2, long var3);

    public static final native long gim_contact_array_internal_allocated_size_get(long var0, gim_contact_array_internal var2);

    public static final native void gim_contact_array_internal_destroyData(long var0, gim_contact_array_internal var2);

    public static final native boolean gim_contact_array_internal_resizeData(long var0, gim_contact_array_internal var2, long var3);

    public static final native boolean gim_contact_array_internal_growingCheck(long var0, gim_contact_array_internal var2);

    public static final native boolean gim_contact_array_internal_reserve(long var0, gim_contact_array_internal var2, long var3);

    public static final native void gim_contact_array_internal_clear_range(long var0, gim_contact_array_internal var2, long var3);

    public static final native void gim_contact_array_internal_clear(long var0, gim_contact_array_internal var2);

    public static final native void gim_contact_array_internal_clear_memory(long var0, gim_contact_array_internal var2);

    public static final native long new_gim_array__SWIG_0();

    public static final native long new_gim_array__SWIG_1(long var0);

    public static final native void delete_gim_contact_array_internal(long var0);

    public static final native long gim_contact_array_internal_sizeVal(long var0, gim_contact_array_internal var2);

    public static final native long gim_contact_array_internal_max_size(long var0, gim_contact_array_internal var2);

    public static final native long gim_contact_array_internal_operatorSubscript(long var0, gim_contact_array_internal var2, long var3);

    public static final native long gim_contact_array_internal_operatorSubscriptConst(long var0, gim_contact_array_internal var2, long var3);

    public static final native long gim_contact_array_internal_pointer(long var0, gim_contact_array_internal var2);

    public static final native long gim_contact_array_internal_pointer_const(long var0, gim_contact_array_internal var2);

    public static final native long gim_contact_array_internal_get_pointer_at(long var0, gim_contact_array_internal var2, long var3);

    public static final native long gim_contact_array_internal_get_pointer_at_const(long var0, gim_contact_array_internal var2, long var3);

    public static final native long gim_contact_array_internal_at(long var0, gim_contact_array_internal var2, long var3);

    public static final native long gim_contact_array_internal_at_const(long var0, gim_contact_array_internal var2, long var3);

    public static final native long gim_contact_array_internal_front(long var0, gim_contact_array_internal var2);

    public static final native long gim_contact_array_internal_front_const(long var0, gim_contact_array_internal var2);

    public static final native long gim_contact_array_internal_back(long var0, gim_contact_array_internal var2);

    public static final native long gim_contact_array_internal_back_const(long var0, gim_contact_array_internal var2);

    public static final native void gim_contact_array_internal_swap(long var0, gim_contact_array_internal var2, long var3, long var5);

    public static final native void gim_contact_array_internal_push_back(long var0, gim_contact_array_internal var2, long var3, GIM_CONTACT var5);

    public static final native void gim_contact_array_internal_push_back_mem(long var0, gim_contact_array_internal var2);

    public static final native void gim_contact_array_internal_push_back_memcpy(long var0, gim_contact_array_internal var2, long var3, GIM_CONTACT var5);

    public static final native void gim_contact_array_internal_pop_back(long var0, gim_contact_array_internal var2);

    public static final native void gim_contact_array_internal_pop_back_mem(long var0, gim_contact_array_internal var2);

    public static final native void gim_contact_array_internal_erase(long var0, gim_contact_array_internal var2, long var3);

    public static final native void gim_contact_array_internal_erase_sorted_mem(long var0, gim_contact_array_internal var2, long var3);

    public static final native void gim_contact_array_internal_erase_sorted(long var0, gim_contact_array_internal var2, long var3);

    public static final native void gim_contact_array_internal_insert_mem(long var0, gim_contact_array_internal var2, long var3);

    public static final native void gim_contact_array_internal_insert(long var0, gim_contact_array_internal var2, long var3, GIM_CONTACT var5, long var6);

    public static final native void gim_contact_array_internal_resize__SWIG_0(long var0, gim_contact_array_internal var2, long var3, boolean var5, long var6, GIM_CONTACT var8);

    public static final native void gim_contact_array_internal_resize__SWIG_1(long var0, gim_contact_array_internal var2, long var3, boolean var5);

    public static final native void gim_contact_array_internal_resize__SWIG_2(long var0, gim_contact_array_internal var2, long var3);

    public static final native void gim_contact_array_internal_refit(long var0, gim_contact_array_internal var2);

    public static final native long new_gim_contact_array();

    public static final native void gim_contact_array_push_contact(long var0, gim_contact_array var2, Vector3 var3, Vector3 var4, long var5, long var7, long var9);

    public static final native void gim_contact_array_push_triangle_contacts(long var0, gim_contact_array var2, long var3, GIM_TRIANGLE_CONTACT_DATA var5, long var6, long var8);

    public static final native void gim_contact_array_merge_contacts__SWIG_0(long var0, gim_contact_array var2, long var3, gim_contact_array var5, boolean var6);

    public static final native void gim_contact_array_merge_contacts__SWIG_1(long var0, gim_contact_array var2, long var3, gim_contact_array var5);

    public static final native void gim_contact_array_merge_contacts_unique(long var0, gim_contact_array var2, long var3, gim_contact_array var5);

    public static final native void delete_gim_contact_array(long var0);

    public static final native long new_GIM_HASH_NODE_GET_KEY();

    public static final native void delete_GIM_HASH_NODE_GET_KEY(long var0);

    public static final native long new_GIM_HASH_NODE_CMP_KEY_MACRO();

    public static final native void delete_GIM_HASH_NODE_CMP_KEY_MACRO(long var0);

    public static final native long new_GIM_HASH_NODE_CMP_MACRO();

    public static final native void delete_GIM_HASH_NODE_CMP_MACRO(long var0);

    public static final native long gim_prime_list_get();

    public static final native long gim_next_prime(long var0);

    public static final native float gim_inv_sqrt(float var0);

    public static final native float gim_sqrt(float var0);

    public static final native long new_less_comparator();

    public static final native void delete_less_comparator(long var0);

    public static final native long new_integer_comparator();

    public static final native void delete_integer_comparator(long var0);

    public static final native long new_uint_key_func();

    public static final native void delete_uint_key_func(long var0);

    public static final native long new_copy_elements_func();

    public static final native void delete_copy_elements_func(long var0);

    public static final native long new_memcopy_elements_func();

    public static final native void delete_memcopy_elements_func(long var0);

    public static final native void GIM_RSORT_TOKEN_key_set(long var0, GIM_RSORT_TOKEN var2, long var3);

    public static final native long GIM_RSORT_TOKEN_key_get(long var0, GIM_RSORT_TOKEN var2);

    public static final native void GIM_RSORT_TOKEN_value_set(long var0, GIM_RSORT_TOKEN var2, long var3);

    public static final native long GIM_RSORT_TOKEN_value_get(long var0, GIM_RSORT_TOKEN var2);

    public static final native long new_GIM_RSORT_TOKEN__SWIG_0();

    public static final native long new_GIM_RSORT_TOKEN__SWIG_1(long var0, GIM_RSORT_TOKEN var2);

    public static final native boolean GIM_RSORT_TOKEN_operatorLessThan(long var0, GIM_RSORT_TOKEN var2, long var3, GIM_RSORT_TOKEN var5);

    public static final native boolean GIM_RSORT_TOKEN_operatorGreaterThan(long var0, GIM_RSORT_TOKEN var2, long var3, GIM_RSORT_TOKEN var5);

    public static final native void delete_GIM_RSORT_TOKEN(long var0);

    public static final native int GIM_RSORT_TOKEN_COMPARATOR_operatorFunctionCall(long var0, GIM_RSORT_TOKEN_COMPARATOR var2, long var3, GIM_RSORT_TOKEN var5, long var6, GIM_RSORT_TOKEN var8);

    public static final native long new_GIM_RSORT_TOKEN_COMPARATOR();

    public static final native void delete_GIM_RSORT_TOKEN_COMPARATOR(long var0);

    public static final native void gim_radix_sort_rtokens(long var0, GIM_RSORT_TOKEN var2, long var3, GIM_RSORT_TOKEN var5, long var6);

    public static final native void GIM_TRIANGLE_CONTACT_DATA_penetration_depth_set(long var0, GIM_TRIANGLE_CONTACT_DATA var2, float var3);

    public static final native float GIM_TRIANGLE_CONTACT_DATA_penetration_depth_get(long var0, GIM_TRIANGLE_CONTACT_DATA var2);

    public static final native void GIM_TRIANGLE_CONTACT_DATA_point_count_set(long var0, GIM_TRIANGLE_CONTACT_DATA var2, long var3);

    public static final native long GIM_TRIANGLE_CONTACT_DATA_point_count_get(long var0, GIM_TRIANGLE_CONTACT_DATA var2);

    public static final native void GIM_TRIANGLE_CONTACT_DATA_separating_normal_set(long var0, GIM_TRIANGLE_CONTACT_DATA var2, long var3, btVector4 var5);

    public static final native long GIM_TRIANGLE_CONTACT_DATA_separating_normal_get(long var0, GIM_TRIANGLE_CONTACT_DATA var2);

    public static final native void GIM_TRIANGLE_CONTACT_DATA_points_set(long var0, GIM_TRIANGLE_CONTACT_DATA var2, long var3, btVector3 var5);

    public static final native long GIM_TRIANGLE_CONTACT_DATA_points_get(long var0, GIM_TRIANGLE_CONTACT_DATA var2);

    public static final native void GIM_TRIANGLE_CONTACT_DATA_copy_from(long var0, GIM_TRIANGLE_CONTACT_DATA var2, long var3, GIM_TRIANGLE_CONTACT_DATA var5);

    public static final native long new_GIM_TRIANGLE_CONTACT_DATA__SWIG_0();

    public static final native long new_GIM_TRIANGLE_CONTACT_DATA__SWIG_1(long var0, GIM_TRIANGLE_CONTACT_DATA var2);

    public static final native void GIM_TRIANGLE_CONTACT_DATA_merge_points(long var0, GIM_TRIANGLE_CONTACT_DATA var2, long var3, btVector4 var5, float var6, long var7, btVector3 var9, long var10);

    public static final native void delete_GIM_TRIANGLE_CONTACT_DATA(long var0);

    public static final native void GIM_TRIANGLE_margin_set(long var0, GIM_TRIANGLE var2, float var3);

    public static final native float GIM_TRIANGLE_margin_get(long var0, GIM_TRIANGLE var2);

    public static final native void GIM_TRIANGLE_vertices_set(long var0, GIM_TRIANGLE var2, long var3, btVector3 var5);

    public static final native long GIM_TRIANGLE_vertices_get(long var0, GIM_TRIANGLE var2);

    public static final native long new_GIM_TRIANGLE();

    public static final native long GIM_TRIANGLE_get_box(long var0, GIM_TRIANGLE var2);

    public static final native void GIM_TRIANGLE_get_normal(long var0, GIM_TRIANGLE var2, Vector3 var3);

    public static final native void GIM_TRIANGLE_get_plane(long var0, GIM_TRIANGLE var2, long var3, btVector4 var5);

    public static final native void GIM_TRIANGLE_apply_transform(long var0, GIM_TRIANGLE var2, Matrix4 var3);

    public static final native void GIM_TRIANGLE_get_edge_plane(long var0, GIM_TRIANGLE var2, long var3, Vector3 var5, long var6, btVector4 var8);

    public static final native void GIM_TRIANGLE_get_triangle_transform(long var0, GIM_TRIANGLE var2, Matrix4 var3);

    public static final native boolean GIM_TRIANGLE_collide_triangle_hard_test(long var0, GIM_TRIANGLE var2, long var3, GIM_TRIANGLE var5, long var6, GIM_TRIANGLE_CONTACT_DATA var8);

    public static final native boolean GIM_TRIANGLE_collide_triangle(long var0, GIM_TRIANGLE var2, long var3, GIM_TRIANGLE var5, long var6, GIM_TRIANGLE_CONTACT_DATA var8);

    public static final native boolean GIM_TRIANGLE_get_uv_parameters(long var0, GIM_TRIANGLE var2, Vector3 var3, Vector3 var4, long var5, long var7);

    public static final native boolean GIM_TRIANGLE_is_point_inside(long var0, GIM_TRIANGLE var2, Vector3 var3, Vector3 var4);

    public static final native boolean GIM_TRIANGLE_ray_collision__SWIG_0(long var0, GIM_TRIANGLE var2, Vector3 var3, Vector3 var4, Vector3 var5, Vector3 var6, long var7, float var9);

    public static final native boolean GIM_TRIANGLE_ray_collision__SWIG_1(long var0, GIM_TRIANGLE var2, Vector3 var3, Vector3 var4, Vector3 var5, Vector3 var6, long var7);

    public static final native boolean GIM_TRIANGLE_ray_collision_front_side__SWIG_0(long var0, GIM_TRIANGLE var2, Vector3 var3, Vector3 var4, Vector3 var5, Vector3 var6, long var7, float var9);

    public static final native boolean GIM_TRIANGLE_ray_collision_front_side__SWIG_1(long var0, GIM_TRIANGLE var2, Vector3 var3, Vector3 var4, Vector3 var5, Vector3 var6, long var7);

    public static final native void delete_GIM_TRIANGLE(long var0);

    public static final native long new_btCollisionWorldImporter(long var0, btCollisionWorld var2);

    public static final native void delete_btCollisionWorldImporter(long var0);

    public static final native boolean btCollisionWorldImporter_convertAllObjects(long var0, btCollisionWorldImporter var2, long var3, btBulletSerializedArrays var5);

    public static final native void btCollisionWorldImporter_deleteAllData(long var0, btCollisionWorldImporter var2);

    public static final native void btCollisionWorldImporter_setVerboseMode(long var0, btCollisionWorldImporter var2, int var3);

    public static final native int btCollisionWorldImporter_getVerboseMode(long var0, btCollisionWorldImporter var2);

    public static final native int btCollisionWorldImporter_getNumCollisionShapes(long var0, btCollisionWorldImporter var2);

    public static final native long btCollisionWorldImporter_getCollisionShapeByIndex(long var0, btCollisionWorldImporter var2, int var3);

    public static final native int btCollisionWorldImporter_getNumRigidBodies(long var0, btCollisionWorldImporter var2);

    public static final native long btCollisionWorldImporter_getRigidBodyByIndex(long var0, btCollisionWorldImporter var2, int var3);

    public static final native int btCollisionWorldImporter_getNumBvhs(long var0, btCollisionWorldImporter var2);

    public static final native long btCollisionWorldImporter_getBvhByIndex(long var0, btCollisionWorldImporter var2, int var3);

    public static final native int btCollisionWorldImporter_getNumTriangleInfoMaps(long var0, btCollisionWorldImporter var2);

    public static final native long btCollisionWorldImporter_getTriangleInfoMapByIndex(long var0, btCollisionWorldImporter var2, int var3);

    public static final native long btCollisionWorldImporter_getCollisionShapeByName(long var0, btCollisionWorldImporter var2, String var3);

    public static final native long btCollisionWorldImporter_getCollisionObjectByName(long var0, btCollisionWorldImporter var2, String var3);

    public static final native String btCollisionWorldImporter_getNameForPointer(long var0, btCollisionWorldImporter var2, long var3);

    public static final native long btCollisionWorldImporter_createCollisionObject(long var0, btCollisionWorldImporter var2, Matrix4 var3, long var4, btCollisionShape var6, String var7);

    public static final native long btCollisionWorldImporter_createPlaneShape(long var0, btCollisionWorldImporter var2, Vector3 var3, float var4);

    public static final native long btCollisionWorldImporter_createBoxShape(long var0, btCollisionWorldImporter var2, Vector3 var3);

    public static final native long btCollisionWorldImporter_createSphereShape(long var0, btCollisionWorldImporter var2, float var3);

    public static final native long btCollisionWorldImporter_createCapsuleShapeX(long var0, btCollisionWorldImporter var2, float var3, float var4);

    public static final native long btCollisionWorldImporter_createCapsuleShapeY(long var0, btCollisionWorldImporter var2, float var3, float var4);

    public static final native long btCollisionWorldImporter_createCapsuleShapeZ(long var0, btCollisionWorldImporter var2, float var3, float var4);

    public static final native long btCollisionWorldImporter_createCylinderShapeX(long var0, btCollisionWorldImporter var2, float var3, float var4);

    public static final native long btCollisionWorldImporter_createCylinderShapeY(long var0, btCollisionWorldImporter var2, float var3, float var4);

    public static final native long btCollisionWorldImporter_createCylinderShapeZ(long var0, btCollisionWorldImporter var2, float var3, float var4);

    public static final native long btCollisionWorldImporter_createConeShapeX(long var0, btCollisionWorldImporter var2, float var3, float var4);

    public static final native long btCollisionWorldImporter_createConeShapeY(long var0, btCollisionWorldImporter var2, float var3, float var4);

    public static final native long btCollisionWorldImporter_createConeShapeZ(long var0, btCollisionWorldImporter var2, float var3, float var4);

    public static final native long btCollisionWorldImporter_createTriangleMeshContainer(long var0, btCollisionWorldImporter var2);

    public static final native long btCollisionWorldImporter_createBvhTriangleMeshShape(long var0, btCollisionWorldImporter var2, long var3, btStridingMeshInterface var5, long var6, btOptimizedBvh var8);

    public static final native long btCollisionWorldImporter_createConvexTriangleMeshShape(long var0, btCollisionWorldImporter var2, long var3, btStridingMeshInterface var5);

    public static final native long btCollisionWorldImporter_createStridingMeshInterfaceData(long var0, btCollisionWorldImporter var2, long var3, btStridingMeshInterfaceData var5);

    public static final native long btCollisionWorldImporter_createConvexHullShape(long var0, btCollisionWorldImporter var2);

    public static final native long btCollisionWorldImporter_createCompoundShape(long var0, btCollisionWorldImporter var2);

    public static final native long btCollisionWorldImporter_createScaledTrangleMeshShape(long var0, btCollisionWorldImporter var2, long var3, btBvhTriangleMeshShape var5, Vector3 var6);

    public static final native long btCollisionWorldImporter_createMultiSphereShape(long var0, btCollisionWorldImporter var2, long var3, btVector3 var5, FloatBuffer var6, int var7);

    public static final native long btCollisionWorldImporter_createMeshInterface(long var0, btCollisionWorldImporter var2, long var3, btStridingMeshInterfaceData var5);

    public static final native long btCollisionWorldImporter_createOptimizedBvh(long var0, btCollisionWorldImporter var2);

    public static final native long btCollisionWorldImporter_createTriangleInfoMap(long var0, btCollisionWorldImporter var2);

    public static final native void btGjkCollisionDescription_firstDir_set(long var0, btGjkCollisionDescription var2, long var3, btVector3 var5);

    public static final native long btGjkCollisionDescription_firstDir_get(long var0, btGjkCollisionDescription var2);

    public static final native void btGjkCollisionDescription_maxGjkIterations_set(long var0, btGjkCollisionDescription var2, int var3);

    public static final native int btGjkCollisionDescription_maxGjkIterations_get(long var0, btGjkCollisionDescription var2);

    public static final native void btGjkCollisionDescription_maximumDistanceSquared_set(long var0, btGjkCollisionDescription var2, float var3);

    public static final native float btGjkCollisionDescription_maximumDistanceSquared_get(long var0, btGjkCollisionDescription var2);

    public static final native void btGjkCollisionDescription_gjkRelError2_set(long var0, btGjkCollisionDescription var2, float var3);

    public static final native float btGjkCollisionDescription_gjkRelError2_get(long var0, btGjkCollisionDescription var2);

    public static final native long new_btGjkCollisionDescription();

    public static final native void delete_btGjkCollisionDescription(long var0);

    public static final native void btGjkEpaSolver3_sResults_status_set(long var0, btGjkEpaSolver3.sResults var2, int var3);

    public static final native int btGjkEpaSolver3_sResults_status_get(long var0, btGjkEpaSolver3.sResults var2);

    public static final native void btGjkEpaSolver3_sResults_witnesses_set(long var0, btGjkEpaSolver3.sResults var2, long var3, btVector3 var5);

    public static final native long btGjkEpaSolver3_sResults_witnesses_get(long var0, btGjkEpaSolver3.sResults var2);

    public static final native void btGjkEpaSolver3_sResults_normal_set(long var0, btGjkEpaSolver3.sResults var2, long var3, btVector3 var5);

    public static final native long btGjkEpaSolver3_sResults_normal_get(long var0, btGjkEpaSolver3.sResults var2);

    public static final native void btGjkEpaSolver3_sResults_distance_set(long var0, btGjkEpaSolver3.sResults var2, float var3);

    public static final native float btGjkEpaSolver3_sResults_distance_get(long var0, btGjkEpaSolver3.sResults var2);

    public static final native long new_btGjkEpaSolver3_sResults();

    public static final native void delete_btGjkEpaSolver3_sResults(long var0);

    public static final native long new_btGjkEpaSolver3();

    public static final native void delete_btGjkEpaSolver3(long var0);

    public static final native void btMprCollisionDescription_firstDir_set(long var0, btMprCollisionDescription var2, long var3, btVector3 var5);

    public static final native long btMprCollisionDescription_firstDir_get(long var0, btMprCollisionDescription var2);

    public static final native void btMprCollisionDescription_maxGjkIterations_set(long var0, btMprCollisionDescription var2, int var3);

    public static final native int btMprCollisionDescription_maxGjkIterations_get(long var0, btMprCollisionDescription var2);

    public static final native void btMprCollisionDescription_maximumDistanceSquared_set(long var0, btMprCollisionDescription var2, float var3);

    public static final native float btMprCollisionDescription_maximumDistanceSquared_get(long var0, btMprCollisionDescription var2);

    public static final native void btMprCollisionDescription_gjkRelError2_set(long var0, btMprCollisionDescription var2, float var3);

    public static final native float btMprCollisionDescription_gjkRelError2_get(long var0, btMprCollisionDescription var2);

    public static final native long new_btMprCollisionDescription();

    public static final native void delete_btMprCollisionDescription(long var0);

    public static final native void btMprDistanceInfo_pointOnA_set(long var0, btMprDistanceInfo var2, long var3, btVector3 var5);

    public static final native long btMprDistanceInfo_pointOnA_get(long var0, btMprDistanceInfo var2);

    public static final native void btMprDistanceInfo_pointOnB_set(long var0, btMprDistanceInfo var2, long var3, btVector3 var5);

    public static final native long btMprDistanceInfo_pointOnB_get(long var0, btMprDistanceInfo var2);

    public static final native void btMprDistanceInfo_normalBtoA_set(long var0, btMprDistanceInfo var2, long var3, btVector3 var5);

    public static final native long btMprDistanceInfo_normalBtoA_get(long var0, btMprDistanceInfo var2);

    public static final native void btMprDistanceInfo_distance_set(long var0, btMprDistanceInfo var2, float var3);

    public static final native float btMprDistanceInfo_distance_get(long var0, btMprDistanceInfo var2);

    public static final native long new_btMprDistanceInfo();

    public static final native void delete_btMprDistanceInfo(long var0);

    public static final native void _btMprSupport_t_v_set(long var0, _btMprSupport_t var2, long var3, btVector3 var5);

    public static final native long _btMprSupport_t_v_get(long var0, _btMprSupport_t var2);

    public static final native void _btMprSupport_t_v1_set(long var0, _btMprSupport_t var2, long var3, btVector3 var5);

    public static final native long _btMprSupport_t_v1_get(long var0, _btMprSupport_t var2);

    public static final native void _btMprSupport_t_v2_set(long var0, _btMprSupport_t var2, long var3, btVector3 var5);

    public static final native long _btMprSupport_t_v2_get(long var0, _btMprSupport_t var2);

    public static final native long new__btMprSupport_t();

    public static final native void delete__btMprSupport_t(long var0);

    public static final native void _btMprSimplex_t_ps_set(long var0, _btMprSimplex_t var2, long var3, _btMprSupport_t var5);

    public static final native long _btMprSimplex_t_ps_get(long var0, _btMprSimplex_t var2);

    public static final native void _btMprSimplex_t_last_set(long var0, _btMprSimplex_t var2, int var3);

    public static final native int _btMprSimplex_t_last_get(long var0, _btMprSimplex_t var2);

    public static final native long new__btMprSimplex_t();

    public static final native void delete__btMprSimplex_t(long var0);

    public static final native long btMprSimplexPointW(long var0, _btMprSimplex_t var2, int var3);

    public static final native void btMprSimplexSetSize(long var0, _btMprSimplex_t var2, int var3);

    public static final native int btMprSimplexSize(long var0, _btMprSimplex_t var2);

    public static final native long btMprSimplexPoint(long var0, _btMprSimplex_t var2, int var3);

    public static final native void btMprSupportCopy(long var0, _btMprSupport_t var2, long var3, _btMprSupport_t var5);

    public static final native void btMprSimplexSet(long var0, _btMprSimplex_t var2, long var3, long var5, _btMprSupport_t var7);

    public static final native void btMprSimplexSwap(long var0, _btMprSimplex_t var2, long var3, long var5);

    public static final native int btMprIsZero(float var0);

    public static final native int btMprEq(float var0, float var1);

    public static final native int btMprVec3Eq(long var0, btVector3 var2, long var3, btVector3 var5);

    public static final native void btMprVec3Set(long var0, btVector3 var2, float var3, float var4, float var5);

    public static final native void btMprVec3Add(long var0, btVector3 var2, long var3, btVector3 var5);

    public static final native void btMprVec3Copy(long var0, btVector3 var2, long var3, btVector3 var5);

    public static final native void btMprVec3Scale(long var0, btVector3 var2, float var3);

    public static final native float btMprVec3Dot(long var0, btVector3 var2, long var3, btVector3 var5);

    public static final native float btMprVec3Len2(long var0, btVector3 var2);

    public static final native void btMprVec3Normalize(long var0, btVector3 var2);

    public static final native void btMprVec3Cross(long var0, btVector3 var2, long var3, btVector3 var5, long var6, btVector3 var8);

    public static final native void btMprVec3Sub2(long var0, btVector3 var2, long var3, btVector3 var5, long var6, btVector3 var8);

    public static final native void btPortalDir(long var0, _btMprSimplex_t var2, long var3, btVector3 var5);

    public static final native int portalEncapsulesOrigin(long var0, _btMprSimplex_t var2, long var3, btVector3 var5);

    public static final native int portalReachTolerance(long var0, _btMprSimplex_t var2, long var3, _btMprSupport_t var5, long var6, btVector3 var8);

    public static final native int portalCanEncapsuleOrigin(long var0, _btMprSimplex_t var2, long var3, _btMprSupport_t var5, long var6, btVector3 var8);

    public static final native void btExpandPortal(long var0, _btMprSimplex_t var2, long var3, _btMprSupport_t var5);

    public static final native void btFindPos(long var0, _btMprSimplex_t var2, long var3, btVector3 var5);

    public static final native float btMprVec3Dist2(long var0, btVector3 var2, long var3, btVector3 var5);

    public static final native float _btMprVec3PointSegmentDist2(long var0, btVector3 var2, long var3, btVector3 var5, long var6, btVector3 var8, long var9, btVector3 var11);

    public static final native float btMprVec3PointTriDist2(long var0, btVector3 var2, long var3, btVector3 var5, long var6, btVector3 var8, long var9, btVector3 var11, long var12, btVector3 var14);

    public static final native void btFindPenetrTouch(long var0, _btMprSimplex_t var2, FloatBuffer var3, long var4, btVector3 var6, long var7, btVector3 var9);

    public static final native void btFindPenetrSegment(long var0, _btMprSimplex_t var2, FloatBuffer var3, long var4, btVector3 var6, long var7, btVector3 var9);

    public static final native long btStorageResult_SWIGUpcast(long var0);

    public static final native long btBroadphaseRayCallback_SWIGUpcast(long var0);

    public static final native long btSimpleBroadphaseProxy_SWIGUpcast(long var0);

    public static final native long btSimpleBroadphase_SWIGUpcast(long var0);

    public static final native long btAxisSweep3InternalShort_Handle_SWIGUpcast(long var0);

    public static final native long btAxisSweep3InternalShort_SWIGUpcast(long var0);

    public static final native long btAxisSweep3InternalInt_Handle_SWIGUpcast(long var0);

    public static final native long btAxisSweep3InternalInt_SWIGUpcast(long var0);

    public static final native long btAxisSweep3_SWIGUpcast(long var0);

    public static final native long bt32BitAxisSweep3_SWIGUpcast(long var0);

    public static final native long btOverlappingPairCache_SWIGUpcast(long var0);

    public static final native long btHashedOverlappingPairCache_SWIGUpcast(long var0);

    public static final native long btSortedOverlappingPairCache_SWIGUpcast(long var0);

    public static final native long btNullPairCache_SWIGUpcast(long var0);

    public static final native long btConvexShape_SWIGUpcast(long var0);

    public static final native long btConvexInternalShape_SWIGUpcast(long var0);

    public static final native long btConvexInternalAabbCachingShape_SWIGUpcast(long var0);

    public static final native long btPolyhedralConvexShape_SWIGUpcast(long var0);

    public static final native long btPolyhedralConvexAabbCachingShape_SWIGUpcast(long var0);

    public static final native long btConcaveShape_SWIGUpcast(long var0);

    public static final native long btTriangleInfoMap_SWIGUpcast(long var0);

    public static final native long btStaticPlaneShape_SWIGUpcast(long var0);

    public static final native long btHeightfieldTerrainShape_SWIGUpcast(long var0);

    public static final native long btTriangleMeshShape_SWIGUpcast(long var0);

    public static final native long btBvhTriangleMeshShape_SWIGUpcast(long var0);

    public static final native long btBoxShape_SWIGUpcast(long var0);

    public static final native long btCapsuleShape_SWIGUpcast(long var0);

    public static final native long btCapsuleShapeX_SWIGUpcast(long var0);

    public static final native long btCapsuleShapeZ_SWIGUpcast(long var0);

    public static final native long btBox2dShape_SWIGUpcast(long var0);

    public static final native long btTriangleShape_SWIGUpcast(long var0);

    public static final native long btSphereShape_SWIGUpcast(long var0);

    public static final native long btMinkowskiSumShape_SWIGUpcast(long var0);

    public static final native long btOptimizedBvh_SWIGUpcast(long var0);

    public static final native long btTriangleBuffer_SWIGUpcast(long var0);

    public static final native long btTriangleIndexVertexArray_SWIGUpcast(long var0);

    public static final native long btScaledBvhTriangleMeshShape_SWIGUpcast(long var0);

    public static final native long btConvexHullShape_SWIGUpcast(long var0);

    public static final native long btTriangleIndexVertexMaterialArray_SWIGUpcast(long var0);

    public static final native long btCylinderShape_SWIGUpcast(long var0);

    public static final native long btCylinderShapeX_SWIGUpcast(long var0);

    public static final native long btCylinderShapeZ_SWIGUpcast(long var0);

    public static final native long btTriangleMesh_SWIGUpcast(long var0);

    public static final native long btConeShape_SWIGUpcast(long var0);

    public static final native long btConeShapeX_SWIGUpcast(long var0);

    public static final native long btConeShapeZ_SWIGUpcast(long var0);

    public static final native long btConvexTriangleMeshShape_SWIGUpcast(long var0);

    public static final native long btEmptyShape_SWIGUpcast(long var0);

    public static final native long btMultimaterialTriangleMeshShape_SWIGUpcast(long var0);

    public static final native long btBU_Simplex1to4_SWIGUpcast(long var0);

    public static final native long btUniformScalingShape_SWIGUpcast(long var0);

    public static final native long btConvexPointCloudShape_SWIGUpcast(long var0);

    public static final native long btConvex2dShape_SWIGUpcast(long var0);

    public static final native long btDbvtProxy_SWIGUpcast(long var0);

    public static final native long btDbvtBroadphase_SWIGUpcast(long var0);

    public static final native long btCompoundShape_SWIGUpcast(long var0);

    public static final native long btEmptyAlgorithm_CreateFunc_SWIGUpcast(long var0);

    public static final native long btEmptyAlgorithm_SWIGUpcast(long var0);

    public static final native long btActivatingCollisionAlgorithm_SWIGUpcast(long var0);

    public static final native long btConvexTriangleCallback_SWIGUpcast(long var0);

    public static final native long btConvexConcaveCollisionAlgorithm_CreateFunc_SWIGUpcast(long var0);

    public static final native long btConvexConcaveCollisionAlgorithm_SwappedCreateFunc_SWIGUpcast(long var0);

    public static final native long btConvexConcaveCollisionAlgorithm_SWIGUpcast(long var0);

    public static final native long btConvexPlaneCollisionAlgorithm_CreateFunc_SWIGUpcast(long var0);

    public static final native long btConvexPlaneCollisionAlgorithm_SWIGUpcast(long var0);

    public static final native long btCompoundCollisionAlgorithm_CreateFunc_SWIGUpcast(long var0);

    public static final native long btCompoundCollisionAlgorithm_SwappedCreateFunc_SWIGUpcast(long var0);

    public static final native long btCompoundCollisionAlgorithm_SWIGUpcast(long var0);

    public static final native long btCompoundCompoundCollisionAlgorithm_CreateFunc_SWIGUpcast(long var0);

    public static final native long btCompoundCompoundCollisionAlgorithm_SwappedCreateFunc_SWIGUpcast(long var0);

    public static final native long btCompoundCompoundCollisionAlgorithm_SWIGUpcast(long var0);

    public static final native long btDefaultCollisionConfiguration_SWIGUpcast(long var0);

    public static final native long btManifoldResult_SWIGUpcast(long var0);

    public static final native long btSphereSphereCollisionAlgorithm_CreateFunc_SWIGUpcast(long var0);

    public static final native long btSphereSphereCollisionAlgorithm_SWIGUpcast(long var0);

    public static final native long btBoxBoxCollisionAlgorithm_CreateFunc_SWIGUpcast(long var0);

    public static final native long btBoxBoxCollisionAlgorithm_SWIGUpcast(long var0);

    public static final native long btBox2dBox2dCollisionAlgorithm_CreateFunc_SWIGUpcast(long var0);

    public static final native long btBox2dBox2dCollisionAlgorithm_SWIGUpcast(long var0);

    public static final native long btSphereTriangleCollisionAlgorithm_CreateFunc_SWIGUpcast(long var0);

    public static final native long btSphereTriangleCollisionAlgorithm_SWIGUpcast(long var0);

    public static final native long btGhostObject_SWIGUpcast(long var0);

    public static final native long btPairCachingGhostObject_SWIGUpcast(long var0);

    public static final native long btGhostPairCallback_SWIGUpcast(long var0);

    public static final native long ClosestRayResultCallback_SWIGUpcast(long var0);

    public static final native long AllHitsRayResultCallback_SWIGUpcast(long var0);

    public static final native long ClosestConvexResultCallback_SWIGUpcast(long var0);

    public static final native long ClosestNotMeConvexResultCallback_SWIGUpcast(long var0);

    public static final native long ClosestNotMeRayResultCallback_SWIGUpcast(long var0);

    public static final native long btConvex2dConvex2dAlgorithm_CreateFunc_SWIGUpcast(long var0);

    public static final native long btConvex2dConvex2dAlgorithm_SWIGUpcast(long var0);

    public static final native long btBoxBoxDetector_SWIGUpcast(long var0);

    public static final native long btSphereBoxCollisionAlgorithm_CreateFunc_SWIGUpcast(long var0);

    public static final native long btSphereBoxCollisionAlgorithm_SWIGUpcast(long var0);

    public static final native long btCollisionDispatcher_SWIGUpcast(long var0);

    public static final native long btCollisionDispatcherMt_SWIGUpcast(long var0);

    public static final native long btConvexConvexAlgorithm_CreateFunc_SWIGUpcast(long var0);

    public static final native long btConvexConvexAlgorithm_SWIGUpcast(long var0);

    public static final native long SphereTriangleDetector_SWIGUpcast(long var0);

    public static final native long btSubsimplexConvexCast_SWIGUpcast(long var0);

    public static final native long btPersistentManifold_SWIGUpcast(long var0);

    public static final native long btGjkPairDetector_SWIGUpcast(long var0);

    public static final native long btMinkowskiPenetrationDepthSolver_SWIGUpcast(long var0);

    public static final native long btGjkConvexCast_SWIGUpcast(long var0);

    public static final native long btContinuousConvexCollision_SWIGUpcast(long var0);

    public static final native long btTriangleRaycastCallback_SWIGUpcast(long var0);

    public static final native long btTriangleConvexcastCallback_SWIGUpcast(long var0);

    public static final native long btGjkEpaPenetrationDepthSolver_SWIGUpcast(long var0);

    public static final native long btPointCollector_SWIGUpcast(long var0);

    public static final native long btMultiSphereShape_SWIGUpcast(long var0);

    public static final native long CustomCollisionDispatcher_SWIGUpcast(long var0);

    public static final native long btTriangleShapeEx_SWIGUpcast(long var0);

    public static final native long btPairSet_SWIGUpcast(long var0);

    public static final native long GIM_BVH_DATA_ARRAY_SWIGUpcast(long var0);

    public static final native long GIM_BVH_TREE_NODE_ARRAY_SWIGUpcast(long var0);

    public static final native long GIM_QUANTIZED_BVH_NODE_ARRAY_SWIGUpcast(long var0);

    public static final native long btTetrahedronShapeEx_SWIGUpcast(long var0);

    public static final native long btGImpactShapeInterface_SWIGUpcast(long var0);

    public static final native long btGImpactCompoundShape_CompoundPrimitiveManager_SWIGUpcast(long var0);

    public static final native long btGImpactCompoundShape_SWIGUpcast(long var0);

    public static final native long btGImpactMeshShapePart_TrimeshPrimitiveManager_SWIGUpcast(long var0);

    public static final native long btGImpactMeshShapePart_SWIGUpcast(long var0);

    public static final native long btGImpactMeshShape_SWIGUpcast(long var0);

    public static final native long btContactArray_SWIGUpcast(long var0);

    public static final native long btCompoundFromGimpactShape_SWIGUpcast(long var0);

    public static final native long MyCallback_SWIGUpcast(long var0);

    public static final native long MyInternalTriangleIndexCallback_SWIGUpcast(long var0);

    public static final native long btGImpactCollisionAlgorithm_CreateFunc_SWIGUpcast(long var0);

    public static final native long btGImpactCollisionAlgorithm_SWIGUpcast(long var0);

    public static final native long gim_contact_array_SWIGUpcast(long var0);

    public static boolean SwigDirector_btBroadphaseAabbCallback_process(btBroadphaseAabbCallback jself, long proxy) {
        return jself.process(proxy == 0L ? null : new btBroadphaseProxy(proxy, false));
    }

    public static boolean SwigDirector_btBroadphaseRayCallback_process(btBroadphaseRayCallback jself, long proxy) {
        return jself.process(proxy == 0L ? null : new btBroadphaseProxy(proxy, false));
    }

    public static void SwigDirector_btNodeOverlapCallback_processNode(btNodeOverlapCallback jself, int subPart, int triangleIndex) {
        jself.processNode(subPart, triangleIndex);
    }

    public static boolean SwigDirector_btOverlapCallback_processOverlap(btOverlapCallback jself, btBroadphasePair pair) {
        return jself.processOverlap(pair);
    }

    public static boolean SwigDirector_btOverlapFilterCallback_needBroadphaseCollision(btOverlapFilterCallback jself, long proxy0, long proxy1) {
        return jself.needBroadphaseCollision(proxy0 == 0L ? null : new btBroadphaseProxy(proxy0, false), proxy1 == 0L ? null : new btBroadphaseProxy(proxy1, false));
    }

    public static void SwigDirector_btTriangleCallback_processTriangle(btTriangleCallback jself, long triangle, int partId, int triangleIndex) {
        jself.processTriangle(triangle == 0L ? null : new btVector3(triangle, false), partId, triangleIndex);
    }

    public static void SwigDirector_btInternalTriangleIndexCallback_internalProcessTriangleIndex(btInternalTriangleIndexCallback jself, long triangle, int partId, int triangleIndex) {
        jself.internalProcessTriangleIndex(triangle == 0L ? null : new btVector3(triangle, false), partId, triangleIndex);
    }

    public static void SwigDirector_ICollide_Process__SWIG_0(ICollide jself, long arg0, long arg1) {
        jself.Process(btDbvtNode.obtainForArgument(arg0, false), btDbvtNode.obtainForArgument(arg1, false));
    }

    public static void SwigDirector_ICollide_Process__SWIG_1(ICollide jself, long arg0) {
        jself.Process(btDbvtNode.obtainForArgument(arg0, false));
    }

    public static void SwigDirector_ICollide_Process__SWIG_2(ICollide jself, long n, float arg1) {
        jself.Process(btDbvtNode.obtainForArgument(n, false), arg1);
    }

    public static boolean SwigDirector_ICollide_Descent(ICollide jself, long arg0) {
        return jself.Descent(btDbvtNode.obtainForArgument(arg0, false));
    }

    public static boolean SwigDirector_ICollide_AllLeaves(ICollide jself, long arg0) {
        return jself.AllLeaves(btDbvtNode.obtainForArgument(arg0, false));
    }

    public static void SwigDirector_btConvexTriangleCallback_processTriangle(btConvexTriangleCallback jself, long triangle, int partId, int triangleIndex) {
        jself.processTriangle(triangle == 0L ? null : new btVector3(triangle, false), partId, triangleIndex);
    }

    public static long SwigDirector_btGhostPairCallback_removeOverlappingPair(btGhostPairCallback jself, long proxy0, long proxy1, long dispatcher) {
        return jself.removeOverlappingPair(proxy0 == 0L ? null : new btBroadphaseProxy(proxy0, false), proxy1 == 0L ? null : new btBroadphaseProxy(proxy1, false), dispatcher == 0L ? null : new btDispatcher(dispatcher, false));
    }

    public static void SwigDirector_btGhostPairCallback_removeOverlappingPairsContainingProxy(btGhostPairCallback jself, long arg0, long arg1) {
        jself.removeOverlappingPairsContainingProxy(arg0 == 0L ? null : new btBroadphaseProxy(arg0, false), arg1 == 0L ? null : new btDispatcher(arg1, false));
    }

    public static boolean SwigDirector_RayResultCallback_needsCollision(RayResultCallback jself, long proxy0) {
        return jself.needsCollision(proxy0 == 0L ? null : new btBroadphaseProxy(proxy0, false));
    }

    public static float SwigDirector_RayResultCallback_addSingleResult(RayResultCallback jself, long rayResult, boolean normalInWorldSpace) {
        return jself.addSingleResult(new LocalRayResult(rayResult, false), normalInWorldSpace);
    }

    public static boolean SwigDirector_ClosestRayResultCallback_needsCollision(ClosestRayResultCallback jself, long proxy0) {
        return jself.needsCollision(proxy0 == 0L ? null : new btBroadphaseProxy(proxy0, false));
    }

    public static float SwigDirector_ClosestRayResultCallback_addSingleResult(ClosestRayResultCallback jself, long rayResult, boolean normalInWorldSpace) {
        return jself.addSingleResult(new LocalRayResult(rayResult, false), normalInWorldSpace);
    }

    public static boolean SwigDirector_AllHitsRayResultCallback_needsCollision(AllHitsRayResultCallback jself, long proxy0) {
        return jself.needsCollision(proxy0 == 0L ? null : new btBroadphaseProxy(proxy0, false));
    }

    public static float SwigDirector_AllHitsRayResultCallback_addSingleResult(AllHitsRayResultCallback jself, long rayResult, boolean normalInWorldSpace) {
        return jself.addSingleResult(new LocalRayResult(rayResult, false), normalInWorldSpace);
    }

    public static boolean SwigDirector_ConvexResultCallback_needsCollision(ConvexResultCallback jself, long proxy0) {
        return jself.needsCollision(proxy0 == 0L ? null : new btBroadphaseProxy(proxy0, false));
    }

    public static float SwigDirector_ConvexResultCallback_addSingleResult(ConvexResultCallback jself, long convexResult, boolean normalInWorldSpace) {
        return jself.addSingleResult(new LocalConvexResult(convexResult, false), normalInWorldSpace);
    }

    public static boolean SwigDirector_ClosestConvexResultCallback_needsCollision(ClosestConvexResultCallback jself, long proxy0) {
        return jself.needsCollision(proxy0 == 0L ? null : new btBroadphaseProxy(proxy0, false));
    }

    public static float SwigDirector_ClosestConvexResultCallback_addSingleResult(ClosestConvexResultCallback jself, long convexResult, boolean normalInWorldSpace) {
        return jself.addSingleResult(new LocalConvexResult(convexResult, false), normalInWorldSpace);
    }

    public static boolean SwigDirector_ContactResultCallback_needsCollision(ContactResultCallback jself, long proxy0) {
        return jself.needsCollision(proxy0 == 0L ? null : new btBroadphaseProxy(proxy0, false));
    }

    public static float SwigDirector_ContactResultCallback_addSingleResult(ContactResultCallback jself, long cp, long colObj0Wrap, int partId0, int index0, long colObj1Wrap, int partId1, int index1) {
        return jself.addSingleResult(new btManifoldPoint(cp, false), btCollisionObjectWrapper.obtainForArgument(colObj0Wrap, false), partId0, index0, btCollisionObjectWrapper.obtainForArgument(colObj1Wrap, false), partId1, index1);
    }

    public static void SwigDirector_btTriangleRaycastCallback_processTriangle(btTriangleRaycastCallback jself, long triangle, int partId, int triangleIndex) {
        jself.processTriangle(triangle == 0L ? null : new btVector3(triangle, false), partId, triangleIndex);
    }

    public static float SwigDirector_btTriangleRaycastCallback_reportHit(btTriangleRaycastCallback jself, Vector3 hitNormalLocal, float hitFraction, int partId, int triangleIndex) {
        return jself.reportHit(hitNormalLocal, hitFraction, partId, triangleIndex);
    }

    public static void SwigDirector_btTriangleConvexcastCallback_processTriangle(btTriangleConvexcastCallback jself, long triangle, int partId, int triangleIndex) {
        jself.processTriangle(triangle == 0L ? null : new btVector3(triangle, false), partId, triangleIndex);
    }

    public static float SwigDirector_btTriangleConvexcastCallback_reportHit(btTriangleConvexcastCallback jself, Vector3 hitNormalLocal, Vector3 hitPointLocal, float hitFraction, int partId, int triangleIndex) {
        return jself.reportHit(hitNormalLocal, hitPointLocal, hitFraction, partId, triangleIndex);
    }

    public static boolean SwigDirector_CustomCollisionDispatcher_needsCollision(CustomCollisionDispatcher jself, long body0, long body1) {
        return jself.needsCollision(btCollisionObject.getInstance(body0, false), btCollisionObject.getInstance(body1, false));
    }

    public static boolean SwigDirector_CustomCollisionDispatcher_needsResponse(CustomCollisionDispatcher jself, long body0, long body1) {
        return jself.needsResponse(btCollisionObject.getInstance(body0, false), btCollisionObject.getInstance(body1, false));
    }

    public static boolean SwigDirector_ContactListener_onContactAdded__SWIG_0(ContactListener jself, long cp, long colObj0Wrap, int partId0, int index0, long colObj1Wrap, int partId1, int index1) {
        return jself.onContactAdded(btManifoldPoint.obtainForArgument(cp, false), btCollisionObjectWrapper.obtainForArgument(colObj0Wrap, false), partId0, index0, btCollisionObjectWrapper.obtainForArgument(colObj1Wrap, false), partId1, index1);
    }

    public static boolean SwigDirector_ContactListener_onContactAdded__SWIG_1(ContactListener jself, long cp, long colObj0, int partId0, int index0, long colObj1, int partId1, int index1) {
        return jself.onContactAdded(btManifoldPoint.obtainForArgument(cp, false), btCollisionObject.getInstance(colObj0, false), partId0, index0, btCollisionObject.getInstance(colObj1, false), partId1, index1);
    }

    public static boolean SwigDirector_ContactListener_onContactAdded__SWIG_2(ContactListener jself, long cp, int userValue0, int partId0, int index0, int userValue1, int partId1, int index1) {
        return jself.onContactAdded(btManifoldPoint.obtainForArgument(cp, false), userValue0, partId0, index0, userValue1, partId1, index1);
    }

    public static boolean SwigDirector_ContactListener_onContactAdded__SWIG_3(ContactListener jself, long cp, long colObj0Wrap, int partId0, int index0, boolean match0, long colObj1Wrap, int partId1, int index1, boolean match1) {
        return jself.onContactAdded(btManifoldPoint.obtainForArgument(cp, false), btCollisionObjectWrapper.obtainForArgument(colObj0Wrap, false), partId0, index0, match0, btCollisionObjectWrapper.obtainForArgument(colObj1Wrap, false), partId1, index1, match1);
    }

    public static boolean SwigDirector_ContactListener_onContactAdded__SWIG_4(ContactListener jself, long cp, long colObj0, int partId0, int index0, boolean match0, long colObj1, int partId1, int index1, boolean match1) {
        return jself.onContactAdded(btManifoldPoint.obtainForArgument(cp, false), btCollisionObject.getInstance(colObj0, false), partId0, index0, match0, btCollisionObject.getInstance(colObj1, false), partId1, index1, match1);
    }

    public static boolean SwigDirector_ContactListener_onContactAdded__SWIG_5(ContactListener jself, long cp, int userValue0, int partId0, int index0, boolean match0, int userValue1, int partId1, int index1, boolean match1) {
        return jself.onContactAdded(btManifoldPoint.obtainForArgument(cp, false), userValue0, partId0, index0, match0, userValue1, partId1, index1, match1);
    }

    public static boolean SwigDirector_ContactListener_onContactAdded__SWIG_6(ContactListener jself, long colObj0Wrap, int partId0, int index0, long colObj1Wrap, int partId1, int index1) {
        return jself.onContactAdded(btCollisionObjectWrapper.obtainForArgument(colObj0Wrap, false), partId0, index0, btCollisionObjectWrapper.obtainForArgument(colObj1Wrap, false), partId1, index1);
    }

    public static boolean SwigDirector_ContactListener_onContactAdded__SWIG_7(ContactListener jself, long colObj0, int partId0, int index0, long colObj1, int partId1, int index1) {
        return jself.onContactAdded(btCollisionObject.getInstance(colObj0, false), partId0, index0, btCollisionObject.getInstance(colObj1, false), partId1, index1);
    }

    public static boolean SwigDirector_ContactListener_onContactAdded__SWIG_8(ContactListener jself, int userValue0, int partId0, int index0, int userValue1, int partId1, int index1) {
        return jself.onContactAdded(userValue0, partId0, index0, userValue1, partId1, index1);
    }

    public static boolean SwigDirector_ContactListener_onContactAdded__SWIG_9(ContactListener jself, long colObj0Wrap, int partId0, int index0, boolean match0, long colObj1Wrap, int partId1, int index1, boolean match1) {
        return jself.onContactAdded(btCollisionObjectWrapper.obtainForArgument(colObj0Wrap, false), partId0, index0, match0, btCollisionObjectWrapper.obtainForArgument(colObj1Wrap, false), partId1, index1, match1);
    }

    public static boolean SwigDirector_ContactListener_onContactAdded__SWIG_10(ContactListener jself, long colObj0, int partId0, int index0, boolean match0, long colObj1, int partId1, int index1, boolean match1) {
        return jself.onContactAdded(btCollisionObject.getInstance(colObj0, false), partId0, index0, match0, btCollisionObject.getInstance(colObj1, false), partId1, index1, match1);
    }

    public static boolean SwigDirector_ContactListener_onContactAdded__SWIG_11(ContactListener jself, int userValue0, int partId0, int index0, boolean match0, int userValue1, int partId1, int index1, boolean match1) {
        return jself.onContactAdded(userValue0, partId0, index0, match0, userValue1, partId1, index1, match1);
    }

    public static void SwigDirector_ContactListener_onContactProcessed__SWIG_0(ContactListener jself, long cp, long colObj0, long colObj1) {
        jself.onContactProcessed(btManifoldPoint.obtainForArgument(cp, false), btCollisionObject.getInstance(colObj0, false), btCollisionObject.getInstance(colObj1, false));
    }

    public static void SwigDirector_ContactListener_onContactProcessed__SWIG_1(ContactListener jself, long cp, int userValue0, int userValue1) {
        jself.onContactProcessed(btManifoldPoint.obtainForArgument(cp, false), userValue0, userValue1);
    }

    public static void SwigDirector_ContactListener_onContactProcessed__SWIG_2(ContactListener jself, long cp, long colObj0, boolean match0, long colObj1, boolean match1) {
        jself.onContactProcessed(btManifoldPoint.obtainForArgument(cp, false), btCollisionObject.getInstance(colObj0, false), match0, btCollisionObject.getInstance(colObj1, false), match1);
    }

    public static void SwigDirector_ContactListener_onContactProcessed__SWIG_3(ContactListener jself, long cp, int userValue0, boolean match0, int userValue1, boolean match1) {
        jself.onContactProcessed(btManifoldPoint.obtainForArgument(cp, false), userValue0, match0, userValue1, match1);
    }

    public static void SwigDirector_ContactListener_onContactProcessed__SWIG_4(ContactListener jself, long colObj0, long colObj1) {
        jself.onContactProcessed(btCollisionObject.getInstance(colObj0, false), btCollisionObject.getInstance(colObj1, false));
    }

    public static void SwigDirector_ContactListener_onContactProcessed__SWIG_5(ContactListener jself, int userValue0, int userValue1) {
        jself.onContactProcessed(userValue0, userValue1);
    }

    public static void SwigDirector_ContactListener_onContactProcessed__SWIG_6(ContactListener jself, long colObj0, boolean match0, long colObj1, boolean match1) {
        jself.onContactProcessed(btCollisionObject.getInstance(colObj0, false), match0, btCollisionObject.getInstance(colObj1, false), match1);
    }

    public static void SwigDirector_ContactListener_onContactProcessed__SWIG_7(ContactListener jself, int userValue0, boolean match0, int userValue1, boolean match1) {
        jself.onContactProcessed(userValue0, match0, userValue1, match1);
    }

    public static void SwigDirector_ContactListener_onContactDestroyed(ContactListener jself, int manifoldPointUserValue) {
        jself.onContactDestroyed(manifoldPointUserValue);
    }

    public static void SwigDirector_ContactListener_onContactStarted__SWIG_0(ContactListener jself, long manifold) {
        jself.onContactStarted(manifold == 0L ? null : new btPersistentManifold(manifold, false));
    }

    public static void SwigDirector_ContactListener_onContactStarted__SWIG_1(ContactListener jself, long colObj0, long colObj1) {
        jself.onContactStarted(btCollisionObject.getInstance(colObj0, false), btCollisionObject.getInstance(colObj1, false));
    }

    public static void SwigDirector_ContactListener_onContactStarted__SWIG_2(ContactListener jself, int userValue0, int userValue1) {
        jself.onContactStarted(userValue0, userValue1);
    }

    public static void SwigDirector_ContactListener_onContactStarted__SWIG_3(ContactListener jself, long manifold, boolean match0, boolean match1) {
        jself.onContactStarted(manifold == 0L ? null : new btPersistentManifold(manifold, false), match0, match1);
    }

    public static void SwigDirector_ContactListener_onContactStarted__SWIG_4(ContactListener jself, long colObj0, boolean match0, long colObj1, boolean match1) {
        jself.onContactStarted(btCollisionObject.getInstance(colObj0, false), match0, btCollisionObject.getInstance(colObj1, false), match1);
    }

    public static void SwigDirector_ContactListener_onContactStarted__SWIG_5(ContactListener jself, int userValue0, boolean match0, int userValue1, boolean match1) {
        jself.onContactStarted(userValue0, match0, userValue1, match1);
    }

    public static void SwigDirector_ContactListener_onContactEnded__SWIG_0(ContactListener jself, long manifold) {
        jself.onContactEnded(manifold == 0L ? null : new btPersistentManifold(manifold, false));
    }

    public static void SwigDirector_ContactListener_onContactEnded__SWIG_1(ContactListener jself, long colObj0, long colObj1) {
        jself.onContactEnded(btCollisionObject.getInstance(colObj0, false), btCollisionObject.getInstance(colObj1, false));
    }

    public static void SwigDirector_ContactListener_onContactEnded__SWIG_2(ContactListener jself, int userValue0, int userValue1) {
        jself.onContactEnded(userValue0, userValue1);
    }

    public static void SwigDirector_ContactListener_onContactEnded__SWIG_3(ContactListener jself, long manifold, boolean match0, boolean match1) {
        jself.onContactEnded(manifold == 0L ? null : new btPersistentManifold(manifold, false), match0, match1);
    }

    public static void SwigDirector_ContactListener_onContactEnded__SWIG_4(ContactListener jself, long colObj0, boolean match0, long colObj1, boolean match1) {
        jself.onContactEnded(btCollisionObject.getInstance(colObj0, false), match0, btCollisionObject.getInstance(colObj1, false), match1);
    }

    public static void SwigDirector_ContactListener_onContactEnded__SWIG_5(ContactListener jself, int userValue0, boolean match0, int userValue1, boolean match1) {
        jself.onContactEnded(userValue0, match0, userValue1, match1);
    }

    public static void SwigDirector_ContactCache_onContactStarted(ContactCache jself, long manifold, boolean match0, boolean match1) {
        jself.onContactStarted(manifold == 0L ? null : new btPersistentManifold(manifold, false), match0, match1);
    }

    public static void SwigDirector_ContactCache_onContactEnded(ContactCache jself, long colObj0, boolean match0, long colObj1, boolean match1) {
        jself.onContactEnded(btCollisionObject.getInstance(colObj0, false), match0, btCollisionObject.getInstance(colObj1, false), match1);
    }

    private static final native void swig_module_init();

    static {
        CollisionJNI.swig_module_init();
    }
}

