/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.backends.lwjgl;

import com.badlogic.gdx.Input;

public interface LwjglInput
extends Input {
    public void update();

    public void processEvents();
}

