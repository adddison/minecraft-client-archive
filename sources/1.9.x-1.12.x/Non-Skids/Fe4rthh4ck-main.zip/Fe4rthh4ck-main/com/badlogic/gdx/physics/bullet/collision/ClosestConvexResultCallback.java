/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.ConvexResultCallback;
import com.badlogic.gdx.physics.bullet.collision.LocalConvexResult;
import com.badlogic.gdx.physics.bullet.collision.btCollisionObject;
import com.badlogic.gdx.physics.bullet.linearmath.btVector3;

public class ClosestConvexResultCallback
extends ConvexResultCallback {
    private long swigCPtr;

    protected ClosestConvexResultCallback(String className, long cPtr, boolean cMemoryOwn) {
        super(className, CollisionJNI.ClosestConvexResultCallback_SWIGUpcast(cPtr), cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public ClosestConvexResultCallback(long cPtr, boolean cMemoryOwn) {
        this("ClosestConvexResultCallback", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(CollisionJNI.ClosestConvexResultCallback_SWIGUpcast(this.swigCPtr), cMemoryOwn);
    }

    public static long getCPtr(ClosestConvexResultCallback obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_ClosestConvexResultCallback(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    @Override
    protected void swigDirectorDisconnect() {
        this.swigCMemOwn = false;
        this.delete();
    }

    @Override
    public void swigReleaseOwnership() {
        this.swigCMemOwn = false;
        CollisionJNI.ClosestConvexResultCallback_change_ownership(this, this.swigCPtr, false);
    }

    @Override
    public void swigTakeOwnership() {
        this.swigCMemOwn = true;
        CollisionJNI.ClosestConvexResultCallback_change_ownership(this, this.swigCPtr, true);
    }

    public ClosestConvexResultCallback(Vector3 convexFromWorld, Vector3 convexToWorld) {
        this(CollisionJNI.new_ClosestConvexResultCallback(convexFromWorld, convexToWorld), true);
        CollisionJNI.ClosestConvexResultCallback_director_connect(this, this.swigCPtr, this.swigCMemOwn, true);
    }

    public void setConvexFromWorld(btVector3 value) {
        CollisionJNI.ClosestConvexResultCallback_convexFromWorld_set(this.swigCPtr, this, btVector3.getCPtr(value), value);
    }

    public btVector3 getConvexFromWorld() {
        long cPtr = CollisionJNI.ClosestConvexResultCallback_convexFromWorld_get(this.swigCPtr, this);
        return cPtr == 0L ? null : new btVector3(cPtr, false);
    }

    public void setConvexToWorld(btVector3 value) {
        CollisionJNI.ClosestConvexResultCallback_convexToWorld_set(this.swigCPtr, this, btVector3.getCPtr(value), value);
    }

    public btVector3 getConvexToWorld() {
        long cPtr = CollisionJNI.ClosestConvexResultCallback_convexToWorld_get(this.swigCPtr, this);
        return cPtr == 0L ? null : new btVector3(cPtr, false);
    }

    public void setHitCollisionObject(btCollisionObject value) {
        CollisionJNI.ClosestConvexResultCallback_hitCollisionObject_set(this.swigCPtr, this, btCollisionObject.getCPtr(value), value);
    }

    public btCollisionObject getHitCollisionObject() {
        return btCollisionObject.getInstance(CollisionJNI.ClosestConvexResultCallback_hitCollisionObject_get(this.swigCPtr, this), false);
    }

    @Override
    public float addSingleResult(LocalConvexResult convexResult, boolean normalInWorldSpace) {
        return this.getClass() == ClosestConvexResultCallback.class ? CollisionJNI.ClosestConvexResultCallback_addSingleResult(this.swigCPtr, this, LocalConvexResult.getCPtr(convexResult), convexResult, normalInWorldSpace) : CollisionJNI.ClosestConvexResultCallback_addSingleResultSwigExplicitClosestConvexResultCallback(this.swigCPtr, this, LocalConvexResult.getCPtr(convexResult), convexResult, normalInWorldSpace);
    }

    public void getConvexFromWorld(Vector3 out) {
        CollisionJNI.ClosestConvexResultCallback_getConvexFromWorld(this.swigCPtr, this, out);
    }

    public void setRayFromWorld(Vector3 value) {
        CollisionJNI.ClosestConvexResultCallback_setRayFromWorld(this.swigCPtr, this, value);
    }

    public void getConvexToWorld(Vector3 out) {
        CollisionJNI.ClosestConvexResultCallback_getConvexToWorld(this.swigCPtr, this, out);
    }

    public void setConvexToWorld(Vector3 value) {
        CollisionJNI.ClosestConvexResultCallback_setConvexToWorld(this.swigCPtr, this, value);
    }

    public void getHitNormalWorld(Vector3 out) {
        CollisionJNI.ClosestConvexResultCallback_getHitNormalWorld(this.swigCPtr, this, out);
    }

    public void setHitNormalWorld(Vector3 value) {
        CollisionJNI.ClosestConvexResultCallback_setHitNormalWorld(this.swigCPtr, this, value);
    }

    public void getHitPointWorld(Vector3 out) {
        CollisionJNI.ClosestConvexResultCallback_getHitPointWorld(this.swigCPtr, this, out);
    }

    public void setHitPointWorld(Vector3 value) {
        CollisionJNI.ClosestConvexResultCallback_setHitPointWorld(this.swigCPtr, this, value);
    }
}

