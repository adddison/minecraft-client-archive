/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.graphics.g3d.model.data;

public class ModelNodeKeyframe<T> {
    public float keytime;
    public T value = null;
}

