/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.btBoxShape;
import com.badlogic.gdx.physics.bullet.collision.btDiscreteCollisionDetectorInterface;
import com.badlogic.gdx.physics.bullet.linearmath.btIDebugDraw;

public class btBoxBoxDetector
extends btDiscreteCollisionDetectorInterface {
    private long swigCPtr;

    protected btBoxBoxDetector(String className, long cPtr, boolean cMemoryOwn) {
        super(className, CollisionJNI.btBoxBoxDetector_SWIGUpcast(cPtr), cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public btBoxBoxDetector(long cPtr, boolean cMemoryOwn) {
        this("btBoxBoxDetector", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(CollisionJNI.btBoxBoxDetector_SWIGUpcast(this.swigCPtr), cMemoryOwn);
    }

    public static long getCPtr(btBoxBoxDetector obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_btBoxBoxDetector(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public void setBox1(btBoxShape value) {
        CollisionJNI.btBoxBoxDetector_box1_set(this.swigCPtr, this, btBoxShape.getCPtr(value), value);
    }

    public btBoxShape getBox1() {
        long cPtr = CollisionJNI.btBoxBoxDetector_box1_get(this.swigCPtr, this);
        return cPtr == 0L ? null : new btBoxShape(cPtr, false);
    }

    public void setBox2(btBoxShape value) {
        CollisionJNI.btBoxBoxDetector_box2_set(this.swigCPtr, this, btBoxShape.getCPtr(value), value);
    }

    public btBoxShape getBox2() {
        long cPtr = CollisionJNI.btBoxBoxDetector_box2_get(this.swigCPtr, this);
        return cPtr == 0L ? null : new btBoxShape(cPtr, false);
    }

    public btBoxBoxDetector(btBoxShape box1, btBoxShape box2) {
        this(CollisionJNI.new_btBoxBoxDetector(btBoxShape.getCPtr(box1), box1, btBoxShape.getCPtr(box2), box2), true);
    }

    @Override
    public void getClosestPoints(btDiscreteCollisionDetectorInterface.ClosestPointInput input, btDiscreteCollisionDetectorInterface.Result output, btIDebugDraw debugDraw, boolean swapResults) {
        CollisionJNI.btBoxBoxDetector_getClosestPoints__SWIG_0(this.swigCPtr, this, btDiscreteCollisionDetectorInterface.ClosestPointInput.getCPtr(input), input, btDiscreteCollisionDetectorInterface.Result.getCPtr(output), output, btIDebugDraw.getCPtr(debugDraw), debugDraw, swapResults);
    }

    @Override
    public void getClosestPoints(btDiscreteCollisionDetectorInterface.ClosestPointInput input, btDiscreteCollisionDetectorInterface.Result output, btIDebugDraw debugDraw) {
        CollisionJNI.btBoxBoxDetector_getClosestPoints__SWIG_1(this.swigCPtr, this, btDiscreteCollisionDetectorInterface.ClosestPointInput.getCPtr(input), input, btDiscreteCollisionDetectorInterface.Result.getCPtr(output), output, btIDebugDraw.getCPtr(debugDraw), debugDraw);
    }
}

