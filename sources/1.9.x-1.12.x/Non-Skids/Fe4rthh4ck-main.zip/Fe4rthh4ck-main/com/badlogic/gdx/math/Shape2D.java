/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.math;

import com.badlogic.gdx.math.Vector2;

public interface Shape2D {
    public boolean contains(Vector2 var1);

    public boolean contains(float var1, float var2);
}

