/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.physics.bullet.BulletBase;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;

public class LocalShapeInfo
extends BulletBase {
    private long swigCPtr;

    protected LocalShapeInfo(String className, long cPtr, boolean cMemoryOwn) {
        super(className, cPtr, cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public LocalShapeInfo(long cPtr, boolean cMemoryOwn) {
        this("LocalShapeInfo", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(this.swigCPtr, cMemoryOwn);
    }

    public static long getCPtr(LocalShapeInfo obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_LocalShapeInfo(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public void setShapePart(int value) {
        CollisionJNI.LocalShapeInfo_shapePart_set(this.swigCPtr, this, value);
    }

    public int getShapePart() {
        return CollisionJNI.LocalShapeInfo_shapePart_get(this.swigCPtr, this);
    }

    public void setTriangleIndex(int value) {
        CollisionJNI.LocalShapeInfo_triangleIndex_set(this.swigCPtr, this, value);
    }

    public int getTriangleIndex() {
        return CollisionJNI.LocalShapeInfo_triangleIndex_get(this.swigCPtr, this);
    }

    public LocalShapeInfo() {
        this(CollisionJNI.new_LocalShapeInfo(), true);
    }
}

