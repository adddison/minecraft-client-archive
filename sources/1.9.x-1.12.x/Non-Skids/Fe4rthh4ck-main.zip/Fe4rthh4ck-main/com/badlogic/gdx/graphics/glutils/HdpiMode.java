/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.graphics.glutils;

public enum HdpiMode {
    Logical,
    Pixels;

}

