/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.assets.loaders;

import com.badlogic.gdx.files.FileHandle;

public interface FileHandleResolver {
    public FileHandle resolve(String var1);
}

