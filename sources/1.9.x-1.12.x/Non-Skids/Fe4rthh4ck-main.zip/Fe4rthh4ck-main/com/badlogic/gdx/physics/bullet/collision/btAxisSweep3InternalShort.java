/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.bullet.BulletBase;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.btBroadphaseInterface;
import com.badlogic.gdx.physics.bullet.collision.btBroadphaseProxy;
import com.badlogic.gdx.physics.bullet.collision.btBroadphaseRayCallback;
import com.badlogic.gdx.physics.bullet.collision.btDispatcher;
import com.badlogic.gdx.physics.bullet.collision.btOverlappingPairCache;
import com.badlogic.gdx.physics.bullet.collision.btOverlappingPairCallback;
import java.nio.IntBuffer;

public class btAxisSweep3InternalShort
extends btBroadphaseInterface {
    private long swigCPtr;

    protected btAxisSweep3InternalShort(String className, long cPtr, boolean cMemoryOwn) {
        super(className, CollisionJNI.btAxisSweep3InternalShort_SWIGUpcast(cPtr), cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public btAxisSweep3InternalShort(long cPtr, boolean cMemoryOwn) {
        this("btAxisSweep3InternalShort", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(CollisionJNI.btAxisSweep3InternalShort_SWIGUpcast(this.swigCPtr), cMemoryOwn);
    }

    public static long getCPtr(btAxisSweep3InternalShort obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_btAxisSweep3InternalShort(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public long operatorNew(long sizeInBytes) {
        return CollisionJNI.btAxisSweep3InternalShort_operatorNew__SWIG_0(this.swigCPtr, this, sizeInBytes);
    }

    public void operatorDelete(long ptr) {
        CollisionJNI.btAxisSweep3InternalShort_operatorDelete__SWIG_0(this.swigCPtr, this, ptr);
    }

    public long operatorNew(long arg0, long ptr) {
        return CollisionJNI.btAxisSweep3InternalShort_operatorNew__SWIG_1(this.swigCPtr, this, arg0, ptr);
    }

    public void operatorDelete(long arg0, long arg1) {
        CollisionJNI.btAxisSweep3InternalShort_operatorDelete__SWIG_1(this.swigCPtr, this, arg0, arg1);
    }

    public long operatorNewArray(long sizeInBytes) {
        return CollisionJNI.btAxisSweep3InternalShort_operatorNewArray__SWIG_0(this.swigCPtr, this, sizeInBytes);
    }

    public void operatorDeleteArray(long ptr) {
        CollisionJNI.btAxisSweep3InternalShort_operatorDeleteArray__SWIG_0(this.swigCPtr, this, ptr);
    }

    public long operatorNewArray(long arg0, long ptr) {
        return CollisionJNI.btAxisSweep3InternalShort_operatorNewArray__SWIG_1(this.swigCPtr, this, arg0, ptr);
    }

    public void operatorDeleteArray(long arg0, long arg1) {
        CollisionJNI.btAxisSweep3InternalShort_operatorDeleteArray__SWIG_1(this.swigCPtr, this, arg0, arg1);
    }

    public btAxisSweep3InternalShort(Vector3 worldAabbMin, Vector3 worldAabbMax, int handleMask, int handleSentinel, int maxHandles, btOverlappingPairCache pairCache, boolean disableRaycastAccelerator) {
        this(CollisionJNI.new_btAxisSweep3InternalShort__SWIG_0(worldAabbMin, worldAabbMax, handleMask, handleSentinel, maxHandles, btOverlappingPairCache.getCPtr(pairCache), pairCache, disableRaycastAccelerator), true);
    }

    public btAxisSweep3InternalShort(Vector3 worldAabbMin, Vector3 worldAabbMax, int handleMask, int handleSentinel, int maxHandles, btOverlappingPairCache pairCache) {
        this(CollisionJNI.new_btAxisSweep3InternalShort__SWIG_1(worldAabbMin, worldAabbMax, handleMask, handleSentinel, maxHandles, btOverlappingPairCache.getCPtr(pairCache), pairCache), true);
    }

    public btAxisSweep3InternalShort(Vector3 worldAabbMin, Vector3 worldAabbMax, int handleMask, int handleSentinel, int maxHandles) {
        this(CollisionJNI.new_btAxisSweep3InternalShort__SWIG_2(worldAabbMin, worldAabbMax, handleMask, handleSentinel, maxHandles), true);
    }

    public btAxisSweep3InternalShort(Vector3 worldAabbMin, Vector3 worldAabbMax, int handleMask, int handleSentinel) {
        this(CollisionJNI.new_btAxisSweep3InternalShort__SWIG_3(worldAabbMin, worldAabbMax, handleMask, handleSentinel), true);
    }

    public int getNumHandles() {
        return CollisionJNI.btAxisSweep3InternalShort_getNumHandles(this.swigCPtr, this);
    }

    public int addHandle(Vector3 aabbMin, Vector3 aabbMax, long pOwner, int collisionFilterGroup, int collisionFilterMask, btDispatcher dispatcher) {
        return CollisionJNI.btAxisSweep3InternalShort_addHandle(this.swigCPtr, this, aabbMin, aabbMax, pOwner, collisionFilterGroup, collisionFilterMask, btDispatcher.getCPtr(dispatcher), dispatcher);
    }

    public void removeHandle(int handle, btDispatcher dispatcher) {
        CollisionJNI.btAxisSweep3InternalShort_removeHandle(this.swigCPtr, this, handle, btDispatcher.getCPtr(dispatcher), dispatcher);
    }

    public void updateHandle(int handle, Vector3 aabbMin, Vector3 aabbMax, btDispatcher dispatcher) {
        CollisionJNI.btAxisSweep3InternalShort_updateHandle(this.swigCPtr, this, handle, aabbMin, aabbMax, btDispatcher.getCPtr(dispatcher), dispatcher);
    }

    public Handle getHandle(int index) {
        long cPtr = CollisionJNI.btAxisSweep3InternalShort_getHandle(this.swigCPtr, this, index);
        return cPtr == 0L ? null : new Handle(cPtr, false);
    }

    @Override
    public void rayTest(Vector3 rayFrom, Vector3 rayTo, btBroadphaseRayCallback rayCallback, Vector3 aabbMin, Vector3 aabbMax) {
        CollisionJNI.btAxisSweep3InternalShort_rayTest__SWIG_0(this.swigCPtr, this, rayFrom, rayTo, btBroadphaseRayCallback.getCPtr(rayCallback), rayCallback, aabbMin, aabbMax);
    }

    @Override
    public void rayTest(Vector3 rayFrom, Vector3 rayTo, btBroadphaseRayCallback rayCallback, Vector3 aabbMin) {
        CollisionJNI.btAxisSweep3InternalShort_rayTest__SWIG_1(this.swigCPtr, this, rayFrom, rayTo, btBroadphaseRayCallback.getCPtr(rayCallback), rayCallback, aabbMin);
    }

    @Override
    public void rayTest(Vector3 rayFrom, Vector3 rayTo, btBroadphaseRayCallback rayCallback) {
        CollisionJNI.btAxisSweep3InternalShort_rayTest__SWIG_2(this.swigCPtr, this, rayFrom, rayTo, btBroadphaseRayCallback.getCPtr(rayCallback), rayCallback);
    }

    public void quantize(IntBuffer out, Vector3 point, int isMax) {
        assert (out.isDirect()) : "Buffer must be allocated direct.";
        CollisionJNI.btAxisSweep3InternalShort_quantize(this.swigCPtr, this, out, point, isMax);
    }

    public void unQuantize(btBroadphaseProxy proxy, Vector3 aabbMin, Vector3 aabbMax) {
        CollisionJNI.btAxisSweep3InternalShort_unQuantize(this.swigCPtr, this, btBroadphaseProxy.getCPtr(proxy), proxy, aabbMin, aabbMax);
    }

    public boolean testAabbOverlap(btBroadphaseProxy proxy0, btBroadphaseProxy proxy1) {
        return CollisionJNI.btAxisSweep3InternalShort_testAabbOverlap(this.swigCPtr, this, btBroadphaseProxy.getCPtr(proxy0), proxy0, btBroadphaseProxy.getCPtr(proxy1), proxy1);
    }

    public void setOverlappingPairUserCallback(btOverlappingPairCallback pairCallback) {
        CollisionJNI.btAxisSweep3InternalShort_setOverlappingPairUserCallback(this.swigCPtr, this, btOverlappingPairCallback.getCPtr(pairCallback), pairCallback);
    }

    public btOverlappingPairCallback getOverlappingPairUserCallback() {
        long cPtr = CollisionJNI.btAxisSweep3InternalShort_getOverlappingPairUserCallback(this.swigCPtr, this);
        return cPtr == 0L ? null : new btOverlappingPairCallback(cPtr, false);
    }

    public static class Handle
    extends btBroadphaseProxy {
        private long swigCPtr;

        protected Handle(String className, long cPtr, boolean cMemoryOwn) {
            super(className, CollisionJNI.btAxisSweep3InternalShort_Handle_SWIGUpcast(cPtr), cMemoryOwn);
            this.swigCPtr = cPtr;
        }

        public Handle(long cPtr, boolean cMemoryOwn) {
            this("Handle", cPtr, cMemoryOwn);
            this.construct();
        }

        @Override
        protected void reset(long cPtr, boolean cMemoryOwn) {
            if (!this.destroyed) {
                this.destroy();
            }
            this.swigCPtr = cPtr;
            super.reset(CollisionJNI.btAxisSweep3InternalShort_Handle_SWIGUpcast(this.swigCPtr), cMemoryOwn);
        }

        public static long getCPtr(Handle obj) {
            return obj == null ? 0L : obj.swigCPtr;
        }

        @Override
        protected void finalize() throws Throwable {
            if (!this.destroyed) {
                this.destroy();
            }
            super.finalize();
        }

        @Override
        protected synchronized void delete() {
            if (this.swigCPtr != 0L) {
                if (this.swigCMemOwn) {
                    this.swigCMemOwn = false;
                    CollisionJNI.delete_btAxisSweep3InternalShort_Handle(this.swigCPtr);
                }
                this.swigCPtr = 0L;
            }
            super.delete();
        }

        @Override
        public long operatorNew(long sizeInBytes) {
            return CollisionJNI.btAxisSweep3InternalShort_Handle_operatorNew__SWIG_0(this.swigCPtr, this, sizeInBytes);
        }

        @Override
        public void operatorDelete(long ptr) {
            CollisionJNI.btAxisSweep3InternalShort_Handle_operatorDelete__SWIG_0(this.swigCPtr, this, ptr);
        }

        @Override
        public long operatorNew(long arg0, long ptr) {
            return CollisionJNI.btAxisSweep3InternalShort_Handle_operatorNew__SWIG_1(this.swigCPtr, this, arg0, ptr);
        }

        @Override
        public void operatorDelete(long arg0, long arg1) {
            CollisionJNI.btAxisSweep3InternalShort_Handle_operatorDelete__SWIG_1(this.swigCPtr, this, arg0, arg1);
        }

        @Override
        public long operatorNewArray(long sizeInBytes) {
            return CollisionJNI.btAxisSweep3InternalShort_Handle_operatorNewArray__SWIG_0(this.swigCPtr, this, sizeInBytes);
        }

        @Override
        public void operatorDeleteArray(long ptr) {
            CollisionJNI.btAxisSweep3InternalShort_Handle_operatorDeleteArray__SWIG_0(this.swigCPtr, this, ptr);
        }

        @Override
        public long operatorNewArray(long arg0, long ptr) {
            return CollisionJNI.btAxisSweep3InternalShort_Handle_operatorNewArray__SWIG_1(this.swigCPtr, this, arg0, ptr);
        }

        @Override
        public void operatorDeleteArray(long arg0, long arg1) {
            CollisionJNI.btAxisSweep3InternalShort_Handle_operatorDeleteArray__SWIG_1(this.swigCPtr, this, arg0, arg1);
        }

        public void setMinEdges(int[] value) {
            CollisionJNI.btAxisSweep3InternalShort_Handle_minEdges_set(this.swigCPtr, this, value);
        }

        public int[] getMinEdges() {
            return CollisionJNI.btAxisSweep3InternalShort_Handle_minEdges_get(this.swigCPtr, this);
        }

        public void setMaxEdges(int[] value) {
            CollisionJNI.btAxisSweep3InternalShort_Handle_maxEdges_set(this.swigCPtr, this, value);
        }

        public int[] getMaxEdges() {
            return CollisionJNI.btAxisSweep3InternalShort_Handle_maxEdges_get(this.swigCPtr, this);
        }

        public void setDbvtProxy(btBroadphaseProxy value) {
            CollisionJNI.btAxisSweep3InternalShort_Handle_dbvtProxy_set(this.swigCPtr, this, btBroadphaseProxy.getCPtr(value), value);
        }

        public btBroadphaseProxy getDbvtProxy() {
            return btBroadphaseProxy.internalTemp(CollisionJNI.btAxisSweep3InternalShort_Handle_dbvtProxy_get(this.swigCPtr, this), false);
        }

        public void SetNextFree(int next) {
            CollisionJNI.btAxisSweep3InternalShort_Handle_SetNextFree(this.swigCPtr, this, next);
        }

        public int GetNextFree() {
            return CollisionJNI.btAxisSweep3InternalShort_Handle_GetNextFree(this.swigCPtr, this);
        }

        public Handle() {
            this(CollisionJNI.new_btAxisSweep3InternalShort_Handle(), true);
        }
    }

    public static class Edge
    extends BulletBase {
        private long swigCPtr;

        protected Edge(String className, long cPtr, boolean cMemoryOwn) {
            super(className, cPtr, cMemoryOwn);
            this.swigCPtr = cPtr;
        }

        public Edge(long cPtr, boolean cMemoryOwn) {
            this("Edge", cPtr, cMemoryOwn);
            this.construct();
        }

        @Override
        protected void reset(long cPtr, boolean cMemoryOwn) {
            if (!this.destroyed) {
                this.destroy();
            }
            this.swigCPtr = cPtr;
            super.reset(this.swigCPtr, cMemoryOwn);
        }

        public static long getCPtr(Edge obj) {
            return obj == null ? 0L : obj.swigCPtr;
        }

        @Override
        protected void finalize() throws Throwable {
            if (!this.destroyed) {
                this.destroy();
            }
            super.finalize();
        }

        @Override
        protected synchronized void delete() {
            if (this.swigCPtr != 0L) {
                if (this.swigCMemOwn) {
                    this.swigCMemOwn = false;
                    CollisionJNI.delete_btAxisSweep3InternalShort_Edge(this.swigCPtr);
                }
                this.swigCPtr = 0L;
            }
            super.delete();
        }

        public void setPos(int value) {
            CollisionJNI.btAxisSweep3InternalShort_Edge_pos_set(this.swigCPtr, this, value);
        }

        public int getPos() {
            return CollisionJNI.btAxisSweep3InternalShort_Edge_pos_get(this.swigCPtr, this);
        }

        public void setHandle(int value) {
            CollisionJNI.btAxisSweep3InternalShort_Edge_handle_set(this.swigCPtr, this, value);
        }

        public int getHandle() {
            return CollisionJNI.btAxisSweep3InternalShort_Edge_handle_get(this.swigCPtr, this);
        }

        public int IsMax() {
            return CollisionJNI.btAxisSweep3InternalShort_Edge_IsMax(this.swigCPtr, this);
        }

        public Edge() {
            this(CollisionJNI.new_btAxisSweep3InternalShort_Edge(), true);
        }
    }
}

