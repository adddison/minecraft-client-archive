/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.btCollisionConfiguration;
import com.badlogic.gdx.physics.bullet.collision.btCollisionDispatcher;
import com.badlogic.gdx.physics.bullet.collision.btCollisionObject;

public class CustomCollisionDispatcher
extends btCollisionDispatcher {
    private long swigCPtr;

    protected CustomCollisionDispatcher(String className, long cPtr, boolean cMemoryOwn) {
        super(className, CollisionJNI.CustomCollisionDispatcher_SWIGUpcast(cPtr), cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public CustomCollisionDispatcher(long cPtr, boolean cMemoryOwn) {
        this("CustomCollisionDispatcher", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(CollisionJNI.CustomCollisionDispatcher_SWIGUpcast(this.swigCPtr), cMemoryOwn);
    }

    public static long getCPtr(CustomCollisionDispatcher obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_CustomCollisionDispatcher(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    protected void swigDirectorDisconnect() {
        this.swigCMemOwn = false;
        this.delete();
    }

    public void swigReleaseOwnership() {
        this.swigCMemOwn = false;
        CollisionJNI.CustomCollisionDispatcher_change_ownership(this, this.swigCPtr, false);
    }

    public void swigTakeOwnership() {
        this.swigCMemOwn = true;
        CollisionJNI.CustomCollisionDispatcher_change_ownership(this, this.swigCPtr, true);
    }

    public CustomCollisionDispatcher(btCollisionConfiguration collisionConfiguration) {
        this(CollisionJNI.new_CustomCollisionDispatcher(btCollisionConfiguration.getCPtr(collisionConfiguration), collisionConfiguration), true);
        CollisionJNI.CustomCollisionDispatcher_director_connect(this, this.swigCPtr, this.swigCMemOwn, true);
    }

    @Override
    public boolean needsCollision(btCollisionObject body0, btCollisionObject body1) {
        return this.getClass() == CustomCollisionDispatcher.class ? CollisionJNI.CustomCollisionDispatcher_needsCollision(this.swigCPtr, this, btCollisionObject.getCPtr(body0), body0, btCollisionObject.getCPtr(body1), body1) : CollisionJNI.CustomCollisionDispatcher_needsCollisionSwigExplicitCustomCollisionDispatcher(this.swigCPtr, this, btCollisionObject.getCPtr(body0), body0, btCollisionObject.getCPtr(body1), body1);
    }

    @Override
    public boolean needsResponse(btCollisionObject body0, btCollisionObject body1) {
        return this.getClass() == CustomCollisionDispatcher.class ? CollisionJNI.CustomCollisionDispatcher_needsResponse(this.swigCPtr, this, btCollisionObject.getCPtr(body0), body0, btCollisionObject.getCPtr(body1), body1) : CollisionJNI.CustomCollisionDispatcher_needsResponseSwigExplicitCustomCollisionDispatcher(this.swigCPtr, this, btCollisionObject.getCPtr(body0), body0, btCollisionObject.getCPtr(body1), body1);
    }
}

