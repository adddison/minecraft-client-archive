/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

import com.badlogic.gdx.physics.bullet.BulletBase;
import com.badlogic.gdx.physics.bullet.collision.CollisionJNI;
import com.badlogic.gdx.physics.bullet.collision.GIM_RSORT_TOKEN;

public class GIM_RSORT_TOKEN_COMPARATOR
extends BulletBase {
    private long swigCPtr;

    protected GIM_RSORT_TOKEN_COMPARATOR(String className, long cPtr, boolean cMemoryOwn) {
        super(className, cPtr, cMemoryOwn);
        this.swigCPtr = cPtr;
    }

    public GIM_RSORT_TOKEN_COMPARATOR(long cPtr, boolean cMemoryOwn) {
        this("GIM_RSORT_TOKEN_COMPARATOR", cPtr, cMemoryOwn);
        this.construct();
    }

    @Override
    protected void reset(long cPtr, boolean cMemoryOwn) {
        if (!this.destroyed) {
            this.destroy();
        }
        this.swigCPtr = cPtr;
        super.reset(this.swigCPtr, cMemoryOwn);
    }

    public static long getCPtr(GIM_RSORT_TOKEN_COMPARATOR obj) {
        return obj == null ? 0L : obj.swigCPtr;
    }

    @Override
    protected void finalize() throws Throwable {
        if (!this.destroyed) {
            this.destroy();
        }
        super.finalize();
    }

    @Override
    protected synchronized void delete() {
        if (this.swigCPtr != 0L) {
            if (this.swigCMemOwn) {
                this.swigCMemOwn = false;
                CollisionJNI.delete_GIM_RSORT_TOKEN_COMPARATOR(this.swigCPtr);
            }
            this.swigCPtr = 0L;
        }
        super.delete();
    }

    public int operatorFunctionCall(GIM_RSORT_TOKEN a, GIM_RSORT_TOKEN b) {
        return CollisionJNI.GIM_RSORT_TOKEN_COMPARATOR_operatorFunctionCall(this.swigCPtr, this, GIM_RSORT_TOKEN.getCPtr(a), a, GIM_RSORT_TOKEN.getCPtr(b), b);
    }

    public GIM_RSORT_TOKEN_COMPARATOR() {
        this(CollisionJNI.new_GIM_RSORT_TOKEN_COMPARATOR(), true);
    }
}

