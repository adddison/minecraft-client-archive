/*
 * Decompiled with CFR 0.150.
 */
package com.badlogic.gdx.physics.bullet.collision;

public final class GIM_SCALAR_TYPES {
    public static final int G_STYPE_REAL = 0;
    public static final int G_STYPE_REAL2 = 1;
    public static final int G_STYPE_SHORT = 2;
    public static final int G_STYPE_USHORT = 3;
    public static final int G_STYPE_INT = 4;
    public static final int G_STYPE_UINT = 5;
    public static final int G_STYPE_INT64 = 6;
    public static final int G_STYPE_UINT64 = 7;
}

