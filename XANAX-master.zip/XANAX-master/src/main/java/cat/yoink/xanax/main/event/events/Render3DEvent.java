package cat.yoink.xanax.main.event.events;

import cat.yoink.xanax.main.event.EventBase;

public final class Render3DEvent extends EventBase
{
}
