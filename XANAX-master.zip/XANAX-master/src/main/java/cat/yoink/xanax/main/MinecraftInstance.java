package cat.yoink.xanax.main;

import net.minecraft.client.Minecraft;

public interface MinecraftInstance
{
    Minecraft mc = Minecraft.getMinecraft();
}
