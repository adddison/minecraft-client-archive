package me.nathan.xerxes.module;

public enum Category {
	COMBAT, MOVEMENT, PLAYER, RENDER, MISC
}
