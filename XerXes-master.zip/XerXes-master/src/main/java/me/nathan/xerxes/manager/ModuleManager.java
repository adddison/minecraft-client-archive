package me.nathan.xerxes.manager;

import java.util.ArrayList;

import me.nathan.xerxes.module.Category;
import me.nathan.xerxes.module.Module;
import me.nathan.xerxes.module.render.ClickGUI;
import me.nathan.xerxes.module.render.HUD;
import me.nathan.xerxes.module.render.InfoDisplay;

public class ModuleManager {

	public static ArrayList<Module> modules;
	
	public ModuleManager() {
		(modules = new ArrayList<Module>()).clear();

		//COMBAT

		//MISC

		//MOVEMENT

		//PLAYER

		//RENDER
		this.modules.add(new ClickGUI());
		this.modules.add(new HUD());
		this.modules.add(new InfoDisplay());
	}
	
	public Module getModule(String name) {
		for (Module m : this.modules) {
			if (m.getName().equalsIgnoreCase(name)) {
				return m;
			}
		}
		return null;
	}
	
	public ArrayList<Module> getModuleList() {
		return this.modules;
	}
	
	public ArrayList<Module> getModulesInCategory(Category c) {
		ArrayList<Module> mods = new ArrayList<Module>();
		for (Module m : this.modules) {
			if (m.getCategory() == c) {
				mods.add(m);
			}
		}
		return mods;
	}
}
