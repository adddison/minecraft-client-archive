package me.nathan.xerxes.manager;

import java.util.ArrayList;
import java.util.List;

import me.nathan.xerxes.module.Module;
import me.nathan.xerxes.settings.Setting;

public class SettingsManager {

	public static ArrayList m = ModuleManager.modules;

	public static ArrayList<Setting> settings;

	public static List<Setting> getSettingList() {
		return settings;
	}

	public SettingsManager(){
		this.settings = new ArrayList<Setting>();
	}
	
	public void rSetting(Setting in){
		this.settings.add(in);
	}
	
	public ArrayList<Setting> getSettings(){
		return this.settings;
	}

	public ArrayList<Setting> getSettingsByMod(Module mod){
		ArrayList<Setting> out = new ArrayList<Setting>();
		for(Setting s : getSettings()){
			if(s.getParentMod().equals(mod)){
				out.add(s);
			}
		}
		if(out.isEmpty()){
			return null;
		}
		return out;
	}
	
	public Setting getSettingByName(Module mod, String name){
		for(Setting set : getSettings()){
			if(set.getName().equalsIgnoreCase(name) && set.getParentMod() == mod){
				return set;
			}
		}
		System.err.println("Setting not found! '" + name +"'!");
		return null;
	}

}