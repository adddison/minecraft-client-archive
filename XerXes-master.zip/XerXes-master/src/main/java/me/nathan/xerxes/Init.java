package me.nathan.xerxes;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

@Mod(modid = "xerxes", version = "b1.0")
public class Init {

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        xerxes.instance = new xerxes();
        xerxes.instance.init();
    }
}
