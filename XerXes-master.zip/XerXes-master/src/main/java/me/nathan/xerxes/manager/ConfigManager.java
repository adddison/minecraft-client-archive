/*package me.nathan.xerxes.manager;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import me.nathan.xerxes.module.Module;
import me.nathan.xerxes.settings.Setting;

public class Preset
{
    private String _displayName;
    private ConcurrentHashMap<String, ConcurrentHashMap<String, String>> _valueListMods = new ConcurrentHashMap<>();
    private boolean _active;

    public Preset(String displayName)
    {
        _displayName = displayName;
    }

    public void initNewPreset()
    {
        SettingsManager.m.forEach(mod ->
        {
            addModuleSettings((Module) mod);
        });
    }


   String key;
    public void addModuleSettings(final Module mod)
    {
        ConcurrentHashMap<String, String> valsMap = new ConcurrentHashMap<>();

        String key = String.valueOf(mod.getKey());

        valsMap.put("enabled", mod.isToggled() ? "true" : "false");
        valsMap.put("display", mod.getName());
        valsMap.put("keybind", key);
        valsMap.put("hidden",  mod.visible ? "true" : "false");

        SettingsManager.getSettingList().forEach(val ->
        {
            if (val.getValString() != null)
                valsMap.put(val.getName(), val.getValString().toString());
        });

        _valueListMods.put(mod.getName(), valsMap);

        save();
    }

    // this will load the settings for presets, and modules settings
    public void load(File directory)
    {
        File exists = new File("XerXes/Presets/" + directory.getName() + "/" + directory.getName() + ".json");
        if (!exists.exists())
            return;

        try
        {
            Gson gson = new Gson();

            Reader reader = Files.newBufferedReader(Paths.get("XerXes/Presets/" + directory.getName() + "/" + directory.getName() + ".json"));

            Map<?, ?> map = gson.fromJson(reader, Map.class);

            for (Map.Entry<?, ?> entry : map.entrySet())
            {
                String key = (String) entry.getKey();
                String val = (String) entry.getValue();

                if (key == "displayName")
                {
                    _displayName = val;
                    continue;
                }
            }

            reader.close();

        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }

        try (Stream<Path> paths = Files.walk(Paths.get("XerXes/Presets/" + directory.getName() + "/Modules/")))
        {
            paths
                    .filter(Files::isRegularFile)
                    .forEach(path ->
                    {
                        try
                        {
                            Gson gson = new Gson();

                            Reader reader = Files.newBufferedReader(Paths.get("XerXes/Presets/" + directory.getName() + "/Modules/" + path.getFileName().toString()));

                            Map<?, ?> map = gson.fromJson(reader, Map.class);

                            ConcurrentHashMap<String, String> valsMap = new ConcurrentHashMap<>();

                            for (Map.Entry<?, ?> entry : map.entrySet())
                            {
                                String key = (String) entry.getKey();
                                String val = (String) entry.getValue();

                                valsMap.put(key, val);
                            }

                            _valueListMods.put(path.getFileName().toString().substring(0, path.getFileName().toString().indexOf(".json")), valsMap);

                            reader.close();

                        }
                        catch (Exception ex)
                        {
                            ex.printStackTrace();
                        }
                    });
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    public void save()
    {
        try
        {
            GsonBuilder builder = new GsonBuilder();

            Gson gson = builder.setPrettyPrinting().create();

            Writer writer = Files.newBufferedWriter(Paths.get("XerXes/Presets/" + _displayName + "/" + _displayName + ".json"));
            Map<String, String> map = new HashMap<>();

            map.put("displayName", _displayName);
            gson.toJson(map, writer);
            writer.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        try
        {

            for (Entry<String, ConcurrentHashMap<String, String>> entry : _valueListMods.entrySet())
            {
                GsonBuilder builder = new GsonBuilder();

                Gson gson = builder.setPrettyPrinting().create();

                Writer writer = Files.newBufferedWriter(Paths.get("XerXes/Presets/" + _displayName + "/Modules/" + entry.getKey() + ".json"));
                Map<String, String> map = new HashMap<>();

                for (Entry<String, String> value : entry.getValue().entrySet())
                {
                    String key = (String)value.getKey();
                    String val = (String)value.getValue();

                    map.put(key, val);
                }
                gson.toJson(map, writer);
                writer.close();
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    public String getName()
    {
        return _displayName;
    }

    public boolean isActive()
    {
        return _active;
    }

    public void setActive(boolean b)
    {
        _active = b;
    }

    public void initValuesForMod(Module mod)
    {
        if (_valueListMods.containsKey(mod.getName().toString()))
        {
            for (Entry<String, String> value : _valueListMods.get(mod.getName().toString()).entrySet())
            {
                String l_Key = (String)value.getKey();
                String l_Value = (String)value.getValue();

                if (l_Key.equalsIgnoreCase("enabled"))
                {
                    if (l_Value.equalsIgnoreCase("true"))
                    {
                        if (!mod.isToggled())
                            mod.toggleNoSave();
                    }
                    else if (mod.isToggled())
                        mod.toggle();
                    continue;
                }

                if (l_Key.equalsIgnoreCase("display"))
                {
                    mod.getName() = l_Value;
                    continue;
                }

                if (l_Key.equalsIgnoreCase("keybind"))
                {
                    key = l_Value;
                    continue;
                }

                if (l_Key.equalsIgnoreCase("hidden"))
                {
                    mod.visible = l_Value.equalsIgnoreCase("true");
                    continue;
                }

                for (Setting l_Val : SettingsManager.getSettingList())
                {
                    if (l_Val.getName().equalsIgnoreCase((String) value.getKey()))
                    {
                        if (l_Val.get instanceof Number && !(l_Val.getValue() instanceof Enum))
                        {
                            if (l_Val.getValue() instanceof Integer)
                                l_Val.SetForcedValue(Integer.parseInt(l_Value));
                            else if (l_Val.getValue() instanceof Float)
                                l_Val.SetForcedValue(Float.parseFloat(l_Value));
                            else if (l_Val.getValue() instanceof Double)
                                l_Val.SetForcedValue(Double.parseDouble(l_Value));
                        }
                        else if (l_Val.getValue() instanceof Boolean)
                        {
                            l_Val.SetForcedValue(l_Value.equalsIgnoreCase("true"));
                        }
                        else if (l_Val.getValue() instanceof Enum)
                        {
                            Enum e = l_Val.GetEnumReal(l_Value);

                            if (e != null)
                                l_Val.SetForcedValue(e);
                        }
                        else if (l_Val.getValue() instanceof String)
                            l_Val.SetForcedValue(l_Value);

                        break;
                    }
                }
            }
        }
    }
}

 */