package me.nathan.xerxes.module.render;

import me.nathan.xerxes.xerxes;
import me.nathan.xerxes.manager.TickRateManager;
import me.nathan.xerxes.module.Category;
import me.nathan.xerxes.module.Module;
import me.nathan.xerxes.settings.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

import java.text.SimpleDateFormat;;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class InfoDisplay extends Module {

    private boolean tps;
    private boolean ping;
    private boolean fps;
    private boolean time;

    public InfoDisplay() {

        super("UIRenderer", "menu.skeet", Category.RENDER);
        this.setKey(Keyboard.KEY_NONE);

        xerxes.instance.settingsManager.rSetting(new Setting("Time", this, false));
        xerxes.instance.settingsManager.rSetting(new Setting("Fps", this, false));
        xerxes.instance.settingsManager.rSetting(new Setting("Tps", this, false));
        xerxes.instance.settingsManager.rSetting(new Setting("Ping", this, false));
    }

    //Generates tps text
    public static String generateTickRateText() {
        TickRateManager.TickRateData data = TickRateManager.getTickData();
        StringBuilder builderTickRate = new StringBuilder();

        TickRateManager.TickRateData.CalculationData point = data.getPoint();
        builderTickRate.append(String.format(
                "TPS: " + getColorTPS(point.getAverage()) + "%.2f" + TextFormatting.WHITE, point.getAverage()));

        return builderTickRate.toString();
    }

    //Generates fps text
    public static String generateFpsText() {
        return "FPS: " + String.format("%s", Minecraft.getDebugFPS());
    }

    //Ping Calculations
    static int client_ping = latencyCalc();

    private static int latencyCalc() {
        if (mc.getConnection() == null) {
            return 1;
        } else if (mc.player == null) {
            return -1;
        } else {
            try {

                // Returns the player's ping
                return client_ping = mc.getConnection().getPlayerInfo(mc.player.getUniqueID()).getResponseTime();
            } catch (NullPointerException ignored) {
            }
            return -1;
        }
    }

    //Generates ping text
    public static String generatePingText() {
        int ping = latencyCalc();
        return ("Ping: " + getColorPING(ping) + ping + TextFormatting.WHITE);
    }

    //Generates system time text
    public static String generateSystemTimeText() {
        String dateFormat = "HH:mm a";
        return new SimpleDateFormat(dateFormat).format(new Date());
    }

    @SubscribeEvent
    public void onRenderScreen(RenderGameOverlayEvent.Text event) {

         List<String> text = new ArrayList<>();
        if ( time = true) {
            text.add(generateSystemTimeText());
        }
        if (fps = true) {
            text.add(generateFpsText());
        }
        if (tps = true) {
            text.add(generateTickRateText());
        }
        if (ping = true) {
            text.add(generatePingText());
        }
        mc.fontRenderer.drawString(String.valueOf(text), 2, 2, 0xffffff, true);
    }

    private static String getColorTPS(double tps) {
        if (tps > 19D) return TextFormatting.DARK_GREEN.toString();
        if (tps > 16D) return TextFormatting.GREEN.toString();
        if (tps > 12) return TextFormatting.YELLOW.toString();
        if (tps > 8D) return TextFormatting.GOLD.toString();
        if (tps > 5D) return TextFormatting.RED.toString();
        if (tps > 2D) return TextFormatting.DARK_RED.toString();
        return TextFormatting.DARK_GRAY.toString();
    }

    private static String getColorPING(int ping) {
        if (ping > 19) return TextFormatting.DARK_GREEN.toString();
        if (ping > 16) return TextFormatting.GREEN.toString();
        if (ping > 12) return TextFormatting.YELLOW.toString();
        if (ping > 8) return TextFormatting.GOLD.toString();
        if (ping > 5) return TextFormatting.RED.toString();
        if (ping > 2) return TextFormatting.DARK_RED.toString();
        return TextFormatting.DARK_AQUA.toString();
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.updateVals();
    }

    public void updateVals() {
        Boolean time = xerxes.instance.settingsManager.getSettingByName(this, "Time").getValBoolean();
        Boolean fps = xerxes.instance.settingsManager.getSettingByName(this, "Fps").getValBoolean();
        Boolean tps = xerxes.instance.settingsManager.getSettingByName(this, "Tps").getValBoolean();
        Boolean ping = xerxes.instance.settingsManager.getSettingByName(this, "Ping").getValBoolean();
    }
}
