package com.invicta.api.hack;

/**
 * @author cookiedragon234 06/Dec/2019
 */
public enum HackCategory
{
	COMBAT()
}
