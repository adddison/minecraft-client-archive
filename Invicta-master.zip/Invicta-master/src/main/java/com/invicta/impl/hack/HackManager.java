package com.invicta.impl.hack;

/**
 * @author cookiedragon234 06/Dec/2019
 */
public class HackManager
{
	
	
	public static void init()
	{
	
	}
}
