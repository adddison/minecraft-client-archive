package dev.lors.bloodhack.mixin.client;

import net.minecraft.entity.player.EntityPlayer;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(EntityPlayer.class)
public class MixinEntityPlayer {
}
