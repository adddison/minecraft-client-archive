package dev.lors.bloodhack.module.BloodModules.movement;

import dev.lors.bloodhack.module.Category;
import dev.lors.bloodhack.module.Module;

public class NoFall extends Module {
  public NoFall() {
    super("NoFall", Category.MOVEMENT);
  }


}
