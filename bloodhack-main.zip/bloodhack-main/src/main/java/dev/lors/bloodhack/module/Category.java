package dev.lors.bloodhack.module;

public enum Category {
  COMBAT,
  MISC,
  MOVEMENT,
  RENDER,
  PLAYER,
  CHAT,
  HUD
}