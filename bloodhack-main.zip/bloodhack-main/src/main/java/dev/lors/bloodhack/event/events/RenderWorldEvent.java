package dev.lors.bloodhack.event.events;

import dev.lors.bloodhack.event.Event;

//Credit 086 - KAMI
public class RenderWorldEvent extends Event {

  public RenderWorldEvent() {
    super();

  }

}
