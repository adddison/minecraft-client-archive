package dev.lors.bloodhack.event.events;

import dev.lors.bloodhack.event.Event;

public class TickEvent extends Event {
}
