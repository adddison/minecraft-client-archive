package dev.lors.bloodhack.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.world.World;
import org.lwjgl.input.Keyboard;

public class Wrapper {

  final static Minecraft mc = Minecraft.getMinecraft();
  private static FontRenderer fontRenderer;

  public static Minecraft GetMC() {
    return mc;
  }

  public static EntityPlayerSP GetPlayer() {
    return mc.player;
  }

  public static Minecraft getMinecraft() {
    return Minecraft.getMinecraft();
  }

  public static EntityPlayerSP getPlayer() {
    return getMinecraft().player;
  }

  public static World getWorld() {
    return getMinecraft().world;
  }

  public static int getKey(String keyname) {
    return Keyboard.getKeyIndex(keyname.toUpperCase());
  }
}
