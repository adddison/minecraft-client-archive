package dev.lors.bloodhack.managers.friends;

public class Friends {
  public static boolean isFriend(String name) {
    return false;
  }

}
