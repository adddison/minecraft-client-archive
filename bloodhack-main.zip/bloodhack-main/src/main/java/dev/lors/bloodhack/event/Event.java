package dev.lors.bloodhack.event;

import me.zero.alpine.type.Cancellable;

public class Event extends Cancellable {

  public Event() {
  }
}