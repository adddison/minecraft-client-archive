package dev.lors.bloodhack.utils;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public class BlockUtils {
  private static final Minecraft mc = Minecraft.getMinecraft();
  public static List<Block> emptyBlocks;
  public static List<Block> rightclickableBlocks;

  public static boolean rayTracePlaceCheck(final BlockPos pos, final boolean shouldCheck, final float height) {
    return !shouldCheck || mc.world.rayTraceBlocks(new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ), new Vec3d(pos.getX(), pos.getY() + height, pos.getZ()), false, true, false) == null;
  }

  public static boolean rayTracePlaceCheck(final BlockPos pos, final boolean shouldCheck) {
    return rayTracePlaceCheck(pos, shouldCheck, 1.0f);
  }

  public static boolean canSeeBlock(final BlockPos p_Pos) {
    return mc.player != null && mc.world.rayTraceBlocks(new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ), new Vec3d(p_Pos.getX(), p_Pos.getY(), p_Pos.getZ()), false, true, false) == null;
  }

  public static void placeCrystalOnBlock(final BlockPos pos, final EnumHand hand) {
    final RayTraceResult result = mc.world.rayTraceBlocks(new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ), new Vec3d(pos.getX() + 0.5, pos.getY() - 0.5, pos.getZ() + 0.5));
    final EnumFacing facing = (result == null || result.sideHit == null) ? EnumFacing.UP : result.sideHit;
    mc.player.connection.sendPacket(new CPacketPlayerTryUseItemOnBlock(pos, facing, hand, 0.0f, 0.0f, 0.0f));
  }
}