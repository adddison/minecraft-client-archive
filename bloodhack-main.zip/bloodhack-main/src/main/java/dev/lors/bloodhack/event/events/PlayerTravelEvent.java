package dev.lors.bloodhack.event.events;

import dev.lors.bloodhack.event.Event;

public class PlayerTravelEvent extends Event {
  public PlayerTravelEvent() {
  }
}
