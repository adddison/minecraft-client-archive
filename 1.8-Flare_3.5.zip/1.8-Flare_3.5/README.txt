Flare 3.5 - By Gildfesh, KNOX and Aarow
	Cracked: July 18, 2015

IMPORTANT:
	- Delete the the "flare" directory in ".minecraft" if you crash!

Shout out to: Bibl

Info:
	- Obfuscator: Zelix KlassMaster - http://zelix.com/
	- Website: https://aarow.me/
	
Checksum info (1.8-Flare_3.5.jar):
	CRC32: 4C8A0E22
	CRC64: EFF43B7559A7E4F7
	SHA256: 6A6C248A4DEAB1B4A889DD9105EDB59A34A84060AD66393A7C494C481A9092C1
	SHA1: 4101886D53C13B8825A7480456B1B8E2DDCBED6E

Anime (airing):
	- Gangsta.
	- Ore Monogatari!!
	- Overlord
	- Charlotte
	
-------------------------------------------------
People:
	- Lone
	- Ayzhin
	- Itami
	- 

Find us at: http://hentaiandecchi.ayzhin.com/

We have a forum!: http://hentaiandecchi.ayzhin.com/forums/

About us: http://hentaiandecchi.ayzhin.com/about/

-------------------------------------------------

HEY! THIS IS IMPORTANT

| | | | | | | | | | | |
V V V V V V V V V V V V

Prerequisites:
	Software:
		- Java 8
		- Minecraft
		- WinRAR, unrar
		- 7zip, p7zip
		- unzip

FAQ:
	- No we cannot crack a client that we don't have. Thank you for asking.
	- We distribute our releases in "RAR", "7z", "tar.xz", "zip"!
	- If you have a problem be check your Java version first
		You should preferably use Java with version 8 support because it has the best compatibility with modern Java programs
	- GL15 function not supported:
		Your video card is too old, or needs updated drivers. Please use a modern video card with OpenGL 2.1 or higher.
	- Client does not show up in "Use Version"
		1) Check if the archive was extracted properly.
		2) Make sure the folder name is the same as in the JSON file.
			- id": "some client"
	- Client crashes and/or doesn't start.
		Please post or PM the ENTIRE crash log!
	- Client closes without crash log.
		Contact lonephenom.
	- All published cracks (usually) have had all authentication and IRC connections removed.
		Note: Harmless connections are still active.
		Also if we are lazy the bytecode for these connections are still in there for you to inspect.
	- Sometimes the cracker misses a kill switch or a check.
		If this is the case report this on the thread and contact lonephenom.
	- Why don't you release cracks more frequently?
		1) If nobody has given us the program so we can't crack it.
		2) We don't have time at the moment.
		3) A new form of obfuscation makes it difficult to crack the code.
		4) We are busy watching Chinese cartoons.
		5) Noooo body gives a shit
		6) We have vulnerable white girls to exploit.
		7) Long live the queen! (RIP)
		8) ALLAHU AKBAR!
		9) Too high on the SUGOI scale
		10) wingdings right up in that bitch
		11) ayy lmao
		12) "I'm on a mission"
		13) "I fucking hate her when she doesn't fucking tell me what's wrong fuck fuck fuck n3xuz help me with my waifu problems."

How to install:

	Windows:
	- Hold down "Windows" key and press "R"
	- Type %appdata%\.minecraft\versions

	OSX:
	- Go to ~/Library/Application Support/minecraft/versions

	Linux:
	- Go to ~/.minecraft/versions
	
	How to extract:
	- Extract archive into a folder
		- The versions folder should look like so:
			/client/client.jar
			/client/client.json
		
	How to switch profiles:
		- Open Minecraft Launcher
		- Press "Edit Profile" in the bottom left
		- Select "Use Version" and find the client name
		- Press "Save Profile" and press "Play"
		
	If the profile doesn't show up check the JSON file for the "name" tag and correct it if necessary.